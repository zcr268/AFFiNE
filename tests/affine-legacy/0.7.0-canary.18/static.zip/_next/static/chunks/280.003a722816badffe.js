(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[280],{1297:function(e,t,i){var n=i(48834).lW,o=i(34406);e.exports=(function e(t,i,n){function o(a,s){if(!i[a]){if(!t[a]){if(r)return r(a,!0);var l=Error("Cannot find module '"+a+"'");throw l.code="MODULE_NOT_FOUND",l}var d=i[a]={exports:{}};t[a][0].call(d.exports,function(e){return o(t[a][1][e]||e)},d,d.exports,e,t,i,n)}return i[a].exports}for(var r=void 0,a=0;a<n.length;a++)o(n[a]);return o})({1:[function(e,t,i){"use strict";var n=e("./utils"),o=e("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";i.encode=function(e){for(var t,i,o,a,s,l,d,c=[],h=0,u=e.length,f=u,p="string"!==n.getTypeOf(e);h<e.length;)f=u-h,o=p?(t=e[h++],i=h<u?e[h++]:0,h<u?e[h++]:0):(t=e.charCodeAt(h++),i=h<u?e.charCodeAt(h++):0,h<u?e.charCodeAt(h++):0),a=t>>2,s=(3&t)<<4|i>>4,l=1<f?(15&i)<<2|o>>6:64,d=2<f?63&o:64,c.push(r.charAt(a)+r.charAt(s)+r.charAt(l)+r.charAt(d));return c.join("")},i.decode=function(e){var t,i,n,a,s,l,d=0,c=0,h="data:";if(e.substr(0,h.length)===h)throw Error("Invalid base64 input, it looks like a data url.");var u,f=3*(e=e.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(e.charAt(e.length-1)===r.charAt(64)&&f--,e.charAt(e.length-2)===r.charAt(64)&&f--,f%1!=0)throw Error("Invalid base64 input, bad content length.");for(u=o.uint8array?new Uint8Array(0|f):Array(0|f);d<e.length;)t=r.indexOf(e.charAt(d++))<<2|(a=r.indexOf(e.charAt(d++)))>>4,i=(15&a)<<4|(s=r.indexOf(e.charAt(d++)))>>2,n=(3&s)<<6|(l=r.indexOf(e.charAt(d++))),u[c++]=t,64!==s&&(u[c++]=i),64!==l&&(u[c++]=n);return u}},{"./support":30,"./utils":32}],2:[function(e,t,i){"use strict";var n=e("./external"),o=e("./stream/DataWorker"),r=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function s(e,t,i,n,o){this.compressedSize=e,this.uncompressedSize=t,this.crc32=i,this.compression=n,this.compressedContent=o}s.prototype={getContentWorker:function(){var e=new o(n.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),t=this;return e.on("end",function(){if(this.streamInfo.data_length!==t.uncompressedSize)throw Error("Bug : uncompressed data size mismatch")}),e},getCompressedWorker:function(){return new o(n.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},s.createWorkerFrom=function(e,t,i){return e.pipe(new r).pipe(new a("uncompressedSize")).pipe(t.compressWorker(i)).pipe(new a("compressedSize")).withStreamInfo("compression",t)},t.exports=s},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,t,i){"use strict";var n=e("./stream/GenericWorker");i.STORE={magic:"\x00\x00",compressWorker:function(){return new n("STORE compression")},uncompressWorker:function(){return new n("STORE decompression")}},i.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,t,i){"use strict";var n=e("./utils"),o=function(){for(var e,t=[],i=0;i<256;i++){e=i;for(var n=0;n<8;n++)e=1&e?3988292384^e>>>1:e>>>1;t[i]=e}return t}();t.exports=function(e,t){return void 0!==e&&e.length?"string"!==n.getTypeOf(e)?function(e,t,i,n){var r=n+i;e^=-1;for(var a=n;a<r;a++)e=e>>>8^o[255&(e^t[a])];return -1^e}(0|t,e,e.length,0):function(e,t,i,n){var r=n+i;e^=-1;for(var a=n;a<r;a++)e=e>>>8^o[255&(e^t.charCodeAt(a))];return -1^e}(0|t,e,e.length,0):0}},{"./utils":32}],5:[function(e,t,i){"use strict";i.base64=!1,i.binary=!1,i.dir=!1,i.createFolders=!0,i.date=null,i.compression=null,i.compressionOptions=null,i.comment=null,i.unixPermissions=null,i.dosPermissions=null},{}],6:[function(e,t,i){"use strict";var n=null;n="undefined"!=typeof Promise?Promise:e("lie"),t.exports={Promise:n}},{lie:37}],7:[function(e,t,i){"use strict";var n="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Uint32Array,o=e("pako"),r=e("./utils"),a=e("./stream/GenericWorker"),s=n?"uint8array":"array";function l(e,t){a.call(this,"FlateWorker/"+e),this._pako=null,this._pakoAction=e,this._pakoOptions=t,this.meta={}}i.magic="\b\x00",r.inherits(l,a),l.prototype.processChunk=function(e){this.meta=e.meta,null===this._pako&&this._createPako(),this._pako.push(r.transformTo(s,e.data),!1)},l.prototype.flush=function(){a.prototype.flush.call(this),null===this._pako&&this._createPako(),this._pako.push([],!0)},l.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},l.prototype._createPako=function(){this._pako=new o[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var e=this;this._pako.onData=function(t){e.push({data:t,meta:e.meta})}},i.compressWorker=function(e){return new l("Deflate",e)},i.uncompressWorker=function(){return new l("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,t,i){"use strict";function n(e,t){var i,n="";for(i=0;i<t;i++)n+=String.fromCharCode(255&e),e>>>=8;return n}function o(e,t,i,o,a,c){var h,u,f,p,g=e.file,m=e.compression,v=c!==s.utf8encode,b=r.transformTo("string",c(g.name)),C=r.transformTo("string",s.utf8encode(g.name)),y=g.comment,x=r.transformTo("string",c(y)),w=r.transformTo("string",s.utf8encode(y)),_=C.length!==g.name.length,k=w.length!==y.length,M="",S="",E="",L=g.dir,$=g.date,P={crc32:0,compressedSize:0,uncompressedSize:0};t&&!i||(P.crc32=e.crc32,P.compressedSize=e.compressedSize,P.uncompressedSize=e.uncompressedSize);var B=0;t&&(B|=8),!v&&(_||k)&&(B|=2048);var R=0,T=0;L&&(R|=16),"UNIX"===a?(T=798,R|=(u=h=g.unixPermissions,h||(u=L?16893:33204),(65535&u)<<16)):(T=20,R|=63&(g.dosPermissions||0)),f=($.getUTCHours()<<6|$.getUTCMinutes())<<5|$.getUTCSeconds()/2,p=($.getUTCFullYear()-1980<<4|$.getUTCMonth()+1)<<5|$.getUTCDate(),_&&(S=n(1,1)+n(l(b),4)+C,M+="up"+n(S.length,2)+S),k&&(E=n(1,1)+n(l(x),4)+w,M+="uc"+n(E.length,2)+E);var O="";return O+="\n\x00"+n(B,2)+m.magic+n(f,2)+n(p,2)+n(P.crc32,4)+n(P.compressedSize,4)+n(P.uncompressedSize,4)+n(b.length,2)+n(M.length,2),{fileRecord:d.LOCAL_FILE_HEADER+O+b+M,dirRecord:d.CENTRAL_FILE_HEADER+n(T,2)+O+n(x.length,2)+"\x00\x00\x00\x00"+n(R,4)+n(o,4)+b+M+x}}var r=e("../utils"),a=e("../stream/GenericWorker"),s=e("../utf8"),l=e("../crc32"),d=e("../signature");function c(e,t,i,n){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=t,this.zipPlatform=i,this.encodeFileName=n,this.streamFiles=e,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(c,a),c.prototype.push=function(e){var t=e.meta.percent||0,i=this.entriesCount,n=this._sources.length;this.accumulate?this.contentBuffer.push(e):(this.bytesWritten+=e.data.length,a.prototype.push.call(this,{data:e.data,meta:{currentFile:this.currentFile,percent:i?(t+100*(i-n-1))/i:100}}))},c.prototype.openedSource=function(e){this.currentSourceOffset=this.bytesWritten,this.currentFile=e.file.name;var t=this.streamFiles&&!e.file.dir;if(t){var i=o(e,t,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:i.fileRecord,meta:{percent:0}})}else this.accumulate=!0},c.prototype.closedSource=function(e){this.accumulate=!1;var t=this.streamFiles&&!e.file.dir,i=o(e,t,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(i.dirRecord),t)this.push({data:d.DATA_DESCRIPTOR+n(e.crc32,4)+n(e.compressedSize,4)+n(e.uncompressedSize,4),meta:{percent:100}});else for(this.push({data:i.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},c.prototype.flush=function(){for(var e,t,i,o,a=this.bytesWritten,s=0;s<this.dirRecords.length;s++)this.push({data:this.dirRecords[s],meta:{percent:100}});var l=this.bytesWritten-a,c=(e=this.dirRecords.length,t=this.zipComment,i=this.encodeFileName,o=r.transformTo("string",i(t)),d.CENTRAL_DIRECTORY_END+"\x00\x00\x00\x00"+n(e,2)+n(e,2)+n(l,4)+n(a,4)+n(o.length,2)+o);this.push({data:c,meta:{percent:100}})},c.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},c.prototype.registerPrevious=function(e){this._sources.push(e);var t=this;return e.on("data",function(e){t.processChunk(e)}),e.on("end",function(){t.closedSource(t.previous.streamInfo),t._sources.length?t.prepareNextSource():t.end()}),e.on("error",function(e){t.error(e)}),this},c.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},c.prototype.error=function(e){var t=this._sources;if(!a.prototype.error.call(this,e))return!1;for(var i=0;i<t.length;i++)try{t[i].error(e)}catch(e){}return!0},c.prototype.lock=function(){a.prototype.lock.call(this);for(var e=this._sources,t=0;t<e.length;t++)e[t].lock()},t.exports=c},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,t,i){"use strict";var n=e("../compressions"),o=e("./ZipFileWorker");i.generateWorker=function(e,t,i){var r=new o(t.streamFiles,i,t.platform,t.encodeFileName),a=0;try{e.forEach(function(e,i){a++;var o=function(e,t){var i=e||t,o=n[i];if(!o)throw Error(i+" is not a valid compression method !");return o}(i.options.compression,t.compression),s=i.options.compressionOptions||t.compressionOptions||{},l=i.dir,d=i.date;i._compressWorker(o,s).withStreamInfo("file",{name:e,dir:l,date:d,comment:i.comment||"",unixPermissions:i.unixPermissions,dosPermissions:i.dosPermissions}).pipe(r)}),r.entriesCount=a}catch(e){r.error(e)}return r}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,t,i){"use strict";function n(){if(!(this instanceof n))return new n;if(arguments.length)throw Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var e=new n;for(var t in this)"function"!=typeof this[t]&&(e[t]=this[t]);return e}}(n.prototype=e("./object")).loadAsync=e("./load"),n.support=e("./support"),n.defaults=e("./defaults"),n.version="3.10.1",n.loadAsync=function(e,t){return(new n).loadAsync(e,t)},n.external=e("./external"),t.exports=n},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,t,i){"use strict";var n=e("./utils"),o=e("./external"),r=e("./utf8"),a=e("./zipEntries"),s=e("./stream/Crc32Probe"),l=e("./nodejsUtils");t.exports=function(e,t){var i=this;return t=n.extend(t||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),l.isNode&&l.isStream(e)?o.Promise.reject(Error("JSZip can't accept a stream when loading a zip file.")):n.prepareContent("the loaded zip file",e,!0,t.optimizedBinaryString,t.base64).then(function(e){var i=new a(t);return i.load(e),i}).then(function(e){var i=[o.Promise.resolve(e)],n=e.files;if(t.checkCRC32)for(var r=0;r<n.length;r++)i.push(function(e){return new o.Promise(function(t,i){var n=e.decompressed.getContentWorker().pipe(new s);n.on("error",function(e){i(e)}).on("end",function(){n.streamInfo.crc32!==e.decompressed.crc32?i(Error("Corrupted zip : CRC32 mismatch")):t()}).resume()})}(n[r]));return o.Promise.all(i)}).then(function(e){for(var o=e.shift(),r=o.files,a=0;a<r.length;a++){var s=r[a],l=s.fileNameStr,d=n.resolve(s.fileNameStr);i.file(d,s.decompressed,{binary:!0,optimizedBinaryString:!0,date:s.date,dir:s.dir,comment:s.fileCommentStr.length?s.fileCommentStr:null,unixPermissions:s.unixPermissions,dosPermissions:s.dosPermissions,createFolders:t.createFolders}),s.dir||(i.file(d).unsafeOriginalName=l)}return o.zipComment.length&&(i.comment=o.zipComment),i})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,t,i){"use strict";var n=e("../utils"),o=e("../stream/GenericWorker");function r(e,t){o.call(this,"Nodejs stream input adapter for "+e),this._upstreamEnded=!1,this._bindStream(t)}n.inherits(r,o),r.prototype._bindStream=function(e){var t=this;(this._stream=e).pause(),e.on("data",function(e){t.push({data:e,meta:{percent:0}})}).on("error",function(e){t.isPaused?this.generatedError=e:t.error(e)}).on("end",function(){t.isPaused?t._upstreamEnded=!0:t.end()})},r.prototype.pause=function(){return!!o.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!o.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},t.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,t,i){"use strict";var n=e("readable-stream").Readable;function o(e,t,i){n.call(this,t),this._helper=e;var o=this;e.on("data",function(e,t){o.push(e)||o._helper.pause(),i&&i(t)}).on("error",function(e){o.emit("error",e)}).on("end",function(){o.push(null)})}e("../utils").inherits(o,n),o.prototype._read=function(){this._helper.resume()},t.exports=o},{"../utils":32,"readable-stream":16}],14:[function(e,t,i){"use strict";t.exports={isNode:void 0!==n,newBufferFrom:function(e,t){if(n.from&&n.from!==Uint8Array.from)return n.from(e,t);if("number"==typeof e)throw Error('The "data" argument must not be a number');return new n(e,t)},allocBuffer:function(e){if(n.alloc)return n.alloc(e);var t=new n(e);return t.fill(0),t},isBuffer:function(e){return n.isBuffer(e)},isStream:function(e){return e&&"function"==typeof e.on&&"function"==typeof e.pause&&"function"==typeof e.resume}}},{}],15:[function(e,t,i){"use strict";function n(e,t,i){var n,o=r.getTypeOf(t),s=r.extend(i||{},l);s.date=s.date||new Date,null!==s.compression&&(s.compression=s.compression.toUpperCase()),"string"==typeof s.unixPermissions&&(s.unixPermissions=parseInt(s.unixPermissions,8)),s.unixPermissions&&16384&s.unixPermissions&&(s.dir=!0),s.dosPermissions&&16&s.dosPermissions&&(s.dir=!0),s.dir&&(e=g(e)),s.createFolders&&(n=p(e))&&m.call(this,n,!0);var h="string"===o&&!1===s.binary&&!1===s.base64;i&&void 0!==i.binary||(s.binary=!h),(t instanceof d&&0===t.uncompressedSize||s.dir||!t||0===t.length)&&(s.base64=!1,s.binary=!0,t="",s.compression="STORE",o="string");var v=null;v=t instanceof d||t instanceof a?t:u.isNode&&u.isStream(t)?new f(e,t):r.prepareContent(e,t,s.binary,s.optimizedBinaryString,s.base64);var b=new c(e,v,s);this.files[e]=b}var o=e("./utf8"),r=e("./utils"),a=e("./stream/GenericWorker"),s=e("./stream/StreamHelper"),l=e("./defaults"),d=e("./compressedObject"),c=e("./zipObject"),h=e("./generate"),u=e("./nodejsUtils"),f=e("./nodejs/NodejsStreamInputAdapter"),p=function(e){"/"===e.slice(-1)&&(e=e.substring(0,e.length-1));var t=e.lastIndexOf("/");return 0<t?e.substring(0,t):""},g=function(e){return"/"!==e.slice(-1)&&(e+="/"),e},m=function(e,t){return t=void 0!==t?t:l.createFolders,e=g(e),this.files[e]||n.call(this,e,null,{dir:!0,createFolders:t}),this.files[e]};function v(e){return"[object RegExp]"===Object.prototype.toString.call(e)}t.exports={load:function(){throw Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(e){var t,i,n;for(t in this.files)n=this.files[t],(i=t.slice(this.root.length,t.length))&&t.slice(0,this.root.length)===this.root&&e(i,n)},filter:function(e){var t=[];return this.forEach(function(i,n){e(i,n)&&t.push(n)}),t},file:function(e,t,i){if(1!=arguments.length)return e=this.root+e,n.call(this,e,t,i),this;if(v(e)){var o=e;return this.filter(function(e,t){return!t.dir&&o.test(e)})}var r=this.files[this.root+e];return r&&!r.dir?r:null},folder:function(e){if(!e)return this;if(v(e))return this.filter(function(t,i){return i.dir&&e.test(t)});var t=this.root+e,i=m.call(this,t),n=this.clone();return n.root=i.name,n},remove:function(e){e=this.root+e;var t=this.files[e];if(t||("/"!==e.slice(-1)&&(e+="/"),t=this.files[e]),t&&!t.dir)delete this.files[e];else for(var i=this.filter(function(t,i){return i.name.slice(0,e.length)===e}),n=0;n<i.length;n++)delete this.files[i[n].name];return this},generate:function(){throw Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(e){var t,i={};try{if((i=r.extend(e||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:o.utf8encode})).type=i.type.toLowerCase(),i.compression=i.compression.toUpperCase(),"binarystring"===i.type&&(i.type="string"),!i.type)throw Error("No output type specified.");r.checkSupport(i.type),"darwin"!==i.platform&&"freebsd"!==i.platform&&"linux"!==i.platform&&"sunos"!==i.platform||(i.platform="UNIX"),"win32"===i.platform&&(i.platform="DOS");var n=i.comment||this.comment||"";t=h.generateWorker(this,i,n)}catch(e){(t=new a("error")).error(e)}return new s(t,i.type||"string",i.mimeType)},generateAsync:function(e,t){return this.generateInternalStream(e).accumulate(t)},generateNodeStream:function(e,t){return(e=e||{}).type||(e.type="nodebuffer"),this.generateInternalStream(e).toNodejsStream(t)}}},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,t,i){"use strict";t.exports=e("stream")},{stream:void 0}],17:[function(e,t,i){"use strict";var n=e("./DataReader");function o(e){n.call(this,e);for(var t=0;t<this.data.length;t++)e[t]=255&e[t]}e("../utils").inherits(o,n),o.prototype.byteAt=function(e){return this.data[this.zero+e]},o.prototype.lastIndexOfSignature=function(e){for(var t=e.charCodeAt(0),i=e.charCodeAt(1),n=e.charCodeAt(2),o=e.charCodeAt(3),r=this.length-4;0<=r;--r)if(this.data[r]===t&&this.data[r+1]===i&&this.data[r+2]===n&&this.data[r+3]===o)return r-this.zero;return -1},o.prototype.readAndCheckSignature=function(e){var t=e.charCodeAt(0),i=e.charCodeAt(1),n=e.charCodeAt(2),o=e.charCodeAt(3),r=this.readData(4);return t===r[0]&&i===r[1]&&n===r[2]&&o===r[3]},o.prototype.readData=function(e){if(this.checkOffset(e),0===e)return[];var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=o},{"../utils":32,"./DataReader":18}],18:[function(e,t,i){"use strict";var n=e("../utils");function o(e){this.data=e,this.length=e.length,this.index=0,this.zero=0}o.prototype={checkOffset:function(e){this.checkIndex(this.index+e)},checkIndex:function(e){if(this.length<this.zero+e||e<0)throw Error("End of data reached (data length = "+this.length+", asked index = "+e+"). Corrupted zip ?")},setIndex:function(e){this.checkIndex(e),this.index=e},skip:function(e){this.setIndex(this.index+e)},byteAt:function(){},readInt:function(e){var t,i=0;for(this.checkOffset(e),t=this.index+e-1;t>=this.index;t--)i=(i<<8)+this.byteAt(t);return this.index+=e,i},readString:function(e){return n.transformTo("string",this.readData(e))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var e=this.readInt(4);return new Date(Date.UTC(1980+(e>>25&127),(e>>21&15)-1,e>>16&31,e>>11&31,e>>5&63,(31&e)<<1))}},t.exports=o},{"../utils":32}],19:[function(e,t,i){"use strict";var n=e("./Uint8ArrayReader");function o(e){n.call(this,e)}e("../utils").inherits(o,n),o.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=o},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,t,i){"use strict";var n=e("./DataReader");function o(e){n.call(this,e)}e("../utils").inherits(o,n),o.prototype.byteAt=function(e){return this.data.charCodeAt(this.zero+e)},o.prototype.lastIndexOfSignature=function(e){return this.data.lastIndexOf(e)-this.zero},o.prototype.readAndCheckSignature=function(e){return e===this.readData(4)},o.prototype.readData=function(e){this.checkOffset(e);var t=this.data.slice(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=o},{"../utils":32,"./DataReader":18}],21:[function(e,t,i){"use strict";var n=e("./ArrayReader");function o(e){n.call(this,e)}e("../utils").inherits(o,n),o.prototype.readData=function(e){if(this.checkOffset(e),0===e)return new Uint8Array(0);var t=this.data.subarray(this.zero+this.index,this.zero+this.index+e);return this.index+=e,t},t.exports=o},{"../utils":32,"./ArrayReader":17}],22:[function(e,t,i){"use strict";var n=e("../utils"),o=e("../support"),r=e("./ArrayReader"),a=e("./StringReader"),s=e("./NodeBufferReader"),l=e("./Uint8ArrayReader");t.exports=function(e){var t=n.getTypeOf(e);return n.checkSupport(t),"string"!==t||o.uint8array?"nodebuffer"===t?new s(e):o.uint8array?new l(n.transformTo("uint8array",e)):new r(n.transformTo("array",e)):new a(e)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,t,i){"use strict";i.LOCAL_FILE_HEADER="PK\x03\x04",i.CENTRAL_FILE_HEADER="PK\x01\x02",i.CENTRAL_DIRECTORY_END="PK\x05\x06",i.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x06\x07",i.ZIP64_CENTRAL_DIRECTORY_END="PK\x06\x06",i.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,t,i){"use strict";var n=e("./GenericWorker"),o=e("../utils");function r(e){n.call(this,"ConvertWorker to "+e),this.destType=e}o.inherits(r,n),r.prototype.processChunk=function(e){this.push({data:o.transformTo(this.destType,e.data),meta:e.meta})},t.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(e,t,i){"use strict";var n=e("./GenericWorker"),o=e("../crc32");function r(){n.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(r,n),r.prototype.processChunk=function(e){this.streamInfo.crc32=o(e.data,this.streamInfo.crc32||0),this.push(e)},t.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,t,i){"use strict";var n=e("../utils"),o=e("./GenericWorker");function r(e){o.call(this,"DataLengthProbe for "+e),this.propName=e,this.withStreamInfo(e,0)}n.inherits(r,o),r.prototype.processChunk=function(e){if(e){var t=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=t+e.data.length}o.prototype.processChunk.call(this,e)},t.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(e,t,i){"use strict";var n=e("../utils"),o=e("./GenericWorker");function r(e){o.call(this,"DataWorker");var t=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,e.then(function(e){t.dataIsReady=!0,t.data=e,t.max=e&&e.length||0,t.type=n.getTypeOf(e),t.isPaused||t._tickAndRepeat()},function(e){t.error(e)})}n.inherits(r,o),r.prototype.cleanUp=function(){o.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!o.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,n.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(n.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var e=null,t=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":e=this.data.substring(this.index,t);break;case"uint8array":e=this.data.subarray(this.index,t);break;case"array":case"nodebuffer":e=this.data.slice(this.index,t)}return this.index=t,this.push({data:e,meta:{percent:this.max?this.index/this.max*100:0}})},t.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(e,t,i){"use strict";function n(e){this.name=e||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}n.prototype={push:function(e){this.emit("data",e)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(e){this.emit("error",e)}return!0},error:function(e){return!this.isFinished&&(this.isPaused?this.generatedError=e:(this.isFinished=!0,this.emit("error",e),this.previous&&this.previous.error(e),this.cleanUp()),!0)},on:function(e,t){return this._listeners[e].push(t),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(e,t){if(this._listeners[e])for(var i=0;i<this._listeners[e].length;i++)this._listeners[e][i].call(this,t)},pipe:function(e){return e.registerPrevious(this)},registerPrevious:function(e){if(this.isLocked)throw Error("The stream '"+this+"' has already been used.");this.streamInfo=e.streamInfo,this.mergeStreamInfo(),this.previous=e;var t=this;return e.on("data",function(e){t.processChunk(e)}),e.on("end",function(){t.end()}),e.on("error",function(e){t.error(e)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var e=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),e=!0),this.previous&&this.previous.resume(),!e},flush:function(){},processChunk:function(e){this.push(e)},withStreamInfo:function(e,t){return this.extraStreamInfo[e]=t,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var e in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,e)&&(this.streamInfo[e]=this.extraStreamInfo[e])},lock:function(){if(this.isLocked)throw Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var e="Worker "+this.name;return this.previous?this.previous+" -> "+e:e}},t.exports=n},{}],29:[function(e,t,i){"use strict";var o=e("../utils"),r=e("./ConvertWorker"),a=e("./GenericWorker"),s=e("../base64"),l=e("../support"),d=e("../external"),c=null;if(l.nodestream)try{c=e("../nodejs/NodejsStreamOutputAdapter")}catch(e){}function h(e,t,i){var n=t;switch(t){case"blob":case"arraybuffer":n="uint8array";break;case"base64":n="string"}try{this._internalType=n,this._outputType=t,this._mimeType=i,o.checkSupport(n),this._worker=e.pipe(new r(n)),e.lock()}catch(e){this._worker=new a("error"),this._worker.error(e)}}h.prototype={accumulate:function(e){var t;return t=this,new d.Promise(function(i,r){var a=[],l=t._internalType,d=t._outputType,c=t._mimeType;t.on("data",function(t,i){a.push(t),e&&e(i)}).on("error",function(e){a=[],r(e)}).on("end",function(){try{var e=function(e,t,i){switch(e){case"blob":return o.newBlob(o.transformTo("arraybuffer",t),i);case"base64":return s.encode(t);default:return o.transformTo(e,t)}}(d,function(e,t){var i,o=0,r=null,a=0;for(i=0;i<t.length;i++)a+=t[i].length;switch(e){case"string":return t.join("");case"array":return Array.prototype.concat.apply([],t);case"uint8array":for(r=new Uint8Array(a),i=0;i<t.length;i++)r.set(t[i],o),o+=t[i].length;return r;case"nodebuffer":return n.concat(t);default:throw Error("concat : unsupported type '"+e+"'")}}(l,a),c);i(e)}catch(e){r(e)}a=[]}).resume()})},on:function(e,t){var i=this;return"data"===e?this._worker.on(e,function(e){t.call(i,e.data,e.meta)}):this._worker.on(e,function(){o.delay(t,arguments,i)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(e){if(o.checkSupport("nodestream"),"nodebuffer"!==this._outputType)throw Error(this._outputType+" is not supported by this method");return new c(this,{objectMode:"nodebuffer"!==this._outputType},e)}},t.exports=h},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,t,i){"use strict";if(i.base64=!0,i.array=!0,i.string=!0,i.arraybuffer="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof Uint8Array,i.nodebuffer=void 0!==n,i.uint8array="undefined"!=typeof Uint8Array,"undefined"==typeof ArrayBuffer)i.blob=!1;else{var o=new ArrayBuffer(0);try{i.blob=0===new Blob([o],{type:"application/zip"}).size}catch(e){try{var r=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);r.append(o),i.blob=0===r.getBlob("application/zip").size}catch(e){i.blob=!1}}}try{i.nodestream=!!e("readable-stream").Readable}catch(e){i.nodestream=!1}},{"readable-stream":16}],31:[function(e,t,i){"use strict";for(var n=e("./utils"),o=e("./support"),r=e("./nodejsUtils"),a=e("./stream/GenericWorker"),s=Array(256),l=0;l<256;l++)s[l]=252<=l?6:248<=l?5:240<=l?4:224<=l?3:192<=l?2:1;function d(){a.call(this,"utf-8 decode"),this.leftOver=null}function c(){a.call(this,"utf-8 encode")}s[254]=s[254]=1,i.utf8encode=function(e){return o.nodebuffer?r.newBufferFrom(e,"utf-8"):function(e){var t,i,n,r,a,s=e.length,l=0;for(r=0;r<s;r++)55296==(64512&(i=e.charCodeAt(r)))&&r+1<s&&56320==(64512&(n=e.charCodeAt(r+1)))&&(i=65536+(i-55296<<10)+(n-56320),r++),l+=i<128?1:i<2048?2:i<65536?3:4;for(t=o.uint8array?new Uint8Array(l):Array(l),r=a=0;a<l;r++)55296==(64512&(i=e.charCodeAt(r)))&&r+1<s&&56320==(64512&(n=e.charCodeAt(r+1)))&&(i=65536+(i-55296<<10)+(n-56320),r++),i<128?t[a++]=i:(i<2048?t[a++]=192|i>>>6:(i<65536?t[a++]=224|i>>>12:(t[a++]=240|i>>>18,t[a++]=128|i>>>12&63),t[a++]=128|i>>>6&63),t[a++]=128|63&i);return t}(e)},i.utf8decode=function(e){return o.nodebuffer?n.transformTo("nodebuffer",e).toString("utf-8"):function(e){var t,i,o,r,a=e.length,l=Array(2*a);for(t=i=0;t<a;)if((o=e[t++])<128)l[i++]=o;else if(4<(r=s[o]))l[i++]=65533,t+=r-1;else{for(o&=2===r?31:3===r?15:7;1<r&&t<a;)o=o<<6|63&e[t++],r--;1<r?l[i++]=65533:o<65536?l[i++]=o:(o-=65536,l[i++]=55296|o>>10&1023,l[i++]=56320|1023&o)}return l.length!==i&&(l.subarray?l=l.subarray(0,i):l.length=i),n.applyFromCharCode(l)}(e=n.transformTo(o.uint8array?"uint8array":"array",e))},n.inherits(d,a),d.prototype.processChunk=function(e){var t=n.transformTo(o.uint8array?"uint8array":"array",e.data);if(this.leftOver&&this.leftOver.length){if(o.uint8array){var r=t;(t=new Uint8Array(r.length+this.leftOver.length)).set(this.leftOver,0),t.set(r,this.leftOver.length)}else t=this.leftOver.concat(t);this.leftOver=null}var a=function(e,t){var i;for((t=t||e.length)>e.length&&(t=e.length),i=t-1;0<=i&&128==(192&e[i]);)i--;return i<0?t:0===i?t:i+s[e[i]]>t?i:t}(t),l=t;a!==t.length&&(o.uint8array?(l=t.subarray(0,a),this.leftOver=t.subarray(a,t.length)):(l=t.slice(0,a),this.leftOver=t.slice(a,t.length))),this.push({data:i.utf8decode(l),meta:e.meta})},d.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:i.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},i.Utf8DecodeWorker=d,n.inherits(c,a),c.prototype.processChunk=function(e){this.push({data:i.utf8encode(e.data),meta:e.meta})},i.Utf8EncodeWorker=c},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,t,i){"use strict";var n=e("./support"),o=e("./base64"),r=e("./nodejsUtils"),a=e("./external");function s(e){return e}function l(e,t){for(var i=0;i<e.length;++i)t[i]=255&e.charCodeAt(i);return t}e("setimmediate"),i.newBlob=function(e,t){i.checkSupport("blob");try{return new Blob([e],{type:t})}catch(i){try{var n=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return n.append(e),n.getBlob(t)}catch(e){throw Error("Bug : can't construct the Blob.")}}};var d={stringifyByChunk:function(e,t,i){var n=[],o=0,r=e.length;if(r<=i)return String.fromCharCode.apply(null,e);for(;o<r;)"array"===t||"nodebuffer"===t?n.push(String.fromCharCode.apply(null,e.slice(o,Math.min(o+i,r)))):n.push(String.fromCharCode.apply(null,e.subarray(o,Math.min(o+i,r)))),o+=i;return n.join("")},stringifyByChar:function(e){for(var t="",i=0;i<e.length;i++)t+=String.fromCharCode(e[i]);return t},applyCanBeUsed:{uint8array:function(){try{return n.uint8array&&1===String.fromCharCode.apply(null,new Uint8Array(1)).length}catch(e){return!1}}(),nodebuffer:function(){try{return n.nodebuffer&&1===String.fromCharCode.apply(null,r.allocBuffer(1)).length}catch(e){return!1}}()}};function c(e){var t=65536,n=i.getTypeOf(e),o=!0;if("uint8array"===n?o=d.applyCanBeUsed.uint8array:"nodebuffer"===n&&(o=d.applyCanBeUsed.nodebuffer),o)for(;1<t;)try{return d.stringifyByChunk(e,n,t)}catch(e){t=Math.floor(t/2)}return d.stringifyByChar(e)}function h(e,t){for(var i=0;i<e.length;i++)t[i]=e[i];return t}i.applyFromCharCode=c;var u={};u.string={string:s,array:function(e){return l(e,Array(e.length))},arraybuffer:function(e){return u.string.uint8array(e).buffer},uint8array:function(e){return l(e,new Uint8Array(e.length))},nodebuffer:function(e){return l(e,r.allocBuffer(e.length))}},u.array={string:c,array:s,arraybuffer:function(e){return new Uint8Array(e).buffer},uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return r.newBufferFrom(e)}},u.arraybuffer={string:function(e){return c(new Uint8Array(e))},array:function(e){return h(new Uint8Array(e),Array(e.byteLength))},arraybuffer:s,uint8array:function(e){return new Uint8Array(e)},nodebuffer:function(e){return r.newBufferFrom(new Uint8Array(e))}},u.uint8array={string:c,array:function(e){return h(e,Array(e.length))},arraybuffer:function(e){return e.buffer},uint8array:s,nodebuffer:function(e){return r.newBufferFrom(e)}},u.nodebuffer={string:c,array:function(e){return h(e,Array(e.length))},arraybuffer:function(e){return u.nodebuffer.uint8array(e).buffer},uint8array:function(e){return h(e,new Uint8Array(e.length))},nodebuffer:s},i.transformTo=function(e,t){return(t=t||"",e)?(i.checkSupport(e),u[i.getTypeOf(t)][e](t)):t},i.resolve=function(e){for(var t=e.split("/"),i=[],n=0;n<t.length;n++){var o=t[n];"."===o||""===o&&0!==n&&n!==t.length-1||(".."===o?i.pop():i.push(o))}return i.join("/")},i.getTypeOf=function(e){return"string"==typeof e?"string":"[object Array]"===Object.prototype.toString.call(e)?"array":n.nodebuffer&&r.isBuffer(e)?"nodebuffer":n.uint8array&&e instanceof Uint8Array?"uint8array":n.arraybuffer&&e instanceof ArrayBuffer?"arraybuffer":void 0},i.checkSupport=function(e){if(!n[e.toLowerCase()])throw Error(e+" is not supported by this platform")},i.MAX_VALUE_16BITS=65535,i.MAX_VALUE_32BITS=-1,i.pretty=function(e){var t,i,n="";for(i=0;i<(e||"").length;i++)n+="\\x"+((t=e.charCodeAt(i))<16?"0":"")+t.toString(16).toUpperCase();return n},i.delay=function(e,t,i){setImmediate(function(){e.apply(i||null,t||[])})},i.inherits=function(e,t){function i(){}i.prototype=t.prototype,e.prototype=new i},i.extend=function(){var e,t,i={};for(e=0;e<arguments.length;e++)for(t in arguments[e])Object.prototype.hasOwnProperty.call(arguments[e],t)&&void 0===i[t]&&(i[t]=arguments[e][t]);return i},i.prepareContent=function(e,t,r,s,d){return a.Promise.resolve(t).then(function(e){return n.blob&&(e instanceof Blob||-1!==["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(e)))&&"undefined"!=typeof FileReader?new a.Promise(function(t,i){var n=new FileReader;n.onload=function(e){t(e.target.result)},n.onerror=function(e){i(e.target.error)},n.readAsArrayBuffer(e)}):e}).then(function(t){var c,h=i.getTypeOf(t);return h?("arraybuffer"===h?t=i.transformTo("uint8array",t):"string"===h&&(d?t=o.decode(t):r&&!0!==s&&(t=l(c=t,n.uint8array?new Uint8Array(c.length):Array(c.length)))),t):a.Promise.reject(Error("Can't read the data of '"+e+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,t,i){"use strict";var n=e("./reader/readerFor"),o=e("./utils"),r=e("./signature"),a=e("./zipEntry"),s=e("./support");function l(e){this.files=[],this.loadOptions=e}l.prototype={checkSignature:function(e){if(!this.reader.readAndCheckSignature(e)){this.reader.index-=4;var t=this.reader.readString(4);throw Error("Corrupted zip or bug: unexpected signature ("+o.pretty(t)+", expected "+o.pretty(e)+")")}},isSignature:function(e,t){var i=this.reader.index;this.reader.setIndex(e);var n=this.reader.readString(4)===t;return this.reader.setIndex(i),n},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var e=this.reader.readData(this.zipCommentLength),t=s.uint8array?"uint8array":"array",i=o.transformTo(t,e);this.zipComment=this.loadOptions.decodeFileName(i)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var e,t,i,n=this.zip64EndOfCentralSize-44;0<n;)e=this.reader.readInt(2),t=this.reader.readInt(4),i=this.reader.readData(t),this.zip64ExtensibleData[e]={id:e,length:t,value:i}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var e,t;for(e=0;e<this.files.length;e++)t=this.files[e],this.reader.setIndex(t.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),t.readLocalPart(this.reader),t.handleUTF8(),t.processAttributes()},readCentralDir:function(){var e;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(e=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(e);if(this.centralDirRecords!==this.files.length&&0!==this.centralDirRecords&&0===this.files.length)throw Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var e=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(e<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?Error("Corrupted zip: can't find end of central directory"):Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(e);var t=e;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===o.MAX_VALUE_16BITS||this.diskWithCentralDirStart===o.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===o.MAX_VALUE_16BITS||this.centralDirRecords===o.MAX_VALUE_16BITS||this.centralDirSize===o.MAX_VALUE_32BITS||this.centralDirOffset===o.MAX_VALUE_32BITS){if(this.zip64=!0,(e=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(e),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var i=this.centralDirOffset+this.centralDirSize;this.zip64&&(i+=20+(12+this.zip64EndOfCentralSize));var n=t-i;if(0<n)this.isSignature(t,r.CENTRAL_FILE_HEADER)||(this.reader.zero=n);else if(n<0)throw Error("Corrupted zip: missing "+Math.abs(n)+" bytes.")},prepareReader:function(e){this.reader=n(e)},load:function(e){this.prepareReader(e),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},t.exports=l},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,t,i){"use strict";var n=e("./reader/readerFor"),o=e("./utils"),r=e("./compressedObject"),a=e("./crc32"),s=e("./utf8"),l=e("./compressions"),d=e("./support");function c(e,t){this.options=e,this.loadOptions=t}c.prototype={isEncrypted:function(){return 1==(1&this.bitFlag)},useUTF8:function(){return 2048==(2048&this.bitFlag)},readLocalPart:function(e){var t,i;if(e.skip(22),this.fileNameLength=e.readInt(2),i=e.readInt(2),this.fileName=e.readData(this.fileNameLength),e.skip(i),-1===this.compressedSize||-1===this.uncompressedSize)throw Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if(null===(t=function(e){for(var t in l)if(Object.prototype.hasOwnProperty.call(l,t)&&l[t].magic===e)return l[t];return null}(this.compressionMethod)))throw Error("Corrupted zip : compression "+o.pretty(this.compressionMethod)+" unknown (inner file : "+o.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,t,e.readData(this.compressedSize))},readCentralPart:function(e){this.versionMadeBy=e.readInt(2),e.skip(2),this.bitFlag=e.readInt(2),this.compressionMethod=e.readString(2),this.date=e.readDate(),this.crc32=e.readInt(4),this.compressedSize=e.readInt(4),this.uncompressedSize=e.readInt(4);var t=e.readInt(2);if(this.extraFieldsLength=e.readInt(2),this.fileCommentLength=e.readInt(2),this.diskNumberStart=e.readInt(2),this.internalFileAttributes=e.readInt(2),this.externalFileAttributes=e.readInt(4),this.localHeaderOffset=e.readInt(4),this.isEncrypted())throw Error("Encrypted zip are not supported");e.skip(t),this.readExtraFields(e),this.parseZIP64ExtraField(e),this.fileComment=e.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var e=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),0==e&&(this.dosPermissions=63&this.externalFileAttributes),3==e&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||"/"!==this.fileNameStr.slice(-1)||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var e=n(this.extraFields[1].value);this.uncompressedSize===o.MAX_VALUE_32BITS&&(this.uncompressedSize=e.readInt(8)),this.compressedSize===o.MAX_VALUE_32BITS&&(this.compressedSize=e.readInt(8)),this.localHeaderOffset===o.MAX_VALUE_32BITS&&(this.localHeaderOffset=e.readInt(8)),this.diskNumberStart===o.MAX_VALUE_32BITS&&(this.diskNumberStart=e.readInt(4))}},readExtraFields:function(e){var t,i,n,o=e.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});e.index+4<o;)t=e.readInt(2),i=e.readInt(2),n=e.readData(i),this.extraFields[t]={id:t,length:i,value:n};e.setIndex(o)},handleUTF8:function(){var e=d.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=s.utf8decode(this.fileName),this.fileCommentStr=s.utf8decode(this.fileComment);else{var t=this.findExtraFieldUnicodePath();if(null!==t)this.fileNameStr=t;else{var i=o.transformTo(e,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(i)}var n=this.findExtraFieldUnicodeComment();if(null!==n)this.fileCommentStr=n;else{var r=o.transformTo(e,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(r)}}},findExtraFieldUnicodePath:function(){var e=this.extraFields[28789];if(e){var t=n(e.value);return 1!==t.readInt(1)?null:a(this.fileName)!==t.readInt(4)?null:s.utf8decode(t.readData(e.length-5))}return null},findExtraFieldUnicodeComment:function(){var e=this.extraFields[25461];if(e){var t=n(e.value);return 1!==t.readInt(1)?null:a(this.fileComment)!==t.readInt(4)?null:s.utf8decode(t.readData(e.length-5))}return null}},t.exports=c},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,t,i){"use strict";function n(e,t,i){this.name=e,this.dir=i.dir,this.date=i.date,this.comment=i.comment,this.unixPermissions=i.unixPermissions,this.dosPermissions=i.dosPermissions,this._data=t,this._dataBinary=i.binary,this.options={compression:i.compression,compressionOptions:i.compressionOptions}}var o=e("./stream/StreamHelper"),r=e("./stream/DataWorker"),a=e("./utf8"),s=e("./compressedObject"),l=e("./stream/GenericWorker");n.prototype={internalStream:function(e){var t=null,i="string";try{if(!e)throw Error("No output type specified.");var n="string"===(i=e.toLowerCase())||"text"===i;"binarystring"!==i&&"text"!==i||(i="string"),t=this._decompressWorker();var r=!this._dataBinary;r&&!n&&(t=t.pipe(new a.Utf8EncodeWorker)),!r&&n&&(t=t.pipe(new a.Utf8DecodeWorker))}catch(e){(t=new l("error")).error(e)}return new o(t,i,"")},async:function(e,t){return this.internalStream(e).accumulate(t)},nodeStream:function(e,t){return this.internalStream(e||"nodebuffer").toNodejsStream(t)},_compressWorker:function(e,t){if(this._data instanceof s&&this._data.compression.magic===e.magic)return this._data.getCompressedWorker();var i=this._decompressWorker();return this._dataBinary||(i=i.pipe(new a.Utf8EncodeWorker)),s.createWorkerFrom(i,e,t)},_decompressWorker:function(){return this._data instanceof s?this._data.getContentWorker():this._data instanceof l?this._data:new r(this._data)}};for(var d=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],c=function(){throw Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},h=0;h<d.length;h++)n.prototype[d[h]]=c;t.exports=n},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,t,n){(function(e){"use strict";var i,n,o=e.MutationObserver||e.WebKitMutationObserver;if(o){var r=0,a=new o(c),s=e.document.createTextNode("");a.observe(s,{characterData:!0}),i=function(){s.data=r=++r%2}}else if(e.setImmediate||void 0===e.MessageChannel)i="document"in e&&"onreadystatechange"in e.document.createElement("script")?function(){var t=e.document.createElement("script");t.onreadystatechange=function(){c(),t.onreadystatechange=null,t.parentNode.removeChild(t),t=null},e.document.documentElement.appendChild(t)}:function(){setTimeout(c,0)};else{var l=new e.MessageChannel;l.port1.onmessage=c,i=function(){l.port2.postMessage(0)}}var d=[];function c(){var e,t;n=!0;for(var i=d.length;i;){for(t=d,d=[],e=-1;++e<i;)t[e]();i=d.length}n=!1}t.exports=function(e){1!==d.push(e)||n||i()}}).call(this,void 0!==i.g?i.g:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],37:[function(e,t,i){"use strict";var n=e("immediate");function o(){}var r={},a=["REJECTED"],s=["FULFILLED"],l=["PENDING"];function d(e){if("function"!=typeof e)throw TypeError("resolver must be a function");this.state=l,this.queue=[],this.outcome=void 0,e!==o&&f(this,e)}function c(e,t,i){this.promise=e,"function"==typeof t&&(this.onFulfilled=t,this.callFulfilled=this.otherCallFulfilled),"function"==typeof i&&(this.onRejected=i,this.callRejected=this.otherCallRejected)}function h(e,t,i){n(function(){var n;try{n=t(i)}catch(t){return r.reject(e,t)}n===e?r.reject(e,TypeError("Cannot resolve promise with itself")):r.resolve(e,n)})}function u(e){var t=e&&e.then;if(e&&("object"==typeof e||"function"==typeof e)&&"function"==typeof t)return function(){t.apply(e,arguments)}}function f(e,t){var i=!1;function n(t){i||(i=!0,r.reject(e,t))}function o(t){i||(i=!0,r.resolve(e,t))}var a=p(function(){t(o,n)});"error"===a.status&&n(a.value)}function p(e,t){var i={};try{i.value=e(t),i.status="success"}catch(e){i.status="error",i.value=e}return i}(t.exports=d).prototype.finally=function(e){if("function"!=typeof e)return this;var t=this.constructor;return this.then(function(i){return t.resolve(e()).then(function(){return i})},function(i){return t.resolve(e()).then(function(){throw i})})},d.prototype.catch=function(e){return this.then(null,e)},d.prototype.then=function(e,t){if("function"!=typeof e&&this.state===s||"function"!=typeof t&&this.state===a)return this;var i=new this.constructor(o);return this.state!==l?h(i,this.state===s?e:t,this.outcome):this.queue.push(new c(i,e,t)),i},c.prototype.callFulfilled=function(e){r.resolve(this.promise,e)},c.prototype.otherCallFulfilled=function(e){h(this.promise,this.onFulfilled,e)},c.prototype.callRejected=function(e){r.reject(this.promise,e)},c.prototype.otherCallRejected=function(e){h(this.promise,this.onRejected,e)},r.resolve=function(e,t){var i=p(u,t);if("error"===i.status)return r.reject(e,i.value);var n=i.value;if(n)f(e,n);else{e.state=s,e.outcome=t;for(var o=-1,a=e.queue.length;++o<a;)e.queue[o].callFulfilled(t)}return e},r.reject=function(e,t){e.state=a,e.outcome=t;for(var i=-1,n=e.queue.length;++i<n;)e.queue[i].callRejected(t);return e},d.resolve=function(e){return e instanceof this?e:r.resolve(new this(o),e)},d.reject=function(e){var t=new this(o);return r.reject(t,e)},d.all=function(e){var t=this;if("[object Array]"!==Object.prototype.toString.call(e))return this.reject(TypeError("must be an array"));var i=e.length,n=!1;if(!i)return this.resolve([]);for(var a=Array(i),s=0,l=-1,d=new this(o);++l<i;)(function(e,o){t.resolve(e).then(function(e){a[o]=e,++s!==i||n||(n=!0,r.resolve(d,a))},function(e){n||(n=!0,r.reject(d,e))})})(e[l],l);return d},d.race=function(e){if("[object Array]"!==Object.prototype.toString.call(e))return this.reject(TypeError("must be an array"));var t,i=e.length,n=!1;if(!i)return this.resolve([]);for(var a=-1,s=new this(o);++a<i;)t=e[a],this.resolve(t).then(function(e){n||(n=!0,r.resolve(s,e))},function(e){n||(n=!0,r.reject(s,e))});return s}},{immediate:36}],38:[function(e,t,i){"use strict";var n={};(0,e("./lib/utils/common").assign)(n,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),t.exports=n},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,t,i){"use strict";var n=e("./zlib/deflate"),o=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/messages"),s=e("./zlib/zstream"),l=Object.prototype.toString;function d(e){if(!(this instanceof d))return new d(e);this.options=o.assign({level:-1,method:8,chunkSize:16384,windowBits:15,memLevel:8,strategy:0,to:""},e||{});var t,i=this.options;i.raw&&0<i.windowBits?i.windowBits=-i.windowBits:i.gzip&&0<i.windowBits&&i.windowBits<16&&(i.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new s,this.strm.avail_out=0;var c=n.deflateInit2(this.strm,i.level,i.method,i.windowBits,i.memLevel,i.strategy);if(0!==c)throw Error(a[c]);if(i.header&&n.deflateSetHeader(this.strm,i.header),i.dictionary){if(t="string"==typeof i.dictionary?r.string2buf(i.dictionary):"[object ArrayBuffer]"===l.call(i.dictionary)?new Uint8Array(i.dictionary):i.dictionary,0!==(c=n.deflateSetDictionary(this.strm,t)))throw Error(a[c]);this._dict_set=!0}}function c(e,t){var i=new d(t);if(i.push(e,!0),i.err)throw i.msg||a[i.err];return i.result}d.prototype.push=function(e,t){var i,a,s=this.strm,d=this.options.chunkSize;if(this.ended)return!1;a=t===~~t?t:!0===t?4:0,"string"==typeof e?s.input=r.string2buf(e):"[object ArrayBuffer]"===l.call(e)?s.input=new Uint8Array(e):s.input=e,s.next_in=0,s.avail_in=s.input.length;do{if(0===s.avail_out&&(s.output=new o.Buf8(d),s.next_out=0,s.avail_out=d),1!==(i=n.deflate(s,a))&&0!==i)return this.onEnd(i),this.ended=!0,!1;0!==s.avail_out&&(0!==s.avail_in||4!==a&&2!==a)||("string"===this.options.to?this.onData(r.buf2binstring(o.shrinkBuf(s.output,s.next_out))):this.onData(o.shrinkBuf(s.output,s.next_out)))}while((0<s.avail_in||0===s.avail_out)&&1!==i);return 4===a?(i=n.deflateEnd(this.strm),this.onEnd(i),this.ended=!0,0===i):2!==a||(this.onEnd(0),s.avail_out=0,!0)},d.prototype.onData=function(e){this.chunks.push(e)},d.prototype.onEnd=function(e){0===e&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=o.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},i.Deflate=d,i.deflate=c,i.deflateRaw=function(e,t){return(t=t||{}).raw=!0,c(e,t)},i.gzip=function(e,t){return(t=t||{}).gzip=!0,c(e,t)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,t,i){"use strict";var n=e("./zlib/inflate"),o=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/constants"),s=e("./zlib/messages"),l=e("./zlib/zstream"),d=e("./zlib/gzheader"),c=Object.prototype.toString;function h(e){if(!(this instanceof h))return new h(e);this.options=o.assign({chunkSize:16384,windowBits:0,to:""},e||{});var t=this.options;t.raw&&0<=t.windowBits&&t.windowBits<16&&(t.windowBits=-t.windowBits,0===t.windowBits&&(t.windowBits=-15)),!(0<=t.windowBits&&t.windowBits<16)||e&&e.windowBits||(t.windowBits+=32),15<t.windowBits&&t.windowBits<48&&0==(15&t.windowBits)&&(t.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new l,this.strm.avail_out=0;var i=n.inflateInit2(this.strm,t.windowBits);if(i!==a.Z_OK)throw Error(s[i]);this.header=new d,n.inflateGetHeader(this.strm,this.header)}function u(e,t){var i=new h(t);if(i.push(e,!0),i.err)throw i.msg||s[i.err];return i.result}h.prototype.push=function(e,t){var i,s,l,d,h,u,f=this.strm,p=this.options.chunkSize,g=this.options.dictionary,m=!1;if(this.ended)return!1;s=t===~~t?t:!0===t?a.Z_FINISH:a.Z_NO_FLUSH,"string"==typeof e?f.input=r.binstring2buf(e):"[object ArrayBuffer]"===c.call(e)?f.input=new Uint8Array(e):f.input=e,f.next_in=0,f.avail_in=f.input.length;do{if(0===f.avail_out&&(f.output=new o.Buf8(p),f.next_out=0,f.avail_out=p),(i=n.inflate(f,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&g&&(u="string"==typeof g?r.string2buf(g):"[object ArrayBuffer]"===c.call(g)?new Uint8Array(g):g,i=n.inflateSetDictionary(this.strm,u)),i===a.Z_BUF_ERROR&&!0===m&&(i=a.Z_OK,m=!1),i!==a.Z_STREAM_END&&i!==a.Z_OK)return this.onEnd(i),this.ended=!0,!1;f.next_out&&(0!==f.avail_out&&i!==a.Z_STREAM_END&&(0!==f.avail_in||s!==a.Z_FINISH&&s!==a.Z_SYNC_FLUSH)||("string"===this.options.to?(l=r.utf8border(f.output,f.next_out),d=f.next_out-l,h=r.buf2string(f.output,l),f.next_out=d,f.avail_out=p-d,d&&o.arraySet(f.output,f.output,l,d,0),this.onData(h)):this.onData(o.shrinkBuf(f.output,f.next_out)))),0===f.avail_in&&0===f.avail_out&&(m=!0)}while((0<f.avail_in||0===f.avail_out)&&i!==a.Z_STREAM_END);return i===a.Z_STREAM_END&&(s=a.Z_FINISH),s===a.Z_FINISH?(i=n.inflateEnd(this.strm),this.onEnd(i),this.ended=!0,i===a.Z_OK):s!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),f.avail_out=0,!0)},h.prototype.onData=function(e){this.chunks.push(e)},h.prototype.onEnd=function(e){e===a.Z_OK&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=o.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},i.Inflate=h,i.inflate=u,i.inflateRaw=function(e,t){return(t=t||{}).raw=!0,u(e,t)},i.ungzip=u},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,t,i){"use strict";var n="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Int32Array;i.assign=function(e){for(var t=Array.prototype.slice.call(arguments,1);t.length;){var i=t.shift();if(i){if("object"!=typeof i)throw TypeError(i+"must be non-object");for(var n in i)i.hasOwnProperty(n)&&(e[n]=i[n])}}return e},i.shrinkBuf=function(e,t){return e.length===t?e:e.subarray?e.subarray(0,t):(e.length=t,e)};var o={arraySet:function(e,t,i,n,o){if(t.subarray&&e.subarray)e.set(t.subarray(i,i+n),o);else for(var r=0;r<n;r++)e[o+r]=t[i+r]},flattenChunks:function(e){var t,i,n,o,r,a;for(t=n=0,i=e.length;t<i;t++)n+=e[t].length;for(a=new Uint8Array(n),t=o=0,i=e.length;t<i;t++)r=e[t],a.set(r,o),o+=r.length;return a}},r={arraySet:function(e,t,i,n,o){for(var r=0;r<n;r++)e[o+r]=t[i+r]},flattenChunks:function(e){return[].concat.apply([],e)}};i.setTyped=function(e){e?(i.Buf8=Uint8Array,i.Buf16=Uint16Array,i.Buf32=Int32Array,i.assign(i,o)):(i.Buf8=Array,i.Buf16=Array,i.Buf32=Array,i.assign(i,r))},i.setTyped(n)},{}],42:[function(e,t,i){"use strict";var n=e("./common"),o=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch(e){o=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch(e){r=!1}for(var a=new n.Buf8(256),s=0;s<256;s++)a[s]=252<=s?6:248<=s?5:240<=s?4:224<=s?3:192<=s?2:1;function l(e,t){if(t<65537&&(e.subarray&&r||!e.subarray&&o))return String.fromCharCode.apply(null,n.shrinkBuf(e,t));for(var i="",a=0;a<t;a++)i+=String.fromCharCode(e[a]);return i}a[254]=a[254]=1,i.string2buf=function(e){var t,i,o,r,a,s=e.length,l=0;for(r=0;r<s;r++)55296==(64512&(i=e.charCodeAt(r)))&&r+1<s&&56320==(64512&(o=e.charCodeAt(r+1)))&&(i=65536+(i-55296<<10)+(o-56320),r++),l+=i<128?1:i<2048?2:i<65536?3:4;for(t=new n.Buf8(l),r=a=0;a<l;r++)55296==(64512&(i=e.charCodeAt(r)))&&r+1<s&&56320==(64512&(o=e.charCodeAt(r+1)))&&(i=65536+(i-55296<<10)+(o-56320),r++),i<128?t[a++]=i:(i<2048?t[a++]=192|i>>>6:(i<65536?t[a++]=224|i>>>12:(t[a++]=240|i>>>18,t[a++]=128|i>>>12&63),t[a++]=128|i>>>6&63),t[a++]=128|63&i);return t},i.buf2binstring=function(e){return l(e,e.length)},i.binstring2buf=function(e){for(var t=new n.Buf8(e.length),i=0,o=t.length;i<o;i++)t[i]=e.charCodeAt(i);return t},i.buf2string=function(e,t){var i,n,o,r,s=t||e.length,d=Array(2*s);for(i=n=0;i<s;)if((o=e[i++])<128)d[n++]=o;else if(4<(r=a[o]))d[n++]=65533,i+=r-1;else{for(o&=2===r?31:3===r?15:7;1<r&&i<s;)o=o<<6|63&e[i++],r--;1<r?d[n++]=65533:o<65536?d[n++]=o:(o-=65536,d[n++]=55296|o>>10&1023,d[n++]=56320|1023&o)}return l(d,n)},i.utf8border=function(e,t){var i;for((t=t||e.length)>e.length&&(t=e.length),i=t-1;0<=i&&128==(192&e[i]);)i--;return i<0?t:0===i?t:i+a[e[i]]>t?i:t}},{"./common":41}],43:[function(e,t,i){"use strict";t.exports=function(e,t,i,n){for(var o=65535&e|0,r=e>>>16&65535|0,a=0;0!==i;){for(i-=a=2e3<i?2e3:i;r=r+(o=o+t[n++]|0)|0,--a;);o%=65521,r%=65521}return o|r<<16|0}},{}],44:[function(e,t,i){"use strict";t.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,t,i){"use strict";var n=function(){for(var e,t=[],i=0;i<256;i++){e=i;for(var n=0;n<8;n++)e=1&e?3988292384^e>>>1:e>>>1;t[i]=e}return t}();t.exports=function(e,t,i,o){var r=o+i;e^=-1;for(var a=o;a<r;a++)e=e>>>8^n[255&(e^t[a])];return -1^e}},{}],46:[function(e,t,i){"use strict";var n,o=e("../utils/common"),r=e("./trees"),a=e("./adler32"),s=e("./crc32"),l=e("./messages");function d(e,t){return e.msg=l[t],t}function c(e){return(e<<1)-(4<e?9:0)}function h(e){for(var t=e.length;0<=--t;)e[t]=0}function u(e){var t=e.state,i=t.pending;i>e.avail_out&&(i=e.avail_out),0!==i&&(o.arraySet(e.output,t.pending_buf,t.pending_out,i,e.next_out),e.next_out+=i,t.pending_out+=i,e.total_out+=i,e.avail_out-=i,t.pending-=i,0===t.pending&&(t.pending_out=0))}function f(e,t){r._tr_flush_block(e,0<=e.block_start?e.block_start:-1,e.strstart-e.block_start,t),e.block_start=e.strstart,u(e.strm)}function p(e,t){e.pending_buf[e.pending++]=t}function g(e,t){e.pending_buf[e.pending++]=t>>>8&255,e.pending_buf[e.pending++]=255&t}function m(e,t){var i,n,o=e.max_chain_length,r=e.strstart,a=e.prev_length,s=e.nice_match,l=e.strstart>e.w_size-262?e.strstart-(e.w_size-262):0,d=e.window,c=e.w_mask,h=e.prev,u=e.strstart+258,f=d[r+a-1],p=d[r+a];e.prev_length>=e.good_match&&(o>>=2),s>e.lookahead&&(s=e.lookahead);do if(d[(i=t)+a]===p&&d[i+a-1]===f&&d[i]===d[r]&&d[++i]===d[r+1]){r+=2,i++;do;while(d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&d[++r]===d[++i]&&r<u);if(n=258-(u-r),r=u-258,a<n){if(e.match_start=t,s<=(a=n))break;f=d[r+a-1],p=d[r+a]}}while((t=h[t&c])>l&&0!=--o);return a<=e.lookahead?a:e.lookahead}function v(e){var t,i,n,r,l,d,c,h,u,f,p=e.w_size;do{if(r=e.window_size-e.lookahead-e.strstart,e.strstart>=p+(p-262)){for(o.arraySet(e.window,e.window,p,p,0),e.match_start-=p,e.strstart-=p,e.block_start-=p,t=i=e.hash_size;n=e.head[--t],e.head[t]=p<=n?n-p:0,--i;);for(t=i=p;n=e.prev[--t],e.prev[t]=p<=n?n-p:0,--i;);r+=p}if(0===e.strm.avail_in)break;if(d=e.strm,c=e.window,h=e.strstart+e.lookahead,u=r,f=void 0,f=d.avail_in,u<f&&(f=u),i=0===f?0:(d.avail_in-=f,o.arraySet(c,d.input,d.next_in,f,h),1===d.state.wrap?d.adler=a(d.adler,c,f,h):2===d.state.wrap&&(d.adler=s(d.adler,c,f,h)),d.next_in+=f,d.total_in+=f,f),e.lookahead+=i,e.lookahead+e.insert>=3)for(l=e.strstart-e.insert,e.ins_h=e.window[l],e.ins_h=(e.ins_h<<e.hash_shift^e.window[l+1])&e.hash_mask;e.insert&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[l+3-1])&e.hash_mask,e.prev[l&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=l,l++,e.insert--,!(e.lookahead+e.insert<3)););}while(e.lookahead<262&&0!==e.strm.avail_in)}function b(e,t){for(var i,n;;){if(e.lookahead<262){if(v(e),e.lookahead<262&&0===t)return 1;if(0===e.lookahead)break}if(i=0,e.lookahead>=3&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+3-1])&e.hash_mask,i=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),0!==i&&e.strstart-i<=e.w_size-262&&(e.match_length=m(e,i)),e.match_length>=3){if(n=r._tr_tally(e,e.strstart-e.match_start,e.match_length-3),e.lookahead-=e.match_length,e.match_length<=e.max_lazy_match&&e.lookahead>=3){for(e.match_length--;e.strstart++,e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+3-1])&e.hash_mask,i=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart,0!=--e.match_length;);e.strstart++}else e.strstart+=e.match_length,e.match_length=0,e.ins_h=e.window[e.strstart],e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+1])&e.hash_mask}else n=r._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++;if(n&&(f(e,!1),0===e.strm.avail_out))return 1}return e.insert=e.strstart<2?e.strstart:2,4===t?(f(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(f(e,!1),0===e.strm.avail_out)?1:2}function C(e,t){for(var i,n,o;;){if(e.lookahead<262){if(v(e),e.lookahead<262&&0===t)return 1;if(0===e.lookahead)break}if(i=0,e.lookahead>=3&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+3-1])&e.hash_mask,i=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),e.prev_length=e.match_length,e.prev_match=e.match_start,e.match_length=2,0!==i&&e.prev_length<e.max_lazy_match&&e.strstart-i<=e.w_size-262&&(e.match_length=m(e,i),e.match_length<=5&&(1===e.strategy||3===e.match_length&&4096<e.strstart-e.match_start)&&(e.match_length=2)),e.prev_length>=3&&e.match_length<=e.prev_length){for(o=e.strstart+e.lookahead-3,n=r._tr_tally(e,e.strstart-1-e.prev_match,e.prev_length-3),e.lookahead-=e.prev_length-1,e.prev_length-=2;++e.strstart<=o&&(e.ins_h=(e.ins_h<<e.hash_shift^e.window[e.strstart+3-1])&e.hash_mask,i=e.prev[e.strstart&e.w_mask]=e.head[e.ins_h],e.head[e.ins_h]=e.strstart),0!=--e.prev_length;);if(e.match_available=0,e.match_length=2,e.strstart++,n&&(f(e,!1),0===e.strm.avail_out))return 1}else if(e.match_available){if((n=r._tr_tally(e,0,e.window[e.strstart-1]))&&f(e,!1),e.strstart++,e.lookahead--,0===e.strm.avail_out)return 1}else e.match_available=1,e.strstart++,e.lookahead--}return e.match_available&&(n=r._tr_tally(e,0,e.window[e.strstart-1]),e.match_available=0),e.insert=e.strstart<2?e.strstart:2,4===t?(f(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(f(e,!1),0===e.strm.avail_out)?1:2}function y(e,t,i,n,o){this.good_length=e,this.max_lazy=t,this.nice_length=i,this.max_chain=n,this.func=o}function x(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=8,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new o.Buf16(1146),this.dyn_dtree=new o.Buf16(122),this.bl_tree=new o.Buf16(78),h(this.dyn_ltree),h(this.dyn_dtree),h(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new o.Buf16(16),this.heap=new o.Buf16(573),h(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new o.Buf16(573),h(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function w(e){var t;return e&&e.state?(e.total_in=e.total_out=0,e.data_type=2,(t=e.state).pending=0,t.pending_out=0,t.wrap<0&&(t.wrap=-t.wrap),t.status=t.wrap?42:113,e.adler=2===t.wrap?0:1,t.last_flush=0,r._tr_init(t),0):d(e,-2)}function _(e){var t,i=w(e);return 0===i&&((t=e.state).window_size=2*t.w_size,h(t.head),t.max_lazy_match=n[t.level].max_lazy,t.good_match=n[t.level].good_length,t.nice_match=n[t.level].nice_length,t.max_chain_length=n[t.level].max_chain,t.strstart=0,t.block_start=0,t.lookahead=0,t.insert=0,t.match_length=t.prev_length=2,t.match_available=0,t.ins_h=0),i}function k(e,t,i,n,r,a){if(!e)return -2;var s=1;if(-1===t&&(t=6),n<0?(s=0,n=-n):15<n&&(s=2,n-=16),r<1||9<r||8!==i||n<8||15<n||t<0||9<t||a<0||4<a)return d(e,-2);8===n&&(n=9);var l=new x;return(e.state=l).strm=e,l.wrap=s,l.gzhead=null,l.w_bits=n,l.w_size=1<<l.w_bits,l.w_mask=l.w_size-1,l.hash_bits=r+7,l.hash_size=1<<l.hash_bits,l.hash_mask=l.hash_size-1,l.hash_shift=~~((l.hash_bits+3-1)/3),l.window=new o.Buf8(2*l.w_size),l.head=new o.Buf16(l.hash_size),l.prev=new o.Buf16(l.w_size),l.lit_bufsize=1<<r+6,l.pending_buf_size=4*l.lit_bufsize,l.pending_buf=new o.Buf8(l.pending_buf_size),l.d_buf=1*l.lit_bufsize,l.l_buf=3*l.lit_bufsize,l.level=t,l.strategy=a,l.method=i,_(e)}n=[new y(0,0,0,0,function(e,t){var i=65535;for(65535>e.pending_buf_size-5&&(i=e.pending_buf_size-5);;){if(e.lookahead<=1){if(v(e),0===e.lookahead&&0===t)return 1;if(0===e.lookahead)break}e.strstart+=e.lookahead,e.lookahead=0;var n=e.block_start+i;if((0===e.strstart||e.strstart>=n)&&(e.lookahead=e.strstart-n,e.strstart=n,f(e,!1),0===e.strm.avail_out)||e.strstart-e.block_start>=e.w_size-262&&(f(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(f(e,!0),0===e.strm.avail_out?3:4):(e.strstart>e.block_start&&(f(e,!1),e.strm.avail_out),1)}),new y(4,4,8,4,b),new y(4,5,16,8,b),new y(4,6,32,32,b),new y(4,4,16,16,C),new y(8,16,32,32,C),new y(8,16,128,128,C),new y(8,32,128,256,C),new y(32,128,258,1024,C),new y(32,258,258,4096,C)],i.deflateInit=function(e,t){return k(e,t,8,15,8,0)},i.deflateInit2=k,i.deflateReset=_,i.deflateResetKeep=w,i.deflateSetHeader=function(e,t){return e&&e.state?2!==e.state.wrap?-2:(e.state.gzhead=t,0):-2},i.deflate=function(e,t){var i,o,a,l;if(!e||!e.state||5<t||t<0)return e?d(e,-2):-2;if(o=e.state,!e.output||!e.input&&0!==e.avail_in||666===o.status&&4!==t)return d(e,0===e.avail_out?-5:-2);if(o.strm=e,i=o.last_flush,o.last_flush=t,42===o.status){if(2===o.wrap)e.adler=0,p(o,31),p(o,139),p(o,8),o.gzhead?(p(o,(o.gzhead.text?1:0)+(o.gzhead.hcrc?2:0)+(o.gzhead.extra?4:0)+(o.gzhead.name?8:0)+(o.gzhead.comment?16:0)),p(o,255&o.gzhead.time),p(o,o.gzhead.time>>8&255),p(o,o.gzhead.time>>16&255),p(o,o.gzhead.time>>24&255),p(o,9===o.level?2:2<=o.strategy||o.level<2?4:0),p(o,255&o.gzhead.os),o.gzhead.extra&&o.gzhead.extra.length&&(p(o,255&o.gzhead.extra.length),p(o,o.gzhead.extra.length>>8&255)),o.gzhead.hcrc&&(e.adler=s(e.adler,o.pending_buf,o.pending,0)),o.gzindex=0,o.status=69):(p(o,0),p(o,0),p(o,0),p(o,0),p(o,0),p(o,9===o.level?2:2<=o.strategy||o.level<2?4:0),p(o,3),o.status=113);else{var m=8+(o.w_bits-8<<4)<<8;m|=(2<=o.strategy||o.level<2?0:o.level<6?1:6===o.level?2:3)<<6,0!==o.strstart&&(m|=32),m+=31-m%31,o.status=113,g(o,m),0!==o.strstart&&(g(o,e.adler>>>16),g(o,65535&e.adler)),e.adler=1}}if(69===o.status){if(o.gzhead.extra){for(a=o.pending;o.gzindex<(65535&o.gzhead.extra.length)&&(o.pending!==o.pending_buf_size||(o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),u(e),a=o.pending,o.pending!==o.pending_buf_size));)p(o,255&o.gzhead.extra[o.gzindex]),o.gzindex++;o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),o.gzindex===o.gzhead.extra.length&&(o.gzindex=0,o.status=73)}else o.status=73}if(73===o.status){if(o.gzhead.name){a=o.pending;do{if(o.pending===o.pending_buf_size&&(o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),u(e),a=o.pending,o.pending===o.pending_buf_size)){l=1;break}l=o.gzindex<o.gzhead.name.length?255&o.gzhead.name.charCodeAt(o.gzindex++):0,p(o,l)}while(0!==l);o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),0===l&&(o.gzindex=0,o.status=91)}else o.status=91}if(91===o.status){if(o.gzhead.comment){a=o.pending;do{if(o.pending===o.pending_buf_size&&(o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),u(e),a=o.pending,o.pending===o.pending_buf_size)){l=1;break}l=o.gzindex<o.gzhead.comment.length?255&o.gzhead.comment.charCodeAt(o.gzindex++):0,p(o,l)}while(0!==l);o.gzhead.hcrc&&o.pending>a&&(e.adler=s(e.adler,o.pending_buf,o.pending-a,a)),0===l&&(o.status=103)}else o.status=103}if(103===o.status&&(o.gzhead.hcrc?(o.pending+2>o.pending_buf_size&&u(e),o.pending+2<=o.pending_buf_size&&(p(o,255&e.adler),p(o,e.adler>>8&255),e.adler=0,o.status=113)):o.status=113),0!==o.pending){if(u(e),0===e.avail_out)return o.last_flush=-1,0}else if(0===e.avail_in&&c(t)<=c(i)&&4!==t)return d(e,-5);if(666===o.status&&0!==e.avail_in)return d(e,-5);if(0!==e.avail_in||0!==o.lookahead||0!==t&&666!==o.status){var b=2===o.strategy?function(e,t){for(var i;;){if(0===e.lookahead&&(v(e),0===e.lookahead)){if(0===t)return 1;break}if(e.match_length=0,i=r._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++,i&&(f(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(f(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(f(e,!1),0===e.strm.avail_out)?1:2}(o,t):3===o.strategy?function(e,t){for(var i,n,o,a,s=e.window;;){if(e.lookahead<=258){if(v(e),e.lookahead<=258&&0===t)return 1;if(0===e.lookahead)break}if(e.match_length=0,e.lookahead>=3&&0<e.strstart&&(n=s[o=e.strstart-1])===s[++o]&&n===s[++o]&&n===s[++o]){a=e.strstart+258;do;while(n===s[++o]&&n===s[++o]&&n===s[++o]&&n===s[++o]&&n===s[++o]&&n===s[++o]&&n===s[++o]&&n===s[++o]&&o<a);e.match_length=258-(a-o),e.match_length>e.lookahead&&(e.match_length=e.lookahead)}if(e.match_length>=3?(i=r._tr_tally(e,1,e.match_length-3),e.lookahead-=e.match_length,e.strstart+=e.match_length,e.match_length=0):(i=r._tr_tally(e,0,e.window[e.strstart]),e.lookahead--,e.strstart++),i&&(f(e,!1),0===e.strm.avail_out))return 1}return e.insert=0,4===t?(f(e,!0),0===e.strm.avail_out?3:4):e.last_lit&&(f(e,!1),0===e.strm.avail_out)?1:2}(o,t):n[o.level].func(o,t);if(3!==b&&4!==b||(o.status=666),1===b||3===b)return 0===e.avail_out&&(o.last_flush=-1),0;if(2===b&&(1===t?r._tr_align(o):5!==t&&(r._tr_stored_block(o,0,0,!1),3===t&&(h(o.head),0===o.lookahead&&(o.strstart=0,o.block_start=0,o.insert=0))),u(e),0===e.avail_out))return o.last_flush=-1,0}return 4!==t?0:o.wrap<=0?1:(2===o.wrap?(p(o,255&e.adler),p(o,e.adler>>8&255),p(o,e.adler>>16&255),p(o,e.adler>>24&255),p(o,255&e.total_in),p(o,e.total_in>>8&255),p(o,e.total_in>>16&255),p(o,e.total_in>>24&255)):(g(o,e.adler>>>16),g(o,65535&e.adler)),u(e),0<o.wrap&&(o.wrap=-o.wrap),0!==o.pending?0:1)},i.deflateEnd=function(e){var t;return e&&e.state?42!==(t=e.state.status)&&69!==t&&73!==t&&91!==t&&103!==t&&113!==t&&666!==t?d(e,-2):(e.state=null,113===t?d(e,-3):0):-2},i.deflateSetDictionary=function(e,t){var i,n,r,s,l,d,c,u,f=t.length;if(!e||!e.state||2===(s=(i=e.state).wrap)||1===s&&42!==i.status||i.lookahead)return -2;for(1===s&&(e.adler=a(e.adler,t,f,0)),i.wrap=0,f>=i.w_size&&(0===s&&(h(i.head),i.strstart=0,i.block_start=0,i.insert=0),u=new o.Buf8(i.w_size),o.arraySet(u,t,f-i.w_size,i.w_size,0),t=u,f=i.w_size),l=e.avail_in,d=e.next_in,c=e.input,e.avail_in=f,e.next_in=0,e.input=t,v(i);i.lookahead>=3;){for(n=i.strstart,r=i.lookahead-2;i.ins_h=(i.ins_h<<i.hash_shift^i.window[n+3-1])&i.hash_mask,i.prev[n&i.w_mask]=i.head[i.ins_h],i.head[i.ins_h]=n,n++,--r;);i.strstart=n,i.lookahead=2,v(i)}return i.strstart+=i.lookahead,i.block_start=i.strstart,i.insert=i.lookahead,i.lookahead=0,i.match_length=i.prev_length=2,i.match_available=0,e.next_in=d,e.input=c,e.avail_in=l,i.wrap=s,0},i.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,t,i){"use strict";t.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,t,i){"use strict";t.exports=function(e,t){var i,n,o,r,a,s,l,d,c,h,u,f,p,g,m,v,b,C,y,x,w,_,k,M,S;i=e.state,n=e.next_in,M=e.input,o=n+(e.avail_in-5),r=e.next_out,S=e.output,a=r-(t-e.avail_out),s=r+(e.avail_out-257),l=i.dmax,d=i.wsize,c=i.whave,h=i.wnext,u=i.window,f=i.hold,p=i.bits,g=i.lencode,m=i.distcode,v=(1<<i.lenbits)-1,b=(1<<i.distbits)-1;e:do{p<15&&(f+=M[n++]<<p,p+=8,f+=M[n++]<<p,p+=8),C=g[f&v];t:for(;;){if(f>>>=y=C>>>24,p-=y,0==(y=C>>>16&255))S[r++]=65535&C;else{if(!(16&y)){if(0==(64&y)){C=g[(65535&C)+(f&(1<<y)-1)];continue t}if(32&y){i.mode=12;break e}e.msg="invalid literal/length code",i.mode=30;break e}x=65535&C,(y&=15)&&(p<y&&(f+=M[n++]<<p,p+=8),x+=f&(1<<y)-1,f>>>=y,p-=y),p<15&&(f+=M[n++]<<p,p+=8,f+=M[n++]<<p,p+=8),C=m[f&b];i:for(;;){if(f>>>=y=C>>>24,p-=y,!(16&(y=C>>>16&255))){if(0==(64&y)){C=m[(65535&C)+(f&(1<<y)-1)];continue i}e.msg="invalid distance code",i.mode=30;break e}if(w=65535&C,p<(y&=15)&&(f+=M[n++]<<p,(p+=8)<y&&(f+=M[n++]<<p,p+=8)),l<(w+=f&(1<<y)-1)){e.msg="invalid distance too far back",i.mode=30;break e}if(f>>>=y,p-=y,(y=r-a)<w){if(c<(y=w-y)&&i.sane){e.msg="invalid distance too far back",i.mode=30;break e}if(k=u,(_=0)===h){if(_+=d-y,y<x){for(x-=y;S[r++]=u[_++],--y;);_=r-w,k=S}}else if(h<y){if(_+=d+h-y,(y-=h)<x){for(x-=y;S[r++]=u[_++],--y;);if(_=0,h<x){for(x-=y=h;S[r++]=u[_++],--y;);_=r-w,k=S}}}else if(_+=h-y,y<x){for(x-=y;S[r++]=u[_++],--y;);_=r-w,k=S}for(;2<x;)S[r++]=k[_++],S[r++]=k[_++],S[r++]=k[_++],x-=3;x&&(S[r++]=k[_++],1<x&&(S[r++]=k[_++]))}else{for(_=r-w;S[r++]=S[_++],S[r++]=S[_++],S[r++]=S[_++],2<(x-=3););x&&(S[r++]=S[_++],1<x&&(S[r++]=S[_++]))}break}}break}}while(n<o&&r<s);n-=x=p>>3,f&=(1<<(p-=x<<3))-1,e.next_in=n,e.next_out=r,e.avail_in=n<o?o-n+5:5-(n-o),e.avail_out=r<s?s-r+257:257-(r-s),i.hold=f,i.bits=p}},{}],49:[function(e,t,i){"use strict";var n=e("../utils/common"),o=e("./adler32"),r=e("./crc32"),a=e("./inffast"),s=e("./inftrees");function l(e){return(e>>>24&255)+(e>>>8&65280)+((65280&e)<<8)+((255&e)<<24)}function d(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new n.Buf16(320),this.work=new n.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function c(e){var t;return e&&e.state?(t=e.state,e.total_in=e.total_out=t.total=0,e.msg="",t.wrap&&(e.adler=1&t.wrap),t.mode=1,t.last=0,t.havedict=0,t.dmax=32768,t.head=null,t.hold=0,t.bits=0,t.lencode=t.lendyn=new n.Buf32(852),t.distcode=t.distdyn=new n.Buf32(592),t.sane=1,t.back=-1,0):-2}function h(e){var t;return e&&e.state?((t=e.state).wsize=0,t.whave=0,t.wnext=0,c(e)):-2}function u(e,t){var i,n;return e&&e.state?(n=e.state,t<0?(i=0,t=-t):(i=1+(t>>4),t<48&&(t&=15)),t&&(t<8||15<t)?-2:(null!==n.window&&n.wbits!==t&&(n.window=null),n.wrap=i,n.wbits=t,h(e))):-2}function f(e,t){var i,n;return e?(n=new d,(e.state=n).window=null,0!==(i=u(e,t))&&(e.state=null),i):-2}var p,g,m=!0;function v(e,t,i,o){var r,a=e.state;return null===a.window&&(a.wsize=1<<a.wbits,a.wnext=0,a.whave=0,a.window=new n.Buf8(a.wsize)),o>=a.wsize?(n.arraySet(a.window,t,i-a.wsize,a.wsize,0),a.wnext=0,a.whave=a.wsize):(o<(r=a.wsize-a.wnext)&&(r=o),n.arraySet(a.window,t,i-o,r,a.wnext),(o-=r)?(n.arraySet(a.window,t,i-o,o,0),a.wnext=o,a.whave=a.wsize):(a.wnext+=r,a.wnext===a.wsize&&(a.wnext=0),a.whave<a.wsize&&(a.whave+=r))),0}i.inflateReset=h,i.inflateReset2=u,i.inflateResetKeep=c,i.inflateInit=function(e){return f(e,15)},i.inflateInit2=f,i.inflate=function(e,t){var i,d,c,h,u,f,b,C,y,x,w,_,k,M,S,E,L,$,P,B,R,T,O,I,D=0,z=new n.Buf8(4),A=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!e||!e.state||!e.output||!e.input&&0!==e.avail_in)return -2;12===(i=e.state).mode&&(i.mode=13),u=e.next_out,c=e.output,b=e.avail_out,h=e.next_in,d=e.input,f=e.avail_in,C=i.hold,y=i.bits,x=f,w=b,T=0;e:for(;;)switch(i.mode){case 1:if(0===i.wrap){i.mode=13;break}for(;y<16;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(2&i.wrap&&35615===C){z[i.check=0]=255&C,z[1]=C>>>8&255,i.check=r(i.check,z,2,0),y=C=0,i.mode=2;break}if(i.flags=0,i.head&&(i.head.done=!1),!(1&i.wrap)||(((255&C)<<8)+(C>>8))%31){e.msg="incorrect header check",i.mode=30;break}if(8!=(15&C)){e.msg="unknown compression method",i.mode=30;break}if(y-=4,R=8+(15&(C>>>=4)),0===i.wbits)i.wbits=R;else if(R>i.wbits){e.msg="invalid window size",i.mode=30;break}i.dmax=1<<R,e.adler=i.check=1,i.mode=512&C?10:12,y=C=0;break;case 2:for(;y<16;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(i.flags=C,8!=(255&i.flags)){e.msg="unknown compression method",i.mode=30;break}if(57344&i.flags){e.msg="unknown header flags set",i.mode=30;break}i.head&&(i.head.text=C>>8&1),512&i.flags&&(z[0]=255&C,z[1]=C>>>8&255,i.check=r(i.check,z,2,0)),y=C=0,i.mode=3;case 3:for(;y<32;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.head&&(i.head.time=C),512&i.flags&&(z[0]=255&C,z[1]=C>>>8&255,z[2]=C>>>16&255,z[3]=C>>>24&255,i.check=r(i.check,z,4,0)),y=C=0,i.mode=4;case 4:for(;y<16;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.head&&(i.head.xflags=255&C,i.head.os=C>>8),512&i.flags&&(z[0]=255&C,z[1]=C>>>8&255,i.check=r(i.check,z,2,0)),y=C=0,i.mode=5;case 5:if(1024&i.flags){for(;y<16;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.length=C,i.head&&(i.head.extra_len=C),512&i.flags&&(z[0]=255&C,z[1]=C>>>8&255,i.check=r(i.check,z,2,0)),y=C=0}else i.head&&(i.head.extra=null);i.mode=6;case 6:if(1024&i.flags&&(f<(_=i.length)&&(_=f),_&&(i.head&&(R=i.head.extra_len-i.length,i.head.extra||(i.head.extra=Array(i.head.extra_len)),n.arraySet(i.head.extra,d,h,_,R)),512&i.flags&&(i.check=r(i.check,d,_,h)),f-=_,h+=_,i.length-=_),i.length))break e;i.length=0,i.mode=7;case 7:if(2048&i.flags){if(0===f)break e;for(_=0;R=d[h+_++],i.head&&R&&i.length<65536&&(i.head.name+=String.fromCharCode(R)),R&&_<f;);if(512&i.flags&&(i.check=r(i.check,d,_,h)),f-=_,h+=_,R)break e}else i.head&&(i.head.name=null);i.length=0,i.mode=8;case 8:if(4096&i.flags){if(0===f)break e;for(_=0;R=d[h+_++],i.head&&R&&i.length<65536&&(i.head.comment+=String.fromCharCode(R)),R&&_<f;);if(512&i.flags&&(i.check=r(i.check,d,_,h)),f-=_,h+=_,R)break e}else i.head&&(i.head.comment=null);i.mode=9;case 9:if(512&i.flags){for(;y<16;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(C!==(65535&i.check)){e.msg="header crc mismatch",i.mode=30;break}y=C=0}i.head&&(i.head.hcrc=i.flags>>9&1,i.head.done=!0),e.adler=i.check=0,i.mode=12;break;case 10:for(;y<32;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}e.adler=i.check=l(C),y=C=0,i.mode=11;case 11:if(0===i.havedict)return e.next_out=u,e.avail_out=b,e.next_in=h,e.avail_in=f,i.hold=C,i.bits=y,2;e.adler=i.check=1,i.mode=12;case 12:if(5===t||6===t)break e;case 13:if(i.last){C>>>=7&y,y-=7&y,i.mode=27;break}for(;y<3;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}switch(i.last=1&C,y-=1,3&(C>>>=1)){case 0:i.mode=14;break;case 1:if(function(e){if(m){var t;for(p=new n.Buf32(512),g=new n.Buf32(32),t=0;t<144;)e.lens[t++]=8;for(;t<256;)e.lens[t++]=9;for(;t<280;)e.lens[t++]=7;for(;t<288;)e.lens[t++]=8;for(s(1,e.lens,0,288,p,0,e.work,{bits:9}),t=0;t<32;)e.lens[t++]=5;s(2,e.lens,0,32,g,0,e.work,{bits:5}),m=!1}e.lencode=p,e.lenbits=9,e.distcode=g,e.distbits=5}(i),i.mode=20,6!==t)break;C>>>=2,y-=2;break e;case 2:i.mode=17;break;case 3:e.msg="invalid block type",i.mode=30}C>>>=2,y-=2;break;case 14:for(C>>>=7&y,y-=7&y;y<32;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if((65535&C)!=(C>>>16^65535)){e.msg="invalid stored block lengths",i.mode=30;break}if(i.length=65535&C,y=C=0,i.mode=15,6===t)break e;case 15:i.mode=16;case 16:if(_=i.length){if(f<_&&(_=f),b<_&&(_=b),0===_)break e;n.arraySet(c,d,h,_,u),f-=_,h+=_,b-=_,u+=_,i.length-=_;break}i.mode=12;break;case 17:for(;y<14;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(i.nlen=257+(31&C),C>>>=5,y-=5,i.ndist=1+(31&C),C>>>=5,y-=5,i.ncode=4+(15&C),C>>>=4,y-=4,286<i.nlen||30<i.ndist){e.msg="too many length or distance symbols",i.mode=30;break}i.have=0,i.mode=18;case 18:for(;i.have<i.ncode;){for(;y<3;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.lens[A[i.have++]]=7&C,C>>>=3,y-=3}for(;i.have<19;)i.lens[A[i.have++]]=0;if(i.lencode=i.lendyn,i.lenbits=7,O={bits:i.lenbits},T=s(0,i.lens,0,19,i.lencode,0,i.work,O),i.lenbits=O.bits,T){e.msg="invalid code lengths set",i.mode=30;break}i.have=0,i.mode=19;case 19:for(;i.have<i.nlen+i.ndist;){for(;E=(D=i.lencode[C&(1<<i.lenbits)-1])>>>16&255,L=65535&D,!((S=D>>>24)<=y);){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(L<16)C>>>=S,y-=S,i.lens[i.have++]=L;else{if(16===L){for(I=S+2;y<I;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(C>>>=S,y-=S,0===i.have){e.msg="invalid bit length repeat",i.mode=30;break}R=i.lens[i.have-1],_=3+(3&C),C>>>=2,y-=2}else if(17===L){for(I=S+3;y<I;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}y-=S,R=0,_=3+(7&(C>>>=S)),C>>>=3,y-=3}else{for(I=S+7;y<I;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}y-=S,R=0,_=11+(127&(C>>>=S)),C>>>=7,y-=7}if(i.have+_>i.nlen+i.ndist){e.msg="invalid bit length repeat",i.mode=30;break}for(;_--;)i.lens[i.have++]=R}}if(30===i.mode)break;if(0===i.lens[256]){e.msg="invalid code -- missing end-of-block",i.mode=30;break}if(i.lenbits=9,O={bits:i.lenbits},T=s(1,i.lens,0,i.nlen,i.lencode,0,i.work,O),i.lenbits=O.bits,T){e.msg="invalid literal/lengths set",i.mode=30;break}if(i.distbits=6,i.distcode=i.distdyn,O={bits:i.distbits},T=s(2,i.lens,i.nlen,i.ndist,i.distcode,0,i.work,O),i.distbits=O.bits,T){e.msg="invalid distances set",i.mode=30;break}if(i.mode=20,6===t)break e;case 20:i.mode=21;case 21:if(6<=f&&258<=b){e.next_out=u,e.avail_out=b,e.next_in=h,e.avail_in=f,i.hold=C,i.bits=y,a(e,w),u=e.next_out,c=e.output,b=e.avail_out,h=e.next_in,d=e.input,f=e.avail_in,C=i.hold,y=i.bits,12===i.mode&&(i.back=-1);break}for(i.back=0;E=(D=i.lencode[C&(1<<i.lenbits)-1])>>>16&255,L=65535&D,!((S=D>>>24)<=y);){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(E&&0==(240&E)){for($=S,P=E,B=L;E=(D=i.lencode[B+((C&(1<<$+P)-1)>>$)])>>>16&255,L=65535&D,!($+(S=D>>>24)<=y);){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}C>>>=$,y-=$,i.back+=$}if(C>>>=S,y-=S,i.back+=S,i.length=L,0===E){i.mode=26;break}if(32&E){i.back=-1,i.mode=12;break}if(64&E){e.msg="invalid literal/length code",i.mode=30;break}i.extra=15&E,i.mode=22;case 22:if(i.extra){for(I=i.extra;y<I;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.length+=C&(1<<i.extra)-1,C>>>=i.extra,y-=i.extra,i.back+=i.extra}i.was=i.length,i.mode=23;case 23:for(;E=(D=i.distcode[C&(1<<i.distbits)-1])>>>16&255,L=65535&D,!((S=D>>>24)<=y);){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(0==(240&E)){for($=S,P=E,B=L;E=(D=i.distcode[B+((C&(1<<$+P)-1)>>$)])>>>16&255,L=65535&D,!($+(S=D>>>24)<=y);){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}C>>>=$,y-=$,i.back+=$}if(C>>>=S,y-=S,i.back+=S,64&E){e.msg="invalid distance code",i.mode=30;break}i.offset=L,i.extra=15&E,i.mode=24;case 24:if(i.extra){for(I=i.extra;y<I;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}i.offset+=C&(1<<i.extra)-1,C>>>=i.extra,y-=i.extra,i.back+=i.extra}if(i.offset>i.dmax){e.msg="invalid distance too far back",i.mode=30;break}i.mode=25;case 25:if(0===b)break e;if(_=w-b,i.offset>_){if((_=i.offset-_)>i.whave&&i.sane){e.msg="invalid distance too far back",i.mode=30;break}k=_>i.wnext?(_-=i.wnext,i.wsize-_):i.wnext-_,_>i.length&&(_=i.length),M=i.window}else M=c,k=u-i.offset,_=i.length;for(b<_&&(_=b),b-=_,i.length-=_;c[u++]=M[k++],--_;);0===i.length&&(i.mode=21);break;case 26:if(0===b)break e;c[u++]=i.length,b--,i.mode=21;break;case 27:if(i.wrap){for(;y<32;){if(0===f)break e;f--,C|=d[h++]<<y,y+=8}if(w-=b,e.total_out+=w,i.total+=w,w&&(e.adler=i.check=i.flags?r(i.check,c,w,u-w):o(i.check,c,w,u-w)),w=b,(i.flags?C:l(C))!==i.check){e.msg="incorrect data check",i.mode=30;break}y=C=0}i.mode=28;case 28:if(i.wrap&&i.flags){for(;y<32;){if(0===f)break e;f--,C+=d[h++]<<y,y+=8}if(C!==(4294967295&i.total)){e.msg="incorrect length check",i.mode=30;break}y=C=0}i.mode=29;case 29:T=1;break e;case 30:T=-3;break e;case 31:return -4;default:return -2}return e.next_out=u,e.avail_out=b,e.next_in=h,e.avail_in=f,i.hold=C,i.bits=y,(i.wsize||w!==e.avail_out&&i.mode<30&&(i.mode<27||4!==t))&&v(e,e.output,e.next_out,w-e.avail_out)?(i.mode=31,-4):(x-=e.avail_in,w-=e.avail_out,e.total_in+=x,e.total_out+=w,i.total+=w,i.wrap&&w&&(e.adler=i.check=i.flags?r(i.check,c,w,e.next_out-w):o(i.check,c,w,e.next_out-w)),e.data_type=i.bits+(i.last?64:0)+(12===i.mode?128:0)+(20===i.mode||15===i.mode?256:0),(0==x&&0===w||4===t)&&0===T&&(T=-5),T)},i.inflateEnd=function(e){if(!e||!e.state)return -2;var t=e.state;return t.window&&(t.window=null),e.state=null,0},i.inflateGetHeader=function(e,t){var i;return e&&e.state?0==(2&(i=e.state).wrap)?-2:((i.head=t).done=!1,0):-2},i.inflateSetDictionary=function(e,t){var i,n=t.length;return e&&e.state?0!==(i=e.state).wrap&&11!==i.mode?-2:11===i.mode&&o(1,t,n,0)!==i.check?-3:v(e,t,n,n)?(i.mode=31,-4):(i.havedict=1,0):-2},i.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,t,i){"use strict";var n=e("../utils/common"),o=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],s=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];t.exports=function(e,t,i,l,d,c,h,u){var f,p,g,m,v,b,C,y,x,w=u.bits,_=0,k=0,M=0,S=0,E=0,L=0,$=0,P=0,B=0,R=0,T=null,O=0,I=new n.Buf16(16),D=new n.Buf16(16),z=null,A=0;for(_=0;_<=15;_++)I[_]=0;for(k=0;k<l;k++)I[t[i+k]]++;for(E=w,S=15;1<=S&&0===I[S];S--);if(S<E&&(E=S),0===S)return d[c++]=20971520,d[c++]=20971520,u.bits=1,0;for(M=1;M<S&&0===I[M];M++);for(E<M&&(E=M),_=P=1;_<=15;_++)if(P<<=1,(P-=I[_])<0)return -1;if(0<P&&(0===e||1!==S))return -1;for(D[1]=0,_=1;_<15;_++)D[_+1]=D[_]+I[_];for(k=0;k<l;k++)0!==t[i+k]&&(h[D[t[i+k]]++]=k);if(b=0===e?(T=z=h,19):1===e?(T=o,O-=257,z=r,A-=257,256):(T=a,z=s,-1),_=M,v=c,$=k=R=0,g=-1,m=(B=1<<(L=E))-1,1===e&&852<B||2===e&&592<B)return 1;for(;;){for(C=_-$,x=h[k]<b?(y=0,h[k]):h[k]>b?(y=z[A+h[k]],T[O+h[k]]):(y=96,0),f=1<<_-$,M=p=1<<L;d[v+(R>>$)+(p-=f)]=C<<24|y<<16|x|0,0!==p;);for(f=1<<_-1;R&f;)f>>=1;if(0!==f?(R&=f-1,R+=f):R=0,k++,0==--I[_]){if(_===S)break;_=t[i+h[k]]}if(E<_&&(R&m)!==g){for(0===$&&($=E),v+=M,P=1<<(L=_-$);L+$<S&&!((P-=I[L+$])<=0);)L++,P<<=1;if(B+=1<<L,1===e&&852<B||2===e&&592<B)return 1;d[g=R&m]=E<<24|L<<16|v-c|0}}return 0!==R&&(d[v+R]=_-$<<24|4194304),u.bits=E,0}},{"../utils/common":41}],51:[function(e,t,i){"use strict";t.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,t,i){"use strict";var n=e("../utils/common");function o(e){for(var t=e.length;0<=--t;)e[t]=0}var r=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],a=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],s=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],l=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],d=Array(576);o(d);var c=Array(60);o(c);var h=Array(512);o(h);var u=Array(256);o(u);var f=Array(29);o(f);var p,g,m,v=Array(30);function b(e,t,i,n,o){this.static_tree=e,this.extra_bits=t,this.extra_base=i,this.elems=n,this.max_length=o,this.has_stree=e&&e.length}function C(e,t){this.dyn_tree=e,this.max_code=0,this.stat_desc=t}function y(e){return e<256?h[e]:h[256+(e>>>7)]}function x(e,t){e.pending_buf[e.pending++]=255&t,e.pending_buf[e.pending++]=t>>>8&255}function w(e,t,i){e.bi_valid>16-i?(e.bi_buf|=t<<e.bi_valid&65535,x(e,e.bi_buf),e.bi_buf=t>>16-e.bi_valid,e.bi_valid+=i-16):(e.bi_buf|=t<<e.bi_valid&65535,e.bi_valid+=i)}function _(e,t,i){w(e,i[2*t],i[2*t+1])}function k(e,t){for(var i=0;i|=1&e,e>>>=1,i<<=1,0<--t;);return i>>>1}function M(e,t,i){var n,o,r=Array(16),a=0;for(n=1;n<=15;n++)r[n]=a=a+i[n-1]<<1;for(o=0;o<=t;o++){var s=e[2*o+1];0!==s&&(e[2*o]=k(r[s]++,s))}}function S(e){var t;for(t=0;t<286;t++)e.dyn_ltree[2*t]=0;for(t=0;t<30;t++)e.dyn_dtree[2*t]=0;for(t=0;t<19;t++)e.bl_tree[2*t]=0;e.dyn_ltree[512]=1,e.opt_len=e.static_len=0,e.last_lit=e.matches=0}function E(e){8<e.bi_valid?x(e,e.bi_buf):0<e.bi_valid&&(e.pending_buf[e.pending++]=e.bi_buf),e.bi_buf=0,e.bi_valid=0}function L(e,t,i,n){var o=2*t,r=2*i;return e[o]<e[r]||e[o]===e[r]&&n[t]<=n[i]}function $(e,t,i){for(var n=e.heap[i],o=i<<1;o<=e.heap_len&&(o<e.heap_len&&L(t,e.heap[o+1],e.heap[o],e.depth)&&o++,!L(t,n,e.heap[o],e.depth));)e.heap[i]=e.heap[o],i=o,o<<=1;e.heap[i]=n}function P(e,t,i){var n,o,s,l,d=0;if(0!==e.last_lit)for(;n=e.pending_buf[e.d_buf+2*d]<<8|e.pending_buf[e.d_buf+2*d+1],o=e.pending_buf[e.l_buf+d],d++,0===n?_(e,o,t):(_(e,(s=u[o])+256+1,t),0!==(l=r[s])&&w(e,o-=f[s],l),_(e,s=y(--n),i),0!==(l=a[s])&&w(e,n-=v[s],l)),d<e.last_lit;);_(e,256,t)}function B(e,t){var i,n,o,r=t.dyn_tree,a=t.stat_desc.static_tree,s=t.stat_desc.has_stree,l=t.stat_desc.elems,d=-1;for(e.heap_len=0,e.heap_max=573,i=0;i<l;i++)0!==r[2*i]?(e.heap[++e.heap_len]=d=i,e.depth[i]=0):r[2*i+1]=0;for(;e.heap_len<2;)r[2*(o=e.heap[++e.heap_len]=d<2?++d:0)]=1,e.depth[o]=0,e.opt_len--,s&&(e.static_len-=a[2*o+1]);for(t.max_code=d,i=e.heap_len>>1;1<=i;i--)$(e,r,i);for(o=l;i=e.heap[1],e.heap[1]=e.heap[e.heap_len--],$(e,r,1),n=e.heap[1],e.heap[--e.heap_max]=i,e.heap[--e.heap_max]=n,r[2*o]=r[2*i]+r[2*n],e.depth[o]=(e.depth[i]>=e.depth[n]?e.depth[i]:e.depth[n])+1,r[2*i+1]=r[2*n+1]=o,e.heap[1]=o++,$(e,r,1),2<=e.heap_len;);e.heap[--e.heap_max]=e.heap[1],function(e,t){var i,n,o,r,a,s,l=t.dyn_tree,d=t.max_code,c=t.stat_desc.static_tree,h=t.stat_desc.has_stree,u=t.stat_desc.extra_bits,f=t.stat_desc.extra_base,p=t.stat_desc.max_length,g=0;for(r=0;r<=15;r++)e.bl_count[r]=0;for(l[2*e.heap[e.heap_max]+1]=0,i=e.heap_max+1;i<573;i++)p<(r=l[2*l[2*(n=e.heap[i])+1]+1]+1)&&(r=p,g++),l[2*n+1]=r,d<n||(e.bl_count[r]++,a=0,f<=n&&(a=u[n-f]),s=l[2*n],e.opt_len+=s*(r+a),h&&(e.static_len+=s*(c[2*n+1]+a)));if(0!==g){do{for(r=p-1;0===e.bl_count[r];)r--;e.bl_count[r]--,e.bl_count[r+1]+=2,e.bl_count[p]--,g-=2}while(0<g);for(r=p;0!==r;r--)for(n=e.bl_count[r];0!==n;)d<(o=e.heap[--i])||(l[2*o+1]!==r&&(e.opt_len+=(r-l[2*o+1])*l[2*o],l[2*o+1]=r),n--)}}(e,t),M(r,d,e.bl_count)}function R(e,t,i){var n,o,r=-1,a=t[1],s=0,l=7,d=4;for(0===a&&(l=138,d=3),t[2*(i+1)+1]=65535,n=0;n<=i;n++)o=a,a=t[2*(n+1)+1],++s<l&&o===a||(s<d?e.bl_tree[2*o]+=s:0!==o?(o!==r&&e.bl_tree[2*o]++,e.bl_tree[32]++):s<=10?e.bl_tree[34]++:e.bl_tree[36]++,r=o,d=(s=0)===a?(l=138,3):o===a?(l=6,3):(l=7,4))}function T(e,t,i){var n,o,r=-1,a=t[1],s=0,l=7,d=4;for(0===a&&(l=138,d=3),n=0;n<=i;n++)if(o=a,a=t[2*(n+1)+1],!(++s<l&&o===a)){if(s<d)for(;_(e,o,e.bl_tree),0!=--s;);else 0!==o?(o!==r&&(_(e,o,e.bl_tree),s--),_(e,16,e.bl_tree),w(e,s-3,2)):s<=10?(_(e,17,e.bl_tree),w(e,s-3,3)):(_(e,18,e.bl_tree),w(e,s-11,7));r=o,d=(s=0)===a?(l=138,3):o===a?(l=6,3):(l=7,4)}}o(v);var O=!1;function I(e,t,i,o){var r;w(e,0+(o?1:0),3),E(r=e),x(r,i),x(r,~i),n.arraySet(r.pending_buf,r.window,t,i,r.pending),r.pending+=i}i._tr_init=function(e){O||(function(){var e,t,i,n,o,l=Array(16);for(n=i=0;n<28;n++)for(f[n]=i,e=0;e<1<<r[n];e++)u[i++]=n;for(u[i-1]=n,n=o=0;n<16;n++)for(v[n]=o,e=0;e<1<<a[n];e++)h[o++]=n;for(o>>=7;n<30;n++)for(v[n]=o<<7,e=0;e<1<<a[n]-7;e++)h[256+o++]=n;for(t=0;t<=15;t++)l[t]=0;for(e=0;e<=143;)d[2*e+1]=8,e++,l[8]++;for(;e<=255;)d[2*e+1]=9,e++,l[9]++;for(;e<=279;)d[2*e+1]=7,e++,l[7]++;for(;e<=287;)d[2*e+1]=8,e++,l[8]++;for(M(d,287,l),e=0;e<30;e++)c[2*e+1]=5,c[2*e]=k(e,5);p=new b(d,r,257,286,15),g=new b(c,a,0,30,15),m=new b([],s,0,19,7)}(),O=!0),e.l_desc=new C(e.dyn_ltree,p),e.d_desc=new C(e.dyn_dtree,g),e.bl_desc=new C(e.bl_tree,m),e.bi_buf=0,e.bi_valid=0,S(e)},i._tr_stored_block=I,i._tr_flush_block=function(e,t,i,n){var o,r,a=0;0<e.level?(2===e.strm.data_type&&(e.strm.data_type=function(e){var t,i=4093624447;for(t=0;t<=31;t++,i>>>=1)if(1&i&&0!==e.dyn_ltree[2*t])return 0;if(0!==e.dyn_ltree[18]||0!==e.dyn_ltree[20]||0!==e.dyn_ltree[26])return 1;for(t=32;t<256;t++)if(0!==e.dyn_ltree[2*t])return 1;return 0}(e)),B(e,e.l_desc),B(e,e.d_desc),a=function(e){var t;for(R(e,e.dyn_ltree,e.l_desc.max_code),R(e,e.dyn_dtree,e.d_desc.max_code),B(e,e.bl_desc),t=18;3<=t&&0===e.bl_tree[2*l[t]+1];t--);return e.opt_len+=3*(t+1)+5+5+4,t}(e),o=e.opt_len+3+7>>>3,(r=e.static_len+3+7>>>3)<=o&&(o=r)):o=r=i+5,i+4<=o&&-1!==t?I(e,t,i,n):4===e.strategy||r===o?(w(e,2+(n?1:0),3),P(e,d,c)):(w(e,4+(n?1:0),3),function(e,t,i,n){var o;for(w(e,t-257,5),w(e,i-1,5),w(e,n-4,4),o=0;o<n;o++)w(e,e.bl_tree[2*l[o]+1],3);T(e,e.dyn_ltree,t-1),T(e,e.dyn_dtree,i-1)}(e,e.l_desc.max_code+1,e.d_desc.max_code+1,a+1),P(e,e.dyn_ltree,e.dyn_dtree)),S(e),n&&E(e)},i._tr_tally=function(e,t,i){return e.pending_buf[e.d_buf+2*e.last_lit]=t>>>8&255,e.pending_buf[e.d_buf+2*e.last_lit+1]=255&t,e.pending_buf[e.l_buf+e.last_lit]=255&i,e.last_lit++,0===t?e.dyn_ltree[2*i]++:(e.matches++,t--,e.dyn_ltree[2*(u[i]+256+1)]++,e.dyn_dtree[2*y(t)]++),e.last_lit===e.lit_bufsize-1},i._tr_align=function(e){var t;w(e,2,3),_(e,256,d),16===(t=e).bi_valid?(x(t,t.bi_buf),t.bi_buf=0,t.bi_valid=0):8<=t.bi_valid&&(t.pending_buf[t.pending++]=255&t.bi_buf,t.bi_buf>>=8,t.bi_valid-=8)}},{"../utils/common":41}],53:[function(e,t,i){"use strict";t.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,t,n){(function(e){!function(e,t){"use strict";if(!e.setImmediate){var i,n,r,a,s=1,l={},d=!1,c=e.document,h=Object.getPrototypeOf&&Object.getPrototypeOf(e);h=h&&h.setTimeout?h:e,i="[object process]"===({}).toString.call(e.process)?function(e){o.nextTick(function(){f(e)})}:!function(){if(e.postMessage&&!e.importScripts){var t=!0,i=e.onmessage;return e.onmessage=function(){t=!1},e.postMessage("","*"),e.onmessage=i,t}}()?e.MessageChannel?((r=new MessageChannel).port1.onmessage=function(e){f(e.data)},function(e){r.port2.postMessage(e)}):c&&"onreadystatechange"in c.createElement("script")?(n=c.documentElement,function(e){var t=c.createElement("script");t.onreadystatechange=function(){f(e),t.onreadystatechange=null,n.removeChild(t),t=null},n.appendChild(t)}):function(e){setTimeout(f,0,e)}:(a="setImmediate$"+Math.random()+"$",e.addEventListener?e.addEventListener("message",p,!1):e.attachEvent("onmessage",p),function(t){e.postMessage(a+t,"*")}),h.setImmediate=function(e){"function"!=typeof e&&(e=Function(""+e));for(var t=Array(arguments.length-1),n=0;n<t.length;n++)t[n]=arguments[n+1];var o={callback:e,args:t};return l[s]=o,i(s),s++},h.clearImmediate=u}function u(e){delete l[e]}function f(e){if(d)setTimeout(f,0,e);else{var t=l[e];if(t){d=!0;try{!function(e){var t=e.callback,i=e.args;switch(i.length){case 0:t();break;case 1:t(i[0]);break;case 2:t(i[0],i[1]);break;case 3:t(i[0],i[1],i[2]);break;default:t.apply(void 0,i)}}(t)}finally{u(e),d=!1}}}}function p(t){t.source===e&&"string"==typeof t.data&&0===t.data.indexOf(a)&&f(+t.data.slice(a.length))}}("undefined"==typeof self?void 0===e?this:e:self)}).call(this,void 0!==i.g?i.g:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}]},{},[10])(10)},36976:function(e,t,i){"use strict";i.d(t,{rn:function(){return p},jd:function(){return v},p3:function(){return u.p3}});var n=i(45598),o=i(13246),r=i(91636),a=i(62623),s=i(280),l=i(7291),d=i(9288),c=i(903),h=i(70263),u=i(62554);i(27534);var f=i(13210);class p{constructor(e,t){this._onCut=e=>{if(!d.y.isActive(this._edgeless))return;e.preventDefault(),this._onCopy(e);let{state:t}=this.selection;if(t.active){(0,a.tD)(this._page);return}this._page.transact(()=>{t.selected.forEach(e=>{(0,r.Zi)(e)?this._page.deleteBlock(e):this.surface.removeElement(e.id)})}),this.slots.selectionUpdated.emit({active:!1,selected:[]})},this._onCopy=e=>{if(!d.y.isActive(this._edgeless))return;e.preventDefault();let{state:t}=this.selection;if(t.active){if(t.selected[0]instanceof n.Gy)(0,u.mM)(this._edgeless);else{let e=(0,c.zE)(this._page);(0,o.kP)(e),(0,u.p3)(e)}return}let i=t.selected.map(e=>(0,r.Zi)(e)?(0,u.mt)(e).json:e.serialize()).filter(e=>!!e),a=(0,f.fQ)(i);(0,f.O)(a)},this._onPaste=async e=>{if(!d.y.isActive(this._edgeless))return;e.preventDefault();let{state:t}=this.selection;if(t.active){t.selected[0]instanceof n.Gy||this._pasteInTextFrame(e);return}let i=(0,f.j$)(e);i&&this._pasteShapesAndFrames(i)},this._page=e,this._edgeless=t}init(e=this._page){this._page=e,document.body.addEventListener("cut",this._onCut),document.body.addEventListener("copy",this._onCopy),document.body.addEventListener("paste",this._onPaste)}get selection(){return this._edgeless.selection}get slots(){return this._edgeless.slots}get surface(){return this._edgeless.surface}dispose(){document.body.removeEventListener("cut",this._onCut),document.body.removeEventListener("copy",this._onCopy),document.body.removeEventListener("paste",this._onPaste)}async _pasteInTextFrame(e){let t=await (0,u.hA)(this._page,e.clipboardData);if(!t.length)return;this._page.captureSync(),(0,a.tD)(this._page);let i=(0,c.zE)(this._page),n=i?.models[0];(0,o.kP)(n);let r=(0,s.getService)(n.flavour);(0,o.kP)(i),await r.json2Block(n,t,i)}_createPhasorElements(e){let t=e?.map(e=>{let t=this.surface.addElement(e.type,e),i=this.surface.pickById(t);return i}).filter(e=>!!e)||[];return t}async _createFrameBlocks(e,t,i,a){let s=await Promise.all(e.map(async({xywh:e,children:s,background:d})=>{let[c,h,u,f]=e?(0,n.CV)(e):[a.x,a.y,r.xM,r.GB],p=(0,n.cJ)(t+c-a.x,i+h-a.y,u,f),g=this._page.addBlock("affine:frame",{xywh:p,background:d},this._page.root?.id),m=this._page.getBlockById(g);return(0,o.kP)(m),await (0,l.C)(this._page,s,m,0),g}));return s}_getOldCommonBound(e,t){let i=(0,n.ci)([...e,...t.map(({xywh:e})=>{if(!e)return;let[t,i,o,r]=(0,n.CV)(e);return{x:t,y:i,w:o,h:r}}).filter(e=>!!e)]);return(0,o.kP)(i),i}_emitSelectionChangeAfterPaste(e,t){let i=[...e.map(e=>this.surface.pickById(e)).filter(e=>!!e),...t.map(e=>this._page.getBlockById(e)).filter(e=>!!e&&"affine:frame"===e.flavour)];this.slots.selectionUpdated.emit({active:!1,selected:i})}async _pasteShapesAndFrames(e){let t=(0,h.vM)(e,e=>(0,r.Zi)(e)?"frames":"elements"),i=this._createPhasorElements(t.elements||[]),o=this._getOldCommonBound(i,t.frames||[]),{lastMousePos:a}=this.selection,[s,l]=this.surface.toModelCoord(a.x,a.y),d=s-o.w/2,c=l-o.h/2;i.forEach(e=>{let t=(0,n.cJ)(d+e.x-o.x,c+e.y-o.y,e.w,e.h);this.surface.updateElement(e.id,{xywh:t})});let u=await this._createFrameBlocks(t.frames||[],d,c,o);this._emitSelectionChangeAfterPaste(i.map(e=>e.id),u)}}var g=i(52933),m=i(65024);class v{constructor(e){this._onPaste=async e=>{if(!d.y.isActive(this._ele))return;let t=(0,m.zE)(this._page);if(!e.clipboardData||!t)return;e.preventDefault();let i=await (0,u.hA)(this._page,e.clipboardData),n=(0,u.P2)(this._page,i);if(!n.length)return;this._page.captureSync();let r=(0,g.tD)(this._page,t);(0,o.kP)(r);let a=(0,s.getService)(r.flavour);(0,o.kP)(t),await a.json2Block(r,n,t),this._page.captureSync(),this._page.slots.pasted.emit(i)},this._onCopy=(e,t=(0,m.zE)(this._page))=>{d.y.isActive(this._ele)&&t&&(e.preventDefault(),this._page.captureSync(),(0,u.p3)(t),this._page.captureSync(),this._page.slots.copied.emit())},this._onCut=e=>{if(!d.y.isActive(this._ele))return;let t=(0,m.zE)(this._page);t&&(e.preventDefault(),this._onCopy(e,t),(0,g.tD)(this._page,t))},this._ele=e}init(e){this._page=e,document.body.addEventListener("cut",this._onCut),document.body.addEventListener("copy",this._onCopy),document.body.addEventListener("paste",this._onPaste)}dispose(){document.body.removeEventListener("cut",this._onCut),document.body.removeEventListener("copy",this._onCopy),document.body.removeEventListener("paste",this._onPaste)}}},62554:function(e,t,i){"use strict";i.d(t,{AQ:function(){return f},P2:function(){return p},hA:function(){return u},mM:function(){return g},mt:function(){return c},p3:function(){return h}});var n=i(13246),o=i(34057),r=i(280),a=i(65024),s=i(78660),l=i(27534),d=i(13210);function c(e,t,i){let n=(0,r.getService)(e.flavour),o=n.block2html(e,{begin:t,end:i}),a=n.block2Text(e,{begin:t,end:i}),s=n.block2Json(e,t,i);return{html:o,text:a,json:s,model:e}}function h(e){let t=function(e){let t=e.models.map((t,i)=>0===i?c(t,e.startOffset,i===e.models.length-1?e.endOffset:void 0):i===e.models.length-1?c(t,void 0,e.endOffset):c(t)),i=JSON.stringify(t.filter(t=>!!t.json&&!function e(t,i){for(let n=0;n<t.length;n++){let o=t[n];if(o.children&&(o.children.findIndex(e=>e.id===i.id)>-1||e(o.children,i)))return!0}return!1}(e.models,t.model)).map(e=>e.json)),n=(0,d.g8)(i,d.L_.BLOCKSUITE_PAGE),o=new s.x(d.L_.TEXT,t.reduce((e,i,n)=>`${e}${i.text}${n===t.length-1?"":"\n"}`,"")),r=new s.x(d.L_.HTML,`${t.map(e=>e.html).join("")}${n}`),a=new s.x(d.L_.BLOCKSUITE_PAGE,i);return[o,r,a]}(e),i=(0,a.E7)()?(0,a.bR)():null;(0,d.O)(t),i&&(0,a.xT)(i)}async function u(e,t){if(!t)return[];let i=new o.F(e);if((0,d.Q2)(t))return i.file2Blocks(t);let n=t.getData(d.L_.HTML);if(n){let e=(0,d.wK)(d.L_.BLOCKSUITE_PAGE,t.getData(d.L_.HTML));if(e)return JSON.parse(e)}let r=t.getData(d.L_.TEXT),a=l.Z.checkIfTextContainsMd(r);return n&&!a?await i.htmlText2Block(n):a?await i.markdown2Block(r):i.text2blocks(r)}function f(e,t){let i=e.workspace.indexer.backlink;return t.forEach(e=>{if(!(e&&e.attributes&&e.attributes.reference&&"Subpage"===e.attributes.reference.type))return;let t=e.attributes.reference,n=i.getParentPage(t.pageId);n&&(e.attributes={...e.attributes,reference:{...t,type:"LinkedPage"}})}),t}function p(e,t){return t.filter(e=>e.text).forEach(t=>{f(e,t.text)}),t}function g(e){let t=e.querySelector("surface-text-editor");if(t){let e=t.vEditor;(0,n.kP)(e);let i=e.getVRange();if(i){let n=e.yText.toString().slice(i.index,i.index+i.length),o=new s.x(d.L_.TEXT,n);t.setKeeping(!0),(0,d.O)([o]),t.setKeeping(!1),e.rootElement.focus(),e.setVRange(i)}}}},27534:function(e,t,i){"use strict";class n{checkIfTextContainsMd(e){e=`

${e=(e=(e=(e=(e=e.replace(/¨/g,"\xa8T")).replace(/\$/g,"\xa8D")).replace(/\r\n/g,"\n")).replace(/\r/g,"\n")).replace(/\u00A0/g,"&nbsp;")}

`,e=n._detab(e);for(let t=0;t<n._checkRegArr.length;t++){let i=3===t?`${e}\xa80`:e;if(n._checkRegArr[t].test(i))return!0}return!1}static _detab(e){return e=(e=(e=(e=(e=e.replace(/\t(?=\t)/g," ")).replace(/\t/g,"\xa8A\xa8B")).replace(/¨B(.+?)¨A/g,(e,t)=>{let i=t,n=4-i.length%4;for(let e=0;e<n;e++)i+=" ";return i})).replace(/¨A/g," ")).replace(/¨B/g,"")}}n._checkRegArr=[/^(#{1,6})[ \t]*(.+?)[ \t]*#*\n+/gm,/^ {0,3}\|?.+\|.+\n {0,3}\|?[ \t]*:?[ \t]*(?:[-=]){2,}[ \t]*:?[ \t]*\|[ \t]*:?[ \t]*(?:[-=]){2,}[\s\S]+?(?:\n\n|¨0)/gm,/(?:^|\n)(?: {0,3})(```+|~~~+)(?: *)([^\s`~]*)\n([\s\S]*?)\n(?: {0,3})\1/g,/(\n\n|^\n?)(( {0,3}([*+-]|\d+[.])[ \t]+)[^\r]+?(¨0|\n{2,}(?=\S)(?![ \t]*(?:[*+-]|\d+[.])[ \t]+)))/gm,/!\[([^\]]*?)] ?(?:\n *)?\[([\s\S]*?)]()()()()()/g,/!\[([^\]]*?)][ \t]*()\([ \t]?<?([\S]+?(?:\([\S]*?\)[\S]*?)?)>?(?: =([*\d]+[A-Za-z%]{0,4})x([*\d]+[A-Za-z%]{0,4}))?[ \t]*(?:(["'])([^"]*?)\6)?[ \t]?\)/g,/!\[([^\]]*?)][ \t]*()\([ \t]?<([^>]*)>(?: =([*\d]+[A-Za-z%]{0,4})x([*\d]+[A-Za-z%]{0,4}))?[ \t]*(?:(?:(["'])([^"]*?)\6))?[ \t]?\)/g,/!\[([^\]]*?)][ \t]*()\([ \t]?<?(data:.+?\/.+?;base64,[A-Za-z0-9+/=\n]+?)>?(?: =([*\d]+[A-Za-z%]{0,4})x([*\d]+[A-Za-z%]{0,4}))?[ \t]*(?:(["'])([^"]*?)\6)?[ \t]?\)/g,/!\[([^\[\]]+)]()()()()()/g,/\[((?:\[[^\]]*]|[^\[\]])*)]()[ \t]*\([ \t]?<?([\S]+?(?:\([\S]*?\)[\S]*?)?)>?(?:[ \t]*((["'])([^"]*?)\5))?[ \t]?\)/g,/\[((?:\[[^\]]*]|[^\[\]])*)] ?(?:\n *)?\[(.*?)]()()()()/g,/\[((?:\[[^\]]*]|[^\[\]])*)]()[ \t]*\([ \t]?<([^>]*)>(?:[ \t]*((["'])([^"]*?)\5))?[ \t]?\)/g,/\[([^\[\]]+)]()()()()()/g],t.Z=new n},81366:function(e,t,i){"use strict";i.d(t,{$x:function(){return n.$x},AL:function(){return n.AL},De:function(){return n.De},Ds:function(){return n.Ds},E7:function(){return n.E7},E9:function(){return n.E9},FV:function(){return n.FV},GF:function(){return n.GF},HP:function(){return n.HP},I8:function(){return n.I8},IE:function(){return n.IE},JP:function(){return n.JP},KO:function(){return n.KO},Lb:function(){return n.Lb},Mb:function(){return n.Mb},Ne:function(){return n.Ne},Or:function(){return n.Or},P2:function(){return n.P2},Rn:function(){return n.Rn},Ty:function(){return n.Ty},U6:function(){return n.U6},UL:function(){return n.UL},YK:function(){return n.YK},YT:function(){return n.YT},Ye:function(){return n.Ye},ZT:function(){return n.ZT},_b:function(){return n._b},a6:function(){return n.a6},az:function(){return n.az},bQ:function(){return n.bQ},bR:function(){return n.bR},cP:function(){return n.cP},cS:function(){return n.cS},cy:function(){return n.cy},d2:function(){return n.d2},dA:function(){return n.dA},e1:function(){return n.e1},ev:function(){return n.ev},fl:function(){return n.fl},gc:function(){return n.gc},gj:function(){return n.gj},hK:function(){return n.hK},hY:function(){return n.hY},im:function(){return n.im},jR:function(){return n.jR},jo:function(){return n.jo},jx:function(){return n.jx},k:function(){return n.k},kK:function(){return n.kK},lK:function(){return n.lK},lN:function(){return n.lN},mw:function(){return n.mw},nE:function(){return n.nE},nF:function(){return n.nF},ok:function(){return n.ok},r3:function(){return n.r3},rc:function(){return n.rc},rr:function(){return n.rr},tq:function(){return n.tq},uZ:function(){return n.uZ},us:function(){return n.us},w_:function(){return n.w_},xT:function(){return n.xT},xb:function(){return n.xb},yM:function(){return n.yM},yd:function(){return n.yd},zE:function(){return n.zE},zl:function(){return n.zl},zv:function(){return n.zv}});var n=i(65024)},36687:function(e,t,i){"use strict";var n=i(92758),o=i(31054),r=i(50634),a=i(29113),s=i(15486),l=i(32916),d=i(91827),c=i(30597),h=i(65024),u=i(65938),f=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let p=class extends r.Zi{get link(){let e=this.delta.attributes?.link;return e||""}constructor(){super(),this.delta={insert:a.$m},this.popoverHoverOpenDelay=150,this._popoverTimer=0,this._isHovering=!1,this.addEventListener("mouseenter",this.onHover),this.addEventListener("mouseleave",this._onHoverEnd)}onHover(e){if(this._isHovering)return;this._isHovering=!0;let t=(0,h.mt)(this);t.page.readonly||(this._popoverTimer=window.setTimeout(()=>{this.onDelayHover(e)},this.popoverHoverOpenDelay))}async onDelayHover(e){if(!(e.target instanceof HTMLElement)||!document.contains(e.target))return;let t=(0,h.mt)(this),i=this.delta.insert,n=await (0,c.A)({anchorEl:e.target,page:t.page,text:i,link:this.link,showMask:!1,interactionKind:"hover"});if("confirm"===n.type){let e=n.link,t=n.text;this._updateLink(e,t!==i?t:void 0);return}if("remove"===n.type){this._updateLink();return}if("toBookmark"===n.type){this._onConvertToBookmark();return}}_updateLink(e,t){let i=(0,h.mt)(this),{page:n}=i,r=this.delta.insert,s=this.delta.attributes,l=this.querySelector('[data-virgo-text="true"]');(0,o.kP)(l);let d=Array.from(l.childNodes).find(e=>e instanceof Text);(0,o.kP)(d);let c=this.closest("rich-text");(0,o.kP)(c);let u=a.gX.textPointToDomPoint(d,0,c.virgoContainer);(0,o.kP)(u);let f=c.vEditor;if((0,o.kP)(f),e)t?(n.captureSync(),f.deleteText({index:u.index,length:d.length}),f.insertText({index:u.index,length:0},t),f.formatText({index:u.index,length:t.length},{link:e})):(n.captureSync(),f.formatText({index:u.index,length:r.length},{link:e}));else{n.captureSync();let e={...s};delete e.link,f.formatText({index:u.index,length:r.length},e,{mode:"replace"})}}_onConvertToBookmark(){let e=(0,h.mt)(this),{page:t}=e,i=this.querySelector('[data-virgo-text="true"]');(0,o.kP)(i);let n=Array.from(i.childNodes).find(e=>e instanceof Text);(0,o.kP)(n);let r=this.closest("rich-text");(0,o.kP)(r);let s=a.gX.textPointToDomPoint(n,0,r.virgoContainer);(0,o.kP)(s);let l=r.vEditor;(0,o.kP)(l);let d=t.getParent(e);(0,o.kP)(d);let c=d.children.indexOf(e);t.addBlock("affine:bookmark",{url:this.link,title:this.delta.insert},d,c+1),l.deleteText({index:s.index,length:n.length})}_onHoverEnd(e){this._isHovering=!1,clearTimeout(this._popoverTimer)}_onMouseUp(e){let t=this.querySelector("a");(0,o.kP)(t),t.isContentEditable&&(t.contentEditable="false",setTimeout(()=>{t.removeAttribute("contenteditable")},0))}render(){let e=this.delta.attributes?(0,u.O)(this.delta.attributes):(0,d.V)({});return s.dy`<a
      href=${this.link}
      rel="noopener noreferrer"
      target="_blank"
      style=${e}
      @mouseup=${this._onMouseUp}
      >${n.E}<v-text .str=${this.delta.insert}></v-text
    ></a>`}};p.styles=s.iv`
    affine-link > a {
      white-space: nowrap;
      word-break: break-word;
      color: var(--affine-link-color);
      fill: var(--affine-link-color);
      text-decoration: none;
      cursor: pointer;
    }

    affine-link > a:hover [data-virgo-text='true'] {
      text-decoration: underline;
    }

    affine-link > a > v-text {
      white-space: break-spaces;
    }
  `,f([(0,l.Cb)({type:Object})],p.prototype,"delta",void 0),f([(0,l.Cb)()],p.prototype,"popoverHoverOpenDelay",void 0),f([(0,l.SB)()],p.prototype,"_popoverTimer",void 0),f([(0,l.Mo)("affine-link")],p)},98094:function(e,t,i){"use strict";i.d(t,{E:function(){return h}}),i(36687);var n=i(31054),o=i(30597),r=i(903),a=i(65024),s=i(15486),l=i(32916),d=i(91827);let c=class extends s.oi{constructor(e){super(),this.rects=e}render(){return s.dy`
      ${this.rects.map(e=>s.dy`<div
          style="${(0,d.V)({position:"absolute",width:`${e.width}px`,height:`${e.height}px`,top:`${e.top}px`,left:`${e.left}px`,backgroundColor:"rgba(35, 131, 226, 0.28)"})}"
        ></div>`)}
    `}};function h(e){let t=(0,r.zE)(e);if(!t)return;if(t.models.length>1)throw Error("Can't create link with multiple blocks for now");let i=t.models[0];if(!i)return;let s=(0,a.gj)(i);(0,n.kP)(s);let l={index:t.startOffset,length:t.endOffset-t.startOffset};if(0===l.length)return;let d=s.getFormat(l);if(d.link){e.captureSync(),s.formatText(l,{link:null}),s.setVRange(l);return}let h=(0,r.yd)(t);(0,n.kP)(h);let u=Array.from(h.getClientRects()),f=(0,a.VA)(e);(0,n.kP)(f);let p=f.getBoundingClientRect(),g=new c(u.map(e=>new DOMRect(e.left-p.left,e.top-p.top,e.width,e.height))),m=(0,a.VA)(e);(0,n.kP)(m),m.appendChild(g),setTimeout(async()=>{let t=await (0,o.A)({anchorEl:g.shadowRoot?.querySelector("div"),page:e});if(g.remove(),"confirm"!==t.type)return;let i=t.link;e.captureSync(),s.formatText(l,{link:i}),s.setVRange(l)})}c=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,l.Mo)("link-mock-selection")],c)},55410:function(e,t,i){"use strict";i.d(t,{O:function(){return u}});var n=i(92758),o=i(31054),r=i(50634),a=i(29113),s=i(15486),l=i(32916),d=i(65024),c=i(65938),h=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let u=" ",f=class extends(0,r.$T)(r.Zi){constructor(){super(...arguments),this.delta={insert:a.$m,attributes:{}},this._refAttribute={type:"LinkedPage",pageId:"0"},this._updateRefMeta=e=>{let t=this.delta.attributes?.reference;(0,o.kP)(t,"Failed to get reference attribute!"),this._refAttribute=t,this._refMeta=e.workspace.meta.pageMetas.find(e=>e.id===t.pageId)}}connectedCallback(){super.connectedCallback(),this.delta.insert!==u&&console.error(`Reference node must be initialized with '${u}', but got '${this.delta.insert}'`);let e=(0,d.mt)(this),t=e.page;this._updateRefMeta(t),this._disposables.add(e.page.workspace.slots.pagesUpdated.on(()=>this._updateRefMeta(t)))}_onClick(e){let t=this._refMeta,i=(0,d.mt)(this);if(!t){console.warn("The page is deleted",this._refAttribute.pageId);return}if(t.id===i.page.id)return;let n=t.id,r=i.page.root;(0,o.kP)(r);let a=(0,d.cP)(r?.id);(0,o.kP)(a),a.slots.pageLinkClicked.emit({pageId:n})}render(){let e=this._refMeta,t=!e,i=t?"Deleted page":e.title,r=this.delta.attributes;(0,o.kP)(r,"Failed to get attributes!");let l=r.reference?.type;(0,o.kP)(l,"Unable to get reference type!");let d=(0,c.O)(r,t?{color:"var(--affine-text-disable-color)",fill:"var(--affine-text-disable-color)"}:{});return s.dy`<span
      class="affine-reference"
      style=${d}
      @click=${this._onClick}
      >${"LinkedPage"===l?n.eG:n.H0}<span
        class="affine-reference-title"
        data-title=${i||"Untitled"}
        data-virgo-text="true"
        data-virgo-text-value=${a.Sj}
        >${a.Sj}</span
      ></span
    >`}};f.styles=s.iv`
    .affine-reference {
      white-space: nowrap;
      word-break: break-word;
      color: var(--affine-link-color);
      fill: var(--affine-link-color);
      border-radius: 2px;
      text-decoration: none;
      cursor: pointer;
      user-select: none;
      padding: 0 2px;
      margin: 0 2px;
    }
    .affine-reference:hover {
      background: var(--affine-hover-color);
    }

    .affine-reference > svg {
      margin-right: 4px;
    }

    .affine-reference > span {
      white-space: break-spaces;
    }

    .affine-reference-title {
      color: var(--affine-text-primary-color);
    }
    .affine-reference-title::before {
      content: attr(data-title);
      color: var(--affine-link-color);
    }
  `,h([(0,l.Cb)({type:Object})],f.prototype,"delta",void 0),h([(0,l.SB)()],f.prototype,"_refMeta",void 0),h([(0,l.Mo)("affine-reference")],f)},50217:function(e,t,i){"use strict";i.r(t),i.d(t,{handleBlockEndEnter:function(){return h},handleBlockSplit:function(){return f},handleIndent:function(){return p},handleKeyDown:function(){return C},handleKeyUp:function(){return b},handleLineStartBackspace:function(){return v},handleMultiBlockIndent:function(){return g},handleSoftEnter:function(){return u},handleUnindent:function(){return m}});var n=i(67072),o=i(31054),r=i(13246),a=i(42424),s=i(68389),l=i(48616),d=i(63989),c=i(70263);function h(e,t){let i=e.getParent(t),n=e.getNextSibling(t);if(!i)return;let[a,l]=(()=>{let e=(0,o.h$)(t,["affine:list"]);return e?[t.flavour,{type:t.type}]:["affine:paragraph",{type:"text"}]})();if(r.cQ.isInsideBlockByFlavour(e,t,"affine:database")){e.captureSync();let n=i.children.findIndex(e=>e.id===t.id),r=i,d=n+1,c=i.children.length;if(n===c-1&&0===t.text?.yText.length){1!==c&&e.deleteBlock(t);let n=e.getNextSibling(r);if(n&&(0,o.h$)(n,["affine:paragraph"])){(0,s.a6)(e,n.id,{index:n.text.yText.length,length:0});return}let a=e.getParent(i);if(!a)return;let l=a.children.findIndex(e=>e.id===i.id);r=a,d=l+1}let h=e.addBlock(a,l,r,d);(0,s.a6)(e,h);return}let d=i.children.indexOf(t);if(-1===d)return;e.captureSync();let c=t.children.length?e.addBlock(a,l,t,0):e.addBlock(a,l,i,d+1);if((0,o.h$)(t,["affine:list"])&&"numbered"===t.type){let i=n;for(;i&&(0,o.h$)(i,["affine:list"])&&"numbered"===t.type;)e.updateBlock(i,{}),i=e.getNextSibling(i)}(0,s.a6)(e,c)}function u(e,t,i,n){if(!t.text){console.error("Failed to handle soft enter! No text found!",t);return}e.captureSync(),t.text.replace(i,n,"\n")}function f(e,t,i,n){if(!(t.text instanceof r.xv)||t.text.yText.length<i+n)return;let a=e.getParent(t);if(!a)return;e.captureSync();let l=t.text.split(i,n),d=a,c=d.children.indexOf(t)+1;(0,o.h$)(t,["affine:list"])&&t.children.length>0&&(d=t,c=0);let h=[...t.children];e.updateBlock(t,{children:[]});let u=e.addBlock(t.flavour,{text:l,type:t.type,children:h},d,c);return(0,s.a6)(e,u)}function p(e,t,i=0){let n=e.getPreviousSibling(t),r=e.getNextSibling(t);if(!n||!(0,c.$v)(n))return;let a=e.getParent(t);if(!a)return;e.captureSync();let l=t.children;if(e.updateBlock(t,{children:[]}),e.updateBlock(a,{children:a.children.filter(e=>e.id!==t.id)}),e.updateBlock(n,{children:[...n.children,t,...l]}),(0,o.h$)(t,["affine:list"])&&"numbered"===t.type){let i=r;for(;i&&(0,o.h$)(i,["affine:list"])&&"numbered"===t.type;)e.updateBlock(i,{}),i=e.getNextSibling(i)}(0,o.kP)(t),(0,s.kH)(t,{index:i,length:0})}function g(e,t){if(!t.length)return;let i=e.getPreviousSibling(t[0]),n=e.getNextSibling(t.at(-1));if(!i||!(0,c.$v)(i)||!t.every((t,i,n)=>{let o=n.at(i-1);if(!o)return!1;let r=e.getParent(t),a=e.getParent(o);return r&&a&&r.id===a.id}))return;e.captureSync();let r=e.getParent(t[0]);(0,o.kP)(r),t.forEach(t=>{let a=t.children;if(e.updateBlock(t,{children:[]}),e.updateBlock(r,{children:r.children.filter(e=>e.id!==t.id)}),e.updateBlock(i,{children:[...i.children,t,...a]}),(0,o.h$)(t,["affine:list"])&&"numbered"===t.type){let i=n;for(;i&&(0,o.h$)(i,["affine:list"])&&"numbered"===t.type;)e.updateBlock(i,{}),i=e.getNextSibling(i)}(0,o.kP)(t),(0,s.kH)(t,{index:0,length:0})})}function m(e,t,i=0,n=!0){let r=e.getParent(t);if(!r||(0,o.h$)(r,["affine:frame"]))return;let a=e.getParent(r);if(!a)return;n&&e.captureSync();let l=e.getPreviousSiblings(t),d=e.getNextSiblings(t);e.updateBlock(r,{children:l});let c=a.children.indexOf(r);e.updateBlock(a,{children:[...a.children.slice(0,c+1),t,...a.children.slice(c+1)]}),e.updateBlock(t,{children:[...t.children,...d]});let h=e.getNextSibling(t);if((0,o.h$)(t,["affine:list"])&&"numbered"===t.type){let i=h;for(;i&&(0,o.h$)(i,["affine:list"])&&"numbered"===t.type;)e.updateBlock(i,{}),i=e.getNextSibling(i)}(0,o.kP)(t),(0,s.kH)(t,{index:i,length:0})}function v(e,t){if((0,o.h$)(t,["affine:code"])&&((0,d.focusBlockByModel)(t),1)||function(e,t){if(!(0,o.h$)(t,["affine:list"]))return!1;let i=e.getParent(t);if(!i)return!1;let n=i.children.indexOf(t),r={type:"text",text:t.text?.clone(),children:t.children};e.captureSync(),e.deleteBlock(t);let a=e.addBlock("affine:paragraph",r,i,n);return(0,s.a6)(e,a),!0}(e,t)||function(e,t){if(!(0,o.h$)(t,["affine:paragraph"]))return!1;if("text"!==t.type)return e.captureSync(),e.updateBlock(t,{type:"text"}),!0;let i=function(e,t){function i(e,t,i){if(i)return!1;let n=t.text,o=document.querySelector(".affine-default-page-block-title"),r=(0,l.mt)(o),a=r.title;e.captureSync();let s=0;return n&&(s=n.length,a.join(n)),e.deleteBlock(t),(0,d.focusTitle)(e,a.length-s),!0}let n=e.getParent(t);if(!n)return!1;let r=(0,l.nt)(t);return(0,o.h$)(n,["affine:database"])?r?(e.deleteBlock(t),(0,d.focusBlockByModel)(r),!0):i(e,t,r):!!(0,o.h$)(n,["affine:frame"])&&(function(e,t,i,n){if(!i||!(0,o.h$)(i,["affine:paragraph","affine:list"]))return!1;e.captureSync();let r=i.text?.length||0;t.text?.length&&i.text?.join(t.text),e.deleteBlock(t,{bringChildrenTo:n});let a=(0,l.gj)(i);return a?.setVRange({index:r,length:0}),!0}(e,t,r,n)||!!(r&&(0,o.h$)(r,["affine:embed","affine:divider","affine:code"]))&&((0,d.focusBlockByModel)(r),t.text?.length||(e.captureSync(),e.deleteBlock(t)),!0)||i(e,t,r))}(e,t);return!!i||(m(e,t),!0)}(e,t)){r.cQ.isInsideBlockByFlavour(e,t,"affine:database");return}!function(e){throw Error("Failed to handle backspace! Unknown block flavours! flavour:"+e.flavour)}(t)}function b(e,t){let i=(0,d.getCurrentNativeRange)();i.collapsed||i.collapse(!0);let o=(0,a.zw)(i,t);return o?n.m7:(e.stopPropagation(),n.RV)}function C(e,t,i){let o=(0,d.getCurrentNativeRange)();o.collapsed||o.collapse();let r=(0,a.$K)(o,i);return r?(0,l.st)(e)?n.m7:n.RV:(t.stopPropagation(),n.RV)}},84954:function(e,t,i){"use strict";var n=i(50634),o=i(13246),r=i(29113),a=i(15486),s=i(32916),l=i(9288),d=i(25005),c=i(65024),h=i(63989);class u{constructor(e){this._abortController=new AbortController,this._disposables=new o.SJ,this._suggestionState={show:!1,position:{x:0,y:0},loading:!1,text:""},this.onFocusIn=e=>{let t=this.provider;if(!t)return;(0,o.kP)(this.model);let i=this.vEditor;(0,o.kP)(i),this._disposables.add(i.slots.vRangeUpdated.on(async([e,t])=>{this._updateSuggestions(e)}))},this.onFocusOut=e=>{this._abortController.abort(),this._disposables.dispose(),this._disposables=new o.SJ},this._updateSuggestions=(0,c.Ds)(async e=>{this._abortController.abort(),this._abortController=new AbortController,(0,o.kP)(this.model);let t=this.vEditor;(0,o.kP)(t);let i=t.yText.length;if(!i||0!==e.length||e.index!==i)return;let n=this.model.page.root;if((0,o.kP)(n),!(0,o.h$)(n,["affine:page"]))throw Error("Invalid page root");this._setSuggestionState({show:!0,loading:!0,position:this._updatePosition()});let r=this.model.text;(0,o.kP)(r);let a=r.toString(),s=n.title.toString(),l=this._abortController;l.signal.addEventListener("abort",()=>{this._setSuggestionState({show:!1,loading:!1})});try{(0,o.kP)(this.provider);let e=await this.provider({title:s,text:a,abortSignal:l.signal});if(l.signal.aborted){this._setSuggestionState({show:!1,loading:!1});return}requestAnimationFrame(()=>{this._setSuggestionState({show:!0,loading:!1,text:e,position:this._updatePosition()})})}catch(e){console.error("Failed to get inline suggest",e),this._setSuggestionState({show:!1,loading:!1})}},300,{leading:!1}),this.onKeyDown=e=>{if(!this._suggestionState.show||this._suggestionState.loading)return;if(e.isComposing||"Tab"!==e.key){requestAnimationFrame(()=>{let e=this._updatePosition();this._setSuggestionState({position:e})});return}let t=this.vEditor;(0,o.kP)(t);let i=t.getVRange();if(!i)return;let n=this._suggestionState.text;t.insertText(i,n),t.setVRange({index:i.index+n.length,length:0}),this._setSuggestionState({text:""}),e.stopPropagation(),e.preventDefault()},e.addController(this),this.host=e}hostConnected(){this._disposables=new o.SJ}hostDisconnected(){this._disposables.dispose()}init({model:e,vEditor:t,provider:i}){this.provider=i,this.model=e,this.vEditor=t}_setSuggestionState(e){let t=this._suggestionState;this._suggestionState={...t,...e},this.host.requestUpdate()}_updatePosition(){let e=this.host.getBoundingClientRect();if(!(0,h.hasNativeSelection)())return;let t=(0,h.getCurrentNativeRange)(),i=t.getBoundingClientRect();return{x:i.x-e.x,y:-i.height}}render(){if(!this._suggestionState.show)return a.Ld;let e=this._suggestionState.loading?"...":this._suggestionState.text,t=this._suggestionState.position;return e?a.dy`<div
      class="inline-suggestion"
      style="text-indent: ${t.x+2}px;"
    >
      ${e}
    </div>`:a.Ld}}u.styles=a.iv`
    .inline-suggestion {
      display: flex;
      align-items: center;
      gap: 4px;
      left: 0;
      top: 0;
      color: var(--affine-placeholder-color);
      fill: var(--affine-placeholder-color);
      margin-bottom: calc(-1 * var(--affine-line-height));
      transform: translateY(calc(-1 * var(--affine-line-height)));
      pointer-events: none;
    }
  `;var f=i(67072),p=i(6635),g=i(31054),m=i(60434),v=i(40063),b=i(280);let C=[{name:"parenthesis",left:"(",right:")"},{name:"square bracket",left:"[",right:"]"},{name:"curly bracket",left:"{",right:"}"},{name:"single quote",left:"'",right:"'"},{name:"double quote",left:'"',right:'"'},{name:"angle bracket",left:"<",right:">"},{name:"fullwidth single quote",left:"‘",right:"’"},{name:"fullwidth double quote",left:"“",right:"”"},{name:"fullwidth parenthesis",left:"（",right:"）"},{name:"fullwidth square bracket",left:"【",right:"】"},{name:"fullwidth angle bracket",left:"《",right:"》"},{name:"corner bracket",left:"「",right:"」"},{name:"white corner bracket",left:"『",right:"』"}],y=p.cj||p.Mq?"metaKey":"ctrlKey";i(46646);var x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=["code","reference"],_=(e,t)=>{let i=e.getVRange();if(!i)return;if(t.attributes?.link&&" "===t.data){delete t.attributes.link;return}let n=/.*\.(com|cn|org|edu|net|gov|mil|info|biz|io|me)(\/\S*)?$/i;if(t.attributes?.link){let o=e.deltaService.getDeltasByVRange(i).filter(([e])=>e.attributes?.link)[0],[r,{index:a,length:s}]=o,l=i.index-a;if(r.attributes?.link!==r.insert){l===s&&delete t.attributes.link;return}let d=r.insert.slice(0,l)+t.data+r.insert.slice(l),c=n.exec(d);if(!c){e.resetText({index:a,length:s}),delete t.attributes.link;return}e.formatText({index:a,length:s},{link:d}),t.attributes={...t.attributes,link:d};return}let[o]=e.getLine(i.index),r=o.textContent.slice(0,i.index),a=n.exec(r+t.data);if(!a)return;let s=a[0],l=i.index-s.length;e.formatText({index:l,length:s.length},{link:s}),t.attributes={...t.attributes,link:s}},k=class extends n.Zi{constructor(){super(...arguments),this._vEditor=null,this._inlineSuggestController=new u(this)}get virgoContainer(){return this._virgoContainer}get vEditor(){return this._vEditor}firstUpdated(){(0,o.kP)(this.model.text,"rich-text need text to init."),this._vEditor=new r.gX(this.model.text.yText,{active:()=>l.y.isActive(this)}),(0,d.m)(this.model.page,this._vEditor);let e=this.textSchema;(0,o.kP)(e,"Failed to render rich-text! textSchema not found"),this._vEditor.setAttributeSchema(e.attributesSchema),this._vEditor.setAttributeRenderer(e.textRenderer());let t=function(e,t){let i=e.page,n=(0,b.getService)(e.flavour),o=n.defineKeymap(e,t),r={...o,linkedPage:{key:["[","【","@"],altKey:null,shiftKey:null,handler(t,{event:n,prefix:o}){if(t.length>0||("["===n.key||"【"===n.key)&&!o.endsWith(n.key))return f.RV;let r=i.awarenessStore.getFlag("enable_linked_page");return!r||(0,g.h$)(e,["affine:code"])||this.vEditor.slots.rangeUpdated.once(()=>{if("["===n.key||"【"===n.key){this.vEditor.deleteText({index:t.index-1,length:2}),this.vEditor.insertText({index:t.index-1,length:0},"@"),this.vEditor.setVRange({index:t.index,length:0}),this.vEditor.slots.rangeUpdated.once(()=>{let t=(0,c.bR)();(0,m.n)({model:e,range:t})});return}let i=(0,c.bR)();(0,m.n)({model:e,range:i})}),f.RV}},slash:{key:["/","、"],shiftKey:null,handler(t,n){let o=i.awarenessStore.getFlag("enable_slash_menu");return!o||(0,g.h$)(e,["affine:code"])||this.vEditor.slots.rangeUpdated.once(()=>{let t=(0,c.bR)();(0,v.M)({model:e,range:t})}),f.RV}},...function(e){let t={};return C.forEach(i=>{t[i.name]={key:i.left,shiftKey:null,collapsed:!1,handler(t){return e.text?(e.text.insert(i.left,t.index),e.text.insert(i.right,t.index+t.length+1),this.vEditor.setVRange({index:t.index+1,length:t.length}),f.m7):f.RV}}}),t.backtick={key:"`",collapsed:!1,handler(t,i){return e.text?(e.text.format(t.index,t.length,{code:!0}),this.vEditor.setVRange({index:t.index,length:t.length}),f.m7):f.RV}},t}(e)};return r}(this.model,this._vEditor),i=function(e,t,i){let n={};return Object.values(t).forEach(e=>{!function(e){var t;let i=((t=e).shortKey&&(t[y]=t.shortKey,delete t.shortKey),t),o=Array.isArray(i.key)?i.key:[i.key];o.forEach(e=>{let t={...i,key:e};n[e]=n[e]??[],n[e].push(t)})}(e)}),function(o){let r=i.page.getParent(i),a=i.page.getPreviousSibling(i);if((r&&(0,g.h$)(r,["affine:database"])||a&&(0,g.h$)(a,["affine:database"]))&&"Tab"===o.key){o.preventDefault(),o.stopPropagation();return}if(o.defaultPrevented||o.isComposing)return;let s=(n[o.key]||[]).concat(n[o.which]||[]),l=s.filter(e=>!["altKey","ctrlKey","metaKey","shiftKey"].some(t=>!!e[t]!==o[t]&&null!==e[t])&&(e.key===o.key||e.key===o.which));if(0===l.length)return;let d=e.getVRange();if(!d||!(0,c.E7)())return;let h=(0,c.bR)();if(!h||!e.rootElement.contains(h.startContainer)||!e.rootElement.contains(h.endContainer))return;let[u,f]=e.getLine(d.index),[p,m]=e.getTextPoint(d.index),[v,b]=0===d.length?[p,m]:e.getTextPoint(d.index+d.length),C=p.textContent?p.textContent.slice(0,m):"",y=v.textContent?v.textContent.slice(b):"",x={collapsed:0===d.length,empty:0===d.length&&u.textLength<=1,format:e.getFormat(d),line:u,offset:f,prefix:C,suffix:y,event:o},w=l.some(i=>!!((null==i.collapsed||i.collapsed===x.collapsed)&&(null==i.prefix||i.prefix.test(x.prefix))&&(null==i.suffix||i.suffix.test(x.suffix)))&&!i.handler.call({vEditor:e,options:{bindings:t}},d,x));w&&o.preventDefault()}}(this._vEditor,t,this.model),n=!1;this._vEditor.mount(this._virgoContainer),this._vEditor.bindHandlers({keydown:i,virgoInput:e=>{let t=this._vEditor;(0,o.kP)(t);let i=t.getVRange();if(!i||0!==i.length)return e;let{data:r,event:a}=e,s=t.getDeltasByVRange(i);if("insertText"===a.inputType&&" "===r?n=!0:". "!==r&&"。 "!==r&&(n=!1),n&&(". "===r||"。 "===r)&&(e.data=" "),r&&r.length>0&&"\n"!==r&&(s.length>1||1===s.length&&0!==i.index)){let{attributes:n}=s[0][0];(1!==s.length||i.index===t.yText.length)&&w.forEach(e=>{delete n?.[e]}),e.attributes=n??null}return _(t,e),e},virgoCompositionEnd:e=>{let t=this._vEditor;(0,o.kP)(t);let i=t.getVRange();if(!i||0!==i.length)return e;let{data:n}=e,r=t.getDeltasByVRange(i);if(n&&n.length>0&&"\n"!==n&&(r.length>1||1===r.length&&0!==i.index)){let n=r[0][0].attributes;(1!==r.length||i.index===t.yText.length)&&w.forEach(e=>{delete n?.[e]}),e.attributes=n??null}return _(t,e),e}}),this._vEditor.setReadonly(this.model.page.readonly);let a=this.model.page.workspace.inlineSuggestionProvider;a&&this._inlineSuggestController.init({provider:a,model:this.model,vEditor:this._vEditor})}updated(){this._vEditor&&this._vEditor.setReadonly(this.model.page.readonly)}render(){return a.dy`<div
        class="affine-rich-text virgo-editor"
        @keydown=${this._inlineSuggestController.onKeyDown}
        @focusin=${this._inlineSuggestController.onFocusIn}
        @focusout=${this._inlineSuggestController.onFocusOut}
      ></div>
      ${this._inlineSuggestController.render()}`}};k.styles=a.iv`
    .affine-rich-text {
      height: 100%;
      width: 100%;
      outline: none;
      cursor: text;
    }

    v-line {
      scroll-margin-top: 50px;
      scroll-margin-bottom: 30px;
    }

    ${u.styles}
  `,x([(0,s.IO)(".affine-rich-text")],k.prototype,"_virgoContainer",void 0),x([(0,s.Cb)()],k.prototype,"model",void 0),x([(0,s.Cb)()],k.prototype,"textSchema",void 0),x([(0,s.Mo)("rich-text")],k)},65938:function(e,t,i){"use strict";i.d(t,{O:function(){return d}});var n=i(50634),o=i(29113),r=i(15486),a=i(32916),s=i(91827),l=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function d(e,t){let i="";e.underline&&(i+="underline"),e.strike&&(i+=" line-through");let n={};return e.code&&(n={"font-family":"var(--affine-font-code-family)",background:"var(--affine-background-code-block)",color:"var(--affine-text-primary-color)","border-radius":"4px",padding:"3px 6px","font-size":"calc(var(--affine-font-base) - 4px)","font-variant-ligatures":"none","line-height":"var(--affine-font-base)",border:"1px solid var(--affine-border-color)"}),(0,s.V)({"font-weight":e.bold?"bold":"normal","font-style":e.italic?"italic":"normal","text-decoration":i.length>0?i:"none",...n,...t})}let c=class extends n.Zi{constructor(){super(...arguments),this.delta={insert:o.$m}}render(){let e=this.delta.attributes?d(this.delta.attributes):(0,s.V)({});return r.dy`<span style=${e}
      ><v-text .str=${this.delta.insert}></v-text
    ></span>`}};c.styles=r.iv`
    affine-text {
      white-space: break-spaces;
      word-break: break-word;
    }
  `,l([(0,a.Cb)({type:Object})],c.prototype,"delta",void 0),l([(0,a.Mo)("affine-text")],c)},9386:function(e,t,i){"use strict";i.d(t,{O:function(){return a}});var n=i(15486),o=i(57891),r=i(55410);let a=()=>e=>{let t=n.dy`<affine-text .delta=${e}></affine-text>`;if(!e.attributes)return t;let i=e.attributes;return i.link?(i.reference&&console.error("Invalid attributes: link and reference cannot be used together",e),n.dy`<affine-link .delta=${e}></affine-link>`):i.reference?n.dy`${(0,o.r)(Array.from(e.insert).map((e,t)=>({delta:{insert:r.O,attributes:i},index:t})),e=>e.index,e=>n.dy`<affine-reference .delta=${e.delta}></affine-reference>`)}`:t}},46646:function(e,t,i){"use strict";i.d(t,{D:function(){return r}});var n=i(29113),o=i(30195);let r=n.mq.extend({reference:o.z.object({type:o.z.enum(["Subpage","LinkedPage"]),pageId:o.z.string()}).optional()})},280:function(e,t,i){"use strict";i.r(t),i.d(t,{getService:function(){return m},getServiceOrRegister:function(){return v},hasService:function(){return p},registerService:function(){return g}});var n=i(22232),o=i(56347),r=i(91519),a=i(83740),s=i(27314),l=i(11826),d=i(37960),c=i(28392);let h={"affine:code":o.E6,"affine:database":r.q,"affine:paragraph":c.Vs,"affine:list":d.pu,"affine:embed":s.Xk,"affine:divider":a.fu,"affine:frame":l.Kg,"affine:bookmark":n.lI};var u=i(88523);let f=new Map;function p(e){return f.has(e)}function g(e,t){if(f.has(e))return;let i=new t;f.set(e,i)}function m(e){let t=f.get(e);if(!t)throw Error(`cannot find service by flavour ${e}`);return t}function v(e){let t=f.get(e);if(!t){let t=h[e]??u.b,i=g(e,t);return i instanceof Promise?i.then(()=>f.get(e)):f.get(e)}return t}},88523:function(e,t,i){"use strict";i.d(t,{b:function(){return v}});var n=i(67072),o=i(31054),r=i(50217),a=i(280),s=i(70263),l=i(7291),d=i(59867),c=i(13592),h=i(65024);let u=[{name:"bolditalic",pattern:/(?:\*){3}(.+?)(?:\*){3}$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{bold:!0,italic:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:s+a.length-3,length:3}),t.deleteText({index:s,length:3}),t.setVRange({index:s+a.length-6,length:0}),!0)}},{name:"bold",pattern:/(?:\*){2}(.+?)(?:\*){2}$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{bold:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:s+a.length-2,length:2}),t.deleteText({index:s,length:2}),t.setVRange({index:s+a.length-4,length:0}),!0)}},{name:"italic",pattern:/(?:\*){1}(.+?)(?:\*){1}$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{italic:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:s+a.length-1,length:1}),t.deleteText({index:s,length:1}),t.setVRange({index:s+a.length-2,length:0}),!0)}},{name:"strikethrough",pattern:/(?:~~)(.+?)(?:~~)$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{strike:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:s+a.length-2,length:2}),t.deleteText({index:s,length:2}),t.setVRange({index:s+a.length-4,length:0}),!0)}},{name:"underthrough",pattern:/(?:~)(.+?)(?:~)$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{underline:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:n.index-1,length:1}),t.deleteText({index:s,length:1}),t.setVRange({index:s+a.length-2,length:0}),!0)}},{name:"code",pattern:/(?:`)(`{2,}?|[^`]+)(?:`)$/g,action:(e,t,i,n,o)=>{let r=o.exec(i);if(!r)return!1;let a=r[0],s=n.index-a.length;return!i.match(/^([* \n]+)$/g)&&(t.insertText({index:s+a.length,length:0}," "),e.page.captureSync(),t.formatText({index:s,length:a.length},{code:!0}),t.deleteText({index:s+a.length,length:1}),t.deleteText({index:s+a.length-1,length:1}),t.deleteText({index:s,length:1}),t.setVRange({index:s+a.length-2,length:0}),!0)}},{name:"codeblock",pattern:/^```([a-zA-Z0-9]*)$/g,action:(e,t,i,n,r)=>{if("affine:paragraph"===e.flavour&&"quote"===e.type)return!1;let a=r.exec(i),s=e.page;s.captureSync();let l=s.getParent(e);(0,o.kP)(l);let u=l.children.indexOf(e);s.deleteBlock(e);let f=s.addBlock("affine:code",{language:d.W(a?.[1]||"")?.id??c.AY},l,u),p=s.getBlockById(f);return(0,o.kP)(p),(0,h.kH)(p,{index:0,length:0}),!0}},{name:"link",pattern:/(?:\[(.+?)\])(?:\((.+?)\))$/g,action:(e,t,i,n,o)=>{let r=i.search(o),a=i.match(o)?.[0],s=i.match(/(?:\[(.*?)\])/g)?.[0],l=i.match(/(?:\((.*?)\))/g)?.[0];if(-1===r||!a||!s||!l)return!1;let d=n.index-a.length;return t.insertText({index:n.index,length:0}," "),e.page.captureSync(),t.formatText({index:d,length:s.length},{link:l.slice(1,l.length-1)}),t.deleteText({index:n.index+a.length,length:1}),t.deleteText({index:n.index-l.length-1,length:l.length+1}),t.deleteText({index:d,length:1}),t.setVRange({index:d+s.length-1,length:0}),!0}}];function f(e,t,i){let n=e.getVRange();if(!n)return!1;for(let o of u){let r=i.match(o.pattern);if(r)return o.action(t,e,i,n,o.pattern)}return!1}function p(e,t,i){return(0,r.handleSoftEnter)(e.page,e,t.index,t.length),i.setVRange({index:t.index+1,length:0}),n.m7}function g(e,t,i,a,s=!1){let l=e.page;a.stopPropagation();let d=l.getParent(e),c=d?.lastChild()===e,h=(0,o.h$)(e,["affine:list"])&&0===e.text.length;if((0,o.kP)(e.text,"Failed to hardEnter! model.text not exists!"),h&&d&&(0,o.h$)(d,["affine:frame","affine:database"])&&0===e.children.length)return(0,r.handleLineStartBackspace)(l,e),n.m7;if(h&&c)return(0,r.handleUnindent)(l,e,t.index),n.m7;let u=e.text.length===t.index;if(u||s){let o=m(e),a=e.text.toString(),s="\n"===a||a.endsWith("\n");return o&&!s?(p(e,t,i),n.m7):(o&&e.text.delete(t.index-1,1),(0,r.handleBlockEndEnter)(l,e),n.m7)}let f=m(e);return f?(p(e,t,i),n.m7):((0,r.handleBlockSplit)(l,e,t.index,t.length),n.m7)}function m(e){return!!(0,o.h$)(e,["affine:code"])||!!(0,o.h$)(e,["affine:paragraph"])&&"quote"===e.type}class v{block2html(e,{childText:t="",begin:i,end:n}={}){let o=e.text?.sliceToDelta(i||0,n)||[],r=o.reduce((t,i)=>t+v.deltaLeaf2Html(e,i),"");return`${r}${t}`}block2Text(e,{childText:t="",begin:i=0,end:n}={}){let o=(e.text?.toString()||"").slice(i,n);return`${o}${t}`}block2Json(e,t,i){let n=e.text?.sliceToDelta(t||0,i)||[];return{flavour:e.flavour,type:e.type,text:n,children:e.children?.map((t,n)=>n===e.children.length-1?(0,a.getService)(t.flavour).block2Json(t,0,i):(0,a.getService)(t.flavour).block2Json(t))}}async json2Block(e,t,i){return(0,l.V)(e,t,{range:i})}async onBlockPasted(e,t){}static deltaLeaf2Html(e,t){let i=t.insert??"";i=i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");let n=t.attributes;if(!n)return i;if(n.code&&(i=`<code>${i}</code>`),n.bold&&(i=`<strong>${i}</strong>`),n.italic&&(i=`<em>${i}</em>`),n.underline&&(i=`<u>${i}</u>`),n.strikethrough&&(i=`<s>${i}</s>`),n.link&&(i=`<a href="${n.link}">${i}</a>`),n.reference){let t=n.reference.pageId,o=e.page.workspace,r=o.meta.pageMetas.find(e=>e.id===t),a=window.location.origin,s=`${a}/workspace/${o.id}/${t}`,l=r?r.title:"Deleted page";i=`<a href="${s}">${l}</a>`}return i}async updateEffect(e){let t=(await Promise.resolve().then(i.bind(i,50217))).handleUnindent;!(0,s.$v)(e)&&e.children.length&&t(e.page,e.children[0],0,!1)}defineKeymap(e,t){return{enterMarkdownMatch:{key:"Enter",handler:(i,r)=>((0,o.kP)(t),function(e,t,i,o){let{prefix:r}=o;return f(t,e,r),n.RV}(e,t,0,r))},spaceMarkdownMatch:{key:" ",handler:(i,r)=>((0,o.kP)(t),function(e,t,i,o){let{prefix:r}=o;return f(t,e,r)?n.m7:n.RV}(e,t,0,r))},hardEnter:{key:"Enter",handler:(i,n)=>((0,o.kP)(t),g(e,i,t,n.event))},softEnter:{key:"Enter",shiftKey:!0,handler:(i,n)=>((0,o.kP)(t),p(e,i,t))},insertLineAfter:{key:"Enter",shortKey:!0,handler:(i,n)=>((0,o.kP)(t),g(e,i,t,n.event,!0))},tab:{key:"Tab",handler(t,i){let o=t.index;return(0,r.handleIndent)(e.page,e,o),i.event.stopPropagation(),n.m7}},shiftTab:{key:"Tab",shiftKey:!0,handler(t,i){let o=t.index;return(0,r.handleUnindent)(e.page,e,o),i.event.stopPropagation(),n.m7}},backspace:{key:"Backspace",handler(t,i){var o,a;return o=i.event,a=this.vEditor,(o.stopPropagation(),(0,h.uI)(a))?((0,r.handleLineStartBackspace)(e.page,e),n.m7):n.RV}},up:{key:"ArrowUp",shiftKey:!1,handler(e,t){return(0,r.handleKeyUp)(t.event,this.vEditor.rootElement)}},down:{key:"ArrowDown",shiftKey:!1,handler(t,i){return(0,r.handleKeyDown)(e,i.event,this.vEditor.rootElement)}},left:{key:"ArrowLeft",shiftKey:!1,handler:(e,t)=>(function(e,t){if(0!==t.length)return e.stopPropagation(),n.RV;let i=0===t.index;return i?n.m7:(e.stopPropagation(),n.RV)})(t.event,e)},right:{key:"ArrowRight",shiftKey:!1,handler:(t,i)=>(function(e,t,i){if(0!==i.length)return t.stopPropagation(),n.RV;(0,o.kP)(e.text,"Failed to onKeyRight! model.text not exists!");let r=e.text.length,a=r===i.index;return a?n.m7:(t.stopPropagation(),n.RV)})(e,i.event,t)},inputRule:{key:" ",shiftKey:null,prefix:/^(\d+\.|-|\*|\[ ?\]|\[x\]|(#){1,6}|(-){3}|(\*){3}|>)$/,handler:(i,r)=>(function(e,t,i,r){let{prefix:a}=r;return function(e,t,i,r,a){let[,s]=i.getLine(a.index);if(s>r.length)return n.RV;let l=(0,o.Xy)(t.type,"quote"),d=(0,o.h$)(t,["affine:code"]);if(l||d)return n.RV;let c=!1;switch(r.trim()){case"[]":case"[ ]":c=(0,h.Sf)(e,t,"todo",r,{checked:!1});break;case"[x]":c=(0,h.Sf)(e,t,"todo",r,{checked:!0});break;case"-":case"*":c=(0,h.Sf)(e,t,"bulleted",r);break;case"***":case"---":c=(0,h.WP)(e,t,r);break;case"#":c=(0,h.AE)(e,t,"h1",r);break;case"##":c=(0,h.AE)(e,t,"h2",r);break;case"###":c=(0,h.AE)(e,t,"h3",r);break;case"####":c=(0,h.AE)(e,t,"h4",r);break;case"#####":c=(0,h.AE)(e,t,"h5",r);break;case"######":c=(0,h.AE)(e,t,"h6",r);break;case">":c=(0,h.AE)(e,t,"quote",r);break;default:c=(0,h.Sf)(e,t,"numbered",r)}return c?n.m7:n.RV}(e.page,e,t,a,i)})(e,t,i,r)}}}}},7291:function(e,t,i){"use strict";i.d(t,{C:function(){return c},V:function(){return l}});var n=i(31054),o=i(13246),r=i(50217),a=i(280),s=i(65024);async function l(e,t,i){let{convertToPastedIfEmpty:o=!1,range:a}=i??{};(0,n.kP)(a);let{page:s}=e,l=t[0],h=t[t.length-1],u=!e.text?.length&&!o,f=!u&&l.text&&e.text,p=e.text&&h.text,g=s.getParent(e);if((0,n.kP)(g),1===t.length){let i=l?.text?.reduce((e,t)=>e+(t.insert?.length||0),0)??0,o=e.text?.length!==a.endOffset;if(o&&await (0,r.handleBlockSplit)(s,e,a.startOffset,0),f)e.text?.insertList(l.text||[],a?.startOffset||0),await c(s,l.children||[],e,0),await d(e,{index:(a?.startOffset??0)+i,length:0});else{let[o]=await c(s,t,g,g.children.indexOf(e)+1),r=s.getBlockById(o);(0,n.kP)(r),r.text&&await d(r,{index:i,length:0})}u&&s.deleteBlock(e);return}await (0,r.handleBlockSplit)(s,e,a.startOffset,0),f&&(e.text?.insertList(l.text||[],a?.startOffset||0),await c(s,l.children||[],e,0));let m=g.children.indexOf(e)+(f?1:0),v=await c(s,t.slice(f?1:0),g,m);u&&s.deleteBlock(e);let b=s.getBlockById(v[v.length-1]);if(p){(0,n.kP)(b);let e=b.text?.length||0,t=s.getNextSibling(b);b.text?.join(t?.text),(0,n.kP)(t),s.deleteBlock(t),requestAnimationFrame(()=>{d(b,{index:e,length:0})})}else b?.text&&d(b,{index:b.text.length,length:0})}async function d(e,t){let i=await (0,s._E)(e);(0,n.kP)(i),i.setVRange(t)}async function c(e,t,i,r){let s=[],l=[];for(let a=0;a<t.length;a++){let d=t[a],h=d.flavour,u={flavour:h,type:d.type,checked:d.checked,sourceId:d.sourceId,caption:d.caption,width:d.width,height:d.height,language:d.language,title:d.databaseProps?.title||d.title,titleColumnName:d.databaseProps?.titleColumnName,titleColumnWidth:d.databaseProps?.titleColumnWidth,url:d.url,description:d.description,icon:d.icon,image:d.image,crawled:d.crawled},f=e.addBlock(h,u,i,r+a);s.push(f);let p=e.getBlockById(f);(0,n.kP)(p);let g=p?.flavour&&e.getInitialPropsByFlavour(p?.flavour);g&&g.text instanceof o.xv&&d.text&&p?.text?.applyDelta(d.text),p&&d.children.length&&(await c(e,d.children,p,0),l.push({model:p,json:d}))}for(let{model:e,json:t}of l){let i=e.flavour,n=await (0,a.getServiceOrRegister)(i);n.onBlockPasted(e,{rowIds:t.databaseProps?.rowIds,cells:t.databaseProps?.cells,columns:t.databaseProps?.columns})}return s}},23862:function(e,t,i){"use strict";i.d(t,{IQ:function(){return n},c1:function(){return r},qn:function(){return a},u$:function(){return o},xZ:function(){return s}});let n=["--affine-brand-color","--affine-primary-color","--affine-secondary-color","--affine-tertiary-color","--affine-hover-color","--affine-icon-color","--affine-icon-secondary","--affine-border-color","--affine-divider-color","--affine-placeholder-color","--affine-quote-color","--affine-link-color","--affine-edgeless-grid-color","--affine-success-color","--affine-warning-color","--affine-error-color","--affine-processing-color","--affine-text-emphasis-color","--affine-text-primary-color","--affine-text-secondary-color","--affine-text-disable-color","--affine-black-10","--affine-black-30","--affine-black-50","--affine-black-60","--affine-black-80","--affine-black-90","--affine-black","--affine-white-10","--affine-white-30","--affine-white-50","--affine-white-60","--affine-white-80","--affine-white-90","--affine-white","--affine-background-code-block","--affine-background-tertiary-color","--affine-background-processing-color","--affine-background-error-color","--affine-background-warning-color","--affine-background-success-color","--affine-background-primary-color","--affine-background-secondary-color","--affine-background-modal-color","--affine-background-overlay-panel-color","--affine-tag-blue","--affine-tag-green","--affine-tag-teal","--affine-tag-white","--affine-tag-purple","--affine-tag-red","--affine-tag-pink","--affine-tag-yellow","--affine-tag-orange","--affine-tag-gray","--affine-palette-line-yellow","--affine-palette-line-orange","--affine-palette-line-tangerine","--affine-palette-line-red","--affine-palette-line-magenta","--affine-palette-line-purple","--affine-palette-line-navy","--affine-palette-line-blue","--affine-palette-line-green","--affine-palette-line-white","--affine-palette-line-black","--affine-palette-line-grey","--affine-palette-shape-yellow","--affine-palette-shape-orange","--affine-palette-shape-tangerine","--affine-palette-shape-red","--affine-palette-shape-magenta","--affine-palette-shape-purple","--affine-palette-shape-navy","--affine-palette-shape-blue","--affine-palette-shape-green","--affine-palette-shape-white","--affine-palette-shape-black","--affine-palette-shape-grey","--affine-tooltip"],o=["--affine-font-h-1","--affine-font-h-2","--affine-font-h-3","--affine-font-h-4","--affine-font-h-5","--affine-font-h-6","--affine-font-base","--affine-font-sm","--affine-font-xs","--affine-line-height","--affine-z-index-modal","--affine-z-index-popover"],r=["--affine-font-family","--affine-font-number-family","--affine-font-code-family"],a=["--affine-editor-width","--affine-theme-mode","--affine-editor-mode","--affine-palette-transparent","--affine-popover-shadow","--affine-menu-shadow","--affine-float-button-shadow","--affine-shadow-1","--affine-shadow-2","--affine-shadow-3","--affine-paragraph-space","--affine-popover-radius","--affine-zoom","--affine-scale",...o,...n,...r];function s(e){return a.includes(e)}},63863:function(e,t,i){"use strict";i.d(t,{cx:function(){return a},zp:function(){return r}});var n=i(13246);function o(e){let t=e.closest("editor-container");return(0,n.kP)(t),t}function r(e,t){let i=o(e);return i.themeObserver.on(t)}function a(e,t){let i=o(e);return i.themeObserver.cssVariables?.[t]}},42424:function(e,t,i){"use strict";function n(e){if(!e.collapsed)return!1;let t=function(e){if(!e.collapsed)throw Error("Failed to shift range! expected a collapsed range");let t=e.startContainer,i=t.nodeType===Node.TEXT_NODE||t.nodeType===Node.COMMENT_NODE||t.nodeType===Node.CDATA_SECTION_NODE;if(!i)return null;let n=t.textContent;if("string"!=typeof n)throw Error("Failed to shift range! unexpected startContainer");let o=n.length;if(o>e.startOffset){let t=e.cloneRange();return t.setStart(e.startContainer,e.startOffset+1),t.setEnd(e.startContainer,e.startOffset+1),t}let r=function(e,t=e=>e===document.body){for(;e.parentNode;){let i=e.parentNode;if(!i){console.warn("Failed to find text node from node! no parent node",e);break}let n=Array.from(i.childNodes).indexOf(e);if(-1===n){console.warn("Failed to find text node from node! no node index",e);break}for(let e=n+1;e<i.childNodes.length;e++){let t=function e(t){if(t.nodeType===Node.TEXT_NODE)return t;for(let i=0;i<t.childNodes.length;i++){let n=e(t.childNodes[i]);if(n)return n}return null}(i.childNodes[e]);if(t)return t}if(t(i))break;e=i}return null}(t,e=>e instanceof HTMLElement&&"true"===e.contentEditable);if(!r)return null;let a=e.cloneRange();return a.setStart(r,0),a.setEnd(r,0),a}(e);if(!t)return!1;let i=t.getBoundingClientRect(),n=e.getBoundingClientRect().top===i.top;return!n&&t}function o(e,t){if(!e.collapsed)throw Error("Failed to determine if the caret is at the first line! expected a collapsed range but got"+e);if(!t.contains(e.commonAncestorContainer))throw Error("Failed to determine if the caret is at the first line! expected the range to be inside the container but got"+e+" and "+t);let i=t.getBoundingClientRect(),o=e.getBoundingClientRect();if(0===o.left&&0===o.top)return!0;let r=o.height,a=i.top>o.top-r/2&&!n(e);return a}function r(e,t){if(!e.collapsed)throw Error("Failed to determine if the caret is at the last line! expected a collapsed range but got"+e);if(!t.contains(e.commonAncestorContainer))throw Error("Failed to determine if the caret is at the first line! expected the range to be inside the container but got"+e+" and "+t);let i=t.getBoundingClientRect(),o=e.getBoundingClientRect();if(0===o.left&&0===o.bottom)return!0;let r=o.height,a=o.bottom+r/2>i.bottom;if(a)return!0;let s=n(e);if(!s)return!1;let l=s.getBoundingClientRect(),d=l.height;return l.bottom+d/2>i.bottom}i.d(t,{$K:function(){return r},q:function(){return n},zw:function(){return o}})},25005:function(e,t,i){"use strict";i.d(t,{F:function(){return o},m:function(){return r}});var n=i(48616);function o(e){let t=e.getVRange(),i=e.slots.vRangeUpdated.on(([n,o])=>{t&&n&&("native"===o&&n.index===t.index||"native"!==o&&n.index===t.index+1)?t=n:(e.resetMarks(),i.dispose())})}function r(e,t){t.shouldLineScrollIntoView=(0,n.im)(e)}},22232:function(e,t,i){"use strict";i.d(t,{Yc:function(){return q},mN:function(){return S.m},lI:function(){return j},qR:function(){return S.q}}),i(74403);var n=i(50634),o=i(13246),r=i(15486),a=i(32916),s=i(57891),l=i(60803),d=i(29691);let c=r.dy`
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3334_77372)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2.71294 6.47927C2.9781 6.34125 3.27709 6.21883 3.59925 6.11144C4.18904 5.91485 4.88593 5.759 5.65385 5.65385C5.759 4.88593 5.91485 4.18904 6.11144 3.59925C6.21883 3.27709 6.34125 2.9781 6.47927 2.71294C4.66435 3.23402 3.23402 4.66435 2.71294 6.47927ZM8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5ZM8 2.5C7.94272 2.5 7.80858 2.53437 7.61422 2.781C7.42429 3.02199 7.23139 3.4017 7.06013 3.91547C6.90527 4.38004 6.77549 4.9317 6.67997 5.5472C7.10671 5.5162 7.5484 5.5 8 5.5C8.4516 5.5 8.89329 5.5162 9.32003 5.5472C9.22451 4.9317 9.09473 4.38004 8.93987 3.91547C8.76861 3.4017 8.57571 3.02199 8.38579 2.781C8.19142 2.53437 8.05728 2.5 8 2.5ZM10.3461 5.65385C10.241 4.88593 10.0852 4.18904 9.88856 3.59925C9.78117 3.27709 9.65875 2.9781 9.52073 2.71294C11.3357 3.23402 12.766 4.66435 13.2871 6.47927C13.0219 6.34125 12.7229 6.21883 12.4008 6.11144C11.811 5.91485 11.1141 5.759 10.3461 5.65385ZM9.44027 6.55973C8.98158 6.52087 8.49906 6.5 8 6.5C7.50094 6.5 7.01842 6.52087 6.55973 6.55973C6.52087 7.01842 6.5 7.50094 6.5 8C6.5 8.49906 6.52087 8.98158 6.55973 9.44027C7.01842 9.47913 7.50094 9.5 8 9.5C8.49906 9.5 8.98158 9.47913 9.44027 9.44027C9.47913 8.98158 9.5 8.49906 9.5 8C9.5 7.50094 9.47913 7.01842 9.44027 6.55973ZM10.4528 9.32002C10.4838 8.89329 10.5 8.4516 10.5 8C10.5 7.5484 10.4838 7.10671 10.4528 6.67998C11.0683 6.7755 11.62 6.90527 12.0845 7.06013C12.5983 7.23139 12.978 7.42429 13.219 7.61422C13.4656 7.80858 13.5 7.94272 13.5 8C13.5 8.05728 13.4656 8.19142 13.219 8.38579C12.978 8.57571 12.5983 8.76861 12.0845 8.93987C11.62 9.09473 11.0683 9.2245 10.4528 9.32002ZM9.32003 10.4528C8.89329 10.4838 8.4516 10.5 8 10.5C7.5484 10.5 7.10671 10.4838 6.67998 10.4528C6.7755 11.0683 6.90527 11.62 7.06013 12.0845C7.23139 12.5983 7.42429 12.978 7.61422 13.219C7.80858 13.4656 7.94272 13.5 8 13.5C8.05728 13.5 8.19142 13.4656 8.38579 13.219C8.57571 12.978 8.76861 12.5983 8.93987 12.0845C9.09473 11.62 9.22451 11.0683 9.32003 10.4528ZM9.52073 13.2871C9.65875 13.0219 9.78117 12.7229 9.88856 12.4008C10.0852 11.811 10.241 11.1141 10.3461 10.3461C11.1141 10.241 11.811 10.0852 12.4008 9.88856C12.7229 9.78117 13.0219 9.65875 13.2871 9.52073C12.766 11.3357 11.3357 12.766 9.52073 13.2871ZM6.47927 13.2871C4.66435 12.766 3.23402 11.3357 2.71294 9.52073C2.9781 9.65875 3.27709 9.78117 3.59925 9.88856C4.18904 10.0852 4.88593 10.241 5.65385 10.3461C5.759 11.1141 5.91485 11.811 6.11144 12.4008C6.21883 12.7229 6.34125 13.0219 6.47927 13.2871ZM5.5472 9.32003C4.9317 9.22451 4.38004 9.09473 3.91547 8.93987C3.4017 8.76861 3.02199 8.57571 2.781 8.38579C2.53437 8.19142 2.5 8.05728 2.5 8C2.5 7.94272 2.53437 7.80858 2.781 7.61422C3.02199 7.42429 3.4017 7.23139 3.91547 7.06013C4.38004 6.90527 4.9317 6.7755 5.5472 6.67998C5.5162 7.10671 5.5 7.5484 5.5 8C5.5 8.4516 5.5162 8.89329 5.5472 9.32003Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3334_77372">
        <rect width="16" height="16" fill="white" />
      </clipPath>
    </defs>
  </svg>
`;r.dy`
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3334_76304)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.33341 3.16667C3.68908 3.16667 3.16675 3.68901 3.16675 4.33334C3.16675 4.97767 3.68908 5.5 4.33341 5.5C4.97775 5.5 5.50008 4.97767 5.50008 4.33334C5.50008 3.68901 4.97775 3.16667 4.33341 3.16667ZM2.16675 4.33334C2.16675 3.13672 3.1368 2.16667 4.33341 2.16667C5.53003 2.16667 6.50008 3.13672 6.50008 4.33334C6.50008 5.52995 5.53003 6.5 4.33341 6.5C3.1368 6.5 2.16675 5.52995 2.16675 4.33334Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.33341 10.5C3.68908 10.5 3.16675 11.0223 3.16675 11.6667C3.16675 12.311 3.68908 12.8333 4.33341 12.8333C4.97775 12.8333 5.50008 12.311 5.50008 11.6667C5.50008 11.0223 4.97775 10.5 4.33341 10.5ZM2.16675 11.6667C2.16675 10.4701 3.1368 9.5 4.33341 9.5C5.53003 9.5 6.50008 10.4701 6.50008 11.6667C6.50008 12.8633 5.53003 13.8333 4.33341 13.8333C3.1368 13.8333 2.16675 12.8633 2.16675 11.6667Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M6.83341 4.33334C6.83341 4.0572 7.05727 3.83334 7.33341 3.83334H8.00008C8.54726 3.83334 9.08907 3.94111 9.59459 4.15051C10.1001 4.3599 10.5594 4.66682 10.9464 5.05373C11.3333 5.44064 11.6402 5.89997 11.8496 6.40549C12.059 6.91101 12.1667 7.45283 12.1667 8V8.66667C12.1667 8.94281 11.9429 9.16667 11.6667 9.16667C11.3906 9.16667 11.1667 8.94281 11.1667 8.66667V8C11.1667 7.58415 11.0848 7.17237 10.9257 6.78817C10.7666 6.40398 10.5333 6.05489 10.2393 5.76083C9.9452 5.46678 9.59611 5.23353 9.21191 5.07439C8.82772 4.91525 8.41593 4.83334 8.00008 4.83334H7.33341C7.05727 4.83334 6.83341 4.60948 6.83341 4.33334Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M9.50008 10.6667C9.50008 10.0223 10.0224 9.5 10.6667 9.5H12.6667C13.3111 9.5 13.8334 10.0223 13.8334 10.6667V12.6667C13.8334 13.311 13.3111 13.8333 12.6667 13.8333H10.6667C10.0224 13.8333 9.50008 13.311 9.50008 12.6667V10.6667ZM10.6667 10.5C10.5747 10.5 10.5001 10.5746 10.5001 10.6667V12.6667C10.5001 12.7587 10.5747 12.8333 10.6667 12.8333H12.6667C12.7588 12.8333 12.8334 12.7587 12.8334 12.6667V10.6667C12.8334 10.5746 12.7588 10.5 12.6667 10.5H10.6667Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.33341 6.83334C4.60956 6.83334 4.83341 7.0572 4.83341 7.33334L4.83341 8.66667C4.83341 8.94281 4.60956 9.16667 4.33341 9.16667C4.05727 9.16667 3.83341 8.94281 3.83341 8.66667L3.83341 7.33334C3.83341 7.0572 4.05727 6.83334 4.33341 6.83334Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3334_76304">
        <rect width="16" height="16" fill="white" />
      </clipPath>
    </defs>
  </svg>
`,r.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  xmlns="http://www.w3.org/2000/svg"
>
  <g clip-path="url(#clip0_3334_79048)">
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      fill="currentColor"
      d="M2.16675 3.99999C2.16675 2.98747 2.98756 2.16666 4.00008 2.16666H9.33342C9.60956 2.16666 9.83342 2.39051 9.83342 2.66666C9.83342 2.9428 9.60956 3.16666 9.33342 3.16666H4.00008C3.53984 3.16666 3.16675 3.53975 3.16675 3.99999V13.3333C3.16675 13.6095 2.94289 13.8333 2.66675 13.8333C2.39061 13.8333 2.16675 13.6095 2.16675 13.3333V3.99999Z"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      fill="currentColor"
      d="M13.8334 12C13.8334 13.0125 13.0126 13.8333 12.0001 13.8333H6.66675C6.39061 13.8333 6.16675 13.6095 6.16675 13.3333C6.16675 13.0572 6.39061 12.8333 6.66675 12.8333L12.0001 12.8333C12.4603 12.8333 12.8334 12.4602 12.8334 12L12.8334 2.66666C12.8334 2.39051 13.0573 2.16666 13.3334 2.16666C13.6096 2.16666 13.8334 2.39051 13.8334 2.66666L13.8334 12Z"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      fill="currentColor"
      d="M5.50008 5.99999C5.50008 5.35566 6.02242 4.83332 6.66675 4.83332H9.33342C9.97775 4.83332 10.5001 5.35566 10.5001 5.99999V7.33332C10.5001 7.97765 9.97775 8.49999 9.33342 8.49999H6.66675C6.02242 8.49999 5.50008 7.97765 5.50008 7.33332V5.99999ZM6.66675 5.83332C6.5747 5.83332 6.50008 5.90794 6.50008 5.99999V7.33332C6.50008 7.42537 6.5747 7.49999 6.66675 7.49999H9.33342C9.42546 7.49999 9.50008 7.42537 9.50008 7.33332V5.99999C9.50008 5.90794 9.42546 5.83332 9.33342 5.83332H6.66675Z"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      fill="currentColor"
      d="M5.50008 10.6667C5.50008 10.3905 5.72394 10.1667 6.00008 10.1667H10.0001C10.2762 10.1667 10.5001 10.3905 10.5001 10.6667C10.5001 10.9428 10.2762 11.1667 10.0001 11.1667H6.00008C5.72394 11.1667 5.50008 10.9428 5.50008 10.6667Z"
    />
  </g>
  <defs>
    <clipPath id="clip0_3334_79048">
      <rect width="16" height="16" fill="white" />
    </clipPath>
  </defs>
</svg>`;let h=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77646)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.70834 12C4.70834 7.97292 7.97293 4.70833 12 4.70833C13.8671 4.70833 15.5717 5.41092 16.8613 6.56516L16.8633 6.56695L18.0417 7.63079V5.33333C18.0417 4.98815 18.3215 4.70833 18.6667 4.70833C19.0119 4.70833 19.2917 4.98815 19.2917 5.33333V9.03704C19.2917 9.38221 19.0119 9.66204 18.6667 9.66204H14.963C14.6178 9.66204 14.338 9.38221 14.338 9.03704C14.338 8.69186 14.6178 8.41204 14.963 8.41204H17.0417L16.0276 7.49658C16.0273 7.49628 16.027 7.49599 16.0266 7.49569C14.9575 6.53917 13.5473 5.95833 12 5.95833C8.66329 5.95833 5.95834 8.66328 5.95834 12C5.95834 15.3367 8.66329 18.0417 12 18.0417C14.8745 18.0417 17.2815 16.0336 17.892 13.3432C17.9684 13.0066 18.3032 12.7956 18.6398 12.872C18.9764 12.9484 19.1874 13.2832 19.111 13.6198C18.3741 16.8671 15.471 19.2917 12 19.2917C7.97293 19.2917 4.70834 16.0271 4.70834 12Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77646">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,u=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77647)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.3166 3.87493C11.3513 3.87497 11.3864 3.875 11.422 3.875H12.578C12.6136 3.875 12.6487 3.87497 12.6834 3.87493C13.2704 3.87439 13.7306 3.87396 14.1375 4.03401C14.4945 4.17443 14.8106 4.40223 15.0567 4.69654C15.3372 5.032 15.4824 5.46866 15.6674 6.02568C15.6784 6.05861 15.6895 6.09197 15.7007 6.12575L15.7838 6.375H18.6667C19.0119 6.375 19.2917 6.65482 19.2917 7C19.2917 7.34518 19.0119 7.625 18.6667 7.625H17.625V15.5268C17.625 16.2041 17.625 16.7505 17.5889 17.1929C17.5517 17.6484 17.473 18.0485 17.2844 18.4187C16.9848 19.0067 16.5067 19.4848 15.9187 19.7844C15.5485 19.973 15.1484 20.0516 14.6929 20.0889C14.2505 20.125 13.7041 20.125 13.0268 20.125H10.9732C10.2959 20.125 9.74954 20.125 9.30712 20.0889C8.85159 20.0516 8.45147 19.973 8.08129 19.7844C7.49328 19.4848 7.01522 19.0067 6.71561 18.4187C6.527 18.0485 6.44836 17.6484 6.41115 17.1929C6.375 16.7505 6.375 16.2041 6.37501 15.5268L6.37501 7.625H5.33334C4.98817 7.625 4.70834 7.34518 4.70834 7C4.70834 6.65482 4.98817 6.375 5.33334 6.375H8.2162L8.29929 6.12575C8.31055 6.09197 8.32163 6.05861 8.33257 6.02568C8.51767 5.46866 8.66277 5.032 8.9433 4.69654C9.18942 4.40224 9.50548 4.17443 9.86251 4.03401C10.2695 3.87396 10.7296 3.87439 11.3166 3.87493ZM8.65226 7.625C8.66195 7.62522 8.67162 7.62522 8.68127 7.625H15.3188C15.3284 7.62522 15.3381 7.62522 15.3478 7.625H16.375V15.5C16.375 16.2104 16.3745 16.7056 16.343 17.0911C16.3121 17.4693 16.2545 17.6866 16.1706 17.8512C15.9909 18.204 15.704 18.4909 15.3512 18.6706C15.1866 18.7545 14.9693 18.8121 14.5911 18.843C14.2056 18.8745 13.7104 18.875 13 18.875H11C10.2896 18.875 9.79444 18.8745 9.40891 18.843C9.03068 18.8121 8.81338 18.7545 8.64878 18.6706C8.29597 18.4909 8.00914 18.204 7.82937 17.8512C7.74551 17.6866 7.6879 17.4693 7.657 17.0911C7.6255 16.7056 7.62501 16.2104 7.62501 15.5V7.625H8.65226ZM14.466 6.375H9.53401C9.73142 5.78788 9.8018 5.61848 9.9022 5.49843C10.0141 5.36465 10.1577 5.2611 10.32 5.19728C10.4771 5.1355 10.6776 5.125 11.422 5.125H12.578C13.3225 5.125 13.5229 5.1355 13.68 5.19728C13.8423 5.2611 13.986 5.36465 14.0978 5.49843C14.1982 5.61848 14.2686 5.78788 14.466 6.375ZM10.3333 9.70833C10.6785 9.70833 10.9583 9.98815 10.9583 10.3333V16.1667C10.9583 16.5118 10.6785 16.7917 10.3333 16.7917C9.98817 16.7917 9.70834 16.5118 9.70834 16.1667V10.3333C9.70834 9.98815 9.98817 9.70833 10.3333 9.70833ZM13.6667 9.70833C14.0119 9.70833 14.2917 9.98815 14.2917 10.3333V16.1667C14.2917 16.5118 14.0119 16.7917 13.6667 16.7917C13.3215 16.7917 13.0417 16.5118 13.0417 16.1667V10.3333C13.0417 9.98815 13.3215 9.70833 13.6667 9.70833Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77647">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,f=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77641)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M15.245 6.43527L14.543 7.16176L16.8382 9.45697L17.5647 8.755C18.2018 8.11415 18.2006 7.07817 17.5612 6.43876C16.9218 5.79935 15.8859 5.79819 15.245 6.43527ZM15.9392 10.3257L13.6743 8.06082L7.13833 14.8251L6.2655 17.7345L9.17493 16.8617L15.9392 10.3257ZM14.3576 5.55488C15.4863 4.42615 17.3164 4.42615 18.4451 5.55488C19.5738 6.68361 19.5738 8.51364 18.4451 9.64238L18.4375 9.64996L9.93429 17.8661C9.86252 17.9355 9.77518 17.9866 9.67959 18.0153L5.51292 19.2653C5.29269 19.3314 5.05397 19.2712 4.89139 19.1086C4.7288 18.946 4.66862 18.7073 4.73469 18.4871L5.98469 14.3204C6.01337 14.2248 6.06452 14.1375 6.13387 14.0657L14.3576 5.55488Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77641">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,p=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77679)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12.7019 5.83896C14.2094 4.33145 16.6535 4.33145 18.161 5.83896C19.6685 7.34646 19.6685 9.79061 18.161 11.2981L16.4453 13.0138C16.2012 13.2579 15.8055 13.2579 15.5614 13.0138C15.3173 12.7698 15.3173 12.374 15.5614 12.13L17.2771 10.4142C18.2965 9.39488 18.2965 7.74219 17.2771 6.72284C16.2578 5.70349 14.6051 5.70349 13.5857 6.72284L11.2981 9.01048C10.2788 10.0298 10.2788 11.6825 11.2981 12.7019C11.4581 12.8619 11.633 12.9963 11.818 13.1055C12.1152 13.281 12.2138 13.6643 12.0383 13.9615C11.8628 14.2587 11.4795 14.3573 11.1823 14.1818C10.9076 14.0196 10.6492 13.8207 10.4142 13.5858C8.90671 12.0782 8.90671 9.6341 10.4142 8.1266L12.7019 5.83896ZM11.9617 10.0385C12.1372 9.74129 12.5204 9.64265 12.8177 9.81819C13.0924 9.98043 13.3508 10.1793 13.5857 10.4142C15.0932 11.9217 15.0932 14.3659 13.5857 15.8734L11.2981 18.161C9.7906 19.6685 7.34645 19.6685 5.83894 18.161C4.33144 16.6535 4.33144 14.2094 5.83894 12.7019L7.55467 10.9861C7.79875 10.7421 8.19448 10.7421 8.43855 10.9861C8.68263 11.2302 8.68263 11.6259 8.43855 11.87L6.72283 13.5858C5.70348 14.6051 5.70348 16.2578 6.72283 17.2771C7.74218 18.2965 9.39487 18.2965 10.4142 17.2771L12.7019 14.9895C13.7212 13.9702 13.7212 12.3175 12.7019 11.2981C12.5418 11.1381 12.367 11.0037 12.182 10.8945C11.8848 10.719 11.7861 10.3357 11.9617 10.0385Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77679">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,g=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77644)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.308 4.70833H16.0254C16.4705 4.70832 16.842 4.70832 17.1456 4.73312C17.4621 4.75898 17.7594 4.81491 18.0404 4.95811C18.4716 5.17782 18.8222 5.5284 19.0419 5.9596C19.1851 6.24066 19.241 6.53787 19.2669 6.85444C19.2917 7.15797 19.2917 7.5295 19.2917 7.97462V12.692C19.2917 13.1372 19.2917 13.5087 19.2669 13.8122C19.241 14.1288 19.1851 14.426 19.0419 14.7071C18.8222 15.1383 18.4716 15.4888 18.0404 15.7086C17.7594 15.8518 17.4621 15.9077 17.1456 15.9336C16.842 15.9584 16.4705 15.9583 16.0254 15.9583H15.9583V16.0254C15.9584 16.4705 15.9584 16.842 15.9336 17.1456C15.9077 17.4621 15.8518 17.7593 15.7086 18.0404C15.4889 18.4716 15.1383 18.8222 14.7071 19.0419C14.426 19.1851 14.1288 19.241 13.8122 19.2669C13.5087 19.2917 13.1372 19.2917 12.6921 19.2917H7.97463C7.52951 19.2917 7.15798 19.2917 6.85445 19.2669C6.53788 19.241 6.24067 19.1851 5.95962 19.0419C5.52841 18.8222 5.17783 18.4716 4.95812 18.0404C4.81492 17.7593 4.75899 17.4621 4.73313 17.1456C4.70833 16.842 4.70833 16.4705 4.70834 16.0254V11.308C4.70833 10.8628 4.70833 10.4913 4.73313 10.1878C4.75899 9.8712 4.81492 9.57399 4.95812 9.29294C5.17783 8.86173 5.52841 8.51115 5.95962 8.29144C6.24067 8.14824 6.53788 8.09231 6.85445 8.06645C7.15798 8.04165 7.52952 8.04166 7.97465 8.04167L8.04168 8.04167L8.04168 7.97464C8.04167 7.52951 8.04166 7.15797 8.06646 6.85444C8.09233 6.53787 8.14825 6.24066 8.29145 5.9596C8.51116 5.5284 8.86174 5.17782 9.29295 4.95811C9.574 4.81491 9.87122 4.75898 10.1878 4.73312C10.4913 4.70832 10.8629 4.70832 11.308 4.70833ZM8.04168 9.29167H8.00001C7.52299 9.29167 7.20281 9.29215 6.95624 9.3123C6.71697 9.33185 6.60257 9.36675 6.5271 9.4052C6.3311 9.50507 6.17175 9.66442 6.07188 9.86043C6.03343 9.93589 5.99852 10.0503 5.97898 10.2896C5.95883 10.5361 5.95834 10.8563 5.95834 11.3333V16C5.95834 16.477 5.95883 16.7972 5.97898 17.0438C5.99852 17.283 6.03343 17.3974 6.07188 17.4729C6.17175 17.6689 6.3311 17.8283 6.5271 17.9281C6.60257 17.9666 6.71697 18.0015 6.95624 18.021C7.20281 18.0412 7.52299 18.0417 8.00001 18.0417H12.6667C13.1437 18.0417 13.4639 18.0412 13.7104 18.021C13.9497 18.0015 14.0641 17.9666 14.1396 17.9281C14.3356 17.8283 14.4949 17.6689 14.5948 17.4729C14.6333 17.3974 14.6682 17.283 14.6877 17.0438C14.7079 16.7972 14.7083 16.477 14.7083 16V15.9583H11.308C10.8628 15.9583 10.4913 15.9584 10.1878 15.9336C9.87122 15.9077 9.574 15.8518 9.29295 15.7086C8.86174 15.4888 8.51116 15.1383 8.29145 14.7071C8.14825 14.426 8.09233 14.1288 8.06646 13.8122C8.04166 13.5087 8.04167 13.1372 8.04168 12.692L8.04168 9.29167ZM11.3333 14.7083C10.8563 14.7083 10.5361 14.7078 10.2896 14.6877C10.0503 14.6682 9.93591 14.6333 9.86044 14.5948C9.66444 14.4949 9.50508 14.3356 9.40521 14.1396C9.36676 14.0641 9.33186 13.9497 9.31231 13.7104C9.29216 13.4639 9.29168 13.1437 9.29168 12.6667V8C9.29168 7.52298 9.29216 7.2028 9.31231 6.95623C9.33186 6.71696 9.36676 6.60256 9.40521 6.52709C9.50508 6.33109 9.66444 6.17174 9.86044 6.07187C9.93591 6.03342 10.0503 5.99851 10.2896 5.97896C10.5361 5.95882 10.8563 5.95833 11.3333 5.95833H16C16.477 5.95833 16.7972 5.95882 17.0438 5.97896C17.2831 5.99851 17.3975 6.03342 17.4729 6.07187C17.6689 6.17174 17.8283 6.33109 17.9281 6.52709C17.9666 6.60256 18.0015 6.71696 18.021 6.95623C18.0412 7.2028 18.0417 7.52298 18.0417 8V12.6667C18.0417 13.1437 18.0412 13.4639 18.021 13.7104C18.0015 13.9497 17.9666 14.0641 17.9281 14.1396C17.8283 14.3356 17.6689 14.4949 17.4729 14.5948C17.3975 14.6333 17.2831 14.6682 17.0438 14.6877C16.7972 14.7078 16.477 14.7083 16 14.7083H11.3333Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77644">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,m=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77683)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.70831 6.16666C4.70831 5.36125 5.36123 4.70833 6.16665 4.70833H9.49998C10.3054 4.70833 10.9583 5.36125 10.9583 6.16666V9.49999C10.9583 10.3054 10.3054 10.9583 9.49998 10.9583H6.16665C5.36123 10.9583 4.70831 10.3054 4.70831 9.49999V6.16666ZM6.16665 5.95833C6.05159 5.95833 5.95831 6.0516 5.95831 6.16666V9.49999C5.95831 9.61505 6.05159 9.70833 6.16665 9.70833H9.49998C9.61504 9.70833 9.70831 9.61505 9.70831 9.49999V6.16666C9.70831 6.0516 9.61504 5.95833 9.49998 5.95833H6.16665Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.70831 18.6667C4.70831 18.3215 4.98814 18.0417 5.33331 18.0417L15.3333 18.0417C15.6785 18.0417 15.9583 18.3215 15.9583 18.6667C15.9583 19.0118 15.6785 19.2917 15.3333 19.2917L5.33331 19.2917C4.98813 19.2917 4.70831 19.0118 4.70831 18.6667Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.70831 14.5C4.70831 14.1548 4.98814 13.875 5.33331 13.875L18.6666 13.875C19.0118 13.875 19.2916 14.1548 19.2916 14.5C19.2916 14.8452 19.0118 15.125 18.6666 15.125L5.33331 15.125C4.98813 15.125 4.70831 14.8452 4.70831 14.5Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77683">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,v=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77645)">
      <path
        d="M11.375 9.5C11.375 9.84518 11.6548 10.125 12 10.125H12.9911L8.22474 14.8914C7.98066 15.1355 7.98066 15.5312 8.22474 15.7753C8.46881 16.0194 8.86454 16.0194 9.10862 15.7753L13.875 11.0089V12C13.875 12.3452 14.1548 12.625 14.5 12.625C14.8452 12.625 15.125 12.3452 15.125 12V9.58333C15.125 9.56886 15.1246 9.5545 15.1237 9.54024C15.1348 9.36716 15.0742 9.19034 14.942 9.05806C14.8097 8.92578 14.6328 8.86519 14.4598 8.87629C14.4455 8.87543 14.4311 8.875 14.4167 8.875H12C11.6548 8.875 11.375 9.15482 11.375 9.5Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M16.0254 4.70833H11.308C10.8629 4.70832 10.4913 4.70832 10.1878 4.73312C9.87122 4.75898 9.574 4.81491 9.29295 4.95811C8.86174 5.17782 8.51116 5.5284 8.29145 5.9596C8.14825 6.24066 8.09233 6.53787 8.06646 6.85444C8.04166 7.15797 8.04167 7.5295 8.04168 7.97463L8.04168 8.04167L7.97465 8.04167C7.52953 8.04166 7.15798 8.04165 6.85445 8.06645C6.53788 8.09231 6.24067 8.14824 5.95962 8.29144C5.52841 8.51115 5.17783 8.86173 4.95812 9.29294C4.81492 9.57399 4.75899 9.8712 4.73313 10.1878C4.70833 10.4913 4.70834 10.8628 4.70834 11.308V16.0254C4.70834 16.4705 4.70833 16.842 4.73313 17.1456C4.75899 17.4621 4.81492 17.7593 4.95812 18.0404C5.17783 18.4716 5.52841 18.8222 5.95962 19.0419C6.24067 19.1851 6.53788 19.241 6.85445 19.2669C7.15798 19.2917 7.52951 19.2917 7.97463 19.2917H12.6921C13.1372 19.2917 13.5087 19.2917 13.8122 19.2669C14.1288 19.241 14.426 19.1851 14.7071 19.0419C15.1383 18.8222 15.4889 18.4716 15.7086 18.0404C15.8518 17.7593 15.9077 17.4621 15.9336 17.1456C15.9584 16.842 15.9584 16.4705 15.9583 16.0254V15.9583H16.0254C16.4705 15.9583 16.8421 15.9583 17.1456 15.9335C17.4621 15.9077 17.7594 15.8518 18.0404 15.7086C18.4716 15.4888 18.8222 15.1383 19.0419 14.7071C19.1851 14.426 19.241 14.1288 19.2669 13.8122C19.2917 13.5087 19.2917 13.1372 19.2917 12.692V7.97462C19.2917 7.5295 19.2917 7.15797 19.2669 6.85444C19.241 6.53787 19.1851 6.24066 19.0419 5.9596C18.8222 5.5284 18.4716 5.17782 18.0404 4.95811C17.7594 4.81491 17.4621 4.75898 17.1456 4.73312C16.842 4.70832 16.4705 4.70832 16.0254 4.70833ZM8.04168 11.1667V9.29167H8.00001C7.52299 9.29167 7.20281 9.29215 6.95624 9.3123C6.71697 9.33185 6.60257 9.36675 6.5271 9.4052C6.3311 9.50507 6.17175 9.66442 6.07188 9.86043C6.03343 9.93589 5.99852 10.0503 5.97898 10.2896C5.95883 10.5361 5.95834 10.8563 5.95834 11.3333V16C5.95834 16.477 5.95883 16.7972 5.97898 17.0438C5.99852 17.283 6.03343 17.3974 6.07188 17.4729C6.17175 17.6689 6.3311 17.8283 6.5271 17.9281C6.60257 17.9666 6.71697 18.0015 6.95624 18.021C7.20281 18.0412 7.52299 18.0417 8.00001 18.0417H12.6667C13.1437 18.0417 13.4639 18.0412 13.7104 18.021C13.9497 18.0015 14.0641 17.9666 14.1396 17.9281C14.3356 17.8283 14.4949 17.6689 14.5948 17.4729C14.6333 17.3974 14.6682 17.283 14.6877 17.0438C14.7079 16.7972 14.7083 16.477 14.7083 16V15.9583H12.8333C12.4882 15.9583 12.2083 15.6785 12.2083 15.3333C12.2083 14.9882 12.4882 14.7083 12.8333 14.7083H16C16.477 14.7083 16.7972 14.7078 17.0438 14.6877C17.283 14.6682 17.3974 14.6333 17.4729 14.5948C17.6689 14.4949 17.8283 14.3356 17.9281 14.1396C17.9666 14.0641 18.0015 13.9497 18.021 13.7104C18.0412 13.4639 18.0417 13.1437 18.0417 12.6667V8C18.0417 7.52298 18.0412 7.2028 18.021 6.95623C18.0015 6.71696 17.9666 6.60256 17.9281 6.52709C17.8283 6.33109 17.6689 6.17174 17.4729 6.07187C17.3974 6.03342 17.283 5.99851 17.0438 5.97896C16.7972 5.95882 16.477 5.95833 16 5.95833H11.3333C10.8563 5.95833 10.5361 5.95882 10.2896 5.97896C10.0503 5.99851 9.9359 6.03342 9.86044 6.07187C9.66444 6.17174 9.50508 6.33109 9.40521 6.52709C9.36676 6.60256 9.33186 6.71696 9.31231 6.95623C9.29216 7.2028 9.29168 7.52298 9.29168 8V11.1667C9.29168 11.5118 9.01186 11.7917 8.66668 11.7917C8.3215 11.7917 8.04168 11.5118 8.04168 11.1667Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77645">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,b=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_76820)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M6.34314 6.34314C6.63604 6.05025 7.11091 6.05025 7.4038 6.34314L12 10.9393L16.5962 6.34314C16.8891 6.05025 17.364 6.05025 17.6569 6.34314C17.9497 6.63604 17.9497 7.11091 17.6569 7.4038L13.0607 12L17.6569 16.5962C17.9497 16.8891 17.9497 17.364 17.6569 17.6569C17.364 17.9497 16.8891 17.9497 16.5962 17.6569L12 13.0607L7.4038 17.6569C7.11091 17.9497 6.63604 17.9497 6.34314 17.6569C6.05025 17.364 6.05025 16.8891 6.34314 16.5962L10.9393 12L6.34314 7.4038C6.05025 7.11091 6.05025 6.63604 6.34314 6.34314Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_76820">
        <rect width="24" height="24" fill="white" />
      </clipPath>
    </defs>
  </svg>
`,C=r.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3407_76065)">
      <path
        d="M12 6.99999C11.5398 6.99999 11.1667 6.6269 11.1667 6.16666C11.1667 5.70642 11.5398 5.33333 12 5.33333C12.4602 5.33333 12.8333 5.70642 12.8333 6.16666C12.8333 6.6269 12.4602 6.99999 12 6.99999Z"
        fill="currentColor"
      />
      <path
        d="M12 12.8333C11.5398 12.8333 11.1667 12.4602 11.1667 12C11.1667 11.5398 11.5398 11.1667 12 11.1667C12.4602 11.1667 12.8333 11.5398 12.8333 12C12.8333 12.4602 12.4602 12.8333 12 12.8333Z"
        fill="currentColor"
      />
      <path
        d="M12 18.6667C11.5398 18.6667 11.1667 18.2936 11.1667 17.8333C11.1667 17.3731 11.5398 17 12 17C12.4602 17 12.8333 17.3731 12.8333 17.8333C12.8333 18.2936 12.4602 18.6667 12 18.6667Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12 5.75001C11.7699 5.75001 11.5833 5.93655 11.5833 6.16667C11.5833 6.39679 11.7699 6.58334 12 6.58334C12.2301 6.58334 12.4167 6.39679 12.4167 6.16667C12.4167 5.93655 12.2301 5.75001 12 5.75001ZM10.75 6.16667C10.75 5.47632 11.3096 4.91667 12 4.91667C12.6904 4.91667 13.25 5.47632 13.25 6.16667C13.25 6.85703 12.6904 7.41667 12 7.41667C11.3096 7.41667 10.75 6.85703 10.75 6.16667ZM12 11.5833C11.7699 11.5833 11.5833 11.7699 11.5833 12C11.5833 12.2301 11.7699 12.4167 12 12.4167C12.2301 12.4167 12.4167 12.2301 12.4167 12C12.4167 11.7699 12.2301 11.5833 12 11.5833ZM10.75 12C10.75 11.3096 11.3096 10.75 12 10.75C12.6904 10.75 13.25 11.3096 13.25 12C13.25 12.6904 12.6904 13.25 12 13.25C11.3096 13.25 10.75 12.6904 10.75 12ZM12 17.4167C11.7699 17.4167 11.5833 17.6032 11.5833 17.8333C11.5833 18.0635 11.7699 18.25 12 18.25C12.2301 18.25 12.4167 18.0635 12.4167 17.8333C12.4167 17.6032 12.2301 17.4167 12 17.4167ZM10.75 17.8333C10.75 17.143 11.3096 16.5833 12 16.5833C12.6904 16.5833 13.25 17.143 13.25 17.8333C13.25 18.5237 12.6904 19.0833 12 19.0833C11.3096 19.0833 10.75 18.5237 10.75 17.8333Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3407_76065">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,y=r.dy`
  <svg
    width="140"
    height="96"
    viewBox="0 0 140 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_4257_88403)">
      <g opacity="0.4">
        <g clip-path="url(#clip1_4257_88403)">
          <g clip-path="url(#clip2_4257_88403)">
            <g opacity="0.8" filter="url(#filter0_f_4257_88403)">
              <ellipse
                cx="45.5713"
                cy="61.2938"
                rx="45.5713"
                ry="61.2938"
                transform="matrix(-0.275152 -0.961401 0.994111 -0.108365 23.6692 80.3025)"
                fill="#C0BFC1"
              />
            </g>
            <g opacity="0.8" filter="url(#filter1_f_4257_88403)">
              <ellipse
                cx="49.6555"
                cy="50.1114"
                rx="49.6555"
                ry="50.1114"
                transform="matrix(-0.517539 -0.855659 0.945307 -0.326182 10.3975 87.9766)"
                fill="#C0BFC1"
              />
            </g>
            <g opacity="0.8" filter="url(#filter2_f_4257_88403)">
              <path
                d="M141.154 3.03247C167.539 22.8936 134.54 99.5878 124.212 92.7915C117.912 88.6456 113.733 60.4772 94.173 45.9086C81.6691 36.5955 56.6586 38.5939 41.1056 37.1878C1.22291 33.5821 114.548 -16.9943 141.154 3.03247Z"
                fill="#C0BFC1"
              />
            </g>
            <path
              d="M78.5971 45.1263C77.9794 49.5216 81.121 53.5957 85.6131 54.2271C90.1053 54.8584 94.2481 51.808 94.8658 47.4128C95.4835 43.0175 92.342 38.9434 87.8498 38.312C83.3577 37.6807 79.2149 40.7311 78.5971 45.1263Z"
              fill="url(#paint0_linear_4257_88403)"
            />
            <path
              d="M120.378 78.3637L119.989 81.1303C119.731 82.9654 119.562 84.15 119.36 85.0413C119.166 85.8959 118.999 86.1992 118.895 86.3451C118.499 86.9002 117.932 87.3171 117.277 87.5363C117.105 87.5938 116.76 87.6677 115.867 87.6141C114.934 87.5582 113.723 87.3905 111.847 87.1268L80.6109 82.7369C78.735 82.4733 77.524 82.3006 76.6125 82.0973C75.7385 81.9024 75.4276 81.7365 75.278 81.6337C74.7087 81.2424 74.2794 80.6856 74.0516 80.0428C73.9917 79.8739 73.9142 79.5361 73.9635 78.6612C74.0149 77.7488 74.1789 76.5635 74.4369 74.7283L75.6584 66.0369C75.8058 65.9369 75.9505 65.8411 76.0924 65.7498C77.1899 65.0437 78.3629 64.4423 79.7464 64.1873C81.8083 63.8072 83.9443 64.0829 85.8427 64.9742C87.1166 65.5723 88.0991 66.452 88.9822 67.4137C89.5619 68.0451 90.1807 68.8058 90.8604 69.6691L94.5285 66.9912C95.9295 65.9684 97.1371 65.0867 98.1922 64.4415C99.3051 63.761 100.491 63.1868 101.879 62.9626C103.947 62.6286 106.075 62.9506 107.951 63.8817C109.21 64.5065 110.172 65.4058 111.033 66.385C111.033 66.385 117.277 74.3919 120.378 78.3637Z"
              fill="url(#paint1_linear_4257_88403)"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M18.0193 52.2289C18.1346 51.4086 18.8931 50.837 19.7134 50.9523L67.2463 57.6326C68.0667 57.7479 68.6382 58.5064 68.5229 59.3268C68.4076 60.1471 67.6491 60.7187 66.8288 60.6034L19.2959 53.9231C18.4755 53.8078 17.904 53.0493 18.0193 52.2289Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M21.5681 26.9771C21.7218 25.8833 22.7332 25.1212 23.827 25.2749L47.5934 28.6151C48.6872 28.7688 49.4493 29.7801 49.2956 30.874C49.1419 31.9678 48.1305 32.7299 47.0367 32.5762L23.2703 29.236C22.1765 29.0823 21.4144 28.0709 21.5681 26.9771Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M19.55 41.336C19.6653 40.5156 20.4238 39.9441 21.2442 40.0593L68.7771 46.7397C69.5974 46.8549 70.169 47.6135 70.0537 48.4338C69.9384 49.2542 69.1799 49.8258 68.3595 49.7105L20.8267 43.0301C20.0063 42.9149 19.4347 42.1564 19.55 41.336Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M16.4883 63.1219C16.6036 62.3015 17.3621 61.7299 18.1824 61.8452L65.7153 68.5255C66.5357 68.6408 67.1072 69.3993 66.9919 70.2197C66.8766 71.0401 66.1181 71.6116 65.2978 71.4963L17.7649 64.816C16.9445 64.7007 16.373 63.9422 16.4883 63.1219Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M15.2358 72.0343C15.3511 71.2139 16.1096 70.6424 16.93 70.7576L64.4628 77.438C65.2832 77.5533 65.8548 78.3118 65.7395 79.1321C65.6242 79.9525 64.8657 80.5241 64.0453 80.4088L16.5125 73.7285C15.6921 73.6132 15.1205 72.8547 15.2358 72.0343Z"
              fill="white"
              fill-opacity="0.4"
            />
          </g>
        </g>
      </g>
    </g>
    <defs>
      <filter
        id="filter0_f_4257_88403"
        x="-14.1589"
        y="-38.4709"
        width="172.444"
        height="136.638"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4257_88403"
        />
      </filter>
      <filter
        id="filter1_f_4257_88403"
        x="-45.8333"
        y="-40.3932"
        width="155.805"
        height="139.072"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4257_88403"
        />
      </filter>
      <filter
        id="filter2_f_4257_88403"
        x="8.68726"
        y="-25.6425"
        width="166.468"
        height="142.859"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4257_88403"
        />
      </filter>
      <linearGradient
        id="paint0_linear_4257_88403"
        x1="102.492"
        y1="40.3698"
        x2="96.2289"
        y2="84.9319"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.578125" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_4257_88403"
        x1="102.492"
        y1="40.3698"
        x2="96.2289"
        y2="84.9319"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.578125" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <clipPath id="clip0_4257_88403">
        <rect width="140" height="96" fill="white" />
      </clipPath>
      <clipPath id="clip1_4257_88403">
        <rect
          x="11.7563"
          y="3.38196"
          width="130"
          height="88"
          rx="4"
          transform="rotate(8 11.7563 3.38196)"
          fill="white"
        />
      </clipPath>
      <clipPath id="clip2_4257_88403">
        <rect
          width="130"
          height="88"
          fill="white"
          transform="translate(11.7563 3.38196) rotate(8)"
        />
      </clipPath>
    </defs>
  </svg>
`,x=r.dy`
  <svg
    width="140"
    height="96"
    viewBox="0 0 140 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_4391_90250)">
      <g opacity="0.4">
        <g clip-path="url(#clip1_4391_90250)">
          <g clip-path="url(#clip2_4391_90250)">
            <g opacity="0.8" filter="url(#filter0_f_4391_90250)">
              <ellipse
                cx="45.5713"
                cy="61.2938"
                rx="45.5713"
                ry="61.2938"
                transform="matrix(-0.275152 -0.961401 0.994111 -0.108365 23.6692 80.3025)"
                fill="#3E3E3F"
              />
            </g>
            <g opacity="0.8" filter="url(#filter1_f_4391_90250)">
              <ellipse
                cx="49.6555"
                cy="50.1114"
                rx="49.6555"
                ry="50.1114"
                transform="matrix(-0.517539 -0.855659 0.945307 -0.326182 10.3975 87.9766)"
                fill="#3E3E3F"
              />
            </g>
            <g opacity="0.8" filter="url(#filter2_f_4391_90250)">
              <path
                d="M141.154 3.03247C167.539 22.8936 134.54 99.5878 124.212 92.7915C117.912 88.6456 113.733 60.4772 94.173 45.9086C81.6691 36.5955 56.6586 38.5939 41.1056 37.1878C1.22291 33.5821 114.548 -16.9943 141.154 3.03247Z"
                fill="#3E3E3F"
              />
            </g>
            <path
              d="M78.5971 45.1263C77.9794 49.5216 81.121 53.5957 85.6131 54.2271C90.1053 54.8584 94.2481 51.808 94.8658 47.4128C95.4835 43.0175 92.342 38.9434 87.8498 38.312C83.3577 37.6807 79.2149 40.7311 78.5971 45.1263Z"
              fill="url(#paint0_linear_4391_90250)"
            />
            <path
              d="M120.378 78.3637L119.989 81.1303C119.731 82.9654 119.562 84.15 119.36 85.0413C119.166 85.8959 118.999 86.1992 118.895 86.3451C118.499 86.9002 117.932 87.3171 117.277 87.5363C117.105 87.5938 116.76 87.6677 115.867 87.6141C114.934 87.5582 113.723 87.3905 111.847 87.1268L80.6109 82.7369C78.735 82.4733 77.524 82.3006 76.6125 82.0973C75.7385 81.9024 75.4276 81.7365 75.278 81.6337C74.7087 81.2424 74.2794 80.6856 74.0516 80.0428C73.9917 79.8739 73.9142 79.5361 73.9635 78.6612C74.0149 77.7488 74.1789 76.5635 74.4369 74.7283L75.6584 66.0369C75.8058 65.9369 75.9505 65.8411 76.0924 65.7498C77.1899 65.0437 78.3629 64.4423 79.7464 64.1873C81.8083 63.8072 83.9443 64.0829 85.8427 64.9742C87.1166 65.5723 88.0991 66.452 88.9822 67.4137C89.5619 68.0451 90.1807 68.8058 90.8604 69.6691L94.5285 66.9912C95.9295 65.9684 97.1371 65.0867 98.1922 64.4415C99.3051 63.761 100.491 63.1868 101.879 62.9626C103.947 62.6286 106.075 62.9506 107.951 63.8817C109.21 64.5065 110.172 65.4058 111.033 66.385C111.033 66.385 117.277 74.3919 120.378 78.3637Z"
              fill="url(#paint1_linear_4391_90250)"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M18.0193 52.2289C18.1346 51.4086 18.8931 50.837 19.7134 50.9523L67.2463 57.6326C68.0667 57.7479 68.6382 58.5064 68.5229 59.3268C68.4076 60.1471 67.6491 60.7187 66.8288 60.6034L19.2959 53.9231C18.4755 53.8078 17.904 53.0493 18.0193 52.2289Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M21.5681 26.9771C21.7218 25.8833 22.7332 25.1212 23.827 25.2749L47.5934 28.6151C48.6872 28.7688 49.4493 29.7801 49.2956 30.874C49.1419 31.9678 48.1305 32.7299 47.0367 32.5762L23.2703 29.236C22.1765 29.0823 21.4144 28.0709 21.5681 26.9771Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M19.55 41.336C19.6653 40.5156 20.4238 39.9441 21.2442 40.0593L68.7771 46.7397C69.5974 46.8549 70.169 47.6135 70.0537 48.4338C69.9384 49.2542 69.1799 49.8258 68.3595 49.7105L20.8267 43.0301C20.0063 42.9149 19.4347 42.1564 19.55 41.336Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M16.4883 63.1219C16.6036 62.3015 17.3621 61.7299 18.1824 61.8452L65.7153 68.5255C66.5357 68.6408 67.1072 69.3993 66.9919 70.2197C66.8766 71.0401 66.1181 71.6116 65.2978 71.4963L17.7649 64.816C16.9445 64.7007 16.373 63.9422 16.4883 63.1219Z"
              fill="white"
              fill-opacity="0.8"
            />
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M15.2358 72.0344C15.3511 71.214 16.1096 70.6424 16.93 70.7577L64.4628 77.438C65.2832 77.5533 65.8548 78.3118 65.7395 79.1322C65.6242 79.9525 64.8657 80.5241 64.0453 80.4088L16.5125 73.7285C15.6921 73.6132 15.1205 72.8547 15.2358 72.0344Z"
              fill="white"
              fill-opacity="0.4"
            />
          </g>
        </g>
      </g>
    </g>
    <defs>
      <filter
        id="filter0_f_4391_90250"
        x="-14.1589"
        y="-38.4709"
        width="172.444"
        height="136.638"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4391_90250"
        />
      </filter>
      <filter
        id="filter1_f_4391_90250"
        x="-45.8333"
        y="-40.3932"
        width="155.805"
        height="139.072"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4391_90250"
        />
      </filter>
      <filter
        id="filter2_f_4391_90250"
        x="8.68726"
        y="-25.6425"
        width="166.468"
        height="142.859"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="BackgroundImageFix"
          result="shape"
        />
        <feGaussianBlur
          stdDeviation="12"
          result="effect1_foregroundBlur_4391_90250"
        />
      </filter>
      <linearGradient
        id="paint0_linear_4391_90250"
        x1="102.492"
        y1="40.3698"
        x2="96.2289"
        y2="84.9319"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.578125" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_4391_90250"
        x1="102.492"
        y1="40.3698"
        x2="96.2289"
        y2="84.9319"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0.578125" stop-color="white" />
        <stop offset="1" stop-color="white" stop-opacity="0" />
      </linearGradient>
      <clipPath id="clip0_4391_90250">
        <rect width="140" height="96" fill="white" />
      </clipPath>
      <clipPath id="clip1_4391_90250">
        <rect
          x="11.7563"
          y="3.38196"
          width="130"
          height="88"
          rx="4"
          transform="rotate(8 11.7563 3.38196)"
          fill="white"
        />
      </clipPath>
      <clipPath id="clip2_4391_90250">
        <rect
          width="130"
          height="88"
          fill="white"
          transform="translate(11.7563 3.38196) rotate(8)"
        />
      </clipPath>
    </defs>
  </svg>
`;var w=i(66208),_=i(37666),k=i(36976),M=i(81366),S=i(81530);async function E(e,t,i=!1){if(window?.apis?.ui?.getBookmarkDataByLink){if((e.crawled||!e.url)&&!i)return;t.loading=!0;let n=await window.apis.ui.getBookmarkDataByLink(e.url);e.page.getBlockById(e.id)&&(e.page.withoutTransact(()=>{e.page.updateBlock(e,{...n,url:e.url,crawled:!0})}),t.loading=!1)}}function L(e){return Object.keys(S.q).reduce((t,i)=>(t[i]=e[i],t),{})}var $=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let P=[{type:"copy",icon:g,label:"Copy original link",action:(e,t)=>{(0,k.p3)({type:"Block",models:[e],startOffset:0,endOffset:0}),(0,_.A)("Copied link to clipboard"),t?.("copy")}},{type:"duplicate",icon:v,label:"Duplicate",action:(e,t)=>{let{page:i}=e,n=i.getParent(e),o=n?.children.indexOf(e),r=L(e);i.addBlock("affine:bookmark",r,n,o),t?.("duplicate")}},{type:"reload",icon:h,label:"Reload",action:(e,t)=>{E(e,(0,M._b)(e),!0),t?.("reload")}},{type:"delete",icon:u,label:"Delete",action:(e,t)=>{e.page.deleteBlock(e),t?.("delete")}}],B=class extends(0,n.$T)(r.oi){connectedCallback(){super.connectedCallback()}render(){let e=(0,s.r)(P,({type:e})=>e,({type:e,icon:t,label:i,action:n,divider:o})=>r.dy`<icon-button
            width="130px"
            height="32px"
            class="menu-item ${e}"
            @click=${()=>{n(this.model,this.onSelected,this)}}
          >
            ${t} ${i}
          </icon-button>
          ${o?r.dy`<div class="divider"></div>`:r.Ld} `);return r.dy` <div class="bookmark-operation-menu">${e}</div> `}};B.styles=r.iv`
    .bookmark-operation-menu {
      border-radius: 8px 8px 8px 0;
      padding: 8px;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
    }
    .menu-item {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      fill: var(--affine-icon-color);
      color: var(--affine-text-primary-color);
    }
    .menu-item:hover {
      background: var(--affine-hover-color);
      fill: var(--affine-primary-color);
      color: var(--affine-primary-color);
    }
    .menu-item svg {
      margin: 0 8px;
    }
  `,$([(0,a.Cb)()],B.prototype,"model",void 0),$([(0,a.Cb)()],B.prototype,"root",void 0),$([(0,a.Cb)()],B.prototype,"onSelected",void 0),$([(0,a.IO)(".bookmark-bar")],B.prototype,"formatQuickBarElement",void 0),B=$([(0,a.Mo)("bookmark-operation-menu")],B);var R=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let T=[{type:"link",icon:p,tooltip:"Turn into Link view",action:(e,t)=>{let{page:i}=e,n=i.getParent(e),o=n?.children.indexOf(e),r=new l.Text,a=e.title||e.caption||e.url;r.insert(0,a),r.format(0,a.length,{link:e.url});let s=new i.Text(r);i.addBlock("affine:paragraph",{text:s},n,o),e.page.deleteBlock(e),t?.("link")},divider:!0},{type:"caption",icon:m,tooltip:"Add Caption",action:(e,t)=>{t?.("caption")}},{type:"edit",icon:f,tooltip:"Edit",action:(e,t)=>{t?.("edit")},divider:!0}],O=class extends(0,n.$T)(r.oi){constructor(){super(...arguments),this._menu=null}_toggleMenu(){this._menu?(this._menu.dispose(),this._menu=null):this._menu=function(e,t){let i=document.createElement("bookmark-operation-menu");i.model=t.model,i.onSelected=t.onSelected,e.appendChild(i);let n=(0,w.fi)(e,i,{placement:"top-start",modifiers:[{name:"offset",options:{offset:[0,6]}}]});return{element:i,dispose:()=>{i.remove(),n.destroy()}}}(this.moreButton,{model:this.model,onSelected:e=>{this._toggleMenu(),this.onSelected?.(e)}})}connectedCallback(){super.connectedCallback()}render(){let e=(0,s.r)(T,({type:e})=>e,({type:e,icon:t,tooltip:i,action:n,divider:o})=>r.dy`<icon-button
            width="32px"
            height="32px"
            class="bookmark-toolbar-button has-tool-tip ${e}"
            @click=${()=>{n(this.model,this.onSelected,this)}}
          >
            ${t}
            <tool-tip inert role="tooltip">${i}</tool-tip>
          </icon-button>
          ${o?r.dy`<div class="divider"></div>`:r.Ld} `);return r.dy`
      <div class="bookmark-bar">
        ${e}

        <div class="more-button-wrapper">
          <icon-button
            width="32px"
            height="32px"
            class="has-tool-tip more-button"
            @click=${()=>{this._toggleMenu()}}
          >
            ${C}
            <tool-tip inert role="tooltip">More</tool-tip>
          </icon-button>
        </div>
      </div>
    `}};O.styles=r.iv`
    ${d.a}
    .bookmark-bar {
      box-sizing: border-box;
      position: absolute;
      right: 0;
      top: -40px;
      display: flex;
      align-items: center;
      padding: 4px 8px;
      gap: 4px;
      height: 40px;

      border-radius: 8px;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      z-index: var(--affine-z-index-popover);
      user-select: none;
    }
    .divider {
      width: 1px;
      height: 24px;
      background-color: var(--affine-border-color);
    }
  `,R([(0,a.Cb)()],O.prototype,"model",void 0),R([(0,a.Cb)()],O.prototype,"onSelected",void 0),R([(0,a.IO)(".bookmark-bar")],O.prototype,"formatQuickBarElement",void 0),R([(0,a.IO)(".more-button-wrapper")],O.prototype,"moreButton",void 0),O=R([(0,a.Mo)("bookmark-toolbar")],O),i(98785);var I=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let D=r.dy`
  <style>
    .bookmark-modal-container {
      position: fixed;
      width: 100vw;
      height: 100vh;
      display: flex;
    }
    .bookmark-modal-mask {
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      margin: auto;
    }
    .bookmark-modal-wrapper {
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      margin: auto;

      width: 360px;
      height: 260px;
      background: var(--affine-background-primary-color);
      box-shadow: var(--affine-menu-shadow);
      border-radius: var(--affine-popover-radius);
      padding: 36px 40px 24px;
    }
    .bookmark-modal-close-button {
      position: absolute;
      right: 20px;
      top: 12px;
    }
    .bookmark-modal-title {
      font-size: var(--affine-font-h-6);
      font-weight: 600;
    }
    .bookmark-modal-desc {
      font-size: var(--affine-font-base);
      margin-top: 20px;
      caret-color: var(--affine-primary-color);
    }
    .bookmark-input {
      width: 100%;
      height: 32px;
      font-size: var(--affine-font-base);
      margin-top: 20px;
      caret-color: var(--affine-primary-color);
      transition: border-color 0.15s;

      line-height: 22px;
      padding: 8px 12px;
      color: var(--affine-text-primary-color);
      border: 1px solid;
      border-color: var(--affine-border-color);
      background-color: var(--affine-white);
      border-radius: 10px;
      outline: medium;
    }
    .bookmark-input:focus {
      border-color: var(--affine-primary-color);
    }

    .bookmark-input::placeholder {
      color: var(--affine-placeholder-color);
      font-size: var(--affine-font-base);
    }

    .bookmark-modal-footer {
      display: flex;
      justify-content: flex-end;
      margin-top: 40px;
    }
    .bookmark-confirm-button {
      padding: 4px 20px;
      height: 32px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: var(--affine-font-base);
      background: var(--affine-primary-color);
      color: var(--affine-white);
      border-color: var(--affine-primary-color);
      border-radius: 8px;
      cursor: pointer;
    }
  </style>
`,z=class extends(0,n.$T)(r.oi){constructor(){super(...arguments),this._modalKeyboardListener=e=>{"Enter"===e.key&&this._onConfirm(),"Escape"===e.key&&this.onCancel?.()}}get id(){return`bookmark-modal-${this.model.id.split(":")[0]}`}connectedCallback(){super.connectedCallback(),document.addEventListener("keydown",this._modalKeyboardListener),requestAnimationFrame(()=>{let e=document.querySelector(`#${this.id} input.title`);e.focus(),e.setSelectionRange(0,e.value.length)})}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this._modalKeyboardListener)}_onConfirm(){let e=document.querySelector(`#${this.id} input.title`),t=document.querySelector(`#${this.id} input.description`);this.model.page.updateBlock(this.model,{title:e.value,description:t.value}),this.onConfirm?.()}render(){let e=r.dy`${D}
      <div class="bookmark-modal" id="${this.id}">
        <div
          class="bookmark-modal-mask"
          @click=${()=>{this.onCancel?.()}}
        ></div>
        <div class="bookmark-modal-wrapper">
          <icon-button
            width="32px"
            height="32px"
            class="bookmark-modal-close-button"
            @click=${()=>{this.onCancel?.()}}
            >${b}</icon-button
          >

          <div class="bookmark-modal-title">Edit</div>
          <input
            type="text"
            class="bookmark-input title"
            placeholder="Title"
            value=${this.model.title||"Bookmark"}
            tabindex="1"
          />
          <input
            type="text"
            class="bookmark-input description"
            placeholder="Description"
            value=${this.model.description||this.model.url}
            tabindex="2"
          />
          <div class="bookmark-modal-footer">
            <div
              class="bookmark-confirm-button"
              tabindex="3"
              @click=${()=>{this._onConfirm()}}
            >
              Save
            </div>
          </div>
        </div>
      </div>`;return r.dy`<affine-portal .template=${e}></affine-portal>`}};I([(0,a.Cb)()],z.prototype,"model",void 0),I([(0,a.Cb)()],z.prototype,"onCancel",void 0),I([(0,a.Cb)()],z.prototype,"onConfirm",void 0),z=I([(0,a.Mo)("bookmark-edit-modal")],z);var A=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let H=class extends(0,n.$T)(r.oi){constructor(){super(...arguments),this._modalKeyboardListener=e=>{"Enter"===e.key&&this._onConfirm(),"Escape"===e.key&&this.onCancel?.()}}get id(){return`bookmark-create-modal-${this.model.id.split(":")[0]}`}connectedCallback(){super.connectedCallback(),requestAnimationFrame(()=>{let e=document.querySelector(`#${this.id} input.link`);e.focus()}),document.addEventListener("keydown",this._modalKeyboardListener)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this._modalKeyboardListener)}_onConfirm(){let e=document.querySelector(`#${this.id} input.link`);if(!e.value){(0,_.A)("Bookmark url can not be empty");return}this.model.page.updateBlock(this.model,{url:e.value}),this.onConfirm?.()}render(){let e=r.dy`${D}
      <div class="bookmark-modal" id="${this.id}">
        <div
          class="bookmark-modal-mask"
          @click=${()=>{this.onCancel?.(),this.model.page.deleteBlock(this.model)}}
        ></div>
        <div class="bookmark-modal-wrapper" style="width:480px">
          <icon-button
            width="32px"
            height="32px"
            class="bookmark-modal-close-button"
            @click=${()=>{this.onCancel?.(),this.model.page.deleteBlock(this.model)}}
            >${b}</icon-button
          >

          <div class="bookmark-modal-title">Bookmark</div>
          <div class="bookmark-modal-desc">
            Create a Bookmark that previews a link in card view.
          </div>
          <input
            tabindex="1"
            type="text"
            class="bookmark-input link"
            placeholder="Input in https://..."
          />

          <div class="bookmark-modal-footer">
            <div
              tabindex="2"
              class="bookmark-confirm-button"
              @click=${()=>this._onConfirm()}
            >
              Confirm
            </div>
          </div>
        </div>
      </div>`;return r.dy`<affine-portal .template=${e}></affine-portal>`}};A([(0,a.Cb)()],H.prototype,"model",void 0),A([(0,a.Cb)()],H.prototype,"onCancel",void 0),A([(0,a.Cb)()],H.prototype,"onConfirm",void 0),H=A([(0,a.Mo)("bookmark-create-modal")],H);var V=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let Z=class extends r.oi{constructor(){super(...arguments),this.size="50px",this.color="blue"}firstUpdated(){this.updateComplete.then(()=>{let{size:e,color:t}=this;this.style.setProperty("--loader-size","string"==typeof e?e:`${e}px`),this.style.setProperty("--loader-color",t)})}render(){return r.dy`<div class="bookmark-loader-wrapper">
      <svg class="bookmark-loader" x="0px" y="0px" viewBox="0 0 150 150">
        <circle class="bookmark-loader-block" cx="75" cy="75" r="60" />
      </svg>
    </div>`}};Z.styles=r.iv`
    .bookmark-loader-wrapper {
      display: flex;
      width: var(--loader-size);
      height: var(--loader-size);
    }
    .bookmark-loader {
      width: var(--loader-size);
      animation: loading 3s linear infinite;
    }
    .bookmark-loader-block {
      animation: loading-circle 2s linear infinite;
      stroke-dashoffset: 0;
      stroke-dasharray: 300;
      stroke-width: 15;
      stroke-miterlimit: 10;
      stroke-linecap: round;
      stroke: var(--loader-color);
      fill: transparent;
    }

    @keyframes loading {
      0% {
        transform: rotate(0);
      }
      100% {
        transform: rotate(360deg);
      }
    }
    @keyframes loading-circle {
      0% {
        stroke-dashoffset: 0;
      }
      100% {
        stroke-dashoffset: -600;
      }
    }
  `,V([(0,a.Cb)()],Z.prototype,"size",void 0),V([(0,a.Cb)()],Z.prototype,"color",void 0),Z=V([(0,a.Mo)("bookmark-loader")],Z);var F=i(280),U=i(88523);class j extends U.b{block2html(e,{childText:t="",begin:i,end:n}={}){return e.url}block2Text(e,{childText:t="",begin:i=0,end:n}={}){return e.url}block2Json(e,t,i){let n=L(e);return{flavour:e.flavour,children:[],...n}}}let N=r.dy`<svg
  width="140"
  height="96"
  viewBox="0 0 140 96"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g clip-path="url(#clip0_3433_80247)">
    <g opacity="0.4">
      <g clip-path="url(#clip1_3433_80247)">
        <g clip-path="url(#clip2_3433_80247)">
          <g opacity="0.8" filter="url(#filter0_f_3433_80247)">
            <ellipse
              cx="45.5713"
              cy="61.2938"
              rx="45.5713"
              ry="61.2938"
              transform="matrix(-0.275152 -0.961401 0.994111 -0.108365 23.6692 80.3025)"
              fill="#5076FF"
            />
          </g>
          <g opacity="0.8" filter="url(#filter1_f_3433_80247)">
            <ellipse
              cx="49.6555"
              cy="50.1114"
              rx="49.6555"
              ry="50.1114"
              transform="matrix(-0.517539 -0.855659 0.945307 -0.326182 10.3975 87.9766)"
              fill="#77FFCE"
            />
          </g>
          <g opacity="0.8" filter="url(#filter2_f_3433_80247)">
            <path
              d="M141.154 3.03247C167.539 22.8936 134.54 99.5878 124.212 92.7915C117.912 88.6456 113.733 60.4772 94.173 45.9086C81.6691 36.5955 56.6586 38.5939 41.1056 37.1878C1.22291 33.5821 114.548 -16.9943 141.154 3.03247Z"
              fill="#35B7E0"
            />
          </g>
          <path
            d="M78.5971 45.1263C77.9794 49.5216 81.121 53.5957 85.6131 54.2271C90.1053 54.8584 94.2481 51.808 94.8658 47.4128C95.4835 43.0175 92.342 38.9434 87.8498 38.312C83.3577 37.6807 79.2149 40.7311 78.5971 45.1263Z"
            fill="url(#paint0_linear_3433_80247)"
          />
          <path
            d="M120.378 78.3637L119.989 81.1303C119.731 82.9654 119.562 84.15 119.36 85.0413C119.166 85.8959 118.999 86.1992 118.895 86.3451C118.499 86.9002 117.932 87.3171 117.277 87.5363C117.105 87.5938 116.76 87.6677 115.867 87.6141C114.934 87.5582 113.723 87.3905 111.847 87.1268L80.6109 82.7369C78.735 82.4733 77.524 82.3006 76.6125 82.0973C75.7385 81.9024 75.4276 81.7365 75.278 81.6337C74.7087 81.2424 74.2794 80.6856 74.0516 80.0428C73.9917 79.8739 73.9142 79.5361 73.9635 78.6612C74.0149 77.7488 74.1789 76.5635 74.4369 74.7283L75.6584 66.0369C75.8058 65.9369 75.9505 65.8411 76.0924 65.7498C77.1899 65.0437 78.3629 64.4423 79.7464 64.1873C81.8083 63.8072 83.9443 64.0829 85.8427 64.9742C87.1166 65.5723 88.0991 66.452 88.9822 67.4137C89.5619 68.0451 90.1807 68.8058 90.8604 69.6691L94.5285 66.9912C95.9295 65.9684 97.1371 65.0867 98.1922 64.4415C99.3051 63.761 100.491 63.1868 101.879 62.9626C103.947 62.6286 106.075 62.9506 107.951 63.8817C109.21 64.5065 110.172 65.4058 111.033 66.385C111.033 66.385 117.277 74.3919 120.378 78.3637Z"
            fill="url(#paint1_linear_3433_80247)"
          />
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M18.0193 52.2289C18.1346 51.4086 18.8931 50.837 19.7134 50.9523L67.2463 57.6326C68.0667 57.7479 68.6382 58.5064 68.5229 59.3268C68.4076 60.1471 67.6491 60.7187 66.8288 60.6034L19.2959 53.9231C18.4755 53.8078 17.904 53.0493 18.0193 52.2289Z"
            fill="white"
            fill-opacity="0.8"
          />
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M21.5681 26.9771C21.7218 25.8833 22.7332 25.1212 23.827 25.2749L47.5934 28.6151C48.6872 28.7688 49.4493 29.7801 49.2956 30.874C49.1419 31.9678 48.1305 32.7299 47.0367 32.5762L23.2703 29.236C22.1765 29.0823 21.4144 28.0709 21.5681 26.9771Z"
            fill="white"
            fill-opacity="0.8"
          />
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M19.55 41.336C19.6653 40.5156 20.4238 39.9441 21.2442 40.0593L68.7771 46.7397C69.5974 46.8549 70.169 47.6135 70.0537 48.4338C69.9384 49.2542 69.1799 49.8258 68.3595 49.7105L20.8267 43.0301C20.0063 42.9149 19.4347 42.1564 19.55 41.336Z"
            fill="white"
            fill-opacity="0.8"
          />
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M16.4883 63.1219C16.6036 62.3015 17.3621 61.7299 18.1824 61.8452L65.7153 68.5255C66.5357 68.6408 67.1072 69.3993 66.9919 70.2197C66.8766 71.0401 66.1181 71.6116 65.2978 71.4963L17.7649 64.816C16.9445 64.7007 16.373 63.9422 16.4883 63.1219Z"
            fill="white"
            fill-opacity="0.8"
          />
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M15.2358 72.0344C15.3511 71.214 16.1096 70.6424 16.93 70.7577L64.4628 77.438C65.2832 77.5533 65.8548 78.3118 65.7395 79.1322C65.6242 79.9525 64.8657 80.5241 64.0453 80.4088L16.5125 73.7285C15.6921 73.6132 15.1205 72.8547 15.2358 72.0344Z"
            fill="white"
            fill-opacity="0.4"
          />
        </g>
      </g>
    </g>
  </g>
  <defs>
    <filter
      id="filter0_f_3433_80247"
      x="-14.1589"
      y="-38.4709"
      width="172.444"
      height="136.638"
      filterUnits="userSpaceOnUse"
      color-interpolation-filters="sRGB"
    >
      <feFlood flood-opacity="0" result="BackgroundImageFix" />
      <feBlend
        mode="normal"
        in="SourceGraphic"
        in2="BackgroundImageFix"
        result="shape"
      />
      <feGaussianBlur
        stdDeviation="12"
        result="effect1_foregroundBlur_3433_80247"
      />
    </filter>
    <filter
      id="filter1_f_3433_80247"
      x="-45.8333"
      y="-40.3932"
      width="155.805"
      height="139.072"
      filterUnits="userSpaceOnUse"
      color-interpolation-filters="sRGB"
    >
      <feFlood flood-opacity="0" result="BackgroundImageFix" />
      <feBlend
        mode="normal"
        in="SourceGraphic"
        in2="BackgroundImageFix"
        result="shape"
      />
      <feGaussianBlur
        stdDeviation="12"
        result="effect1_foregroundBlur_3433_80247"
      />
    </filter>
    <filter
      id="filter2_f_3433_80247"
      x="8.68726"
      y="-25.6425"
      width="166.468"
      height="142.859"
      filterUnits="userSpaceOnUse"
      color-interpolation-filters="sRGB"
    >
      <feFlood flood-opacity="0" result="BackgroundImageFix" />
      <feBlend
        mode="normal"
        in="SourceGraphic"
        in2="BackgroundImageFix"
        result="shape"
      />
      <feGaussianBlur
        stdDeviation="12"
        result="effect1_foregroundBlur_3433_80247"
      />
    </filter>
    <linearGradient
      id="paint0_linear_3433_80247"
      x1="102.492"
      y1="40.3698"
      x2="96.2289"
      y2="84.9319"
      gradientUnits="userSpaceOnUse"
    >
      <stop offset="0.578125" stop-color="white" />
      <stop offset="1" stop-color="white" stop-opacity="0" />
    </linearGradient>
    <linearGradient
      id="paint1_linear_3433_80247"
      x1="102.492"
      y1="40.3698"
      x2="96.2289"
      y2="84.9319"
      gradientUnits="userSpaceOnUse"
    >
      <stop offset="0.578125" stop-color="white" />
      <stop offset="1" stop-color="white" stop-opacity="0" />
    </linearGradient>
    <clipPath id="clip0_3433_80247">
      <rect width="140" height="96" fill="white" />
    </clipPath>
    <clipPath id="clip1_3433_80247">
      <rect
        x="11.7563"
        y="3.38196"
        width="130"
        height="88"
        rx="4"
        transform="rotate(8 11.7563 3.38196)"
        fill="white"
      />
    </clipPath>
    <clipPath id="clip2_3433_80247">
      <rect
        width="130"
        height="88"
        fill="white"
        transform="translate(11.7563 3.38196) rotate(8)"
      />
    </clipPath>
  </defs>
</svg>`;var W=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let q=class extends n.z3{constructor(){super(...arguments),this.slots={openInitialModal:new o.g7},this._showCreateModal=!1,this._showToolbar=!1,this._showEditModal=!1,this._isLoading=!1,this._timer=null,this._onToolbarSelected=e=>{"caption"===e&&(this._input.classList.add("caption-show"),requestAnimationFrame(()=>{this._input.focus()})),"edit"===e&&(this._showEditModal=!0),this._showToolbar=!1}}set loading(e){this._isLoading=e}get loading(){return this._isLoading}firstUpdated(){this.model.propsUpdated.on(()=>this.requestUpdate()),this.updateComplete.then(()=>{this._caption=this.model?.caption??"",this._caption&&this._input.classList.add("caption-show")})}connectedCallback(){super.connectedCallback(),(0,F.registerService)("affine:bookmark",j),E(this.model,this),this.slots.openInitialModal.on(()=>{this._showCreateModal=!0})}_onInputChange(){this._caption=this._input.value,this.model.page.updateBlock(this.model,{caption:this._caption})}_onInputBlur(){this._caption||this._input.classList.remove("caption-show")}_onHover(){!this._isLoading&&(this._showToolbar=!0,this._timer&&clearTimeout(this._timer))}_onHoverOut(){this._timer=setTimeout(()=>{this._showToolbar=!1},100)}render(){let{url:e,title:t,description:i,icon:n,image:o}=this.model,a=(0,M.FV)(),s=this._showCreateModal?r.dy`<bookmark-create-modal
          .model=${this.model}
          .onCancel=${()=>{this._showCreateModal=!1}}
          .onConfirm=${()=>{E(this.model,this,!0),this._showCreateModal=!1}}
        ></bookmark-create-modal>`:r.Ld,l=this._showEditModal?r.dy`<bookmark-edit-modal
          .model=${this.model}
          .onCancel=${()=>{this._showEditModal=!1}}
          .onConfirm=${()=>{this._showEditModal=!1}}
        ></bookmark-edit-modal>`:r.Ld,d=this._showToolbar?r.dy`<bookmark-toolbar
          .model=${this.model}
          .onSelected=${this._onToolbarSelected}
        ></bookmark-toolbar>`:r.Ld,h=this._isLoading?r.dy`<div
          class="affine-bookmark-loading ${"light"===a?"":"dark"}"
        >
          <div class="affine-bookmark-title">
            <bookmark-loader
              size="15px"
              color="var(--affine-primary-color)"
            ></bookmark-loader>
            <div class="affine-bookmark-title-content">Loading...</div>
          </div>
          <div class="affine-bookmark-banner">
            ${"light"===a?y:x}
          </div>
        </div>`:r.Ld,u=r.dy`<a
      href="${e}"
      target="_blank"
      class="affine-bookmark-link"
    >
      <div class="affine-bookmark-content-wrapper">
        <div class="affine-bookmark-title">
          <div class="affine-bookmark-icon">
            ${n?r.dy`<img src="${n}" alt="icon" />`:c}
          </div>
          <div class="affine-bookmark-title-content">
            ${t||"Bookmark"}
          </div>
        </div>

        <div class="affine-bookmark-description">${i||e}</div>
        <div class="affine-bookmark-url">${e}</div>
      </div>
      <div class="affine-bookmark-banner ${o?"shadow":""}">
        ${o?r.dy`<img src="${o}" alt="image" />`:N}
      </div>
    </a>`;return e?r.dy`
      ${l}
      <div
        class="affine-bookmark-block-container"
        @mouseover="${this._onHover}"
        @mouseout="${this._onHoverOut}"
      >
        ${d} ${this._isLoading?h:u}
        <input
          .disabled=${this.model.page.readonly}
          placeholder="Write a caption"
          class="affine-bookmark-caption"
          value=${this._caption}
          @input=${this._onInputChange}
          @blur=${this._onInputBlur}
          @click=${e=>{e.stopPropagation()}}
        />
      </div>
    `:s}};q.styles=r.iv`
    .affine-bookmark-block-container {
      width: 100%;
      margin-top: calc(var(--affine-paragraph-space) + 8px);
      position: relative;
    }
    .affine-bookmark-link {
      height: 112px;
      box-shadow: var(--affine-shadow-1);
      background: var(--affine-card-background-blue);
      border: 3px solid var(--affine-background-secondary-color);
      border-radius: 12px;
      padding: 16px 24px;
      display: flex;
      cursor: pointer;
      text-decoration: none;
      color: var(--affine-text-primary-color);
      overflow: hidden;
      line-height: calc(1em + 4px);
      position: relative;
    }
    .affine-bookmark-banner {
      width: 140px;
      height: 93px;
      margin-left: 20px;
      border-radius: 8px 8px 0 0;
      overflow: hidden;
      flex-shrink: 0;
    }
    .affine-bookmark-banner.shadow {
      box-shadow: var(--affine-shadow-1);
    }

    .affine-bookmark-banner img,
    .affine-bookmark-banner svg {
      width: 140px;
      height: 93px;
      object-fit: cover;
    }
    .affine-bookmark-content-wrapper {
      flex-grow: 1;
      overflow: hidden;
    }
    .affine-bookmark-title {
      height: 18px;
      display: flex;
      align-items: center;
      font-size: var(--affine-font-sm);
      font-weight: 600;
    }
    .affine-bookmark-title-content {
      flex-grow: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-left: 8px;
    }
    .affine-bookmark-icon {
      width: 18px;
      height: 18px;
      color: var(--affine-text-secondary-color);
      flex-shrink: 0;
    }
    .affine-bookmark-icon img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .affine-bookmark-description {
      height: 32px;
      line-height: 16px;
      margin-top: 4px;
      font-size: var(--affine-font-xs);

      display: -webkit-box;
      word-break: break-all;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .affine-bookmark-url {
      font-size: var(--affine-font-xs);
      color: var(--affine-text-secondary-color);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-top: 2px;
    }
    .affine-bookmark-caption {
      width: 100%;
      font-size: var(--affine-font-sm);
      outline: none;
      border: 0;
      font-family: inherit;
      text-align: center;
      color: var(--affine-icon-color);
      display: none;
      background: var(--affine-background-primary-color);
    }
    .affine-bookmark-caption::placeholder {
      color: var(--affine-placeholder-color);
    }
    .affine-bookmark-caption.caption-show {
      display: inline-block;
    }
    .affine-bookmark-loading {
      width: 100%;
      height: 112px;
      padding: 16px 24px;
      display: flex;
      justify-content: space-between;
      box-shadow: var(--affine-shadow-1);
      background: var(--affine-hover-color);
      border: 3px solid var(--affine-background-secondary-color);
      color: var(--affine-placeholder-color);
      border-radius: 12px;
    }
  `,W([(0,a.IO)("input.affine-bookmark-caption")],q.prototype,"_input",void 0),W([(0,a.SB)()],q.prototype,"_showCreateModal",void 0),W([(0,a.SB)()],q.prototype,"_showToolbar",void 0),W([(0,a.SB)()],q.prototype,"_showEditModal",void 0),W([(0,a.SB)()],q.prototype,"_caption",void 0),W([(0,a.SB)()],q.prototype,"_isLoading",void 0),q=W([(0,a.Mo)("affine-bookmark")],q)},56347:function(e,t,i){"use strict";i.d(t,{PO:function(){return L},_Q:function(){return P._},E6:function(){return M},b:function(){return g}}),i(84954),i(98785);var n=i(92758),o=i(15486),r=i(91827),a=i(29691),s=i(93251),l=i(50634),d=i(32916),c=i(464),h=i(81366),u=i(59867),f=i(13592),p=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let g=class extends l.Zi{constructor(){super(...arguments),this._filterText="",this._currentSelectedIndex=0,this.delay=150,this._clickAwayListener=e=>{this.renderRoot.parentElement?.contains(e.target)||this.dispatchEvent((0,h.yM)("dispose",null))}}static get styles(){return o.iv`
      lang-list {
        display: flex;
        flex-direction: column;
        position: absolute;
        background: var(--affine-background-overlay-panel-color);
        border-radius: 12px;
        top: 24px;
        z-index: 1;
      }

      .lang-list-container {
        box-shadow: var(--affine-menu-shadow);
        border-radius: 8px;
        padding: 12px 8px;
      }

      .lang-list-button-container {
        position: relative;
        overflow: scroll;
        height: 424px;
        width: 200px;
        padding-top: 5px;
        padding-left: 4px;
        padding-right: 4px;
        /*scrollbar-color: #fff0 #fff0;*/
      }

      /*
      .lang-list-button-container::-webkit-scrollbar {
        background: none;
      }
      */

      .lang-item {
        display: flex;
        justify-content: flex-start;
        padding-left: 12px;
        margin-bottom: 5px;
      }

      .input-wrapper {
        position: relative;
        display: flex;
        margin-top: 8px;
        margin-left: 4px;
      }

      #filter-input {
        display: flex;
        align-items: center;
        height: 32px;
        width: 192px;
        border: 1px solid var(--affine-border-color);
        border-radius: 8px;
        padding-left: 44px;
        padding-top: 4px;

        font-family: var(--affine-font-family);
        font-size: var(--affine-font-sm);
        box-sizing: border-box;
        color: inherit;
        background: var(--affine-background-overlay-panel-color);
      }

      #filter-input:focus {
        outline: none;
      }

      #filter-input::placeholder {
        color: var(--affine-placeholder-color);
        font-size: var(--affine-font-sm);
      }

      .search-icon {
        position: absolute;
        left: 8px;
        height: 100%;
        display: flex;
        align-items: center;
        fill: var(--affine-icon-color);
      }
    `}async connectedCallback(){super.connectedCallback(),document.addEventListener("click",this._clickAwayListener),setTimeout(()=>{this.filterInput?.focus()},0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("click",this._clickAwayListener)}_onLanguageClicked(e){this.dispatchEvent((0,h.yM)("selected-language-changed",{language:e?.id??null}))}render(){let e=[f.NL,...c.tc].filter(e=>!this._filterText||e.id.startsWith(this._filterText.toLowerCase())||e.aliases?.some(e=>e.startsWith(this._filterText.toLowerCase()))).sort((e,t)=>(u.A[e.id]??1/0)-(u.A[t.id]??1/0)),t=t=>{if("ArrowDown"===t.key)t.preventDefault(),this._currentSelectedIndex=(this._currentSelectedIndex+1)%e.length;else if("ArrowUp"===t.key)t.preventDefault(),this._currentSelectedIndex=(this._currentSelectedIndex+e.length-1)%e.length;else if("Enter"===t.key){if(t.preventDefault(),-1===this._currentSelectedIndex||this._currentSelectedIndex>=e.length)return;this._onLanguageClicked(e[this._currentSelectedIndex])}};return o.dy`
      <div class="lang-list-container">
        <div class="input-wrapper">
          <div class="search-icon">${n.W1}</div>
          <input
            id="filter-input"
            type="text"
            placeholder="Search"
            @input="${()=>{this._filterText=this.filterInput?.value,this._currentSelectedIndex=0}}"
            @keydown="${t}"
          />
        </div>
        <div class="lang-list-button-container">
          ${e.map((e,t)=>o.dy`
              <icon-button
                width="100%"
                height="32px"
                @click="${()=>this._onLanguageClicked(e)}"
                class="lang-item"
                ?hover=${t===this._currentSelectedIndex}
              >
                ${e.id[0].toUpperCase()+e.id.slice(1)}
              </icon-button>
            `)}
        </div>
      </div>
    `}};p([(0,d.SB)()],g.prototype,"_filterText",void 0),p([(0,d.SB)()],g.prototype,"_currentSelectedIndex",void 0),p([(0,d.IO)("#filter-input")],g.prototype,"filterInput",void 0),p([(0,d.Cb)()],g.prototype,"delay",void 0),g=p([(0,d.Mo)("lang-list")],g);var m=i(13246),v=i(57891),b=i(30195),C=i(280),y=i(63863),x=i(67072),w=i(88523),_=i(65024);let k=(e,t,i=0,n=e.length)=>{let o=[],r=i;for(;r<n;){let i=e.indexOf(t,r);if(-1===i||i>n)break;o.push(i),r=i+1}return o};class M extends w.b{setLang(e,t){let i=(0,u.W)(t),n=i?.id??f.AY;e.page.updateBlock(e,{language:n})}block2html(e,{childText:t="",begin:i,end:n}={}){let o=document.querySelector(`[${x.SF}="${e.id}"] rich-text`);if(!o)return super.block2html(e,{childText:t,begin:i,end:n});let r=document.createElement("pre"),a=document.createElement("code");return r.setAttribute("code-lang",e.language),a.innerHTML=Array.from(o.querySelectorAll("v-line")).map(e=>e.textContent+"\n").join(""),r.append(a),r.outerHTML}async json2Block(e,t,i){(0,m.kP)(i);let n=t.map(e=>e.text),o=n.map(e=>e?.map(e=>e.insert).join("")),r=o.join("\n");e.text?.insert(r,i.startOffset);let a=(0,_.gj)(e);(0,m.kP)(a),a.setVRange({index:i.startOffset+r.length,length:0})}defineKeymap(e,t){let i=super.defineKeymap(e,t);return{...i,tab:{key:"Tab",handler(e,t){t.event.stopPropagation();let i=this.vEditor.yText.toString(),n=i.lastIndexOf("\n",e.index-1),o=k(i,"\n",e.index,e.index+e.length).map(e=>e+1).reverse();return -1!==n?o.push(n+1):o.push(0),o.forEach(e=>{this.vEditor.insertText({index:e,length:0},"  ")}),this.vEditor.setVRange({index:e.index+2,length:e.length+(o.length-1)*2}),x.m7}},shiftTab:{key:"Tab",shiftKey:!0,handler:function(e,t){t.event.stopPropagation();let i=this.vEditor.yText.toString(),n=i.lastIndexOf("\n",e.index-1),o=k(i,"\n",e.index,e.index+e.length).map(e=>e+1).reverse();return -1!==n?o.push(n+1):o.push(0),(o=o.filter(e=>"  "===i.slice(e,e+2))).forEach(e=>{this.vEditor.deleteText({index:e,length:2})}),o.length>0&&this.vEditor.setVRange({index:e.index-(o[o.length-1]<e.index?2:0),length:e.length-(o.length-1)*2}),x.m7}}}}}let S=e=>t=>o.dy`<affine-code-line
    .delta=${t}
    .highlightOptionsGetter=${e}
  ></affine-code-line>`;var E=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let L=class extends l.z3{constructor(){super(...arguments),this._showLangList=!1,this._optionPosition=null,this._wrap=!1,this.textSchema={attributesSchema:b.z.object({}),textRenderer:()=>S(()=>({lang:this.model.language.toLowerCase(),highlighter:this._highlighter}))},this._richTextResizeObserver=new ResizeObserver(()=>{this._updateLineNumbers()}),this._themeChangeObserver=null,this._preLang=null,this._highlighter=null,this.hoverState=new m.g7}async _startHighlight(e){let t=(0,h.FV)();this._highlighter=await (0,c.FP)({theme:"dark"===t?f.$J:f.f8,themes:[f.f8,f.$J],langs:[e],paths:{wasm:"https://cdn.jsdelivr.net/npm/shiki/dist",themes:"https://cdn.jsdelivr.net/",languages:"https://cdn.jsdelivr.net/npm/shiki/languages"}});let i=this.querySelector("rich-text");(0,m.kP)(i);let n=i.vEditor;(0,m.kP)(n);let o=n.getVRange();n.requestUpdate(),o&&n.setVRange(o)}get readonly(){return this.model.page.readonly}connectedCallback(){let e;super.connectedCallback(),(0,C.registerService)("affine:code",M),this._disposables.add(this.model.propsUpdated.on(()=>this.requestUpdate())),this._disposables.add(this.model.childrenUpdated.on(()=>this.requestUpdate()));let t=()=>{let e=this.getBoundingClientRect();this._optionPosition={x:e.right+12,y:Math.min(Math.max(e.top,76),e.bottom-96)}};this.hoverState.on(n=>{if(clearTimeout(e),n){t();return}e=window.setTimeout(()=>{this._optionPosition=null},i)}),this._disposables.addFromEvent(this,"mouseover",e=>{this.hoverState.emit(!0)});let i=300;this._disposables.addFromEvent(this,"mouseleave",e=>{this.hoverState.emit(!1)});let n=(0,h.lN)(this.model.page);n&&this._disposables.addFromEvent(n,"scroll",e=>{this._optionPosition&&t()})}disconnectedCallback(){super.disconnectedCallback(),this.hoverState.dispose(),this._richTextResizeObserver.disconnect(),this._themeChangeObserver?.dispose()}_onClickWrapBtn(){let e=this.querySelector(".affine-code-block-container");(0,m.kP)(e),this._wrap=e.classList.toggle("wrap")}firstUpdated(){if(this._themeChangeObserver=(0,y.zp)(this,async e=>{if(!this._highlighter)return;let t=this.querySelector("rich-text"),i=t?.vEditor;i&&setTimeout(()=>{i.requestUpdate()})}),!this.model.language||this.model.language===f.AY){this._highlighter=null;return}let e=c.tc.find(e=>e.id===this.model.language.toLowerCase());if(!e){console.warn("Unexpected language: ",this.model.language);return}this._startHighlight(e)}updated(){if(this.model.language!==this._preLang){this._preLang=this.model.language;let e=c.tc.find(e=>e.id===this.model.language.toLowerCase());if(e){if(this._highlighter){let t=this._highlighter.getLoadedLanguages();t.includes(e.id)||this._highlighter.loadLanguage(e).then(()=>{let e=this.querySelector("rich-text"),t=e?.vEditor;t&&t.requestUpdate()})}else this._startHighlight(e)}else this._highlighter=null;let t=this.querySelector("rich-text"),i=t?.vEditor;i&&i.requestUpdate()}let e=this.querySelector("rich-text");(0,m.kP)(e),this._richTextResizeObserver.disconnect(),this._richTextResizeObserver.observe(e)}_onClickLangBtn(){this.readonly||(this._showLangList=!this._showLangList)}_langListTemplate(){let e=this.model.language[0].toUpperCase()+this.model.language.slice(1);return o.dy`<div
      class="lang-list-wrapper"
      style="${this._showLangList?"visibility: visible;":""}"
    >
      <icon-button
        class="lang-button"
        data-testid="lang-button"
        width="auto"
        height="24px"
        ?hover=${this._showLangList}
        ?disabled=${this.readonly}
        @click=${this._onClickLangBtn}
      >
        ${e} ${this.readonly?o.dy``:n.ve}
      </icon-button>
      ${this._showLangList?o.dy`<lang-list
            @selected-language-changed=${e=>{(0,C.getService)("affine:code").setLang(this.model,e.detail.language),this._showLangList=!1}}
            @dispose=${()=>{this._showLangList=!1}}
          ></lang-list>`:""}
    </div>`}_codeOptionTemplate(){return this._optionPosition?o.dy`<affine-portal
      .template=${function({model:e,position:t,hoverState:i,wrap:l,onClickWrap:d}){let c=e.page,h=c.readonly,u={position:"fixed",left:t.x+"px",top:t.y+"px"};return o.dy`
    <style>
      .affine-codeblock-option-container > div {
          position: fixed;
          z-index: 1;
          box-shadow:var(--affine-shadow-2)
      }
      .affine-codeblock-option {
        box-shadow:var(--affine-shadow-2);
        padding:4px;
        border-radius:8px;
        background:var(--affine-background-overlay-panel-color)
      }

      ${a.a}
    </style>

    <div
      class="affine-codeblock-option"
      style=${(0,r.V)(u)}
      @mouseover=${()=>i.emit(!0)}
      @mouseout=${()=>i.emit(!1)}
    >
      <format-bar-button
        class="has-tool-tip"
        data-testid="copy-button"
        @click=${()=>(0,s.DL)(e)}
      >
        ${n.TI}
        <tool-tip inert tip-position="right" role="tooltip"
          >Copy to Clipboard</tool-tip
        >
      </format-bar-button>
      <format-bar-button
        class="has-tool-tip"
        data-testid="wrap-button"
        ?active=${l}
        @click=${d}
      >
        ${l?n.P9:n.ug}
        <tool-tip inert tip-position="right" role="tooltip">Wrap code</tool-tip>
      </format-bar-button>
      ${h?"":o.dy`<format-bar-button
            data-testid="delete-button"
            class="has-tool-tip"
            @click=${()=>{h||e.page.deleteBlock(e)}}
          >
            ${n.pJ}
            <tool-tip inert tip-position="right" role="tooltip"
              >Delete</tool-tip
            >
          </format-bar-button>`}
    </div>
  `}({model:this.model,position:this._optionPosition,hoverState:this.hoverState,wrap:this._wrap,onClickWrap:()=>this._onClickWrapBtn()})}
    ></affine-portal>`:""}_updateLineNumbers(){let e=this.querySelector("#line-numbers");(0,m.kP)(e);let t=this._wrap?function(e=0){return function(t,i){let n={"--top":`${e}px`};return e=t.getBoundingClientRect().height,o.dy`<div style=${(0,r.V)(n)}>${i+1}</div>`}}():$;(0,o.sY)((0,v.r)(Array.from(this.querySelectorAll("v-line")),t),e)}render(){return o.dy`<div class="affine-code-block-container">
        ${this._langListTemplate()}
        <div class="rich-text-container">
          <div id="line-numbers"></div>
          <rich-text .model=${this.model} .textSchema=${this.textSchema}>
          </rich-text>
        </div>
        ${this.content}
      </div>
      ${this._codeOptionTemplate()}`}};function $(e,t){return o.dy`<div>${t+1}</div>`}L.styles=o.iv`
    code-block {
      position: relative;
      z-index: 1;
    }

    .affine-code-block-container {
      font-size: var(--affine-font-sm);
      line-height: var(--affine-line-height);
      position: relative;
      padding: 32px 0px 12px 0px;
      background: var(--affine-background-code-block);
      border-radius: 10px;
      margin-top: calc(var(--affine-paragraph-space) + 8px);
      margin-bottom: calc(var(--affine-paragraph-space) + 8px);
    }

    /* hover area */
    .affine-code-block-container::after {
      content: '';
      position: absolute;
      top: 0;
      right: 0;
      width: 50px;
      height: 100%;
      transform: translateX(100%);
    }

    /* hover area */
    .affine-code-block-container::after {
      content: '';
      position: absolute;
      top: 0;
      right: 0;
      width: 50px;
      height: 100%;
      transform: translateX(100%);
    }

    .affine-code-block-container .virgo-editor {
      font-family: var(--affine-font-code-family);
      font-variant-ligatures: none;
    }

    .affine-code-block-container .lang-list-wrapper {
      position: absolute;
      font-size: var(--affine-font-sm);
      line-height: var(--affine-line-height);
      top: 12px;
      left: 12px;
    }

    .affine-code-block-container > .lang-list-wrapper {
      visibility: hidden;
    }
    .affine-code-block-container:hover > .lang-list-wrapper {
      visibility: visible;
    }

    .affine-code-block-container > .lang-list-wrapper > .lang-button {
      display: flex;
      justify-content: flex-start;
      padding: 0 8px;
    }

    .affine-code-block-container rich-text {
      /* to make sure the resize observer can be triggered as expected */
      display: block;
      position: relative;
      width: 90%;
      overflow-x: auto;
      overflow-y: hidden;
      padding-bottom: 20px;
    }

    .affine-code-block-container .rich-text-container {
      position: relative;
      border-radius: 5px;
      padding: 4px 12px 4px 60px;
    }

    #line-numbers {
      position: absolute;
      text-align: right;
      left: 20px;
      line-height: var(--affine-line-height);
      color: var(--affine-text-secondary-color);
    }

    .affine-code-block-container .virgo-editor {
      width: 90%;
      margin: 0;
    }

    .affine-code-block-container affine-code-line span v-text {
      display: inline;
    }

    .affine-code-block-container affine-code-line span {
      white-space: pre;
    }

    .affine-code-block-container.wrap #line-numbers {
      top: calc(var(--affine-line-height) + 4px);
    }

    .affine-code-block-container.wrap #line-numbers > div {
      margin-top: calc(
        var(--top, 0) / var(--affine-zoom, 1) - var(--affine-line-height)
      );
    }

    .affine-code-block-container.wrap v-line > div {
      display: block;
    }

    .affine-code-block-container.wrap affine-code-line span {
      white-space: break-spaces;
    }

    .affine-code-block-container .virgo-editor::-webkit-scrollbar {
      display: none;
    }

    .code-block-option {
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
      list-style: none;
      padding: 4px;
      width: 40px;
      background-color: var(--affine-background-overlay-panel-color);
      margin: 0;
    }

    ${a.a}
  `,E([(0,d.SB)()],L.prototype,"_showLangList",void 0),E([(0,d.SB)()],L.prototype,"_optionPosition",void 0),E([(0,d.SB)()],L.prototype,"_wrap",void 0),L=E([(0,d.Mo)("affine-code")],L);var P=i(1669)},74403:function(e,t,i){"use strict";i.d(t,{h:function(){return a}});var n=i(15486),o=i(32916),r=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let a=class extends n.oi{constructor(){super(),this.size=null,this.width="28px",this.height="28px",this.text=null,this.disabled=!1,this.addEventListener("keypress",e=>{this.disabled||"Enter"!==e.key||this.click()}),this.addEventListener("click",e=>{""===this.disabled&&(e.preventDefault(),e.stopPropagation())},{capture:!0})}connectedCallback(){if(super.connectedCallback(),this.tabIndex=0,this.size&&(this.width||this.height))throw Error("Cannot set both size and width/height on an icon-button");let e=this.width,t=this.height;this.size&&(e=this.size,t=this.size),this.style.setProperty("--button-width","string"==typeof e?e:`${e}px`),this.style.setProperty("--button-height","string"==typeof t?t:`${t}px`)}render(){return n.dy`<slot></slot>${this.text?n.dy`<span>${this.text}</span>`:""}<slot name="optional"></slot> `}};a.styles=n.iv`
    :host {
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;
      border: none;
      width: var(--button-width);
      height: var(--button-height);
      border-radius: 5px;
      background: transparent;
      cursor: pointer;
      user-select: none;
      font-family: var(--affine-font-family);
      fill: var(--affine-icon-color);
      color: var(--affine-popover-color);
      pointer-events: auto;
    }

    :host > span {
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    :host(:hover) {
      background: var(--affine-hover-color);
      fill: var(--affine-primary-color);
      color: var(--affine-primary-color);
    }

    :host(:active) {
      background: transparent;
      fill: var(--affine-primary-color);
      color: var(--affine-primary-color);
    }

    :host([disabled]),
    :host(:disabled) {
      background: transparent;
      color: var(--affine-text-disable-color);
      fill: var(--affine-text-disable-color);
      cursor: not-allowed;
    }

    /* You can add a 'hover' attribute to the button to show the hover style */
    :host([hover]) {
      background: var(--affine-hover-color);
      fill: var(--affine-primary-color);
      color: var(--affine-primary-color);
    }

    /* You can add a 'active' attribute to the button to revert the active style */
    :host([active]) {
      fill: var(--affine-primary-color);
      color: var(--affine-primary-color);
    }

    :host(:active[active]) {
      background: transparent;
      fill: var(--affine-icon-color);
    }
  `,r([(0,o.Cb)()],a.prototype,"size",void 0),r([(0,o.Cb)()],a.prototype,"width",void 0),r([(0,o.Cb)()],a.prototype,"height",void 0),r([(0,o.Cb)()],a.prototype,"text",void 0),r([(0,o.Cb)()],a.prototype,"disabled",void 0),a=r([(0,o.Mo)("icon-button")],a)},62610:function(e,t,i){"use strict";i.d(t,{DU:function(){return g},NG:function(){return f},vI:function(){return p}});var n=i(67072),o=i(53905),r=i(31054),a=i(50634),s=i(15486),l=i(32916),d=i(91827),c=i(81366),h=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let u=e=>{e.preventDefault()},f=class extends s.oi{constructor(){super(...arguments),this.rect=null}render(){if(!this.rect)return null;let{left:e,top:t,width:i,height:n}=this.rect,o=(0,d.V)({width:`${i}px`,height:`${n}px`,transform:`translate(${e}px, ${t}px)`});return s.dy`<div class="affine-drag-indicator" style=${o}></div>`}};f.styles=s.iv`
    .affine-drag-indicator {
      position: absolute;
      top: 0;
      left: 0;
      background: var(--affine-primary-color);
      transition-property: width, height, transform;
      transition-duration: 100ms;
      transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
      transition-delay: 0s;
      transform-origin: 0 0;
      pointer-events: none;
      z-index: 1;
    }
  `,h([(0,l.Cb)()],f.prototype,"rect",void 0),f=h([(0,l.Mo)("affine-drag-indicator")],f);let p=class extends a.Zi{constructor(){super(...arguments),this.offset={x:0,y:0}}render(){return s.dy`<style>
      affine-drag-preview {
        --x: 0px;
        --y: 0px;
        height: auto;
        display: block;
        position: absolute;
        box-sizing: border-box;
        font-family: var(--affine-font-family);
        font-size: var(--affine-font-base);
        line-height: var(--affine-line-height);
        color: var(--affine-text-primary-color);
        font-weight: 400;
        top: 0;
        left: 0;
        opacity: 0.843;
        cursor: none;
        user-select: none;
        pointer-events: none;
        caret-color: transparent;
        transform-origin: 0 0;
        z-index: 2;
      }

      affine-drag-preview > .affine-block-element {
        pointer-events: none;
      }

      affine-drag-preview > .affine-block-element:first-child > *:first-child {
        margin-top: 0;
      }

      affine-drag-preview .affine-rich-text {
        user-modify: read-only;
        -webkit-user-modify: read-only;
      }

      affine-drag-preview.grabbing {
        cursor: grabbing;
        pointer-events: auto;
      }

      affine-drag-preview.grabbing:after {
        content: '';
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        width: 24px;
        height: 24px;
        transform: translate(var(--x), var(--y));
      }
    </style>`}};h([(0,l.Cb)()],p.prototype,"offset",void 0),p=h([(0,l.Mo)("affine-drag-preview")],p);let g=class extends(0,a.$T)(s.oi){constructor(e){super(),this._draggingElements=[],this._scale=1,this._currentClientX=0,this._currentClientY=0,this._stopPropagation=!1,this._handleAnchorState=null,this._handleAnchorDisposable=null,this._lastDroppingTarget=null,this._lastDroppingType="none",this._indicator=null,this._dragPreview=null,this._onClick=e=>{let{selectedBlocks:t}=this,{_handleAnchorState:i}=this,n=i?.element;i&&t.length&&n===t[0]&&(i=null),this.setSelectedBlock(i,n),this.toggleAttribute("data-selected",!!i),e.stopPropagation()},this._onDragOverDocument=e=>{if(!o.vU)throw Error("FireFox only");this._currentClientX=e.clientX,this._currentClientY=e.clientY},this.onDragStart=(e,t=!1)=>{if(this._dragPreview||!e.dataTransfer)return;e.dataTransfer.effectAllowed="move";let i=this._handleAnchorState,n=this.selectedBlocks;i&&!n.includes(i.element)&&(n=[i.element],this.setSelectedBlock(i)),this._draggingElements=n,this._createDragPreview(e,(0,c.rc)(n),t),this.setDragType(!0)},this.onDrag=(e,t,i)=>{this._dragHandle.style.cursor="grabbing";let n=e.clientX,r=e.clientY;if(!t&&o.vU&&(n=this._currentClientX,r=this._currentClientY),!this._indicator||!t&&this._indicator.rect&&this._indicator.rect.left===n&&this._indicator.rect.top===r)return;if(this._dragPreview&&e.screenY){let{x:e,y:t}=this._dragPreview.offset,i=n+e,o=r+t,a=this._scale;this._dragPreview.style.transform=`translate(${i}px, ${o}px) scale(${a})`}if(i)return;let a=new c.E9(n,r),s=this._getClosestBlockElement(a.clone()),l="none",d=null,h=null;if(s&&!this._draggingElements.includes(s)&&!(0,c.e1)(this._draggingElements,s)){let e=(0,c.gc)(s),t=(0,c.Lb)(a,e,s,this._draggingElements,this._scale);t&&(l=t.type,d=t.rect,h=t.modelState)}this._indicator.rect=d,this._lastDroppingType=l,this._lastDroppingTarget=h},this.onDragEnd=(e,t)=>{this._stopPropagation=!1;let i=e.dataTransfer?.dropEffect??"none";if(this._removeDragPreview(),this.setDragType(!1),!t&&"none"===i){this.hide(!0);return}(0,r.kP)(this._draggingElements),this.onDropCallback?.(this._indicator?.rect?.min??new c.E9(e.clientX,e.clientY),this._draggingElements,this._lastDroppingTarget,this._lastDroppingType),this.hide(!0)},this.getDropAllowedBlocks=()=>(console.warn("you may forget to set `getAllowedBlocks`"),[]),this.addEventListener("beforeprint",()=>this.hide(!0)),this.onDropCallback=e?.onDropCallback,this.setDragType=e?.setDragType,this.setSelectedBlock=e?.setSelectedBlock,this._getSelectedBlocks=e?.getSelectedBlocks,this._getClosestBlockElement=e?.getClosestBlockElement,e?.container.appendChild(this),this._container=e?.container}get selectedBlocks(){return this._getSelectedBlocks()??[]}onContainerMouseMove(e,t){let i=this._container.querySelector(".affine-frame-block-container");(0,r.kP)(i);let o=i.getBoundingClientRect();if(e.raw.clientY<o.y&&this.hide(),t){let{rect:i,element:o}=t,r=i.left,a=i.top,s=i.height,l=!1,d=this.selectedBlocks;if(d.includes(o)&&(l=!0,d.length>1)){let e=(0,c.rc)(d),t=(0,c.az)(e[0]),i=(0,c.az)(e[e.length-1]);r=t.left,a=t.top,s=i.bottom-t.top}this.toggleAttribute("data-selected",l),this._handleAnchorState=t,this.style.display="block",this.style.height=`${s/this._scale}px`,this.style.width="24px";let h=this._container.getBoundingClientRect(),u=r-h.left-(24+n.Z_)*this._scale,f=a-h.top;this.style.transform=`translate(${u}px, ${f}px) scale(${this._scale})`,this.style.opacity=`${(1-(e.raw.clientX-r)/i.width).toFixed(2)}`;let p=this._calcDragHandleY(e.raw.clientY,a,s,this._scale);this._dragHandle.style.transform=`translateY(${p}px)`,this._handleAnchorDisposable&&this._handleAnchorDisposable.dispose(),this._handleAnchorDisposable=t.model.propsUpdated.on(()=>{this.hide()});return}this.hide()}hide(e=!1){this.style.display="none",e&&this.reset()}reset(){this._handleAnchorState=null,this._lastDroppingType="none",this._lastDroppingTarget=null,this._indicator&&(this._indicator.rect=null),this._draggingElements.forEach(e=>{e.style.opacity="1"}),this._draggingElements=[]}setPointerEvents(e){this.style.pointerEvents=e}setScale(e=1){this._scale=e}firstUpdated(){this.style.display="none",this.style.position="absolute",this._indicator=document.querySelector("affine-drag-indicator"),this._indicator||(this._indicator=document.createElement("affine-drag-indicator"),document.body.appendChild(this._indicator));let e=this._disposables;o.vU&&e.addFromEvent(this._container,"dragover",this._onDragOverDocument),e.addFromEvent(document.body,"dragover",u,!1),e.addFromEvent(this,"mousemove",this._onMouseMoveOnHost),e.addFromEvent(this._dragHandle,"click",this._onClick),e.addFromEvent(this._dragHandle,"dragstart",this.onDragStart),e.addFromEvent(this._dragHandle,"drag",this.onDrag),e.addFromEvent(this._dragHandle,"dragend",this.onDragEnd)}disconnectedCallback(){super.disconnectedCallback(),this.hide(!0),this._handleAnchorDisposable?.dispose()}_onMouseMoveOnHost(e){if(o.vU&&(this._currentClientX=e.clientX,this._currentClientY=e.clientY),this._stopPropagation&&e.stopPropagation(),!this._handleAnchorState)return;let{rect:t,element:i}=this._handleAnchorState,n=this.selectedBlocks,r=t.top,a=t.height;if(n.includes(i)&&n.length>1){let e=(0,c.rc)(n),t=(0,c.az)(e[0]),i=(0,c.az)(e[e.length-1]);r=t.top,a=i.bottom-t.top}let s=this._calcDragHandleY(e.clientY,r,a,this._scale);this._dragHandle.style.cursor="grab",this._dragHandle.style.transform=`translateY(${s}px)`}_calcDragHandleY(e,t,i,n){return Math.max(0,Math.min(e-t-16*n/2,i-16*n))/n}_createDragPreview(e,t,i=!1){let n=this._dragPreview=new p,o=this._container.getBoundingClientRect(),r=t[0].getBoundingClientRect(),{clientX:a,clientY:l}=e,d=this._scale,c=r.left-o.left,h=r.top-o.top;n.offset.x=c-a,n.offset.y=h-l,n.style.width=`${r.width/d}px`,n.style.transform=`translate(${c}px, ${h}px) scale(${d})`;let u=-n.offset.x-o.left-12,f=-n.offset.y-o.top-12;n.style.setProperty("--x",`${u}px`),n.style.setProperty("--y",`${f}px`);let g=document.createDocumentFragment();t.forEach(e=>{let t=document.createElement("div");t.classList.add("affine-block-element"),(0,s.sY)(e.render(),t),g.appendChild(t)}),n.appendChild(g),this._container.appendChild(n),i&&n.classList.add("grabbing"),requestAnimationFrame(()=>{n.querySelector("rich-text")?.vEditor?.rootElement.blur()})}_removeDragPreview(){this._dragPreview&&(this._dragPreview.remove(),this._dragPreview=null)}render(){return s.dy`
      <div class="affine-drag-handle-line"></div>
      <div class="affine-drag-handle" draggable="true">
        <svg
          class="affine-drag-handle-normal"
          width="16"
          height="18"
          viewBox="0 0 16 12"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            x="7.7782"
            y="0.707107"
            width="10"
            height="10"
            rx="2.5"
            transform="rotate(45 7.7782 0.707107)"
          />
        </svg>

        <svg
          class="affine-drag-handle-hover"
          width="16"
          height="18"
          viewBox="0 0 16 12"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M2.41421 6.58579L6.58579 2.41421C7.36684 1.63317 8.63316 1.63316 9.41421 2.41421L13.5858 6.58579C14.3668 7.36684 14.3668 8.63316 13.5858 9.41421L9.41421 13.5858C8.63316 14.3668 7.36684 14.3668 6.58579 13.5858L2.41421 9.41421C1.63317 8.63316 1.63316 7.36684 2.41421 6.58579Z"
            stroke-width="1.5"
          />
          <path
            class="ok"
            d="M5 8.5L7.5 10.5L10.5 7"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </div>
    `}};g.styles=s.iv`
    :host {
      top: 0;
      left: 0;
      overflow: hidden;
      width: ${32}px;
      transform-origin: 0 0;
      pointer-events: none;
      user-select: none;
    }

    :host(:hover) > .affine-drag-handle-line {
      opacity: 1;
    }

    .affine-drag-handle-line {
      opacity: 0;
      width: 1px;
      height: 100%;
      position: absolute;
      left: ${11.5}px;
      background-color: var(--affine-icon-color);
      transition: opacity ease-in-out 300ms;
      pointer-events: none;
    }

    .affine-drag-handle {
      position: absolute;
      display: flex;
      align-items: center;
      justify-content: center;
      width: ${24}px;
      height: ${16}px;
      /* background-color: var(--affine-white-90); */
      pointer-events: auto;
      color: var(--affine-icon-color);
    }

    @media print {
      .affine-drag-handle-line {
        display: none;
      }

      .affine-drag-handle {
        display: none;
      }
    }

    .affine-drag-handle-normal {
      display: flex;
      stroke: currentcolor;
    }

    .affine-drag-handle-hover {
      fill: currentcolor;
      transition: opacity ease-in-out 300ms;
    }

    .affine-drag-handle-hover path.ok {
      stroke: var(--affine-white-90);
    }

    .affine-drag-handle-hover {
      display: none;
    }

    :host(:hover) .affine-drag-handle-normal,
    :host([data-selected]) .affine-drag-handle-normal {
      display: none !important;
    }

    :host(:hover) .affine-drag-handle-hover,
    :host([data-selected]) .affine-drag-handle-hover {
      display: flex !important;
      /* padding-top: 5px !important; FIXME */
    }
  `,h([(0,l.IO)(".affine-drag-handle")],g.prototype,"_dragHandle",void 0),g=h([(0,l.Mo)("affine-drag-handle")],g)},42047:function(e,t,i){"use strict";var n=i(15486),o=i(32916),r=i(74403),a=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let s=class extends r.h{constructor(){super(...arguments),this.width="32px",this.height="32px",this.active=!1,this._mousedown=e=>{e.stopPropagation(),e.preventDefault()}}connectedCallback(){super.connectedCallback(),this.addEventListener("mousedown",this._mousedown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mousedown",this._mousedown)}};s.styles=n.iv`
    ${r.h.styles}

    :host {
      width: var(--button-width);
      height: var(--button-height);
      fill: var(--affine-icon-color);
      white-space: nowrap;
      user-select: none;
      gap: 8px;
    }
  `,a([(0,o.Cb)()],s.prototype,"width",void 0),a([(0,o.Cb)()],s.prototype,"height",void 0),a([(0,o.Cb)()],s.prototype,"active",void 0),a([(0,o.Mo)("format-bar-button")],s)},71281:function(e,t,i){"use strict";i.d(t,{K:function(){return w}}),i(42047);var n,o=i(69692),r=i(92758),a=i(50634),s=i(13246),l=i(15486),d=i(32916),c=i(91827),h=i(903),u=i(65024),f=i(91636),p=i(17164),g=i(54131),m=i(67929),v=i(76709),b=i(29691);let C=l.iv`
  .paragraph-button > svg:nth-child(2) {
    transition-duration: 0.3s;
  }
  .paragraph-button:is(:hover, :focus-visible, :active) > svg:nth-child(2) {
    transform: rotate(180deg);
  }

  .paragraph-panel {
    font-size: var(--affine-font-sm);
    box-sizing: border-box;
    position: absolute;
    min-width: 173px;
    padding: 8px 4px;
    overflow-y: auto;

    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-shadow-2);
    border-radius: 8px;
    z-index: var(--affine-z-index-popover);
  }
`,y=l.iv`
  .format-quick-bar {
    box-sizing: border-box;
    position: fixed;
    display: flex;
    align-items: center;
    padding: 4px 8px;
    gap: 4px;
    height: 40px;

    border-radius: 8px;
    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-shadow-2);
    z-index: var(--affine-z-index-popover);
    user-select: none;
  }

  .divider {
    width: 1px;
    height: 24px;
    background-color: var(--affine-border-color);
  }

  format-bar-button svg {
    width: 20px;
    height: 20px;
  }

  ${C}
  ${b.a}
`;var x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=n=class extends(0,a.$T)(l.oi){constructor(){super(...arguments),this.left=null,this.top=null,this.abortController=new AbortController,this.positionUpdated=new s.g7,this.models=[],this._paragraphType=`${o.I_[0].flavour}/${o.I_[0].type}`,this._paragraphPanelHoverDelay=150,this._paragraphPanelTimer=0,this._showParagraphPanel="hidden",this.paragraphPanelMaxHeight=null,this._format={},this._customElements=[],this._selectionChangeHandler=()=>{let e=(0,h.zE)(this.page);if(!e||"Native"===e.type&&1===e.models.length&&e.startOffset===e.endOffset){this.abortController.abort();return}this._format=(0,m.vC)(this.page),this.positionUpdated.emit()}}update(e){super.update(e),0===this._customElements.length&&0!==n.customElements.length&&(this._customElements=n.customElements.map(e=>e(this.page,()=>(0,h.zE)(this.page))),this.customItemsElement.append(...this._customElements),this._disposables.add(()=>{this._customElements.forEach(e=>{e.remove()}),this._customElements=[],this.customItemsElement.innerHTML=""}))}connectedCallback(){super.connectedCallback();let e=this.models[0];this._paragraphType=`${e.flavour}/${e.type}`,this._format=(0,m.vC)(this.page),this.addEventListener("pointerdown",e=>{e.preventDefault(),e.stopPropagation()}),this.abortController.signal.addEventListener("abort",()=>{this.remove()}),document.addEventListener("selectionchange",this._selectionChangeHandler);let t=new MutationObserver(()=>{this.page&&(this._format=(0,m.vC)(this.page))});this.models.forEach(e=>{let i=(0,u.Et)(e);if(!i){console.warn("Format quick bar may not work properly! Cannot find rich text node by model. model:",e);return}t.observe(i,{childList:!0,subtree:!0})}),this._disposables.add(()=>t.disconnect()),this._disposables.add(()=>document.removeEventListener("selectionchange",this._selectionChangeHandler))}_onHover(){if("hidden"!==this._showParagraphPanel){clearTimeout(this._paragraphPanelTimer);return}this._paragraphPanelTimer=window.setTimeout(async()=>{let{placement:e,height:t}=(0,v.Xz)(this.formatQuickBarElement,document.body,10);this._showParagraphPanel=e,this.paragraphPanelMaxHeight=t+"px"},this._paragraphPanelHoverDelay)}_onHoverEnd(){if("hidden"!==this._showParagraphPanel){this._paragraphPanelTimer=window.setTimeout(async()=>{this._showParagraphPanel="hidden"},2*this._paragraphPanelHoverDelay);return}clearTimeout(this._paragraphPanelTimer)}render(){let e=this.page;if(!this.models.length||!e)return console.error("Failed to render format-quick-bar! no model or page not found!",this.models,e),l.dy``;let t=(0,c.V)({left:this.left,top:this.top}),i=p.D.filter(({showWhen:t=()=>!0})=>t(e,this.models)).map(({id:t,name:i,icon:n,action:o,enabledWhen:r,disabledToolTip:a})=>{let s=r(e),d=s?l.dy`<tool-tip inert role="tooltip">${i}</tool-tip>`:l.dy`<tool-tip tip-position="top" inert role="tooltip"
              >${a}</tool-tip
            >`;return l.dy`<format-bar-button
          class="has-tool-tip"
          data-testid=${t}
          ?disabled=${!s}
          @click=${()=>s&&o({page:e})}
        >
          ${n}${d}
        </format-bar-button>`});if(1===this.models.length&&(0,s.h$)(this.models[0],["affine:database"]))return l.dy`<div
        class="format-quick-bar"
        style="${t}"
        @pointerdown=${f.UW}
      >
        ${i}
      </div>`;let n=o.I_.find(({flavour:e,type:t})=>`${e}/${t}`===this._paragraphType)?.icon??o.I_[0].icon,a=l.dy` <format-bar-button
      class="paragraph-button"
      width="52px"
      @mouseover="${this._onHover}"
      @mouseout="${this._onHoverEnd}"
    >
      ${n} ${r.ve}
    </format-bar-button>`,d=function(e,t,i,n,r,a,d,u,f){if("hidden"===e)return l.dy``;let p=n[0].page;(0,s.kP)(p);let g=(0,c.V)({left:"0",top:"bottom"===e?"calc(100% + 4px)":null,bottom:"top"===e?"calc(100% + 4px)":null,maxHeight:t}),v=(e,t)=>{let a=i===`${e}/${t}`,{flavour:s,type:l}=o.I_[0],d=a?s:e,c=a?l:t,p=(0,m.WV)(n,d,c);if("affine:code"===d){if(1!==p.length)throw Error("Failed to reset selection! New model length isn't 1");let e=p[0];(0,m.FA)(e,()=>{(0,h.vq)({type:"Block",startOffset:0,endOffset:e.text?.length??0,models:[e]})})}u(p),f(`${d}/${c}`),r.emit()};return l.dy` <div
    class="paragraph-panel"
    style="${g}"
    @mouseover="${a}"
    @mouseout="${d}"
  >
    ${o.I_.filter(({flavour:e})=>"affine:divider"!==e).filter(({flavour:e})=>p.schema.flavourSchemaMap.has(e)).map(({flavour:e,type:t,name:i,icon:n})=>l.dy`<format-bar-button
          width="100%"
          style="padding-left: 12px; justify-content: flex-start;"
          text="${i}"
          data-testid="${e}/${t}"
          @click="${()=>v(e,t)}"
        >
          ${n}
        </format-bar-button>`)}
  </div>`}(this._showParagraphPanel,this.paragraphPanelMaxHeight,this._paragraphType,this.models,this.positionUpdated,this._onHover,this._onHoverEnd,e=>this.models=e,e=>this._paragraphType=e),u=g.W.filter(({showWhen:e=()=>!0})=>e(this.models)).map(({id:t,name:i,icon:n,action:o,activeWhen:r})=>l.dy` <format-bar-button
          class="has-tool-tip"
          data-testid=${t}
          ?active=${r(this._format)}
          @click=${()=>{o({page:e,abortController:this.abortController,format:this._format}),this._format=(0,m.vC)(e),this.positionUpdated.emit()}}
        >
          ${n}
          <tool-tip inert role="tooltip">${i}</tool-tip>
        </format-bar-button>`);return l.dy` <div
      class="format-quick-bar"
      style="${t}"
      @pointerdown=${f.UW}
    >
      <div class="custom-items"></div>
      ${this._customElements.length>0?l.dy`<div class="divider"></div>`:null}
      ${a}
      <div class="divider"></div>
      ${u}
      ${u.length?l.dy` <div class="divider"></div>`:""}
      ${i} ${d}
    </div>`}};w.styles=y,w.customElements=[],x([(0,d.Cb)()],w.prototype,"page",void 0),x([(0,d.Cb)()],w.prototype,"left",void 0),x([(0,d.Cb)()],w.prototype,"top",void 0),x([(0,d.Cb)()],w.prototype,"abortController",void 0),x([(0,d.Cb)()],w.prototype,"positionUpdated",void 0),x([(0,d.Cb)()],w.prototype,"models",void 0),x([(0,d.SB)()],w.prototype,"_paragraphType",void 0),x([(0,d.SB)()],w.prototype,"_paragraphPanelHoverDelay",void 0),x([(0,d.SB)()],w.prototype,"_paragraphPanelTimer",void 0),x([(0,d.SB)()],w.prototype,"_showParagraphPanel",void 0),x([(0,d.SB)()],w.prototype,"_format",void 0),x([(0,d.IO)(".format-quick-bar")],w.prototype,"formatQuickBarElement",void 0),x([(0,d.IO)(".custom-items")],w.prototype,"customItemsElement",void 0),w=n=x([(0,d.Mo)("format-quick-bar")],w)},13371:function(e,t,i){"use strict";i.d(t,{T:function(){return h}}),i(42047);var n=i(13246),o=i(903),r=i(48616),a=i(70263),s=i(52933),l=i(76709),d=i(71281);let c=null,h=async({page:e,anchorEl:t,direction:i="right-bottom",container:h=document.body,abortController:u=new AbortController})=>{if(c)return;let f=(0,o.zE)(e);if(!f)return;f.models=f.models.filter(e=>(0,n.h$)(e,["affine:paragraph","affine:list","affine:code","affine:database"]));let p=f.models;if(0===p.length||(0,n.h$)(p[0],["affine:database"])&&"Native"===f.type)return;let g=new d.K;g.page=e,g.models=p,g.abortController=u;let m=new n.g7;g.positionUpdated=m,c=g,u.signal.addEventListener("abort",()=>{c=null});let v=(0,a.P2)(()=>{if(u.signal.aborted)return;let e=t instanceof Range?(0,l.Ak)(t,i):t.getBoundingClientRect(),n=document.body.getBoundingClientRect(),o=g.formatQuickBarElement.getBoundingClientRect(),r=i.includes("bottom"),a=(0,l.Ne)({positioningPoint:e,objRect:o,boundaryRect:n,offsetX:-o.width/2,offsetY:r?5:-o.height-5});g.left=`${a.x}px`,g.top=`${a.y}px`},10);if(!e.root)throw Error("Failed to get page's root element");let b=(0,r.dK)(e);b&&b.addEventListener("scroll",v,{passive:!0}),m.on(v),window.addEventListener("resize",v,{passive:!0}),h.appendChild(g);let C=e=>{e.target!==g&&u.abort()},y=()=>{u.abort()};return document.addEventListener("pointerdown",C),window.addEventListener("popstate",y),(0,s.FA)(f.models[0],v),u.signal.addEventListener("abort",()=>{b?.removeEventListener("scroll",v),window.removeEventListener("resize",v),document.removeEventListener("pointerdown",C),window.removeEventListener("popstate",y),m.dispose()}),g}},61005:function(e,t,i){"use strict";i.d(t,{j:function(){return _}});var n=i(13246),o=i(67072),r=i(15486),a=i(32916),s=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let l=class extends r.oi{constructor(){super(),this.hostModel=null,this.radius="8px",this.width="150px"}connectedCallback(){super.connectedCallback(),this.hostModel&&(this.setAttribute(o.SF,this.hostModel.id),this.setAttribute(o.uv,"true"));let e=this.width;this.style.setProperty("--loader-width","string"==typeof e?e:`${e}px`)}render(){return r.dy`
      <div class="load-container">
        <div class="load load1"></div>
        <div class="load load2"></div>
        <div class="load"></div>
      </div>
    `}};l.styles=r.iv`
    .load-container {
      margin: 10px auto;
      width: var(--loader-width);
      text-align: center;
    }

    .load-container .load {
      width: 8px;
      height: 8px;
      background-color: var(--affine-text-primary-color);

      border-radius: 100%;
      display: inline-block;
      -webkit-animation: bouncedelay 1.4s infinite ease-in-out;
      animation: bouncedelay 1.4s infinite ease-in-out;
      /* Prevent first frame from flickering when animation starts */
      -webkit-animation-fill-mode: both;
      animation-fill-mode: both;
    }
    .load-container .load1 {
      -webkit-animation-delay: -0.32s;
      animation-delay: -0.32s;
    }
    .load-container .load2 {
      -webkit-animation-delay: -0.16s;
      animation-delay: -0.16s;
    }

    @-webkit-keyframes bouncedelay {
      0%,
      80%,
      100% {
        -webkit-transform: scale(0.625);
      }
      40% {
        -webkit-transform: scale(1);
      }
    }

    @keyframes bouncedelay {
      0%,
      80%,
      100% {
        transform: scale(0);
        -webkit-transform: scale(0.625);
      }
      40% {
        transform: scale(1);
        -webkit-transform: scale(1);
      }
    }
  `,s([(0,a.Cb)()],l.prototype,"hostModel",void 0),s([(0,a.Cb)()],l.prototype,"radius",void 0),s([(0,a.Cb)()],l.prototype,"width",void 0),l=s([(0,a.Mo)("loader-element")],l);let d=r.dy`<svg
  width="12"
  height="12"
  viewBox="0 0 12 12"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M0.343205 0.343144C0.636098 0.0502508 1.11097 0.0502508 1.40387 0.343144L6.00006 4.93934L10.5963 0.343144C10.8891 0.0502508 11.364 0.0502508 11.6569 0.343144C11.9498 0.636037 11.9498 1.11091 11.6569 1.4038L7.06072 6L11.6569 10.5962C11.9498 10.8891 11.9498 11.364 11.6569 11.6569C11.364 11.9497 10.8891 11.9497 10.5963 11.6569L6.00006 7.06066L1.40387 11.6569C1.11097 11.9497 0.636098 11.9497 0.343205 11.6569C0.0503118 11.364 0.0503118 10.8891 0.343205 10.5962L4.9394 6L0.343205 1.4038C0.0503118 1.11091 0.0503118 0.636037 0.343205 0.343144Z"
    fill="#77757D"
  />
</svg>`,c=r.dy`<svg
  width="14"
  height="18"
  viewBox="0 0 14 18"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.80805 0.875L7.83342 0.875001C7.99918 0.875001 8.15815 0.940849 8.27536 1.05806L13.2754 6.05806C13.3926 6.17527 13.4584 6.33424 13.4584 6.5V13.8587C13.4584 14.3038 13.4584 14.6754 13.4336 14.9789C13.4078 15.2955 13.3518 15.5927 13.2086 15.8737C12.9889 16.3049 12.6383 16.6555 12.2071 16.8752C11.9261 17.0184 11.6289 17.0744 11.3123 17.1002C11.0088 17.125 10.6372 17.125 10.1921 17.125H3.80804C3.36292 17.125 2.99138 17.125 2.68786 17.1002C2.37129 17.0744 2.07407 17.0184 1.79302 16.8752C1.36182 16.6555 1.01124 16.3049 0.791525 15.8737C0.648322 15.5927 0.592396 15.2955 0.566531 14.9789C0.541732 14.6754 0.541739 14.3038 0.541748 13.8587V4.1413C0.541739 3.69618 0.541732 3.32464 0.566531 3.02111C0.592396 2.70454 0.648322 2.40732 0.791525 2.12627C1.01124 1.69507 1.36182 1.34449 1.79302 1.12478C2.07407 0.981574 2.37129 0.925648 2.68786 0.899783C2.99138 0.874984 3.36292 0.874991 3.80805 0.875ZM2.78965 2.14563C2.55038 2.16518 2.43598 2.20008 2.36051 2.23854C2.16451 2.3384 2.00515 2.49776 1.90528 2.69376C1.86683 2.76923 1.83193 2.88363 1.81238 3.1229C1.79223 3.36946 1.79175 3.68964 1.79175 4.16667V13.8333C1.79175 14.3104 1.79223 14.6305 1.81238 14.8771C1.83193 15.1164 1.86683 15.2308 1.90528 15.3062C2.00515 15.5022 2.16451 15.6616 2.36051 15.7615C2.43598 15.7999 2.55038 15.8348 2.78965 15.8544C3.03621 15.8745 3.35639 15.875 3.83342 15.875H10.1667C10.6438 15.875 10.964 15.8745 11.2105 15.8544C11.4498 15.8348 11.5642 15.7999 11.6397 15.7615C11.8357 15.6616 11.995 15.5022 12.0949 15.3062C12.1333 15.2308 12.1682 15.1164 12.1878 14.8771C12.2079 14.6305 12.2084 14.3104 12.2084 13.8333V7.125H8.66675C7.86133 7.125 7.20842 6.47208 7.20842 5.66667V2.125H3.83342C3.35639 2.125 3.03621 2.12549 2.78965 2.14563ZM8.45842 3.00888L11.3245 5.875H8.66675C8.55169 5.875 8.45842 5.78173 8.45842 5.66667V3.00888Z"
    fill="#77757D"
  />
  <path
    d="M8.37009 13.1207L8.39316 10.2307H8.37585L7.31446 13.1207H6.62225L5.5897 10.2307H5.57239L5.59547 13.1207H4.66675V9.03662H6.06848L6.9972 11.6555H7.02027L7.90861 9.03662H9.33342V13.1207H8.37009Z"
    fill="#77757D"
  />
</svg>`,h=r.dy`<svg
  width="16"
  height="18"
  viewBox="0 0 16 18"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4.80797 0.875L8.83333 0.875001C8.99909 0.875001 9.15806 0.940849 9.27527 1.05806L14.2753 6.05806C14.3925 6.17527 14.4583 6.33424 14.4583 6.5V11.5C14.4583 11.8452 14.1785 12.125 13.8333 12.125C13.4882 12.125 13.2083 11.8452 13.2083 11.5V7.125H9.66667C8.86125 7.125 8.20833 6.47208 8.20833 5.66667V2.125H4.83333C4.35631 2.125 4.03613 2.12549 3.78956 2.14563C3.5503 2.16518 3.43589 2.20008 3.36043 2.23854C3.16442 2.3384 3.00507 2.49776 2.9052 2.69376C2.86675 2.76923 2.83185 2.88363 2.8123 3.1229C2.79215 3.36946 2.79167 3.68964 2.79167 4.16667V11.5C2.79167 11.8452 2.51184 12.125 2.16667 12.125C1.82149 12.125 1.54167 11.8452 1.54167 11.5L1.54167 4.1413C1.54166 3.69618 1.54165 3.32464 1.56645 3.02111C1.59231 2.70454 1.64824 2.40732 1.79144 2.12627C2.01115 1.69507 2.36173 1.34449 2.79294 1.12478C3.07399 0.981574 3.3712 0.925648 3.68777 0.899783C3.9913 0.874984 4.36284 0.874991 4.80797 0.875ZM9.45833 3.00888L12.3244 5.875H9.66667C9.55161 5.875 9.45833 5.78173 9.45833 5.66667V3.00888Z"
    fill="#77757D"
  />
  <path
    d="M3.2085 17.0607V15.4327H1.6905V17.0607H0.75V13.1667H1.6905V14.6407H3.2085V13.1667H4.149V17.0607H3.2085Z"
    fill="#77757D"
  />
  <path
    d="M6.6167 13.9697V17.0607H5.6762V13.9697H4.5762V13.1667H7.7167V13.9697H6.6167Z"
    fill="#77757D"
  />
  <path
    d="M11.677 17.0607L11.699 14.3052H11.6825L10.6705 17.0607H10.0105L9.026 14.3052H9.0095L9.0315 17.0607H8.146V13.1667H9.4825L10.368 15.6637H10.39L11.237 13.1667H12.5955V17.0607H11.677Z"
    fill="#77757D"
  />
  <path
    d="M13.3989 17.0607V13.1667H14.3449V16.2412H15.8519V17.0607H13.3989Z"
    fill="#77757D"
  />
</svg>`,u=r.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M3.22321 3.16561C3.69638 3.54965 3.87301 3.52049 4.76102 3.46134L13.1323 2.959C13.3106 2.959 13.1623 2.78075 13.1032 2.75158L11.7128 1.74689C11.4462 1.54028 11.0914 1.30289 10.4116 1.36203L2.30522 1.9535C2.01029 1.98267 1.95114 2.13094 2.06863 2.24924L3.22321 3.16561ZM3.72555 5.11664V13.9238C3.72555 14.3978 3.96214 14.5745 4.49527 14.5453L13.6946 14.013C14.2269 13.9838 14.2861 13.6581 14.2861 13.274V4.52517C14.2861 4.14112 14.1386 3.9337 13.8129 3.96368L4.19872 4.52517C3.84384 4.55434 3.72555 4.73178 3.72555 5.11664ZM12.8082 5.589C12.8666 5.85476 12.8082 6.12133 12.5409 6.1513L12.0977 6.23962V12.7417C11.7128 12.9491 11.3579 13.0674 11.0622 13.0674C10.589 13.0674 10.4707 12.9192 10.1158 12.476L7.21602 7.92409V12.3285L8.13401 12.5351C8.13401 12.5351 8.13401 13.0674 7.39346 13.0674L5.35249 13.1857C5.29334 13.0674 5.35249 12.7725 5.55991 12.7125L6.09223 12.5651V6.74196L5.35249 6.68282C5.29334 6.41625 5.44162 6.0322 5.85564 6.00222L8.04489 5.85557L11.0622 10.4658V6.38789L10.2925 6.29958C10.2341 5.97386 10.4707 5.73809 10.7664 5.70811L12.8082 5.58981V5.589ZM1.62462 1.15542L10.0559 0.534789C11.0905 0.445664 11.3571 0.505621 12.0085 0.977985L14.6993 2.86987C15.1433 3.19477 15.2916 3.28309 15.2916 3.63797V14.013C15.2916 14.6636 15.055 15.0476 14.2269 15.1068L4.43531 15.6982C3.81386 15.7274 3.51813 15.6391 3.19242 15.2251L1.21059 12.6534C0.855714 12.1802 0.708252 11.8262 0.708252 11.4113V2.19009C0.708252 1.65777 0.944029 1.21457 1.62462 1.15542Z"
    fill="black"
  />
</svg>`,f=r.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.1851 0.708313C13.5303 0.708313 13.8101 0.988135 13.8101 1.33331V2.18979H14.6666C15.0118 2.18979 15.2916 2.46962 15.2916 2.81479C15.2916 3.15997 15.0118 3.43979 14.6666 3.43979H13.8101V4.29628C13.8101 4.64145 13.5303 4.92128 13.1851 4.92128C12.8399 4.92128 12.5601 4.64145 12.5601 4.29628V3.43979H11.7036C11.3584 3.43979 11.0786 3.15997 11.0786 2.81479C11.0786 2.46962 11.3584 2.18979 11.7036 2.18979H12.5601V1.33331C12.5601 0.988135 12.8399 0.708313 13.1851 0.708313ZM6.51844 2.18979C6.77511 2.18979 7.00568 2.34672 7.09985 2.58549L8.18874 5.34639C8.3394 5.7284 8.37968 5.81859 8.43081 5.88998C8.48542 5.96623 8.55218 6.033 8.62844 6.08761C8.69983 6.13874 8.79002 6.17902 9.17203 6.32968L11.9329 7.41856C12.1717 7.51273 12.3286 7.74331 12.3286 7.99998C12.3286 8.25665 12.1717 8.48723 11.9329 8.58139L9.17203 9.67028C8.79002 9.82094 8.69983 9.86122 8.62844 9.91235C8.55218 9.96696 8.48542 10.0337 8.43081 10.11C8.37968 10.1814 8.3394 10.2716 8.18874 10.6536L7.09985 13.4145C7.00568 13.6532 6.77511 13.8102 6.51844 13.8102C6.26177 13.8102 6.03119 13.6532 5.93702 13.4145L4.84814 10.6536C4.69748 10.2716 4.6572 10.1814 4.60607 10.11C4.55146 10.0337 4.48469 9.96696 4.40844 9.91235C4.33705 9.86122 4.24685 9.82094 3.86484 9.67028L1.10395 8.58139C0.865175 8.48723 0.708252 8.25665 0.708252 7.99998C0.708252 7.74331 0.865175 7.51273 1.10395 7.41856L3.86484 6.32968C4.24685 6.17902 4.33705 6.13874 4.40844 6.08761C4.48469 6.033 4.55146 5.96623 4.60607 5.88998C4.6572 5.81859 4.69748 5.7284 4.84814 5.34639L5.93702 2.58549C6.03119 2.34672 6.26177 2.18979 6.51844 2.18979ZM6.51844 4.5183L6.01097 5.805C6.00357 5.82375 5.99627 5.8423 5.98905 5.86065C5.87158 6.15916 5.77495 6.40469 5.62232 6.61781C5.48801 6.80535 5.3238 6.96955 5.13626 7.10386C4.92315 7.25649 4.67762 7.35312 4.3791 7.4706C4.36076 7.47782 4.34221 7.48512 4.32346 7.49251L3.03676 7.99998L4.32346 8.50745C4.34221 8.51484 4.36075 8.52214 4.3791 8.52936C4.67762 8.64684 4.92315 8.74347 5.13626 8.8961C5.3238 9.03041 5.48801 9.19461 5.62232 9.38215C5.77495 9.59527 5.87157 9.84079 5.98905 10.1393C5.99627 10.1577 6.00357 10.1762 6.01097 10.195L6.51844 11.4817L7.0259 10.195C7.0333 10.1762 7.0406 10.1577 7.04782 10.1393C7.1653 9.8408 7.26193 9.59527 7.41455 9.38215C7.54887 9.19461 7.71307 9.03041 7.90061 8.8961C8.11373 8.74347 8.35926 8.64684 8.65777 8.52936C8.67612 8.52214 8.69467 8.51484 8.71342 8.50745L10.0001 7.99998L8.71342 7.49251C8.69467 7.48512 8.67612 7.47782 8.65777 7.4706C8.35926 7.35312 8.11373 7.25649 7.90061 7.10386C7.71307 6.96955 7.54887 6.80535 7.41455 6.61781C7.26193 6.40469 7.1653 6.15916 7.04782 5.86065C7.0406 5.8423 7.0333 5.82375 7.0259 5.805L6.51844 4.5183ZM13.1851 11.0787C13.5303 11.0787 13.8101 11.3585 13.8101 11.7037V12.5602H14.6666C15.0118 12.5602 15.2916 12.84 15.2916 13.1852C15.2916 13.5303 15.0118 13.8102 14.6666 13.8102H13.8101V14.6666C13.8101 15.0118 13.5303 15.2916 13.1851 15.2916C12.8399 15.2916 12.5601 15.0118 12.5601 14.6666V13.8102H11.7036C11.3584 13.8102 11.0786 13.5303 11.0786 13.1852C11.0786 12.84 11.3584 12.5602 11.7036 12.5602H12.5601V11.7037C12.5601 11.3585 12.8399 11.0787 13.1851 11.0787Z"
    fill="#A9A9AD"
  />
</svg>`;r.dy`<svg
  width="12"
  height="12"
  viewBox="0 0 12 12"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.83342 0.666687C7.83342 0.390545 8.05727 0.166687 8.33342 0.166687H11.3334C11.6096 0.166687 11.8334 0.390545 11.8334 0.666687V3.66669C11.8334 3.94283 11.6096 4.16669 11.3334 4.16669C11.0573 4.16669 10.8334 3.94283 10.8334 3.66669V1.87379L6.35364 6.35357C6.15837 6.54884 5.84179 6.54884 5.64653 6.35357C5.45127 6.15831 5.45127 5.84173 5.64653 5.64647L10.1263 1.16669H8.33342C8.05727 1.16669 7.83342 0.942829 7.83342 0.666687ZM2.77979 0.833353L5.66675 0.833354C5.94289 0.833354 6.16675 1.05721 6.16675 1.33335C6.16675 1.6095 5.94289 1.83335 5.66675 1.83335H2.80008C2.41846 1.83335 2.16232 1.83374 1.96507 1.84986C1.77365 1.8655 1.68213 1.89342 1.62176 1.92418C1.46495 2.00408 1.33747 2.13156 1.25758 2.28836C1.22681 2.34874 1.19889 2.44026 1.18325 2.63167C1.16714 2.82892 1.16675 3.08507 1.16675 3.46669V9.20002C1.16675 9.58164 1.16714 9.83778 1.18325 10.035C1.19889 10.2264 1.22681 10.318 1.25758 10.3783C1.33747 10.5351 1.46496 10.6626 1.62176 10.7425C1.68213 10.7733 1.77365 10.8012 1.96507 10.8168C2.16232 10.833 2.41846 10.8334 2.80008 10.8334H8.53342C8.91503 10.8334 9.17118 10.833 9.36843 10.8168C9.55985 10.8012 9.65137 10.7733 9.71174 10.7425C9.86854 10.6626 9.99603 10.5351 10.0759 10.3783C10.1067 10.318 10.1346 10.2264 10.1502 10.035C10.1664 9.83778 10.1667 9.58164 10.1667 9.20002V6.33335C10.1667 6.05721 10.3906 5.83335 10.6667 5.83335C10.9429 5.83335 11.1667 6.05721 11.1667 6.33335V9.22032C11.1668 9.57642 11.1668 9.87365 11.1469 10.1165C11.1262 10.3697 11.0815 10.6075 10.9669 10.8323C10.7912 11.1773 10.5107 11.4578 10.1657 11.6335C9.94089 11.7481 9.70312 11.7928 9.44986 11.8135C9.20704 11.8334 8.90981 11.8334 8.55372 11.8334H2.77978C2.42368 11.8334 2.12645 11.8334 1.88364 11.8135C1.63038 11.7928 1.39261 11.7481 1.16777 11.6335C0.822802 11.4578 0.542338 11.1773 0.36657 10.8323C0.252007 10.6075 0.207267 10.3697 0.186575 10.1165C0.166735 9.87364 0.166741 9.57641 0.166748 9.22031V3.4464C0.166741 3.0903 0.166735 2.79306 0.186575 2.55024C0.207267 2.29698 0.252007 2.05921 0.36657 1.83437C0.542338 1.48941 0.822802 1.20894 1.16777 1.03317C1.39261 0.918612 1.63038 0.873872 1.88364 0.85318C2.12646 0.83334 2.42369 0.833346 2.77979 0.833353Z"
    fill="#5872FB"
  />
</svg>`;let p=r.dy`<svg
  width="18"
  height="18"
  viewBox="0 0 18 18"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M9 2.125C5.20304 2.125 2.125 5.20304 2.125 9C2.125 12.797 5.20304 15.875 9 15.875C12.797 15.875 15.875 12.797 15.875 9C15.875 5.20304 12.797 2.125 9 2.125ZM0.875 9C0.875 4.51269 4.51269 0.875 9 0.875C13.4873 0.875 17.125 4.51269 17.125 9C17.125 13.4873 13.4873 17.125 9 17.125C4.51269 17.125 0.875 13.4873 0.875 9ZM8.97249 6.5C8.48797 6.5 8.07928 6.83137 7.96361 7.28079C7.87757 7.61507 7.53683 7.81631 7.20255 7.73027C6.86826 7.64423 6.66702 7.3035 6.75306 6.96921C7.00742 5.98094 7.90381 5.25 8.97249 5.25C10.2381 5.25 11.2642 6.27601 11.2642 7.54167C11.2642 8.23885 10.928 8.70316 10.5524 9.06572C10.3978 9.21488 10.2216 9.36095 10.0565 9.49784C10.0321 9.51805 10.008 9.53806 9.98417 9.55785C9.79133 9.71827 9.60144 9.87995 9.41445 10.0669C9.17037 10.311 8.77464 10.311 8.53057 10.0669C8.28649 9.82286 8.28649 9.42714 8.53057 9.18306C8.76025 8.95338 8.98703 8.76138 9.1848 8.59686C9.21087 8.57517 9.23619 8.55416 9.26081 8.53373C9.43034 8.39303 9.5663 8.28019 9.6843 8.1663C9.93364 7.92565 10.0142 7.76496 10.0142 7.54167C10.0142 6.96637 9.54779 6.5 8.97249 6.5ZM8.98084 12.75H8.97251C8.62733 12.75 8.34751 12.4702 8.34751 12.125C8.34751 11.7798 8.62733 11.5 8.97251 11.5H8.98084C9.32602 11.5 9.60584 11.7798 9.60584 12.125C9.60584 12.4702 9.32602 12.75 8.98084 12.75Z"
    fill="#77757D"
  />
</svg>`;var g=i(50634),m=i(1297),v=i(34057),b=i(37666),C=i(29691);let y=r.iv`
  :host {
    position: absolute;
    width: 480px;
    left: calc(50% - 480px / 2);
    top: calc(50% - 270px / 2);
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-base);
    line-height: var(--affine-line-height);
    padding: 20px 40px 24px 40px;
    gap: 19px;
    display: flex;
    flex-direction: column;
    background: var(--affine-background-primary-color);
    box-shadow: var(--affine-shadow-2);
    border-radius: 16px;
    z-index: var(--affine-z-index-popover);
  }

  :host([hidden]) {
    display: none;
  }

  header {
    cursor: move;
    user-select: none;
    font-size: var(--affine-font-h-6);
    font-weight: 600;
  }

  a {
    white-space: nowrap;
    word-break: break-word;
    color: var(--affine-link-color);
    fill: var(--affine-link-color);
    text-decoration: none;
    cursor: pointer;
  }

  header icon-button {
    margin-left: auto;
  }

  .button-container {
    display: flex;
    justify-content: space-between;
  }

  .button-container icon-button {
    padding: 8px;
    justify-content: flex-start;
    gap: 8px;
    width: 190px;
    height: 40px;
    box-shadow: var(--affine-shadow-1);
  }

  .footer {
    display: flex;
    align-items: center;
    color: var(--affine-text-secondary-color);
  }

  .loading-header {
    display: flex;
    align-items: center;
  }

  .has-tool-tip {
    display: flex;
    margin-left: auto;
  }

  ${C.a}
`;var x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=class extends(0,g.$T)(r.oi){constructor(e,t,i,n=new AbortController){super(),this.workspace=e,this.multiple=t,this.onSuccess=i,this.abortController=n,this._loading=!1,this.x=0,this.y=0,this._startX=0,this._startY=0,this._loading=!1,this.x=0,this.y=0,this._startX=0,this._startY=0,this._onMouseMove=this._onMouseMove.bind(this)}loading(){return this._loading}updated(e){(e.has("x")||e.has("y"))&&(this.style.transform=`translate(${this.x}px, ${this.y}px)`)}_onMouseDown(e){this._startX=e.clientX-this.x,this._startY=e.clientY-this.y,window.addEventListener("mousemove",this._onMouseMove)}_onMouseUp(){window.removeEventListener("mousemove",this._onMouseMove)}_onMouseMove(e){this.x=e.clientX-this._startX,this.y=e.clientY-this._startY}_onCloseClick(e){e.stopPropagation(),this.abortController.abort()}async _selectFile(e){let t=document.createElement("input");return t.type="file",t.accept=e,t.multiple=this.multiple,t.click(),new Promise((e,i)=>{t.onchange=()=>{let n=t.files;if(!n){i();return}e(Array.from(n))},t.onerror=()=>{i()}})}_onImportSuccess(e){(0,b.A)(`Successfully imported ${e.length} Page${e.length>1?"s":""}.`),this.onSuccess?.(e)}async _importFile(e,t,i){this.hidden=!0;let n=await this._selectFile(e),o=await t(n);o?(this.hidden=!1,this._loading=!0):this.abortController.abort();let r=[];for(let e of n){let t=await i(e);r.push(...t)}this._onImportSuccess(r),o&&this.abortController.abort()}async _importMarkDown(){await this._importFile(".md",async e=>{let t=0;for(let i of e)if((t+=i.size)>204800)return!0;return!1},async e=>{let t=await e.text(),i=this.workspace.createPage({init:{title:""}}),n=i.root?.id,o=new v.F(i);return n?(await o.importMarkdown(t,n),[i.id]):[]})}async _importHtml(){await this._importFile(".html",async e=>{let t=0;for(let i of e)if((t+=i.size)>204800)return!0;return!1},async e=>{let t=await e.text(),i=this.workspace.createPage({init:{title:""}}),n=i.root?.id,o=new v.F(i);return n?(await o.importHtml(t,n),[i.id]):[]})}async _importNotion(){await this._importFile(".zip",async e=>{let t=0;for(let i of e){let e=new m,n=await e.loadAsync(i),o=Object.values(n.files);for(let e of o){if(e.dir)continue;let i=await e.async("uint8array");if((t+=i.length)>204800)return!0}}return!1},async e=>{let t=[],i=[],n=async e=>{let o=new m,r=await o.loadAsync(e),a=new Map;i.push(a);let s=Object.keys(r.files),l=[],d=s.filter(e=>e.endsWith(".csv")).map(e=>e.substring(0,e.length-4));for(let e=0;e<s.length;e++){let t=s[e];if(t.startsWith("__MACOSX/"))continue;let i=t.lastIndexOf("/");if(d.includes(t.substring(0,i)))continue;let o=t.substring(i+1);if(o.endsWith(".html")||o.endsWith(".md")){let e=this.workspace.createPage({init:{title:""}});a.set(t,e)}if(o.endsWith(".zip")){let e=await r.file(o)?.async("blob");e&&l.push(...await n(e))}}let c=Array.from(a.keys()).map(async e=>{let i=a.get(e);if(!i)return;let n=e.lastIndexOf("/"),o=e.substring(0,n)||"",s=e.substring(n+1);if(s.endsWith(".html")||s.endsWith(".md")){let n=s.endsWith(".html"),l=i.root?.id,d=async e=>{let t=this.joinWebPaths(o,decodeURI(e));return await r.file(t)?.async("blob")||new Blob},c=(e,t)=>{if(t.link){let e=t.link,i=this.joinWebPaths(o,decodeURI(e)),n=a.get(i);n&&(t.reference={pageId:n.id,type:"LinkedPage"},delete t.link)}},h=async e=>{if("A"===e.tagName&&e.getAttribute("href")?.endsWith(".csv")){let t=e.getAttribute("href")||"",i=this.joinWebPaths(o,decodeURI(t)),n=await r.file(i)?.async("string"),a=1,s=[],l=[];n?.split("\n").forEach((e,t)=>{if(0===t)s.push(...e.split(","));else{let t=e.split(",");l.push(t)}});let d=s.slice(1).map((e,t)=>({name:e,type:"rich-text",width:200,hide:!1,id:""+a++}));if(l.length>0){let e=l[0].length;for(let t=1;t<l.length;t++)e=Math.max(e,l[t].length);let t=e-d.length;for(let e=0;e<t;e++)d.push({name:"",type:"rich-text",width:200,hide:!1,id:""+a++})}let c=a++,h={},u=[];return l.forEach(e=>{u.push({flavour:"affine:paragraph",type:"text",text:[{insert:e[0]}],children:[]});let t=""+a++;h[t]={},e.slice(1).forEach((e,i)=>{h[t][d[i].id]={columnId:d[i].id,value:e}})}),[{flavour:"affine:database",databaseProps:{id:""+c,title:e.textContent||"Database",titleColumnName:s[0],titleColumnWidth:432,rowIds:Object.keys(h),cells:h,columns:d},children:u}]}return null},u=new v.F(i,d,c,h),f=await r.file(e)?.async("string")||"";l&&(t.push(i.id),n?await u.importHtml(f,l):await u.importMarkdown(f,l))}});return l.push(...c),l},o=await n(e);return await Promise.all(o.flat()),t})}joinWebPaths(...e){let t=e.join("/").replace(/\/+/g,"/"),i=t.split("/").filter(Boolean),n=[];return i.forEach(e=>{"."!==e&&(".."===e?n.pop():n.push(e))}),n.join("/")}_openLearnImportLink(e){e.stopPropagation(),window.open("https://affine.pro/blog/import-your-data-from-notion-into-affine","_blank")}render(){return this._loading?r.dy`
        <header
          class="loading-header"
          @mousedown=${this._onMouseDown}
          @mouseup=${this._onMouseUp}
        >
          <div>Import</div>
          <loader-element width="50px"></loader-element>
        </header>
        <div>
          Importing the file may take some time. It depends on document size and
          complexity.
        </div>
      `:r.dy`
      <header @mousedown=${this._onMouseDown} @mouseup=${this._onMouseUp}>
        <icon-button height="16px" @click=${this._onCloseClick}>
          ${d}
        </icon-button>
        <div>Import</div>
      </header>
      <div>
        AFFiNE will gradually support more and more file types for import.
        <a
          href="https://community.affine.pro/c/feature-requests/import-export"
          target="_blank"
          >Provide feedback.</a
        >
      </div>
      <div class="button-container">
        <icon-button
          class="button-item"
          text="Markdown"
          @click=${this._importMarkDown}
        >
          ${c}
        </icon-button>
        <icon-button class="button-item" text="HTML" @click=${this._importHtml}>
          ${h}
        </icon-button>
      </div>
      <div class="button-container">
        <icon-button
          class="button-item"
          text="Notion"
          @click=${this._importNotion}
        >
          ${u}
          <div
            slot="optional"
            class="has-tool-tip"
            @click=${this._openLearnImportLink}
          >
            ${p}
            <tool-tip inert arrow tip-position="top" role="tooltip">
              Learn how to Import your Notion pages into AFFiNE.
            </tool-tip>
          </div>
        </icon-button>
        <icon-button class="button-item" text="Coming soon..." disabled="true">
          ${f}
        </icon-button>
      </div>
      <!-- <div class="footer">
        <div>Migrate from other versions of AFFiNE?</div>
      </div> -->
    `}};function _({workspace:e,onSuccess:t,multiple:i=!0,container:o=document.body,abortController:r=new AbortController}){let a=new w(e,i,t,r);o.appendChild(a);let s=new n.SJ;return r.signal.addEventListener("abort",()=>s.dispose()),s.add(()=>a.remove()),s.addFromEvent(window,"mousedown",e=>{e.target===a||a.loading()||r.abort()}),a}w.styles=y,x([(0,a.SB)()],w.prototype,"_loading",void 0),x([(0,a.SB)()],w.prototype,"x",void 0),x([(0,a.SB)()],w.prototype,"y",void 0),x([(0,a.SB)()],w.prototype,"_startX",void 0),x([(0,a.SB)()],w.prototype,"_startY",void 0),w=x([(0,a.Mo)("import-page")],w)},91097:function(e,t,i){"use strict";i.d(t,{Nd:function(){return P},li:function(){return C},DU:function(){return p.DU},NG:function(){return p.NG},vI:function(){return p.vI},R:function(){return w},o4:function(){return E},jM:function(){return y.j},ap:function(){return g.a}});var n=i(69692),o=i(92758),r=i(7339),a=i(31054),s=i(53905),l=i(50634),d=i(15486),c=i(32916),h=i(16025),u=i(91827),f=i(81366),p=i(62610),g=i(29691),m=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let v=d.iv`
  affine-block-hub {
    position: absolute;
    z-index: 1;
    user-select: none;
  }

  @media print {
    affine-block-hub {
      display: none;
    }
  }

  .affine-block-hub-container {
    width: 274px;
    position: absolute;
    right: calc(100% + 8px);
    overflow-y: unset;
    display: none;
    justify-content: center;
    fill: var(--affine-icon-color);
    color: var(--affine-icon-color);
    font-size: var(--affine-font-sm);
    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-menu-shadow);
    border-radius: 8px;
  }

  .affine-block-hub-container[type='text'] {
    top: unset;
    bottom: 0;
    transform: unset;
    right: calc(100% + 4px);
  }

  .visible {
    display: block;
  }

  .invisible {
    display: none;
  }

  .card-container-wrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    position: relative;
  }

  .card-container {
    display: flex;
    position: relative;
    align-items: center;
    width: 250px;
    height: 54px;
    background: var(--affine-white-80);
    box-shadow: var(--affine-shadow-1);
    border-radius: 8px;
    margin-bottom: 12px;
    cursor: grab;
    top: 0;
    left: 0;
    transition: all 0.1s ease-in-out;
  }

  .card-icon-container {
    display: flex;
    align-items: center;
    position: absolute;
    right: 12px;
  }

  .card-icon-container > svg {
    width: 20px;
    height: 20px;
  }

  .card-container-inner:hover .card-container {
    background: var(--affine-hover-color);
    top: -2px;
    left: -2px;
  }

  .card-container-inner:hover .card-container.grabbing {
    top: unset;
    left: unset;
    box-shadow: var(--affine-shadow-2);
  }

  .card-description-container {
    display: block;
    width: 190px;
    color: var(--affine-text-primary-color);
    font-size: var(--affine-font-base);
    line-height: var(--affine-line-height);
    margin: 8px 0 8px 12px;
    text-align: justify;
  }

  .affine-block-hub-container .description {
    font-size: var(--affine-font-sm);
    line-height: var(--affine-line-height);
    color: var(--affine-text-secondary-color);
    white-space: pre;
  }

  .grabbing {
    cursor: grabbing;
  }

  .grab {
    cursor: grab;
  }

  .affine-block-hub-title-container {
    margin: 16px 0 20px 12px;
    color: var(--affine-text-secondary-color);
    font-size: var(--affine-font-base);
    user-select: none;
  }

  .prominent {
    z-index: 1;
  }

  .block-hub-menu-container {
    display: flex;
    font-family: var(--affine-font-family);
    flex-flow: column;
    justify-content: center;
    align-items: center;
    position: fixed;
    width: 44px;
    background: var(--affine-background-primary-color);
    border-radius: 8px;
  }

  .block-hub-menu-container[expanded] {
    box-shadow: var(--affine-menu-shadow);
    background: var(--affine-background-overlay-panel-color);
  }

  .block-hub-icon-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 8px;
    position: relative;
    border-radius: 4px;
    fill: var(--affine-icon-color);
    color: var(--affine-icon-color);
    height: 36px;
  }
  .block-hub-icon-container svg {
    width: 24px;
    height: 24px;
  }

  .block-hub-icon-container[selected='true'] {
    background: var(--affine-hover-color);
  }

  .block-hub-icon-container:hover {
    background: var(--affine-hover-color);
    border-radius: 4px;
  }

  .new-icon {
    width: 44px;
    height: 44px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border-radius: 8px;
    fill: var(--affine-icon-color);
  }

  .new-icon-in-edgeless {
    box-shadow: var(--affine-menu-shadow);
  }
  .block-hub-menu-container[expanded] .new-icon {
    border-radius: 4px;
    box-shadow: unset;
  }

  .new-icon:hover {
    box-shadow: var(--affine-menu-shadow);
    background: var(--affine-white);
  }

  .icon-expanded {
    width: 36px;
    height: 36px;
  }

  .icon-expanded:hover {
    background: var(--affine-hover-color);
  }

  .divider {
    height: 1px;
    width: 36px;
    background: var(--affine-border-color);
    margin: 4px 0;
  }

  [role='menuitem'] tool-tip {
    font-size: var(--affine-font-sm);
  }

  .block-hub-icons-container {
    overflow: hidden;
    transition: all 0.2s cubic-bezier(0, 0, 0.55, 1.6);
  }

  ${g.a}
`;function b(e,t,i,n,o,r,a){let s=n<800,l=(0,u.V)({maxHeight:`${n}px`,overflowY:s?"scroll":"unset"});return d.dy`
    <div
      class="affine-block-hub-container ${o?"visible":""}"
      style="${l}"
      type=${t}
    >
      <div class="affine-block-hub-title-container">${i}</div>
      ${e.map(({flavour:t,type:i,name:n,description:o,icon:l,tooltip:c},h)=>d.dy`
            <div class="card-container-wrapper">
              <div class="card-container-inner">
                <div
                  class="card-container has-tool-tip ${r?"grabbing":""}"
                  draggable="true"
                  affine-flavour=${t}
                  affine-type=${i??""}
                >
                  <div class="card-description-container">
                    <div>${n}</div>
                    <div class="description">${o}</div>
                  </div>
                  <div class="card-icon-container">${l}</div>
                  <tool-tip
                    tip-position=${s&&h===e.length-1?"top":"bottom"}
                    style="${a?"":"display: none"}; z-index: ${e.length-h}"
                    >${c}</tool-tip
                  >
                </div>
              </div>
            </div>
          `)}
    </div>
  `}let C=class extends(0,l.$T)(l.Zi){constructor(e){super(),this._expanded=!1,this._isGrabbing=!1,this._visibleCardType=null,this._showTooltip=!0,this._inEdgelessMode=!1,this._maxHeight=2e3,this._currentClientX=0,this._currentClientY=0,this._isCardListVisible=!1,this._lastDroppingTarget=null,this._lastDroppingType="none",this._lastDraggingFlavour=null,this._timer=null,this._onTransitionStart=e=>{this._timer&&clearTimeout(this._timer),this._expanded?(this._blockHubMenuContainer.style.padding="4px",this._timer=window.setTimeout(()=>{this._blockHubIconsContainer.style.overflow="unset"},200)):(this._blockHubMenuContainer.style.padding="0 4px",this._timer=window.setTimeout(()=>{this._blockHubIconsContainer.style.overflow="hidden"},200))},this._onClickOutside=e=>{let t=e.target;t instanceof HTMLElement&&!t.closest("affine-block-hub")&&this._hideCardList()},this._onClickCard=(e,t)=>{let i=t.getAttribute("affine-type");(0,a.kP)(i);let n={flavour:t.getAttribute("affine-flavour")??""};i&&(n.type=i),this._onClickCardCallback(n)},this._onBlockHubButtonClick=e=>{this._expanded=!this._expanded,this._expanded||this._hideCardList()},this._onDragStart=e=>{this._showTooltip=!1,(0,a.kP)(e.dataTransfer),e.dataTransfer.effectAllowed="move";let t=e.target,i=t.getAttribute("affine-type"),n={flavour:t.getAttribute("affine-flavour")};i&&(n.type=i),e.dataTransfer.setData("affine/block-hub",JSON.stringify(n)),this._lastDraggingFlavour=n.flavour,this._onDragStartCallback()},this._onMouseDown=e=>{s.vU&&(this._currentClientX=e.clientX,this._currentClientY=e.clientY)},this._onDrag=e=>{this._hideCardList();let t=e.clientX,i=e.clientY;if(s.vU&&(t=this._currentClientX,i=this._currentClientY),!this._indicator||this._indicator.rect&&this._indicator.rect.left===t&&this._indicator.rect.top===i)return;let n=new f.E9(t,i),{container:o,rect:r,scale:a}=this.getHoveringFrameState(n.clone());if(!r){this._resetDropState();return}let l=(0,f.cy)(n,{container:o,rect:r,snapToEdge:{x:!1,y:!0}},a);if(!l){this._resetDropState();return}let d="none",c=null,h=null,u=(0,f.gc)(l),p=(0,f.Lb)(n,u,l,[],a,this._lastDraggingFlavour);p&&(d=p.type,c=p.rect,h=p.modelState),this._lastDroppingType=d,this._indicator.rect=c,this._lastDroppingTarget=h},this._onDragOver=e=>{e.preventDefault()},this._onDragOverDocument=e=>{if(!s.vU)throw Error("FireFox only");this._currentClientX=e.clientX,this._currentClientY=e.clientY},this._onDragEnd=e=>{this._showTooltip=!0,this._isGrabbing=!1,this._lastDraggingFlavour=null,this._resetDropState()},this._resetDropState=()=>{this._lastDroppingType="none",this._indicator.rect=null,this._lastDroppingTarget=null},this._onDrop=e=>{(0,a.kP)(e.dataTransfer),e.dataTransfer.getData("affine/block-hub")&&this._onDropCallback(e,this._indicator?.rect?.min??new f.E9(e.clientX,e.clientY),this._lastDroppingTarget,this._lastDroppingType)},this._onCardMouseDown=e=>{this._isGrabbing=!0},this._onCardMouseUp=e=>{this._isGrabbing=!1},this._onBlankMenuMouseDown=()=>{this._isGrabbing=!0},this._onBlankMenuMouseUp=()=>{this._isGrabbing=!1},this._onBlockHubMenuMouseOver=e=>{let t=e.currentTarget,i=t.getAttribute("type");(0,a.kP)(i),this._isCardListVisible=!0,this._visibleCardType=i},this._onBlockHubEntryMouseOver=()=>{this._isCardListVisible=!1},this._onResize=()=>{let e=document.body.getBoundingClientRect();this._maxHeight=e.height-24-70},this._page=e.page,this._mouseRoot=e.mouseRoot,this._enableDatabase=e.enableDatabase,this.getAllowedBlocks=e.getAllowedBlocks,this.getHoveringFrameState=e.getHoveringFrameState,this._onDragStartCallback=e.onDragStart,this._onDropCallback=e.onDrop,this._onClickCardCallback=e.onClickCard}connectedCallback(){super.connectedCallback();let e=this._disposables;e.addFromEvent(this,"dragstart",this._onDragStart),e.addFromEvent(this,"drag",this._onDrag),e.addFromEvent(this,"dragend",this._onDragEnd),e.addFromEvent(this._mouseRoot,"dragover",this._onDragOver),e.addFromEvent(this._mouseRoot,"drop",this._onDrop),e.addFromEvent(this,"mousedown",this._onMouseDown),e.add(this._mouseRoot.slots.pageModeSwitched.on(e=>{this._inEdgelessMode="edgeless"===e})),s.vU&&e.addFromEvent(this._mouseRoot,"dragover",this._onDragOverDocument),this._onResize()}firstUpdated(){let e=this._disposables;for(let t of(this._blockHubCards.forEach(t=>{e.addFromEvent(t,"mousedown",this._onCardMouseDown),e.addFromEvent(t,"mouseup",this._onCardMouseUp),e.addFromEvent(t,"click",e=>this._onClickCard(e,t))}),this._blockHubMenus))e.addFromEvent(t,"mouseover",this._onBlockHubMenuMouseOver),"blank"===t.getAttribute("type")&&(e.addFromEvent(t,"mousedown",this._onBlankMenuMouseDown),e.addFromEvent(t,"mouseup",this._onBlankMenuMouseUp));e.addFromEvent(this._blockHubMenuEntry,"mouseover",this._onBlockHubEntryMouseOver),e.addFromEvent(document,"click",this._onClickOutside),e.addFromEvent(this._blockHubButton,"click",this._onBlockHubButtonClick),e.addFromEvent(this._blockHubButton,"mousedown",e=>{e.preventDefault()}),e.addFromEvent(this._blockHubIconsContainer,"transitionstart",this._onTransitionStart),e.addFromEvent(window,"resize",this._onResize),this._indicator=document.createElement("affine-drag-indicator"),document.body.appendChild(this._indicator)}disconnectedCallback(){super.disconnectedCallback(),this._disposables.dispose()}toggleMenu(){this._expanded=!this._expanded,this._expanded||this._hideCardList()}_hideCardList(){this._visibleCardType&&(this._visibleCardType=null,this._isCardListVisible=!1)}render(){var e,t,i;let a=function(e,t,i,a,s,l,c,h){let u=b(n.VA,"list","List",c,t&&s&&"list"===a,i,l),f=b(n.Xr.filter(({flavour:e})=>"affine:bookmark"!==e||h.awarenessStore.getFlag("enable_bookmark_operation")),"file","Content & Media",c,t&&s&&"file"===a,i,l);return d.dy`
    <div
      class="block-hub-icons-container"
      ?transition=${t}
      style="height: ${t?`${44*(e?5:4)+10}px`:"0"};"
    >
      <div
        class="block-hub-icon-container has-tool-tip ${i?"grabbing":"grab"}"
        selected=${"blank"===a?"true":"false"}
        type="blank"
        draggable="true"
        affine-flavour="affine:paragraph"
        affine-type="text"
      >
        ${o.xo}
        <tool-tip
          inert
          role="tooltip"
          tip-position="left"
          ?hidden=${!l}
          >Drag to insert blank line
        </tool-tip>
      </div>
      <div
        class="block-hub-icon-container"
        type="text"
        selected=${"text"===a?"true":"false"}
      >
        ${o.i5}
      </div>
      <div
        class="block-hub-icon-container"
        type="list"
        selected=${"list"===a?"true":"false"}
      >
        ${u} ${o.oP}
      </div>
      <div
        class="block-hub-icon-container"
        type="file"
        selected=${"file"===a?"true":"false"}
      >
        ${f} ${r.FL}
      </div>
      ${e?d.dy`
            <div
              class="block-hub-icon-container has-tool-tip"
              type="database"
              draggable="true"
              affine-flavour="affine:database"
              selected=${"database"===a?"true":"false"}
            >
              ${o.Th}
              <tool-tip
                inert
                role="tooltip"
                tip-position="left"
                ?hidden=${!l}
              >
                Drag to create a database
              </tool-tip>
            </div>
          `:null}
      <div class="divider"></div>
    </div>
  `}(this._enableDatabase,this._expanded,this._isGrabbing,this._visibleCardType,this._isCardListVisible,this._showTooltip,this._maxHeight,this._page),s=b(n.s9,"text","Text block",this._maxHeight,(e=this._expanded,t=this._isCardListVisible,i=this._visibleCardType,e&&t&&"text"===i),this._isGrabbing,this._showTooltip),l=(0,h.$)({"icon-expanded":this._expanded,"new-icon-in-edgeless":this._inEdgelessMode&&!this._expanded,"has-tool-tip":!0,"new-icon":!0});return d.dy`
      <div
        class="block-hub-menu-container"
        ?expanded=${this._expanded}
        style="bottom: ${70}px; right: ${24}px;"
      >
        ${a}
        <div class=${l} role="menuitem" style="cursor:pointer;">
          ${this._expanded?o.aM:o.US}
          <tool-tip
            class=${this._expanded?"invisible":""}
            inert
            tip-position="left"
            role="tooltip"
            >Insert blocks
          </tool-tip>
        </div>
        ${s}
      </div>
    `}};C.styles=v,m([(0,c.Cb)()],C.prototype,"getAllowedBlocks",void 0),m([(0,c.Cb)()],C.prototype,"getHoveringFrameState",void 0),m([(0,c.SB)()],C.prototype,"_expanded",void 0),m([(0,c.SB)()],C.prototype,"_isGrabbing",void 0),m([(0,c.SB)()],C.prototype,"_visibleCardType",void 0),m([(0,c.SB)()],C.prototype,"_showTooltip",void 0),m([(0,c.SB)()],C.prototype,"_inEdgelessMode",void 0),m([(0,c.SB)()],C.prototype,"_maxHeight",void 0),m([(0,c.Kt)(".card-container")],C.prototype,"_blockHubCards",void 0),m([(0,c.Kt)(".block-hub-icon-container[type]")],C.prototype,"_blockHubMenus",void 0),m([(0,c.IO)(".new-icon")],C.prototype,"_blockHubButton",void 0),m([(0,c.IO)(".block-hub-icons-container")],C.prototype,"_blockHubIconsContainer",void 0),m([(0,c.IO)(".block-hub-menu-container")],C.prototype,"_blockHubMenuContainer",void 0),m([(0,c.IO)('[role="menuitem"]')],C.prototype,"_blockHubMenuEntry",void 0),C=m([(0,c.Mo)("affine-block-hub")],C);var y=i(61005),x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=class extends d.oi{constructor(){super(...arguments),this.vertical=!1}render(){return d.dy`<div
      class="divider ${this.vertical?"vertical":"horizontal"}"
    ></div>`}};w.styles=d.iv`
    :host {
      display: inline-block;
    }

    .divider {
      background-color: var(--affine-border-color);
    }

    .divider.vertical {
      width: 1px;
      height: 100%;
      margin: 0 7px;
    }

    .divider.horizontal {
      width: 100%;
      height: 1px;
      margin: 7px 0;
    }
  `,x([(0,c.Cb)()],w.prototype,"vertical",void 0),w=x([(0,c.Mo)("menu-divider")],w);var _=i(13246),k=i(903),M=i(48616),S=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let E=class extends d.oi{constructor(){super(...arguments),this.page=null,this._ranges=[],this._colorMap=new Map,this._resizeObserver=new ResizeObserver(()=>{this.requestUpdate()}),this._abortController=new AbortController}firstUpdated(){(0,_.kP)(this.page),this.page.awarenessStore.slots.update.subscribe(e=>e,e=>{if(!e||!e.state?.rangeMap||e.id===this.page?.awarenessStore.awareness.clientID)return;(0,_.kP)(this.page);let t=this.page,{user:i,rangeMap:n}=e.state;if("update"===e.type){let o=this._ranges.findIndex(t=>t.id===e.id);-1===o?this._ranges.push({id:e.id,userRange:n[t.prefixedId],user:i}):this._ranges[o]={id:e.id,userRange:n[t.prefixedId],user:i}}else if("add"===e.type)this._ranges.push({id:e.id,userRange:n[t.prefixedId],user:i});else if("remove"===e.type){let t=this._ranges.findIndex(t=>t.id===e.id);this._ranges.splice(t,1)}this.requestUpdate()}),this.page.history.on("stack-item-popped",e=>{let t=e.stackItem.meta.get("cursor-location");if(!t)return;(0,_.kP)(this.page);let i=t.blockIds.map(e=>((0,_.kP)(this.page),this.page.getBlockById(e))).filter(Boolean);i.length&&requestAnimationFrame(()=>{if((0,_.kP)(this.page),1===i.length&&i[0]===this.page.root){(0,k.vq)({type:"Title",startOffset:t.startOffset,endOffset:t.endOffset,models:[this.page.root]});return}(0,k.vq)({type:"Native",startOffset:t.startOffset,endOffset:t.endOffset,models:i})})}),this._resizeObserver.observe(document.body);let e=document.querySelector(".affine-default-viewport");e?.addEventListener("scroll",()=>this.requestUpdate(),{signal:this._abortController.signal})}disconnectedCallback(){super.disconnectedCallback(),this._resizeObserver.disconnect(),this._abortController.abort()}_getSelectionRect(e){(0,_.kP)(this.page);let t=e.blockIds.map(e=>((0,_.kP)(this.page),this.page.getBlockById(e))).filter(Boolean),i=null;if(!(i=1===t.length&&t[0]===this.page.root?(0,k.yd)({type:"Title",startOffset:e.startOffset,endOffset:e.endOffset,models:[this.page.root]}):(0,k.yd)({type:"Native",startOffset:e.startOffset,endOffset:e.endOffset,models:t})))return[];let n=(0,M.VA)(this.page);(0,_.kP)(n);let o=n.getBoundingClientRect(),r=Array.from(i.getClientRects());return r.map(e=>({width:e.width,height:e.height,top:e.top-o.top,left:e.left-o.left})).filter(t=>t.width>1&&t.height>0||1===e.blockIds.length)}_getCursorRect(e){(0,_.kP)(this.page);let t=e.blockIds[e.blockIds.length-1],i=e.endOffset,n=this.page.getBlockById(t);if(!n||!n.text)return null;let o=(0,k.yd)({type:"Native",startOffset:i,endOffset:i,models:[n]});if(!o)return null;let r=(0,M.VA)(this.page);(0,_.kP)(r);let a=r.getBoundingClientRect(),s=Array.from(o.getClientRects());if(1===s.length){let e=s[0];return{width:2,height:e.height+4,top:e.top-2-a.top,left:e.left-a.left}}return null}render(){if(!this.page||0===this._ranges.length)return this._colorMap.clear(),d.dy``;let e=this._ranges.filter(e=>e.userRange).map(e=>({id:e.id,userRange:e.userRange,rects:this._getSelectionRect(e.userRange),user:e.user}));return d.dy`<div>
      ${e.flatMap(e=>{e.user&&this._colorMap.set(e.id,e.user.color),this._colorMap.has(e.id)||this._colorMap.set(e.id,function(){let e=Math.floor(16777215*Math.random()).toString(16);return`#${e}`}());let t=this._colorMap.get(e.id),i=this._getCursorRect(e.userRange);return e.rects.map(e=>{var i;return d.dy`
              <div style="${i=t+Math.round(127.5).toString(16).toUpperCase(),(0,u.V)({position:"absolute",width:`${e.width}px`,height:`${e.height}px`,top:`${e.top}px`,left:`${e.left}px`,backgroundColor:i})}"></div>
            `}).concat([d.dy`
              <div
                style="${i?(0,u.V)({position:"absolute",width:`${i.width}px`,height:`${i.height}px`,top:`${i.top}px`,left:`${i.left}px`,backgroundColor:t}):(0,u.V)({display:"none"})}"
              >
                <div
                  style="${(0,u.V)({position:"relative",height:"100%"})}"
                >
                  <div
                    style="${(0,u.V)({position:"absolute",bottom:`${i?.height}px`,padding:"2px","background-color":t,color:"white"})}"
                  >
                    ${e.user?.name}
                  </div>
                </div>
              </div>
            `])})}
    </div>`}};E.styles=d.iv`
    :host {
      position: absolute;
      pointer-events: none;
      left: 0;
      top: 0;
    }
  `,S([(0,c.Cb)()],E.prototype,"page",void 0),E=S([(0,c.Mo)("remote-selection")],E);var L=i(57891),$=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let P=class extends(0,l.$T)(d.oi){constructor(){super(...arguments),this.offset={x:0,y:0},this.state={rects:[],grab:!1}}_onPointerUp({clientX:e,clientY:t,shiftKey:i}){this.removeAttribute("data-grab"),document.dispatchEvent(new PointerEvent("pointerup",{bubbles:!0,clientX:e,clientY:t,shiftKey:i}))}connectedCallback(){super.connectedCallback(),this._disposables.addFromEvent(this,"pointerup",this._onPointerUp)}willUpdate(){let{rects:[e],grab:t}=this.state;if(e){let{x:t,y:i}=this.offset;this.style.top=`${e.top+i}px`,this.style.left=`${e.left+t}px`}this.toggleAttribute("data-grab",!!(e&&t))}render(){let{rects:e}=this.state,t=e[0];return t?(0,L.r)(e,e=>d.dy`<div
            style=${(0,u.V)({width:`${e.width}px`,height:`${e.height}px`,top:`${e.top-t.top}px`,left:`${e.left-t.left}px`})}
          ></div>`):d.Ld}};P.styles=d.iv`
    :host {
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      pointer-events: none;
    }

    :host([data-grab]) {
      pointer-events: auto;
    }

    :host([data-grab]:hover) {
      cursor: grab;
    }

    :host > div {
      position: absolute;
      border-radius: 5px;
      background: var(--affine-hover-color);
    }
  `,$([(0,c.Cb)()],P.prototype,"mouseRoot",void 0),$([(0,c.Cb)()],P.prototype,"offset",void 0),$([(0,c.Cb)()],P.prototype,"state",void 0),P=$([(0,c.Mo)("affine-selected-blocks")],P)},30597:function(e,t,i){"use strict";i.d(t,{A:function(){return x}}),i(74403);var n=i(92758),o=i(15486),r=i(32916),a=i(65024),s=i(37666),l=i(29691);let d=o.iv`
  .affine-link-edit-popover {
    box-sizing: border-box;
    width: 404px;
    height: 112px;
    padding: 12px;
    box-shadow: var(--affine-shadow-2);
    background: var(--affine-background-overlay-panel-color);
    border-radius: 8px;
    display: grid;
    grid-template-columns: auto auto auto;
    grid-template-rows: repeat(2, 1fr);
    gap: 12px;
    grid-template-areas:
      'text-area .'
      'link-area btn';
    justify-items: center;
    align-items: center;
    /* breaks 'basic link' test in chromium */
    /* user-select: none; */
  }

  .affine-edit-text-area {
    grid-area: text-area;
    width: 338px;
    display: grid;
    gap: 6px;
    grid-template-columns: auto auto auto;
    grid-template-rows: repeat(1, 1fr);
    grid-template-areas: 'text span text-input';
    justify-items: center;
    align-items: center;
    user-select: none;
  }

  .affine-edit-link-area {
    grid-area: link-area;
    width: 338px;
    display: grid;
    gap: 6px;
    grid-template-columns: auto auto auto;
    grid-template-rows: repeat(1, 1fr);
    grid-template-areas: 'link span link-input';
    justify-items: center;
    align-items: center;
  }

  .affine-link-popover-dividing-line {
    grid-area: span;
  }
  .affine-edit-text-text {
    grid-area: text;
  }

  .affine-edit-text-input {
    grid-area: text-input;
  }

  .affine-edit-link-text {
    grid-area: link;
  }

  .affine-edit-link-input {
    grid-area: link-input;
  }

  .affine-confirm-button {
    grid-area: btn;
    user-select: none;
    fill: var(--affine-icon-color);
  }
  .affine-confirm-button[disabled],
  .affine-confirm-button:disabled {
    fill: var(--affine-icon-color);
  }
`,c=o.iv`
  .popover-container {
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-base);
    font-style: normal;
    line-height: 24px;
    color: var(--affine-popover-color);
    z-index: var(--affine-z-index-popover);
    animation: affine-popover-fade-in 0.2s ease;
  }

  @keyframes affine-popover-fade-in {
    from {
      opacity: 0;
      transform: translateY(-3px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .overlay-mask {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: var(--affine-z-index-popover);
  }
  .affine-edit-text-area {
    border: 1px solid var(--affine-border-color);
    outline: none;
    border-radius: 10px;
    background: transparent;
  }
  .affine-edit-text-area:focus-within {
    border: 1px solid var(--affine-primary-color);
  }
  .affine-edit-link-area {
    border: 1px solid var(--affine-border-color);
    outline: none;
    border-radius: 10px;
    background: transparent;
  }
  .affine-edit-link-area:focus-within {
    border: 1px solid var(--affine-primary-color);
  }

  label {
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-sm);
    box-sizing: border-box;
    padding: 6px 0 6px 12px;
    color: var(--affine-icon-color);
  }

  input {
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-base);
    box-sizing: border-box;
    padding: 6px 12px 6px 0;
    width: 260px;
    height: 34px;
    color: inherit;
    border: none;
    background: transparent;
  }
  input::placeholder {
    color: var(--affine-placeholder-color);
  }
  input:focus {
    outline: none;
  }
  input:focus ~ label,
  input:active ~ label {
    color: var(--affine-primary-color);
  }

  .affine-link-popover {
    display: flex;
    align-items: center;
    height: 40px;
    padding: 0 12px;

    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-shadow-2);
    border-radius: 8px;
  }

  .affine-link-popover-input {
    border: none;
  }
  .affine-link-popover-input::placeholder {
    color: var(--affine-placeholder-color);
  }
  .affine-link-popover-input:focus {
    border: none;
  }

  .affine-link-preview {
    width: 260px;
    height: 28px;
    display: flex;
    align-items: center;
    user-select: none;
    cursor: pointer;
    white-space: nowrap;
  }

  .affine-link-popover-dividing-line {
    margin: 0 6px;
    width: 1px;
    height: 20px;
    background-color: var(--affine-border-color);
  }

  ${d}
  ${l.a}
`;var h=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let u=["http","https","ftp","sftp","mailto","tel"],f=/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,p=RegExp("^(?:(?:(?:https?|ftp):)?\\/\\/)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z0-9\\u00a1-\\uffff][a-z0-9\\u00a1-\\uffff_-]{0,62})?[a-z0-9\\u00a1-\\uffff]\\.)+(?:[a-z\\u00a1-\\uffff]{2,}\\.?))(?::\\d{2,5})?(?:[/?#]\\S*)?$","i");function g(e){let t=u.some(t=>e.startsWith(t+":"));if(t)return e;let i=f.test(e);return i?"mailto:"+e:"http://"+e}let m=e=>{if(!e)return!1;let t=g(e);return t===e||p.test(t)},v=class extends o.oi{constructor(){super(...arguments),this.left="0",this.top="0",this.type="create",this.showMask=!0,this.text="",this.previewLink="",this.showBookmarkOperation=!1,this._bodyOverflowStyle="",this._disableConfirm=!0}connectedCallback(){super.connectedCallback(),this.showMask&&(this._bodyOverflowStyle=document.body.style.overflow,document.body.style.overflow="hidden")}firstUpdated(e){super.firstUpdated(e),this.linkInput&&this.linkInput.focus()}disconnectedCallback(){super.disconnectedCallback(),this.showMask&&(document.body.style.overflow=this._bodyOverflowStyle)}_hide(){this.dispatchEvent(new CustomEvent("updateLink",{detail:{type:"cancel"}}))}_onConfirm(){if(this._disableConfirm)return;if(!this.linkInput)throw Error("Failed to update link! Link input not found!");let e=g(this.linkInput.value),t=this.textInput?.value??void 0;e&&this.dispatchEvent((0,a.yM)("updateLink",{type:"confirm",link:e,text:t}))}_onCopy(e){navigator.clipboard.writeText(this.previewLink),(0,s.A)("Copied link to clipboard")}_onUnlink(e){this.dispatchEvent((0,a.yM)("updateLink",{type:"remove"}))}_onLinkToCard(e){this.dispatchEvent(new CustomEvent("updateLink",{detail:{type:"toBookmark"}}))}_onEdit(e){this.dispatchEvent((0,a.yM)("editLink",null)),this._disableConfirm=!1}_onInput(e){if(!this.linkInput)throw Error("Failed to update link! Link input not found!");let t=m(this.linkInput.value);this._disableConfirm=!t}_onKeydown(e){"Enter"!==e.key||e.isComposing||(e.preventDefault(),this._onConfirm())}confirmBtnTemplate(){return o.dy`<icon-button
      class="affine-confirm-button"
      ?disabled=${this._disableConfirm}
      @click=${this._onConfirm}
      >${n.q1}</icon-button
    >`}createLinkTemplate(){return o.dy`<div class="affine-link-popover">
      <input
        id="link-input"
        class="affine-link-popover-input"
        type="text"
        spellcheck="false"
        placeholder="Paste or type a link"
        value=${this.previewLink}
        @keydown=${this._onKeydown}
        @input=${this._onInput}
      />
      <span class="affine-link-popover-dividing-line"></span>
      ${this.confirmBtnTemplate()}
    </div>`}previewTemplate(){return o.dy`<div class="affine-link-popover">
      <div class="affine-link-preview has-tool-tip" @click=${this._onCopy}>
        <tool-tip inert role="tooltip">Click to copy link</tool-tip>
        <span style="overflow: hidden;">${this.previewLink}</span>
      </div>
      <span class="affine-link-popover-dividing-line"></span>
      ${this.showBookmarkOperation?o.dy`<icon-button
              class="has-tool-tip"
              data-testid="unlink"
              @click=${this._onLinkToCard}
            >
              ${n.Md}
              <tool-tip inert role="tooltip">Turn into Card view</tool-tip>
            </icon-button>
            <span class="affine-link-popover-dividing-line"></span>`:""}
      <icon-button
        class="has-tool-tip"
        data-testid="unlink"
        @click=${this._onUnlink}
      >
        ${n.ZJ}
        <tool-tip inert role="tooltip">Remove</tool-tip>
      </icon-button>

      <icon-button
        class="has-tool-tip"
        data-testid="edit"
        @click=${this._onEdit}
      >
        ${n.dY}
        <tool-tip inert role="tooltip">Edit</tool-tip>
      </icon-button>
    </div>`}simpleTemplate(){let e=!this.previewLink;return e?this.createLinkTemplate():this.previewTemplate()}editTemplate(){return o.dy`<div class="affine-link-edit-popover">
      <div class="affine-edit-text-area">
        <input
          class="affine-edit-text-input"
          id="text-input"
          type="text"
          placeholder="Enter text"
          value=${this.text}
          @keydown=${this._onKeydown}
        />
        <span class="affine-link-popover-dividing-line"></span>
        <label class="affine-edit-text-text" for="text-input">Text</label>
      </div>
      <div class="affine-edit-link-area">
        <input
          id="link-input"
          class="affine-edit-link-input"
          type="text"
          spellcheck="false"
          placeholder="Paste or type a link"
          value=${this.previewLink}
          @keydown=${this._onKeydown}
        />
        <span class="affine-link-popover-dividing-line"></span>
        <label class="affine-edit-link-text" for="link-input">Link</label>
      </div>
      ${this.confirmBtnTemplate()}
    </div>`}render(){let e=this.showMask?o.dy`<div class="overlay-mask" @click="${this._hide}"></div>`:o.dy``,t="create"===this.type?this.simpleTemplate():this.editTemplate();return o.dy`
      <div class="overlay-root">
        ${e}
        <div
          class="popover-container"
          style="position: absolute; left: ${this.left}; top: ${this.top};${this.style.cssText}"
        >
          ${t}
        </div>
      </div>
    `}};v.styles=c,h([(0,r.Cb)()],v.prototype,"left",void 0),h([(0,r.Cb)()],v.prototype,"top",void 0),h([(0,r.Cb)()],v.prototype,"type",void 0),h([(0,r.Cb)()],v.prototype,"showMask",void 0),h([(0,r.Cb)()],v.prototype,"text",void 0),h([(0,r.Cb)()],v.prototype,"previewLink",void 0),h([(0,r.Cb)()],v.prototype,"showBookmarkOperation",void 0),h([(0,r.SB)()],v.prototype,"_bodyOverflowStyle",void 0),h([(0,r.SB)()],v.prototype,"_disableConfirm",void 0),h([(0,r.IO)("#text-input")],v.prototype,"textInput",void 0),h([(0,r.IO)("#link-input")],v.prototype,"linkInput",void 0),h([(0,r.IO)(".popover-container")],v.prototype,"popoverContainer",void 0),v=h([(0,r.Mo)("edit-link-panel")],v);var b=i(31054),C=i(76709);function y(e,t){let i=t.getBoundingClientRect(),n=(0,C.Ne)({positioningPoint:{x:i.x,y:i.top+i.height+5},objRect:e.popoverContainer?.getBoundingClientRect(),offsetY:5});e.left=`${n.x}px`,e.top=`${n.y}px`}async function x({anchorEl:e,page:t,container:i=document.body,text:n="",link:o="",showMask:r=!0,interactionKind:s="always",abortController:l=new AbortController}){if((0,b.kP)(e,"Can't show tooltip without anchor element!"),l.signal.aborted)return Promise.resolve({type:"cancel"});let d=function(e,t,{showMask:i,previewLink:n,page:o}){let r=document.createElement("edit-link-panel");return r.showMask=i,r.previewLink=n,r.showBookmarkOperation=!!o.awarenessStore.getFlag("enable_bookmark_operation"),t.appendChild(r),requestAnimationFrame(()=>{y(r,e)}),r}(e,i,{showMask:r,previewLink:o,page:t}),c="hover"===s?function(e,t,i){let n;let o=e=>{clearTimeout(n)},r=e=>{n=window.setTimeout(()=>{i.abort()},300)},s=()=>{i.abort()};e.addEventListener("mouseover",o),e.addEventListener("mouseout",r),t.addEventListener("mouseover",o),t.addEventListener("mouseout",r);let l=(0,a.mt)(e),d=(0,a.U6)(l.page),c=d?.viewportElement;return c?.addEventListener("scroll",s),()=>{e.removeEventListener("mouseover",o),e.removeEventListener("mouseout",r),t.removeEventListener("mouseover",o),t.removeEventListener("mouseout",r),c?.removeEventListener("scroll",s)}}(e,d,l):a.ZT;return new Promise(t=>{l.signal.addEventListener("abort",()=>{d.remove(),t({type:"cancel"})}),d.addEventListener("editLink",t=>{l.signal.aborted||(d.type="edit",d.showMask=!0,d.text=n,c(),requestAnimationFrame(()=>{y(d,e)}))}),d.addEventListener("updateLink",e=>{l.signal.aborted||(d.remove(),t(e.detail))})})}},60434:function(e,t,i){"use strict";i.d(t,{n:function(){return y}});var n=i(13246),o=i(48616),r=i(70263),a=i(76709),s=i(92758),l=i(7339),d=i(50634),c=i(15486),h=i(32916),u=i(91827),f=i(55410),p=i(61005),g=i(81890);let m=c.iv`
  :host {
    position: absolute;
  }

  .linked-page-popover {
    position: fixed;
    left: 0;
    top: 0;
    box-sizing: border-box;
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-base);
    padding: 12px 8px;
    display: flex;
    flex-direction: column;

    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-shadow-2);
    border-radius: 12px;
    z-index: var(--affine-z-index-popover);
  }

  .linked-page-popover icon-button {
    padding: 8px;
    justify-content: flex-start;
    gap: 8px;
  }

  .linked-page-popover .group-title {
    color: var(--affine-text-secondary-color);
    margin: 8px 12px;
  }

  .linked-page-popover .divider {
    margin: 6px 12px;
    height: 1px;
    background: var(--affine-border-color);
  }

  ::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 4px;
  }
  ::-webkit-scrollbar-thumb {
    border-radius: 2px;
    background-color: #b1b1b1;
  }
`;var v=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let b="Untitled",C=class extends(0,d.$T)(c.oi){get _actionList(){let e=this._query||b,t=e.slice(0,8)+(e.length>8?"..":""),i=this._pageList.filter(({title:e})=>(0,r.Qn)(e,this._query));return[...i.map((e,t)=>({key:e.id,name:e.title||b,active:t===this._activatedItemIndex,icon:s.YA,action:()=>this._insertLinkedNode("LinkedPage",e.id)})),{key:"create-linked-page",name:`Create "${t}" page`,active:i.length===this._activatedItemIndex,icon:s.yR,action:()=>this._createPage()},{key:"import-linked-page",name:"Import",active:i.length===this._activatedItemIndex,icon:l._c,action:()=>this._importPage()}]}get _page(){return this.model.page}constructor(e,t=new AbortController){super(),this.model=e,this.abortController=t,this._position=null,this._query="",this._pageList=[],this._activatedItemIndex=0}connectedCallback(){super.connectedCallback();let e=(0,o.Et)(this.model);(0,n.kP)(e,"RichText not found"),(0,g.R)({target:e,onUpdateQuery:e=>{this._query=e,this._activatedItemIndex=0},abortController:this.abortController,onMove:e=>{this._activatedItemIndex=(this._actionList.length+this._activatedItemIndex+e)%this._actionList.length;let t=this._actionList[this._activatedItemIndex];if("create-linked-page"===t.key||"import-linked-page"===t.key)return;let i=this.shadowRoot;if(!i){console.warn("Failed to find the shadow root!",this);return}let n=i.querySelector(`icon-button[data-id="${t.key}"]`);if(!n){console.warn("Failed to find the active item!",t);return}n.scrollIntoView({block:"nearest"})},onConfirm:()=>{this._actionList[this._activatedItemIndex].action()},onEsc:()=>{this.abortController.abort()}}),this._disposables.addFromEvent(this,"mousedown",e=>{e.preventDefault()}),this._pageList=this._page.workspace.meta.pageMetas,this._disposables.add(this.model.page.workspace.slots.pagesUpdated.on(()=>{this._pageList=this._page.workspace.meta.pageMetas}))}updatePosition(e){this._position=e}_insertLinkedNode(e,t){this.abortController.abort();let i=(0,o.gj)(this.model);(0,n.kP)(i,"Editor not found"),function(e,t){let i=e.getVRange();(0,n.kP)(i);let o=i.index-t.length,r=e.yText.toString().slice(o,o+t.length);if(r!==t){console.warn(`Failed to clean text! Text mismatch expected: ${t} but actual: ${r}`);return}e.deleteText({index:o,length:t.length}),e.setVRange({index:o,length:0})}(i,"@"+this._query);let r=i.getVRange();(0,n.kP)(r),i.insertText(r,f.O,{reference:{type:e,pageId:t}}),i.setVRange({index:r.index+1,length:0})}_createPage(){let e=this._query,t=this._page.workspace.createPage({init:{title:e}});this._insertLinkedNode("LinkedPage",t.id)}_importPage(){this.abortController.abort();let e=e=>{if(0===e.length)return;let t=e[0];this._insertLinkedNode("LinkedPage",t)};(0,p.j)({workspace:this._page.workspace,multiple:!1,onSuccess:e})}render(){let e=this._position?(0,u.V)({transform:`translate(${this._position.x}, ${this._position.y})`,maxHeight:`${Math.min(this._position.height,396)}px`}):(0,u.V)({visibility:"hidden"}),t=this._actionList.slice(0,-2).map(({key:e,name:t,action:i,active:n,icon:o},r)=>c.dy`<icon-button
        width="280px"
        height="32px"
        data-id=${e}
        text=${t}
        ?hover=${n}
        @click=${i}
        @mousemove=${()=>{this._activatedItemIndex=r}}
        >${o}</icon-button
      >`),i=this._actionList.slice(-2).map(({key:e,name:t,action:i,active:n,icon:o},r)=>c.dy`<icon-button
        width="280px"
        height="32px"
        data-id=${e}
        text=${t}
        ?hover=${n}
        @click=${i}
        @mousemove=${()=>{this._activatedItemIndex=this._actionList.length-1+r}}
        >${o}</icon-button
      >`);return c.dy`<div class="linked-page-popover" style="${e}">
      ${t.length?c.dy`<div class="group-title">Link to page</div>
            <div class="group" style="overflow-y: scroll; max-height: 224px;">
              ${t}
            </div>
            <div class="divider"></div>`:null}

      <div class="group-title">New page</div>
      ${i}
    </div>`}};function y({model:e,range:t,container:i=document.body,abortController:s=new AbortController}){let l=new n.SJ;s.signal.addEventListener("abort",()=>l.dispose());let d=new C(e,s);i.appendChild(d),l.add(()=>d.remove());let c=(0,r.P2)(()=>{let e=d.linkedPageElement;(0,n.kP)(e,"You should render the linked page node even if no position");let i=(0,a.W$)(e,t);d.updatePosition(i)},10);l.addFromEvent(window,"resize",c);let h=(0,o.dK)(e.page);return h&&l.addFromEvent(h,"scroll",c,{passive:!0}),setTimeout(c),l.addFromEvent(window,"mousedown",e=>{e.target!==d&&s.abort()}),d}C.styles=m,v([(0,h.SB)()],C.prototype,"_position",void 0),v([(0,h.SB)()],C.prototype,"_query",void 0),v([(0,h.SB)()],C.prototype,"_pageList",void 0),v([(0,h.SB)()],C.prototype,"_activatedItemIndex",void 0),v([(0,h.IO)(".linked-page-popover")],C.prototype,"linkedPageElement",void 0),C=v([(0,h.Mo)("affine-linked-page-popover")],C)},98785:function(e,t,i){"use strict";var n=i(15486),o=i(32916),r=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let a=class extends n.oi{constructor(){super(...arguments),this.container=document.body,this.template=n.dy``,this._portalRoot=null}disconnectedCallback(){super.disconnectedCallback(),this._portalRoot?.remove()}createRenderRoot(){let e=document.createElement("div");return e.classList.add("affine-portal"),this.container.append(e),this._portalRoot=e,e}render(){return this.template}};r([(0,o.Cb)()],a.prototype,"container",void 0),r([(0,o.Cb)()],a.prototype,"template",void 0),r([(0,o.Mo)("affine-portal")],a)},40063:function(e,t,i){"use strict";i.d(t,{M:function(){return T}});var n=i(13246),o=i(65024),r=i(76709),a=i(50634),s=i(15486),l=i(32916),d=i(91827),c=i(81890),h=i(69692),u=i(92758),f=i(7339),p=i(62554),g=i(55410),m=i(280),v=i(903),b=i(25005),C=i(93251),y=i(54131),x=i(67929),w=i(60434),_=i(37666);function k(e,t,i){if(!e.text)throw Error("Can't insert text! Text not found");let n=(0,o.gj)(e);if(!n)throw Error("Can't insert text! vEditor not found");let r=n.getVRange(),a=r?r.index:e.text.length;e.text.insert(t,a,i),n.setVRange({index:a+t.length,length:0})}function M(e){let t=e.getFullYear(),i=(e.getMonth()+1).toString().padStart(2,"0"),n=e.getDate().toString().padStart(2,"0"),o=`${t}-${i}-${n}`;return o}function S(e){return n.cQ.isInsideBlockByFlavour(e.page,e,"affine:database")}let E=[{name:"Text",items:[...h.I_.filter(e=>"affine:list"!==e.flavour).map(({name:e,icon:t,flavour:i,type:n})=>({name:e,icon:t,showWhen:t=>!!t.page.schema.flavourSchemaMap.has(i)&&(!["Quote","Code Block","Divider"].includes(e)||!S(t)),action:({model:e})=>{let t=(0,x.WV)([e],i,n);if("affine:code"===i){if(1!==t.length)throw Error("Failed to reset selection! New model length isn't 1");let e=t[0];(0,x.HM)(e,()=>{(0,v.vq)({type:"Native",startOffset:0,endOffset:0,models:[e]})})}}}))]},{name:"Style",items:y.W.filter(e=>!["Link","Code"].includes(e.name)).map(({name:e,icon:t,id:i})=>({name:e,icon:t,action:({model:e})=>{if(!e.text)return;let t=e.text.length;if(!t){let t=(0,o.gj)(e);(0,n.kP)(t,"Can't set style mark! vEditor not found"),t.setMarks({[i]:!0}),(0,b.F)(t);return}e.text.format(0,t,{[i]:!0})}}))},{name:"List",items:h.I_.filter(e=>"affine:list"===e.flavour).map(({name:e,icon:t,flavour:i,type:n})=>({name:e,icon:t,showWhen:e=>!!e.page.schema.flavourSchemaMap.has(i),action:({model:e})=>(0,x.WV)([e],i,n)}))},{name:"Pages",items:[{name:"New Page",icon:u.IY,showWhen:e=>!!e.page.awarenessStore.getFlag("enable_linked_page"),action:({page:e,model:t})=>{let i=e.workspace.createPage({init:!0});k(t,g.O,{reference:{type:"LinkedPage",pageId:i.id}})}},{name:"Link Page",alias:["dual link"],icon:u.yR,showWhen:e=>!!e.page.awarenessStore.getFlag("enable_linked_page"),action:({model:e})=>{k(e,"@"),(0,w.n)({model:e,range:(0,o.bR)()})}}]},{name:"Content & Media",items:[{name:"Image",icon:f.u7,showWhen:e=>!(!e.page.schema.flavourSchemaMap.has("affine:embed")||S(e)),async action({page:e,model:t}){let i=e.getParent(t);if(!i)return;i.children.indexOf(t);let n=await (0,o.mw)(e);e.addSiblingBlocks(t,n)}},{name:"Bookmark",icon:f.pl,showWhen:e=>!!(e.page.awarenessStore.getFlag("enable_bookmark_operation")&&e.page.schema.flavourSchemaMap.has("affine:embed"))&&!S(e),async action({page:e,model:t}){let i=e.getParent(t);if(!i)return;let n=i.children.indexOf(t);(0,o.GK)(i,n+1)}}]},{name:"Date & Time",items:[{name:"Today",icon:u.$M,action:({model:e})=>{let t=new Date;k(e,M(t))}},{name:"Tomorrow",icon:u.Gz,action:({model:e})=>{let t=new Date;t.setDate(t.getDate()+1),k(e,M(t))}},{name:"Yesterday",icon:u.l3,action:({model:e})=>{let t=new Date;t.setDate(t.getDate()-1),k(e,M(t))}},{name:"Now",icon:u.p_,action:({model:e})=>{let t=new Date,i=t.getHours(),n=t.getMinutes().toString().padStart(2,"0"),o=i>=12?"pm":"am";i%=12,i=i||12;let r=i+":"+n+" "+o;k(e,r)}}]},{name:"Database",items:[{name:"Table View",alias:["database"],icon:u.Th,showWhen:e=>!(!e.page.awarenessStore.getFlag("enable_database")||!e.page.schema.flavourSchemaMap.has("affine:database")||S(e)),action:async({page:e,model:t})=>{let i=e.getParent(t);(0,n.kP)(i);let o=i.children.indexOf(t),r=e.addBlock("affine:database",{},e.getParent(t),o),a=await (0,m.getServiceOrRegister)("affine:database");a.initDatabaseBlock(e,t,r,!1)}},{name:"Kanban View",alias:["database"],disabled:!0,icon:u.D3,showWhen:e=>!(!e.page.awarenessStore.getFlag("enable_database")||!e.page.schema.flavourSchemaMap.has("affine:database")||S(e)),action:({model:e})=>{}}]},{name:"Actions",items:[{name:"Copy",icon:u.TI,action:async({model:e})=>{let t=(0,o.bR)();await (0,C.Kf)(e),(0,o.xT)(t),(0,_.A)("Copied to clipboard")}},{name:"Duplicate",icon:u.NA,action:({page:e,model:t})=>{if(!t.text||!(t.text instanceof n.xv))throw Error("Can't duplicate a block without text");let i=e.getParent(t);if(!i)throw Error("Failed to duplicate block! Parent not found");let o=i.children.indexOf(t);e.addBlock(t.flavour,{type:t.type,text:e.Text.fromDelta((0,p.AQ)(e,t.text.toDelta())),checked:t.checked},e.getParent(t),o)}},{name:"Delete",icon:u.pJ,action:({page:e,model:t})=>{e.deleteBlock(t)}}]}].map(e=>({name:e.name,items:e.items.map(t=>({...t,groupName:e.name}))})),L=s.iv`
  .overlay-mask {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: var(--affine-z-index-popover);
  }

  .slash-menu-container {
    z-index: var(--affine-z-index-popover);
    user-select: none;
  }

  .slash-menu {
    position: fixed;
    left: 0;
    top: 0;
    box-sizing: border-box;
    font-size: var(--affine-font-base);
    padding: 12px 0;
    display: flex;

    background: var(--affine-background-overlay-panel-color);
    box-shadow: var(--affine-shadow-2);
    border-radius: 12px;
    z-index: var(--affine-z-index-popover);
    /* transition: max-height 0.2s ease-in-out; */
  }

  .slash-category {
    position: relative;
    overflow: hidden;
    box-sizing: border-box;
    width: 150px;
    max-width: 150px;
    display: flex;
    flex-direction: column;
    color: var(--affine-text-secondary-color);
    gap: 5px;
    margin-bottom: 20px;
    /* transition: max-width 0.2s ease-in-out; */
  }
  .slash-category::before {
    content: '';
    position: absolute;
    top: 10px;
    right: 0;
    height: 100%;
    width: 1px;
    background-color: var(--affine-border-color);
  }

  .slash-category-hide {
    max-width: 0;
    padding: 0;
    margin: 0;
    height: 0;
  }

  .slash-category-name {
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-sm);
    white-space: nowrap;
    cursor: pointer;
    padding: 4px 20px;
  }

  .slash-active-category {
    position: relative;
    box-sizing: border-box;
    color: var(--affine-primary-color);
  }

  .slash-active-category::after {
    content: '';
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 1px;
    height: 12px;
    background: linear-gradient(
      180deg,
      var(--affine-text-emphasis-color) 0%,
      var(--affine-palette-purple) 100%
    );
    border-radius: 1px;
  }

  .slash-item-container {
    box-sizing: border-box;
    overflow-y: auto;
    padding: 0 8px;
    width: 200px;
  }

  ::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 4px;
  }
  ::-webkit-scrollbar-thumb {
    border-radius: 2px;
    background-color: #b1b1b1;
  }

  .slash-item-divider {
    border-top: 1px dashed var(--affine-border-color);
    margin: 8px 0;
  }

  format-bar-button svg {
    width: 20px;
    height: 20px;
  }
`;var $=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function P(e){return e.reduce((e,t)=>(e.length&&e[e.length-1]===t.groupName||e.push(t.groupName),e),[])}let B=class extends(0,a.$T)(s.oi){constructor(){super(...arguments),this._leftPanelActivated=!1,this._activatedItemIndex=0,this._filterItems=[],this._hide=!1,this._position=null,this.abortController=new AbortController,this._searchString="",this._onClickAway=e=>{this._hide&&this.abortController.abort()}}get menuGroups(){return E}connectedCallback(){super.connectedCallback(),this._disposables.addFromEvent(window,"mousedown",this._onClickAway),this._disposables.addFromEvent(this,"mousedown",e=>{e.preventDefault()}),this._filterItems=this._updateItem("");let e=(0,o.Et)(this.model);if(!e){console.warn("Slash Menu may not work properly! No rich text found for model",this.model);return}(0,c.R)({target:e,abortController:this.abortController,interceptor:(e,t)=>{if("/"===e.key)return;if(this._hide&&"Backspace"!==e.key){this.abortController.abort();return}if(" "===e.key){this._hide=!0,t();return}this._hide&&(this._hide=!1);let i=(0,o.Jc)(e),n=e.shiftKey;if("ArrowLeft"===e.key&&!i&&!n){if(e.stopPropagation(),e.preventDefault(),this._searchString.length)return;this._leftPanelActivated=!0;return}if("ArrowRight"===e.key&&!i&&!n){e.stopPropagation(),e.preventDefault(),this._leftPanelActivated=!1;return}t()},onUpdateQuery:e=>{let t=this._updateItem(e);this._filterItems=t,t.length||(this._hide=!0)},onMove:e=>{let t=this._filterItems.length;if(this._leftPanelActivated){let t=P(this._filterItems),i=t.findIndex(e=>e===this._filterItems[this._activatedItemIndex].groupName),n=t[(i+e+t.length)%t.length];this._handleClickCategory(n);return}let i=t;do this._activatedItemIndex=(this._activatedItemIndex+e+t)%t;while(this._filterItems[this._activatedItemIndex].disabled&&i--);this._scrollToItem(this._filterItems[this._activatedItemIndex],!1)},onConfirm:()=>{this._handleClickItem(this._activatedItemIndex)},onEsc:()=>{this.abortController.abort()}})}updatePosition(e){this._position=e}_updateItem(e){this._searchString=e,this._activatedItemIndex=0,this._leftPanelActivated&&(this._leftPanelActivated=!1);let t=this._searchString.toLowerCase(),i=this.menuGroups.flatMap(e=>e.items);return(i=i.filter(({showWhen:e=()=>!0})=>e(this.model)),t)?i.filter(({name:e,alias:i=[]})=>[e,...i].some(e=>(0,o.Qn)(e,t))):i}_scrollToItem(e,t=!0){let i=this.shadowRoot;if(!i)return;let n=i.querySelector(`format-bar-button[text="${e.name}"]`);if(n){if(t){n.scrollIntoView(!0);return}n.scrollIntoView({block:"nearest"})}}_handleClickItem(e){if(this._leftPanelActivated||e<0||e>=this._filterItems.length)return;this.abortController.abort(this._searchString);let{action:t}=this._filterItems[e];t({page:this.model.page,model:this.model})}_handleClickCategory(e){let t=this._filterItems.find(t=>t.groupName===e);t&&(this._scrollToItem(t),this._activatedItemIndex=this._filterItems.findIndex(e=>e.name===t.name))}_categoryTemplate(){let e=!this._searchString.length,t=this._filterItems[this._activatedItemIndex]?.groupName,i=P(this._filterItems);return s.dy`<div
      class="slash-category ${e?"":"slash-category-hide"}"
    >
      ${i.map(e=>s.dy`<div
            class="slash-category-name ${t===e?"slash-active-category":""}"
            @click=${()=>this._handleClickCategory(e)}
          >
            ${e}
          </div>`)}
    </div>`}render(){if(this._hide)return s.Ld;let e=!this._searchString.length,t=this._position?(0,d.V)({transform:`translate(${this._position.x}, ${this._position.y})`,maxHeight:`${Math.min(this._position.height,e?408:344)}px`}):(0,d.V)({visibility:"hidden"}),i=this._filterItems.map(({name:e,icon:t,disabled:i=!1,groupName:n},o)=>{let r=0!==o&&this._filterItems[o-1].groupName!==n;return s.dy`<div
            class="slash-item-divider"
            ?hidden=${!r||!!this._searchString.length}
          ></div>
          <format-bar-button
            ?disabled=${i}
            width="100%"
            style="padding-left: 12px; justify-content: flex-start;"
            ?hover=${!i&&!this._leftPanelActivated&&this._activatedItemIndex===o}
            text="${e}"
            data-testid="${e}"
            @mousemove=${()=>{this._leftPanelActivated=!1,this._activatedItemIndex=o}}
            @click=${()=>{this._handleClickItem(o)}}
          >
            ${t}
          </format-bar-button>`});return s.dy`<div class="slash-menu-container">
      <div
        class="overlay-mask"
        @click="${()=>this.abortController.abort()}"
      ></div>
      <div class="slash-menu" style="${t}">
        ${this._categoryTemplate()}
        <div class="slash-item-container">${i}</div>
      </div>
    </div>`}};B.styles=L,$([(0,l.Cb)()],B.prototype,"model",void 0),$([(0,l.IO)(".slash-menu")],B.prototype,"slashMenuElement",void 0),$([(0,l.SB)()],B.prototype,"_leftPanelActivated",void 0),$([(0,l.SB)()],B.prototype,"_activatedItemIndex",void 0),$([(0,l.SB)()],B.prototype,"_filterItems",void 0),$([(0,l.SB)()],B.prototype,"_hide",void 0),$([(0,l.SB)()],B.prototype,"_position",void 0),B=$([(0,l.Mo)("slash-menu")],B);let R=new AbortController;function T({model:e,range:t,container:i=document.body,abortController:a=new AbortController}){R.abort(),R=a;let s=new B;s.model=e,s.abortController=a;let l=(0,o.Il)(()=>{let e=s.slashMenuElement;(0,n.kP)(e,"You should render the slash menu node even if no position");let i=(0,r.W$)(e,t);s.updatePosition(i)},10);return window.addEventListener("resize",l),i.appendChild(s),setTimeout(l),a.signal.addEventListener("abort",t=>{!function(e,t,i,r){if(t.remove(),window.removeEventListener("resize",i),!e.target||!(e.target instanceof AbortSignal))throw Error("Failed to clean slash search text! Unknown abort event");if(e.target.reason instanceof DOMException)return;if("string"!=typeof e.target.reason)throw Error("Failed to clean slash search text! Unknown abort reason");let a="/"+e.target.reason,s=r.text;if(!s){console.warn("Failed to clean slash search text! No text found for model",r);return}let l=(0,o.gj)(r);if(!l){console.warn("Failed to clean slash search text! No vEditor found for model, model:",r);return}let d=l.getVRange();(0,n.kP)(d);let c=d.index-a.length,h=s.toString().slice(c,c+a.length);if(h!==a){console.warn(`Failed to clean slash search text! Text mismatch expected: ${a} but actual: ${h}`);return}s.delete(c,a.length),l.setVRange({index:c,length:0})}(t,s,l,e)}),s}},37666:function(e,t,i){"use strict";i.d(t,{A:function(){return s}});var n=i(15486);let o=null,r=e=>{let t=document.createElement("template");if("string"==typeof e)e=e.trim(),t.innerHTML=e;else{let{strings:i,values:n}=e,o=[...n,""],r=i.reduce((e,t,i)=>e+t+o[i],"");t.innerHTML=r}return t.content.firstChild},a=()=>{let e=n.iv`
    position: fixed;
    z-index: 9999;
    top: 16px;
    left: 16px;
    right: 16px;
    bottom: 78px;
    pointer-events: none;
    display: flex;
    flex-direction: column-reverse;
    align-items: center;
  `,t=n.dy`<div style="${e}"></div>`,i=r(t);return document.body.appendChild(i),i},s=(e,t=2500)=>{o||(o=a());let i=n.iv`
    max-width: 480px;
    text-align: center;
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-sm);
    padding: 6px 12px;
    margin: 10px 0 0 0;
    color: var(--affine-white);
    background: var(--affine-tooltip);
    box-shadow: var(--affine-float-button-shadow);
    border-radius: 10px;
    transition: all 230ms cubic-bezier(0.21, 1.02, 0.73, 1);
    opacity: 0;
  `,s=n.dy`<div style="${i}"></div>`,l=r(s);l.textContent=e,o.appendChild(l);let d=[{opacity:0},{opacity:1}],c={duration:230,easing:"cubic-bezier(0.21, 1.02, 0.73, 1)",fill:"forwards"};return l.animate(d,c),setTimeout(async()=>{let e=d.reverse(),t=l.animate(e,c);await t.finished,l.style.maxHeight="0",l.style.margin="0",l.style.padding="0",l.addEventListener("transitionend",()=>{l.remove()},{once:!0})},t),l}},29691:function(e,t,i){"use strict";i.d(t,{a:function(){return o}});var n=i(15486);let o=n.iv`
  tool-tip {
    font-family: var(--affine-font-family);
    position: absolute;

    inline-size: max-content;
    text-align: center;
    font-size: var(--affine-font-sm);
    padding: 4px 12px;
    color: var(--affine-white);
    background: var(--affine-tooltip);
    opacity: 0;
    transition: opacity 0.2s ease, transform 0.2s ease;
    pointer-events: none;
    user-select: none;

    /* Default is top-start */
    left: 0;
    top: 0;
    border-radius: 10px 10px 10px 0;
    transform: translate(0, calc(-100% - 8px));
  }

  tool-tip:is([tip-position='top']) {
    left: 50%;
    border-radius: 10px;
    transform: translate(-50%, calc(-100% - 8px));
  }
  tool-tip:is([tip-position='right']) {
    left: unset;
    right: 0;
    transform: translateX(calc(100% + 8px));
    border-radius: 0 10px 10px 10px;
  }
  tool-tip:is([tip-position='left']) {
    left: 0;
    top: 50%;
    transform: translate(calc(-100% - 8px), -50%);
    border-radius: 10px 10px 0 10px;
  }
  tool-tip:is([tip-position='bottom']) {
    top: unset;
    left: 50%;
    bottom: 0;
    transform: translate(-50%, calc(100% + 8px));
    border-radius: 10px;
  }

  /* work for tip-position='top' */
  tool-tip:is([arrow]):is([tip-position='top']) {
    transform: translate(-50%, calc(-100% - 16px));
  }
  tool-tip:is([arrow]):is([tip-position='top'])::before {
    position: absolute;
    content: '';
    left: 50%;
    bottom: 0;
    transform: translate(-50%, 100%);
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid var(--affine-tooltip);
  }

  /* work for tip-position='right' */
  tool-tip:is([arrow]):is([tip-position='right']) {
    transform: translateX(calc(100% + 16px));
  }
  tool-tip:is([arrow]):is([tip-position='right'])::before {
    position: absolute;
    content: '';
    left: 0;
    bottom: 50%;
    transform: translate(-100%, 50%);
    width: 0;
    height: 0;
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-right: 6px solid var(--affine-tooltip);
  }

  /* work for tip-position='left' */
  tool-tip:is([arrow]):is([tip-position='left']) {
    transform: translate(calc(-100% - 16px), -50%);
  }
  tool-tip:is([arrow]):is([tip-position='left'])::before {
    position: absolute;
    content: '';
    right: 0;
    bottom: 50%;
    transform: translate(100%, 50%);
    width: 0;
    height: 0;
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-left: 6px solid var(--affine-tooltip);
  }

  /* work for tip-position='bottom' */
  tool-tip:is([arrow]):is([tip-position='bottom']) {
    transform: translate(-50%, calc(100% + 16px));
  }
  tool-tip:is([arrow]):is([tip-position='bottom'])::before {
    position: absolute;
    content: '';
    left: 50%;
    top: 0;
    transform: translate(-50%, -100%);
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-bottom: 6px solid var(--affine-tooltip);
  }

  .has-tool-tip {
    position: relative;
  }
  .has-tool-tip:is(:hover, :focus-visible, :active) > tool-tip {
    opacity: 1;
    transition-delay: 200ms;
  }
`},81890:function(e,t,i){"use strict";i.d(t,{R:function(){return a}});var n=i(31054),o=i(70263),r=i(29045);let a=({target:e,onUpdateQuery:t,onMove:i,onConfirm:a,onEsc:s,interceptor:l=(e,t)=>t(),abortController:d})=>{let c="",h=e.vEditor;(0,n.kP)(h,"Failed to observer keyboard! virgo editor is not exist.");let u=h?.getVRange()?.index??0,f=async()=>{await (0,n._v)(0);let e=(0,r.bR)();if(e.startContainer!==e.endContainer){console.warn("Failed to parse query! Current range is not collapsed.",e),d.abort();return}let i=e.startContainer;if(i.nodeType!==Node.TEXT_NODE){console.warn("Failed to parse query! Current range is not a text node.",e),d.abort();return}let o=h.getVRange()?.index??0,a=h.yText.toString(),s=c;(c=a.slice(u,o))!==s&&t(c)},p=e=>{if(e.stopPropagation(),!e.defaultPrevented){if((0,o.Jc)(e)){let t=(e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey;if(t&&1===e.key.length)switch(e.key){case"P":case"p":i(-1),e.preventDefault();return;case"N":case"n":i(1),e.preventDefault();return}if("Control"===e.key||"Meta"===e.key||"Alt"===e.key)return;d.abort();return}if((0,o.Jc)(e)||1!==e.key.length)switch(e.key){case"Escape":case"ArrowLeft":case"ArrowRight":d.abort();return;case"Backspace":c.length||d.abort(),f();return;case"Enter":if(e.isComposing)return;if(e.shiftKey){d.abort();return}a(),e.preventDefault();return;case"Tab":e.shiftKey?i(-1):i(1),e.preventDefault();return;case"ArrowUp":if(e.shiftKey){d.abort();return}i(-1),e.preventDefault();return;case"ArrowDown":if(e.shiftKey){d.abort();return}i(1),e.preventDefault();return;default:return}f()}};if(e.addEventListener("keydown",e=>l(e,()=>p(e)),{capture:!0,signal:d.signal}),e.addEventListener("input",f,{signal:d.signal}),s){let e=e=>{"Escape"===e.key&&s()};window.addEventListener("keydown",e,{signal:d.signal})}}},91519:function(e,t,i){"use strict";i.d(t,{q:function(){return d}});var n=i(13246),o=i(280),r=i(88523),a=i(29045),s=i(11563),l=i(67704);class d extends r.b{constructor(){super(),this._lastRowSelection=null,this._lastCellSelection=null,this.slots={tableViewRowSelectionUpdated:new n.g7,tableViewCellSelectionUpdated:new n.g7},this.slots.tableViewRowSelectionUpdated.on(e=>{let{type:t}=e;if("select"===t||"click"===t){let{rowIds:t,databaseId:i}=e;this._lastRowSelection={databaseId:i,rowIds:t},(0,s.I9)(i,t)}else"clear"===t&&(this.clearLastRowSelection(),(0,s.Gt)())}),this.slots.tableViewCellSelectionUpdated.on(e=>{let{type:t}=e;if("select"===t){let{databaseId:t,coords:i}=e;this._lastCellSelection={databaseId:t,coords:i},(0,s.Cf)(t,i)}else if("edit"===t){this._lastCellSelection=null;let{databaseId:t,coords:i}=e;(0,s.xt)(t,i[0])}else"clear"===t&&(this._lastCellSelection=null,(0,s.rE)())})}initDatabaseBlock(e,t,i,o=!0){for(let t=0;t<3;t++){let n=e.addBlock("affine:paragraph",{text:new e.Text("")},i);0===t&&(0,a.a6)(e,n)}if(o){let i=e.getParent(t);(0,n.kP)(i),e.addBlock("affine:paragraph",{},i.id)}let r=e.getBlockById(i);(0,n.kP)(r),r.updateColumn({name:"Tag",type:"multi-select",width:200,hide:!1,selection:[]}),r.applyColumnUpdate()}block2Json(e,t,i){let n=[...e.columns],r=e.children.map(e=>e.id);return{flavour:e.flavour,databaseProps:{id:e.id,title:e.title.toString(),titleColumnName:e.titleColumnName,titleColumnWidth:e.titleColumnWidth,rowIds:r,cells:e.cells,columns:n},children:e.children?.map((t,n)=>n===e.children.length-1?(0,o.getService)(t.flavour).block2Json(t,0,i):(0,o.getService)(t.flavour).block2Json(t))}}async onBlockPasted(e,t){let{rowIds:i,columns:n,cells:o}=t,r=n.map(e=>e.id),a=n.map(t=>{let{id:i,...n}=t;return e.updateColumn(n)});e.applyColumnUpdate();let s=e.children.map(e=>e.id);i.forEach((t,i)=>{let n=s[i];r.forEach((i,r)=>{let s=o[t]?.[i],l=s?.value;l&&e.updateCell(n,{columnId:a[r],value:l})})})}clearSelection(){this.clearRowSelection(),this.clearCellLevelSelection()}clearRowSelection(){this.slots.tableViewRowSelectionUpdated.emit({type:"clear"})}setRowSelection(e){if("click"===e.type&&this._lastRowSelection&&e.rowIds?.[0]===this._lastRowSelection.rowIds?.[0]){this.clearRowSelection();return}this.slots.tableViewRowSelectionUpdated.emit(e)}setRowSelectionByElement(e){let t=(0,l.zE)(e);if(""!==t){let i=(0,l.tJ)(e);this.setRowSelection({type:"select",databaseId:i,rowIds:[t]})}}clearLastRowSelection(){this._lastRowSelection=null}refreshRowSelection(){if(!this._lastRowSelection)return;let{databaseId:e,rowIds:t}=this._lastRowSelection;this.setRowSelection({type:"select",databaseId:e,rowIds:t})}toggleRowSelection(e){let t=(0,l.zE)(e);if(""===t)return!1;let i=this._lastRowSelection?.rowIds??[];return i.indexOf(t)>-1?this.clearRowSelection():this.setRowSelection({type:"click",databaseId:(0,l.tJ)(e),rowIds:[t]}),!0}getLastRowSelection(){return this._lastRowSelection}clearCellLevelSelection(){this.slots.tableViewCellSelectionUpdated.emit({type:"clear"})}setCellSelection(e){this.slots.tableViewCellSelectionUpdated.emit(e)}getLastCellSelection(){return this._lastCellSelection}}},11563:function(e,t,i){"use strict";i.d(t,{rE:function(){return g},Gt:function(){return u},VT:function(){return v},VB:function(){return b},KP:function(){return y},vN:function(){return C},xt:function(){return m},Cf:function(){return p},I9:function(){return f}});var n=i(13246),o=i(50634),r=i(15486),a=i(32916),s=i(91827),l=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let d=class extends(0,o.$T)(r.oi){constructor(){super(...arguments),this.state=null,this.setSelection=e=>{this.state=e},this.clearSelection=()=>{this.state=null},this._getStyles=()=>{if(null===this.state)return(0,s.V)({left:0,top:0,height:0,width:0,display:"none"});let{databaseId:e,coords:t}=this.state,{left:i,top:n,width:o,height:r}=b(t,e),a=C(e),l=a.getBoundingClientRect(),d=1/this._zoom,c=(i-l.left)*d,h=(n-l.top)*d;return(0,s.V)({left:`${c}px`,top:`${h}px`,height:`${r*d}px`,width:`${o*d}px`,display:"block"})}}get _zoom(){let e=document.querySelector("affine-edgeless-page");return e?e.surface.viewport.zoom:1}render(){let e=this._getStyles();return r.dy`<div
      class="database-cell-level-selection"
      style=${e}
    ></div>`}};d.styles=r.iv`
    .database-cell-level-selection {
      position: absolute;
      width: 100%;
      z-index: 1;
      box-sizing: border-box;
      border: 2px solid var(--affine-primary-color);
      border-radius: 2px;
      background: var(--affine-primary-color-04);
    }
  `,l([(0,a.Cb)()],d.prototype,"cell",void 0),l([(0,a.SB)()],d.prototype,"state",void 0),d=l([(0,a.Mo)("database-cell-level-selection")],d);var c=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let h=class extends(0,o.$T)(r.oi){constructor(){super(...arguments),this.state=null,this.setSelection=({databaseId:e,rowIds:t})=>{this.state={databaseId:e,rowIds:t}},this.clearSelection=()=>{this.state=null},this._getStyles=()=>{var e;let t=(0,s.V)({left:0,top:0,height:0,display:"none"});if(!this.state)return t;let{rowIds:i}=this.state,{startRow:n,endRow:o}=function(e,{startRowId:t,endRowId:i}){let n=e.querySelector(`.database-row[data-row-id="${t}"]`),o=e.querySelector(`.database-row[data-row-id="${i}"]`);return{startRow:n,endRow:o}}(this.container,{startRowId:i[0],endRowId:i[i.length-1]});if(!n||!o)return t;let r=this.container.getBoundingClientRect(),{left:a,top:l}=n.getBoundingClientRect(),d=1/this._zoom,c=(e=this.container,i.reduce((t,i)=>{let n=e.querySelector(`.database-row[data-row-id="${i}"]`);if(!n)return t;let{height:o}=n.getBoundingClientRect();return t+o},0)*d),h=(a-r.left)*d,u=(l-r.top)*d,f=(0,s.V)({left:`${h}px`,top:`${u}px`,height:`${c}px`});return f}}get _zoom(){let e=document.querySelector("affine-edgeless-page");return e?e.surface.viewport.zoom:1}render(){let e=this._getStyles();return r.dy`<div
      class="database-row-level-selection"
      style=${e}
    ></div>`}};function u(){let e=document.querySelectorAll("affine-database");e.forEach(e=>{let t=e.querySelector("database-row-level-selection");t?.clearSelection()})}function f(e,t){let i=C(e),n=i.querySelector("database-row-level-selection");n||(n=new h,i.appendChild(n)),n.container=i,n.setSelection({databaseId:e,rowIds:t})}function p(e,t){let i;let n=C(e),o=((i=n.querySelector("database-cell-level-selection"))||(i=new d,n.appendChild(i)),i);o.setSelection({databaseId:e,coords:t});let r=x(t[0],e);r.scrollIntoView({block:"nearest"})}function g(){let e=document.querySelectorAll("affine-database");e.forEach(e=>{let t=e.querySelector("database-cell-level-selection");t?.clearSelection()})}function m(e,t){let i=x(t,e),o=i.firstElementChild?.firstElementChild;(0,n.kP)(o);let r=!0,a=o?.querySelector("rich-text");a?a.vEditor?.focusEnd():"number"===o.cellType?o.vEditor?.focusEnd():"rich-text"===o.cellType?o.vEditor?.focusEnd():("checkbox"===o.cellType&&(r=!1),o.click()),r&&function(e){let t=C(e),i=t.querySelector("database-cell-level-selection");i?.clearSelection()}(e)}function v(e,t,i){let o=C(t),r=w(o),a=r.length,s=r[0].length,l=null;e instanceof Element?(l=function(e,t){let i=C(t),n=w(i);for(let t=0;t<n.length;t++){let i=n[t];for(let n=0;n<i.length;n++)if(i[n].cell===e)return{rowIndex:t,cellIndex:n}}return null}(e,t),(0,n.kP)(l)):l=e;let d=function(e,t,i,n){switch(e){case"Escape":break;case"Tab":case"ArrowRight":return function(e,t,i){let n={rowIndex:0,cellIndex:0};return e.cellIndex!==i-1?(n.rowIndex=e.rowIndex,n.cellIndex=e.cellIndex+1,n):e.rowIndex!==t-1?(n.rowIndex=e.rowIndex+1,n.cellIndex=0,n):e}(t,i,n);case"ArrowUp":return function(e){let t={rowIndex:0,cellIndex:0};return 0!==e.rowIndex?(t.rowIndex=e.rowIndex-1,t.cellIndex=e.cellIndex,t):e}(t);case"ArrowDown":return function(e,t){let i={rowIndex:0,cellIndex:0};return e.rowIndex+1!==t?(i.rowIndex=e.rowIndex+1,i.cellIndex=e.cellIndex,i):e}(t,i);case"ArrowLeft":return function(e,t){let i={rowIndex:0,cellIndex:0};return 0!==e.cellIndex?(i.rowIndex=e.rowIndex,i.cellIndex=e.cellIndex-1,i):0!==e.rowIndex?(i.rowIndex=e.rowIndex-1,i.cellIndex=t-1,i):e}(t,n)}return t}(i,l,a,s);return d}function b(e,t){let i=C(t),n=w(i),[o]=e,r=n[o.rowIndex][o.cellIndex];return{left:r.left,top:r.top,width:r.width,height:r.height}}function C(e){let t=y(e),i=t.querySelector(".affine-database-table-container");return(0,n.kP)(i),i}function y(e){let t=document.querySelector(`affine-database[data-block-id="${e}"]`);return(0,n.kP)(t),t}function x(e,t){let i=C(t),n=w(i),{rowIndex:o,cellIndex:r}=e,a=n[o][r].cell;return a}function w(e){let t=[],i=e.querySelectorAll(".affine-database-block-row");return i.forEach((e,i)=>{let n=e.querySelectorAll(".database-cell");n.forEach((e,n)=>{if(e.classList.contains("add-column-button"))return;let{left:o,top:r,height:a,width:s}=e.getBoundingClientRect();t[i]=t[i]??[],t[i][n]={left:o,top:r,height:a,width:s,cell:e}})}),t}h.styles=r.iv`
    .database-row-level-selection {
      position: absolute;
      z-index: 1;
      box-sizing: border-box;
      width: 100%;
      border: 2px solid var(--affine-primary-color);
      border-radius: 2px;
      background: var(--affine-primary-color-04);
    }
  `,c([(0,a.Cb)()],h.prototype,"container",void 0),c([(0,a.SB)()],h.prototype,"state",void 0),h=c([(0,a.Mo)("database-row-level-selection")],h)},67704:function(e,t,i){"use strict";i.d(t,{g5:function(){return s},pD:function(){return c},tJ:function(){return d},uW:function(){return l},wy:function(){return a},zE:function(){return r}});var n=i(13246);function o(e){let t=e.closest(".database-row")?.getAttribute("data-row-index");return t?Number(t):-1}function r(e){let t=e.closest(".database-row")?.getAttribute("data-row-id");return t||""}function a(e,t){return t.map(t=>(function(e,t){let i=e.querySelector(`.database-row[data-row-index="${t}"]`)?.getAttribute("data-row-id");return(0,n.kP)(i),i})(e,t))}function s(e,t){let i=o(e),n=o(t);if(-1===i||-1===n)return[];let r=Math.min(i,n),a=Math.max(i,n),s=[];for(let e=r;e<=a;e++)s.push(e);return s}function l(e){let t=e?.closest("affine-database");return(0,n.kP)(t),t}function d(e){let t=l(e).getAttribute("data-block-id");return(0,n.kP)(t),t}function c(e){let t=e.closest("affine-database");return null!==t}},83740:function(e,t,i){"use strict";i.d(t,{y$:function(){return c},qw:function(){return h.q},fu:function(){return d}});var n=i(67072),o=i(50634),r=i(15486),a=i(32916),s=i(280),l=i(88523);class d extends l.b{block2html(e,{childText:t="",begin:i,end:n}={}){return"<hr/>"}}let c=class extends o.z3{connectedCallback(){super.connectedCallback(),(0,s.registerService)("affine:divider",d)}firstUpdated(){this.model.propsUpdated.on(()=>this.requestUpdate()),this.model.childrenUpdated.on(()=>this.requestUpdate())}render(){let e=r.dy`<div
      class="affine-block-children-container"
      style="padding-left: ${n.qL}px"
    >
      ${this.content}
    </div>`;return r.dy`
      <div class=${"affine-divider-block-container"}>
        <hr />
        ${e}
      </div>
    `}};c.styles=r.iv`
    .affine-divider-block-container {
      width: 100%;
      height: 20px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      margin-top: calc(var(--affine-paragraph-space) + 8px);
      margin-bottom: calc(var(--affine-paragraph-space) + 8px);
    }
    hr {
      width: 100%;
    }
  `,c=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,a.Mo)("affine-divider")],c);var h=i(64705)},92725:function(e,t,i){"use strict";i.d(t,{c:function(){return p}});var n,o=i(50634),r=i(15486),a=i(32916);let s=class extends o.Zi{render(){return r.dy`<div class="affine-image-block-container">
      <div class="affine-image-block-loading"></div>
    </div>`}};s.styles=r.iv`
    @keyframes affine-image-block-rotate {
      from {
        rotate: 0deg;
      }
      to {
        rotate: 360deg;
      }
    }

    .affine-image-block-container {
      width: 24px;
      height: 24px;
      overflow: hidden;
    }

    .affine-image-block-loading {
      display: inline-block;
      width: 24px;
      height: 24px;
      position: relative;
      background: conic-gradient(rgba(255, 255, 255, 0.31), #6880ff);
      border-radius: 50%;
      animation: affine-image-block-rotate 1s infinite ease-in;
    }

    .affine-image-block-loading::before {
      content: '';
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background-color: white;
      position: absolute;
      top: 2px;
      left: 2px;
    }
  `,s=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,a.Mo)("affine-image-block-circle-loading")],s);var l=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let d=class extends o.Zi{constructor(){super(...arguments),this.content="Loading content..."}render(){return r.dy`
      <div class="affine-image-block-loading-card">
        <affine-image-block-circle-loading></affine-image-block-circle-loading>
        <div class="affine-image-block-content">${this.content}</div>
      </div>
    `}};d.styles=r.iv`
    .affine-image-block-loading-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
      margin: 0 auto;
      border: 1px solid #ebeeff;
      border-radius: 10px;
      background: #fbfbff;
    }

    .affine-image-block-content {
      height: 30px;
      line-height: 22px;
      padding-top: 8px;
      color: var(--affine-primary-color);
      font-size: 16px;
      font-weight: 400;
    }
  `,l([(0,a.Cb)()],d.prototype,"content",void 0),d=l([(0,a.Mo)("affine-image-block-loading-card")],d);let c=r.dy`<svg
  width="25"
  height="24"
  viewBox="0 0 25 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M14.5 3H8.3C6.61984 3 5.77976 3 5.13803 3.32698C4.57354 3.6146 4.1146 4.07354 3.82698 4.63803C3.5 5.27976 3.5 6.11984 3.5 7.8V16.2C3.5 17.8802 3.5 18.7202 3.82698 19.362C4.1146 19.9265 4.57354 20.3854 5.13803 20.673C5.77976 21 6.61984 21 8.3 21H12.5L15.5 18L11.5 14L12.8418 12.6582C12.8197 12.6391 12.7979 12.6205 12.7762 12.6022C12.4696 12.3444 12.1366 12.1162 11.7278 11.987C11.1185 11.7945 10.4637 11.8016 9.85866 12.0072C9.45274 12.1452 9.12474 12.3806 8.82383 12.645C8.82383 12.645 6.60291 14.8415 5.5 15.9308V6.6C5.5 6.03995 5.5 5.75992 5.60899 5.54601C5.70487 5.35785 5.85785 5.20487 6.04601 5.10899C6.25992 5 6.53995 5 7.1 5H12.5L14.5 3ZM13.304 7.80408C13.1102 8.15931 13 8.56677 13 9C13 9.94759 13.5271 10.7719 14.3041 11.1959L15.5 10L13.304 7.80408ZM15.4156 11.4986L16.9142 10L13.9514 7.03724C14.3773 6.7008 14.9152 6.5 15.5 6.5C16.8806 6.5 18 7.61914 18 9C18 10.3809 16.8806 11.5 15.5 11.5C15.4718 11.5 15.4437 11.4995 15.4156 11.4986ZM13.5691 13.3451C13.6352 13.4103 13.7029 13.4775 13.7724 13.5464L14.7645 14.5302C15.0059 14.2937 15.2246 14.0861 15.4261 13.9167C15.7329 13.6587 16.0663 13.4302 16.4756 13.3011C17.0855 13.1087 17.7409 13.1162 18.3463 13.3226C18.7524 13.4611 19.0805 13.6971 19.3813 13.9622C19.4202 13.9965 19.4598 14.0322 19.5 14.0694V6.6C19.5 6.03995 19.5 5.75992 19.391 5.54601C19.2951 5.35785 19.1422 5.20487 18.954 5.10899C18.7401 5 18.4601 5 17.9 5H13.9143L15.9143 3H16.7C18.3802 3 19.2202 3 19.862 3.32698C20.4265 3.6146 20.8854 4.07354 21.173 4.63803C21.5 5.27976 21.5 6.11984 21.5 7.8V16.2C21.5 17.8802 21.5 18.7202 21.173 19.362C20.8854 19.9265 20.4265 20.3854 19.862 20.673C19.2202 21 18.3802 21 16.7 21H13.9143L16.9142 18L12.9142 14L13.5691 13.3451Z"
    fill="#6880FF"
  />
</svg>`,h=class extends o.Zi{render(){return r.dy`
      <div class="affine-image-block-not-found-card">${c}</div>
    `}};h.styles=r.iv`
    .affine-image-block-not-found-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
      margin: 0 auto;
      border: 1px solid var(--affine-border-color);
      border-radius: 10px;
      background: var(--affine-background-primary-color);
    }
  `,h=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,a.Mo)("affine-image-block-not-found-card")],h);var u=i(91827),f=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let p=n=class extends(0,o.$T)(o.Zi){constructor(){super(...arguments),this._imageReady={dispose:()=>{}},this._imageState="loading",this._retryCount=0,this._fetchError=e=>{this._imageState="waitUploaded",this._retryCount++,console.warn("Cannot find blob, retrying",this._retryCount),this._retryCount<n.maxRetryCount?setTimeout(()=>{this._fetchImage()},1e3*this._retryCount):(console.error(e),this._imageState="failed")},this._fetchImage=()=>{if("ready"===this._imageState)return;let e=this.model.page.blobs;e.get(this.model.sourceId).then(e=>{e?(this._source=URL.createObjectURL(e),this._imageState="ready"):this._fetchError(Error("Cannot find blob"))}).catch(this._fetchError)}}async firstUpdated(){this.model.propsUpdated.on(()=>this.requestUpdate()),this.model.childrenUpdated.on(()=>this.requestUpdate());let{width:e,height:t}=this.model;e&&t&&(this.resizeImg.style.width=e+"px",this.resizeImg.style.height=t+"px")}connectedCallback(){super.connectedCallback(),this._imageState="loading",this._fetchImage(),this._disposables.add(this.model.page.workspace.slots.blobUpdate.on(this._fetchImage))}disconnectedCallback(){this._imageReady.dispose(),this._source&&URL.revokeObjectURL(this._source),super.disconnectedCallback()}render(){let e={width:"unset",height:"unset"},{width:t,height:i}=this.model;t&&i&&(e.width=`${t}px`,e.height=`${i}px`);let n={waitUploaded:r.dy`<affine-image-block-loading-card
        content="Delivering content..."
      ></affine-image-block-loading-card>`,loading:r.dy`<affine-image-block-loading-card
        content="Loading content..."
      ></affine-image-block-loading-card>`,ready:r.dy`<img src=${this._source} />`,failed:r.dy`<affine-image-block-not-found-card></affine-image-block-not-found-card>`}[this._imageState];return r.dy`
      <div class="affine-image-wrapper">
        <div class="resizable-img" style=${(0,u.V)(e)}>
          ${n}
        </div>
      </div>
    `}};p.styles=r.iv`
    .affine-image-wrapper {
      padding: 8px;
      width: 100%;
      text-align: center;
      line-height: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin-top: calc(var(--affine-paragraph-space) + 8px);
      overflow: hidden;
    }
    .affine-image-wrapper img {
      max-width: 100%;
      margin: auto;
      width: 100%;
    }

    .resizable {
      max-width: 100%;
    }

    .active .resizable {
      border: 1px solid var(--affine-primary-color) !important;
    }
    .resizable .image-option-container {
      display: none;
      position: absolute;
      top: 4px;
      right: -52px;
      margin: 0;
      padding-left: 12px;
    }

    .embed-editing-state {
      box-shadow: var(--affine-shadow-2);
      border-radius: 10px;
      list-style: none;
      padding: 4px;
      width: 40px;
      background-color: var(--affine-background-overlay-panel-color);
      margin: 0;
    }

    .resizable .resizes {
      /* width: 100%; */
      height: 100%;
      box-sizing: border-box;
      line-height: 0;
    }

    .resizable .resizes .resize {
      /* display: none; */
      width: 10px;
      height: 10px;
      border-radius: 50%; /*magic to turn square into circle*/
      background: white;
      border: 2px solid var(--affine-primary-color);
      position: absolute;
    }

    .resizable:hover .resize {
      display: block;
    }
    .active .resize {
      display: block !important;
    }
    .resizable .resizes .resize.top-left {
      left: -5px;
      top: -5px;
      cursor: nwse-resize; /*resizer cursor*/
    }
    .resizable .resizes .resize.top-right {
      right: -5px;
      top: -5px;
      cursor: nesw-resize;
    }
    .resizable .resizes .resize.bottom-left {
      left: -5px;
      bottom: -5px;
      cursor: nesw-resize;
    }
    .resizable .resizes .resize.bottom-right {
      right: -5px;
      bottom: -5px;
      cursor: nwse-resize;
    }

    .resizable-img {
      border: 1px solid var(--affine-white-90);
    }
    .resizable-img:hover {
      border: 1px solid var(--affine-primary-color);
    }

    .resizable-img img {
      width: 100%;
    }
  `,p.maxRetryCount=3,f([(0,a.Cb)()],p.prototype,"model",void 0),f([(0,a.IO)(".resizable-img")],p.prototype,"resizeImg",void 0),f([(0,a.SB)()],p.prototype,"_source",void 0),f([(0,a.SB)()],p.prototype,"_imageState",void 0),p=n=f([(0,a.Mo)("affine-image")],p)},27314:function(e,t,i){"use strict";i.d(t,{MZ:function(){return c},RQ:function(){return h.R},Xk:function(){return l}});var n=i(50634),o=i(15486),r=i(32916),a=i(280),s=i(88523);class l extends s.b{block2html(e,{childText:t="",begin:i,end:n}={}){return`<figure><img src="${e.sourceId}" alt="${e.caption}"><figcaption>${e.caption}</figcaption></figure>`}block2Text(e,{childText:t="",begin:i,end:n}={}){return e.caption}block2Json(e,t,i){return{type:e.type,sourceId:e.sourceId,width:e.width,height:e.height,caption:e.caption,flavour:e.flavour,children:[]}}}var d=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let c=class extends n.z3{connectedCallback(){super.connectedCallback(),(0,a.registerService)("affine:embed",l)}firstUpdated(e){super.firstUpdated(e),this.updateComplete.then(()=>{this._caption=this.model?.caption??"",this._caption.length>0&&this._input.classList.add("caption-show")}),this.addEventListener("click",()=>{document.activeElement&&document.activeElement instanceof HTMLElement&&document.activeElement.blur()}),this._input.addEventListener("pointerup",e=>{e.stopPropagation()})}_onInputChange(){this._caption=this._input.value,this.model.page.updateBlock(this.model,{caption:this._caption})}_onInputBlur(){this._caption||this._input.classList.remove("caption-show")}render(){let e="image"===this.model.type?o.dy`<affine-image .model=${this.model}></affine-image>`:o.Ld;return o.dy`
      ${e}
      <div class="affine-embed-block-container">
        <div class="affine-embed-wrapper">
          <input
            .disabled=${this.model.page.readonly}
            placeholder="Write a caption"
            class="affine-embed-wrapper-caption"
            value=${this._caption}
            @input=${this._onInputChange}
            @blur=${this._onInputBlur}
            @click=${e=>{e.stopPropagation()}}
          />
        </div>
      </div>
    `}};c.styles=o.iv`
    affine-embed {
      display: block;
    }
    .affine-embed-wrapper {
      text-align: center;
      margin-bottom: calc(var(--affine-paragraph-space) + 8px);
    }
    .affine-embed-wrapper-caption {
      width: 100%;
      font-size: var(--affine-font-sm);
      outline: none;
      border: 0;
      font-family: inherit;
      text-align: center;
      color: var(--affine-icon-color);
      display: none;
      background: var(--affine-background-primary-color);
    }
    .affine-embed-wrapper-caption::placeholder {
      color: var(--affine-placeholder-color);
    }

    .affine-embed-wrapper .caption-show {
      display: inline-block;
    }
  `,d([(0,r.IO)("input")],c.prototype,"_input",void 0),d([(0,r.SB)()],c.prototype,"_caption",void 0),c=d([(0,r.Mo)("affine-embed")],c);var h=i(11396);i(92725)},11826:function(e,t,i){"use strict";i.d(t,{F5:function(){return c},il:function(){return h.i},Kg:function(){return d}});var n=i(50634),o=i(15486),r=i(32916),a=i(280),s=i(88523),l=i(7291);class d extends s.b{async json2Block(e,t){await (0,l.C)(e.page,t,e,0)}block2Json(e,t,i){let n=e.text?.sliceToDelta(t||0,i)||[];return{flavour:e.flavour,type:e.type,text:n,xywh:e.xywh,background:e.background,children:e.children?.map((t,n)=>n===e.children.length-1?(0,a.getService)(t.flavour).block2Json(t,0,i):(0,a.getService)(t.flavour).block2Json(t))}}}let c=class extends n.z3{connectedCallback(){super.connectedCallback(),(0,a.registerService)("affine:frame",d)}firstUpdated(){this.model.propsUpdated.on(()=>this.requestUpdate()),this.model.childrenUpdated.on(()=>this.requestUpdate())}render(){return o.dy`
      <div class="affine-frame-block-container">
        <div class="affine-block-children-container">${this.content}</div>
      </div>
    `}};c.styles=o.iv`
    .affine-frame-block-container {
      display: flow-root;
    }
    .affine-frame-block-container.selected {
      background-color: var(--affine-hover-color);
    }
  `,c=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,r.Mo)("affine-frame")],c);var h=i(73454)},59799:function(e,t,i){"use strict";let n;i.r(t),i.d(t,{AbstractSelectionManager:function(){return tR.n},ActiveEditorManager:function(){return eR.e},AffineSelectedBlocks:function(){return tD.Nd},BlockHub:function(){return tD.li},BookmarkBlockComponent:function(){return tT.Yc},BookmarkBlockSchema:function(){return tT.mN},BookmarkBlockService:function(){return tT.lI},BrushSize:function(){return tR.h},COLOR_VARIABLES:function(){return t_.IQ},CodeBlockComponent:function(){return tO.PO},CodeBlockSchema:function(){return tO._Q},CodeBlockService:function(){return tO.E6},CounterBlock:function(){return p},DEFAULT_SHAPE_FILL_COLOR:function(){return c.nq},DEFAULT_SHAPE_STROKE_COLOR:function(){return c.Tq},DatabaseBlockComponent:function(){return ty},DatabaseBlockModel:function(){return tx.o},DatabaseBlockSchema:function(){return tx.E},DefaultPageBlockComponent:function(){return c.wp},DividerBlockComponent:function(){return b.y$},DividerBlockSchema:function(){return b.qw},DividerBlockService:function(){return b.fu},DragHandle:function(){return tD.DU},DragIndicator:function(){return tD.NG},DragPreview:function(){return tD.vI},DropFlags:function(){return t$.pw},EdgelessPageBlockComponent:function(){return c.PZ},EmbedBlockComponent:function(){return L.MZ},EmbedBlockSchema:function(){return L.RQ},EmbedBlockService:function(){return L.Xk},FONT_FAMILY_VARIABLES:function(){return t_.c1},FormatQuickBar:function(){return tI.K},FrameBlockComponent:function(){return v.F5},FrameBlockSchema:function(){return v.il},FrameBlockService:function(){return v.Kg},ImageBlockComponent:function(){return $.c},LangList:function(){return tO.b},ListBlockComponent:function(){return m.EH},ListBlockSchema:function(){return m.QT},ListBlockService:function(){return m.pu},MenuDivider:function(){return tD.R},PageBlockSchema:function(){return c.h6},PageBlockService:function(){return c.lO},ParagraphBlockComponent:function(){return g.n_},ParagraphBlockSchema:function(){return g.vQ},ParagraphBlockService:function(){return g.Vs},RemoteSelection:function(){return tD.o4},SIZE_VARIABLES:function(){return t_.u$},SelectionUtils:function(){return tP},SurfaceBlockSchema:function(){return P.f},ThemeObserver:function(){return tM},VARIABLES:function(){return t_.qn},activeEditorManager:function(){return eR.y},almostEqual:function(){return tB.dA},asyncFocusRichText:function(){return tE.a6},asyncGetBlockElementByModel:function(){return t$.jo},asyncGetRichTextByModel:function(){return t$.w_},asyncGetVirgoByModel:function(){return t$._E},asyncSetVRange:function(){return tE.kH},atLeastNMatches:function(){return tB.Ky},bindCommonHotkey:function(){return c.xM},bindHotkeys:function(){return c.Ps},blockRangeToNativeRange:function(){return tS.yd},capitalize:function(){return tB.kC},clamp:function(){return tB.uZ},contains:function(){return t$.r3},convertToDivider:function(){return tE.WP},convertToList:function(){return tE.Sf},convertToParagraph:function(){return tE.AE},countBy:function(){return tB.VF},createBookmarkBlock:function(){return tE.GK},createEvent:function(){return tB.yM},createImageInputElement:function(){return tL.i},debounce:function(){return tB.Ds},defaultBookmarkProps:function(){return tT.qR},deleteModelsByRange:function(){return c.tD},edgelessPreset:function(){return tN},experimentCreateBlockRange:function(){return tS.mD},extractCssVariables:function(){return tk},getAllowSelectedBlocks:function(){return c.rV},getBlockElementById:function(){return t$.cP},getBlockElementByModel:function(){return t$._b},getBlockElementsByElement:function(){return t$.rr},getBlockElementsExcludeSubtrees:function(){return t$.rc},getBlockElementsIncludeSubtrees:function(){return t$.Mb},getClosestBlockElementByElement:function(){return t$.I8},getClosestBlockElementByPoint:function(){return t$.cy},getClosestFrameBlockElementById:function(){return t$.lK},getCombinedFormat:function(){return c.Tb},getCurrentBlockRange:function(){return tS.zE},getCurrentCombinedFormat:function(){return c.vC},getDOMRectByLine:function(){return t$.vF},getDatabaseBlockColumnHeaderElement:function(){return t$.ve},getDatabaseBlockRowsElement:function(){return t$.kE},getDatabaseBlockTableElement:function(){return t$.zd},getDefaultPage:function(){return t$.U6},getDragDirection:function(){return c.I6},getDropRectByPoint:function(){return t$.XZ},getEdgelessPage:function(){return t$.UR},getEditorContainer:function(){return t$.VA},getEditorContainerByElement:function(){return t$.Ne},getElementFromEventTarget:function(){return t$.Mg},getExtendBlockRange:function(){return tS.Wc},getHoveringFrame:function(){return t$.ev},getModelByBlockElement:function(){return t$.gc},getModelByElement:function(){return t$.mt},getModelsByRange:function(){return t$.pS},getNextBlock:function(){return t$.st},getPageBlock:function(){return t$.De},getParentBlockById:function(){return t$.wl},getPreviousBlock:function(){return t$.nt},getRectByBlockElement:function(){return t$.az},getRichTextByModel:function(){return t$.Et},getSelectedStateRectByBlockElement:function(){return t$.fl},getServiceOrRegister:function(){return e7.getServiceOrRegister},getStartModelBySelection:function(){return t$.EM},getTextNodeByModel:function(){return tS.I},getVRangeByNode:function(){return tS.JO},getViewportElement:function(){return t$.dK},getVirgoByModel:function(){return t$.gj},groupBy:function(){return tB.vM},handleBlockEndEnter:function(){return tw.handleBlockEndEnter},handleBlockSelectionBatchDelete:function(){return c.X1},handleBlockSplit:function(){return tw.handleBlockSplit},handleDown:function(){return c.DZ},handleFormat:function(){return c.OA},handleIndent:function(){return tw.handleIndent},handleKeyDown:function(){return tw.handleKeyDown},handleKeyUp:function(){return tw.handleKeyUp},handleKeydownAfterSelectBlocks:function(){return c.hw},handleLineStartBackspace:function(){return tw.handleLineStartBackspace},handleMultiBlockBackspace:function(){return c.Wo},handleMultiBlockIndent:function(){return tw.handleMultiBlockIndent},handleSelectAll:function(){return c.ib},handleSoftEnter:function(){return tw.handleSoftEnter},handleUnindent:function(){return tw.handleUnindent},handleUp:function(){return c.vo},hasBlockId:function(){return t$.Dw},hasDatabase:function(){return t$.wA},isBlock:function(){return t$.Lq},isCaptionElement:function(){return t$.Fe},isCollapsedAtBlockStart:function(){return tE.uI},isContainedIn:function(){return t$.e1},isControlledKeyboardEvent:function(){return tB.Jc},isCssVariable:function(){return t_.xZ},isDatabaseInput:function(){return t$.Rn},isDefaultPage:function(){return t$.IV},isDragHandle:function(){return t$.hK},isEdgelessBlockChild:function(){return t$.YS},isEdgelessPage:function(){return t$.cu},isElement:function(){return t$.kK},isEmpty:function(){return tB.xb},isEmptyDatabase:function(){return t$.nc},isFuzzyMatch:function(){return tB.Qn},isImage:function(){return t$.Or},isInSamePath:function(){return tE.k},isInsideDatabaseTitle:function(){return t$.Yb},isInsideEdgelessTextEditor:function(){return t$.ok},isInsidePageTitle:function(){return t$.zv},isInsideRichText:function(){return t$.zg},isPageMode:function(){return t$.im},isPageOrFrameOrSurface:function(){return t$.hf},isPrintableKeyEvent:function(){return tB.Ty},isRawInput:function(){return t$.KO},isSelectedBlocks:function(){return t$.IE},isToggleIcon:function(){return t$.OZ},maxBy:function(){return tB.UT},nativeRangeToBlockRange:function(){return tS.cO},noop:function(){return tB.ZT},onModelElementUpdated:function(){return c.FA},onModelTextUpdated:function(){return c.HM},pagePreset:function(){return tj},queryCurrentMode:function(){return t$.FV},removeCommonHotKey:function(){return c.A4},removeHotkeys:function(){return c.ST},restoreSelection:function(){return tS.vq},showFormatQuickBarByClicks:function(){return c.Xf},showImportModal:function(){return tD.jM},supportsChildren:function(){return tB.$v},throttle:function(){return tB.P2},toHex:function(){return tB.NC},tooltipStyle:function(){return tD.ap},tryUpdateFrameSize:function(){return c.uQ},uncapitalize:function(){return tB.Le},updateBlockRange:function(){return tS.y3},updateBlockType:function(){return c.WV},uploadImageFromLocal:function(){return tL.m}});var o,r,a,s,l,d,c=i(52933),h=i(15486),u=i(32916),f=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let p=class extends h.oi{constructor(){super(),this.count=0}async _notify(){this.count++,await this.updateComplete;let e={detail:this.count,bubbles:!0,composed:!0};this.dispatchEvent(new CustomEvent("block-count-update",e))}render(){return h.dy` <div @click=${this._notify}>${this.count}</div> `}};f([(0,u.Cb)()],p.prototype,"count",void 0),p=f([(0,u.Mo)("counter-block")],p);var g=i(28392),m=i(37960),v=i(11826),b=i(83740);i(98094),i(55410);var C=i(50634),y=i(13246),x=i(29113),w=i(91827),_=i(29045),k=i(13592);let M=new class{constructor(e){this.maxSize=e,this.cache=new Map}get(e){let t=this.cache.get(e);return void 0===t?null:(this.cache.delete(e),this.cache.set(e,t),t)}set(e,t){if(this.cache.size>=this.maxSize){let e=this.cache.keys().next().value;this.cache.delete(e)}this.cache.set(e,t)}}(100);var S=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let E=class extends C.Zi{constructor(){super(...arguments),this.delta={insert:x.$m},this.highlightOptionsGetter=null}render(){(0,y.kP)(this.highlightOptionsGetter,"highlightOptionsGetter is not set");let{lang:e,highlighter:t}=this.highlightOptionsGetter();if(!t||!t.getLoadedLanguages().includes(e)){let e=new x.Jj;return e.str=this.delta.insert,e.styles=(0,w.V)({}),h.dy`<span>${e}</span>`}let i=(0,_.FV)(),n=`${this.delta.insert}-${e}-${i}`,o=M.get(n),r=[{content:this.delta.insert}];o?r=o:(r=t.codeToThemedTokens(this.delta.insert,e,"dark"===i?k.$J:k.f8)[0],M.set(n,r));let a=r.map(e=>{let t=new x.Jj;return t.str=e.content,t.styles=(0,w.V)({color:e.color}),t});return h.dy`<span>${a}</span>`}};S([(0,u.Cb)({type:Object})],E.prototype,"delta",void 0),S([(0,u.Cb)()],E.prototype,"highlightOptionsGetter",void 0),E=S([(0,u.Mo)("affine-code-line")],E),i(65938),i(36687);var L=i(27314),$=i(92725),P=i(20580),B=i(4937),R=i(92758),T=i(7339),O=i(43312),I=i(31054),D=i(66208),z=i(57891),A=i(68815),H=i(81366);function V(e,t,i="click",n=!1){let o=i=>{var o;let a=i.composedPath&&i.composedPath(),s=a?0>a.indexOf(e):!e.contains(i.target)&&!!(o=e)&&!!(o.offsetWidth||o.offsetHeight||o.getClientRects().length);s&&(t(e,i.target),n||r())};document.addEventListener(i,o);let r=()=>{document.removeEventListener(i,o)};return r}let Z=["var(--affine-tag-blue)","var(--affine-tag-green)","var(--affine-tag-teal)","var(--affine-tag-white)","var(--affine-tag-purple)","var(--affine-tag-red)","var(--affine-tag-pink)","var(--affine-tag-yellow)","var(--affine-tag-orange)","var(--affine-tag-gray)"],F=(n=[...Z],()=>{0===n.length&&(n=[...Z]);let e=Math.floor(Math.random()*n.length),t=n.splice(e,1)[0];return t});function U(e){return"divider"===e.type}var j=i(74061);(o=s||(s={})).Left="left",o.Right="right",(r=l||(l={})).SearchInput="input",r.SearchIcon="icon",r.Searching="searching",r.Action="action",(a=d||(d={})).Multi="multi",a.Single="single";let N=h.iv`
  .action {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 32px;
    padding: 4px 8px;
    border-radius: 5px;
    cursor: pointer;
  }
  .action:hover {
    background: var(--affine-hover-color);
  }
  .action-content {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .action-content > svg {
    width: 20px;
    height: 20px;
    color: var(--affine-icon-color);
    fill: var(--affine-icon-color);
  }
  .action-divider {
    height: 0.5px;
    background: var(--affine-divider-color);
    margin: 8px 0;
  }
`,W=h.iv`
  :host {
    background: var(--affine-background-primary-color);
    box-shadow: var(--affine-menu-shadow);
    padding: 8px;
    border: 1px solid var(--affine-border-color);
    border-radius: 8px;
    z-index: 1;
    font-family: var(--affine-font-family);
  }

  .affine-database-edit-column-popup {
    display: flex;
    flex-direction: column;
    color: var(--affine-text-primary-color);
  }
  .affine-database-edit-column-popup * {
    box-sizing: border-box;
  }
  .rename,
  .delete,
  .column-type {
    fill: var(--affine-icon-color);
  }
  .column-type > svg {
    transform: rotate(-90deg);
  }
  ${N}
`;var q=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let Y=[{type:"rich-text",text:"Text",icon:R.VL},{type:"select",text:"Select",icon:B.uh},{type:"multi-select",text:"Multi-select",icon:B.eD},{type:"number",text:"Number",icon:B.VI},{type:"checkbox",text:"Checkbox",icon:R.iH},{type:"progress",text:"Progress",icon:B.oX}],X=h.iv`
  :host {
    z-index: 1;
    width: 200px;
    padding: 8px;
    border: 1px solid var(--affine-border-color);
    border-radius: 8px;
    background: var(--affine-background-primary-color);
    box-shadow: var(--affine-menu-shadow);
    font-family: var(--affine-font-family);
  }
  ${N}
  .action > svg {
    width: 16px;
    height: 16px;
  }

  .rich-text {
    fill: var(--affine-icon-color);
  }
  .column-type {
    padding: 0;
    color: var(--affine-text-secondary-color);
    font-size: 14px;
    cursor: unset;
  }
  .column-type:hover {
    background: none;
  }
  .selected {
    color: var(--affine-text-emphasis-color);
    background: rgba(0, 0, 0, 0.02);
  }
  .selected svg {
    color: var(--affine-text-emphasis-color);
  }
  .selected.rich-text svg {
    fill: var(--affine-text-emphasis-color);
  }
  /* .action.disabled {
    cursor: not-allowed;
  }
  .action.disabled:hover {
    background: unset;
  } */
`,K=class extends h.oi{render(){return h.dy`
      <div class="affine-database-column-type-popup">
        <div class="action column-type">
          <div class="action-content"><span>Column type</span></div>
        </div>
        <div class="action-divider"></div>
        ${Y.map(e=>{let t=e.type===this.columnType,i=()=>{t||this.changeColumnType(this.columnId,e.type)};return h.dy`
            <div
              class="action ${e.type} ${t?"selected":""}"
              @click=${i}
            >
              <div class="action-content">
                ${e.icon}<span>${e.text}</span>
              </div>
              ${t?B._U:null}
            </div>
          `})}
      </div>
    `}};function G(e,t,i,n,o){if(J(i))return;let r=i.type;if(n.page.captureSync(),"select"===r&&"multi-select"===t)Q(e,{type:t},n);else if("multi-select"===r&&"select"===t)Q(e,{type:t},n),n.convertCellsByColumn(e,"select");else if("number"===r&&"rich-text"===t)Q(e,{type:t},n),n.convertCellsByColumn(e,"rich-text");else{let i=o.get(t);Q(e,{...i.propertyCreator(),type:t},n),n.deleteCellsByColumn(e)}}function Q(e,t,i){let n=i.getColumn(e);(0,y.kP)(n);let o={...n,...t};i.updateColumn(o)}function J(e){return"string"==typeof e}K.styles=X,q([(0,u.Cb)()],K.prototype,"columnType",void 0),q([(0,u.Cb)()],K.prototype,"columnId",void 0),q([(0,u.Cb)()],K.prototype,"changeColumnType",void 0),K=q([(0,u.Mo)("affine-database-column-type-popup")],K);var ee=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let et=[{type:"rename",text:"Rename",icon:T.Mw},{type:"divider"},{type:"column-type",text:"Column type",icon:R.VL},{type:"duplicate",text:"Duplicate column",icon:B.f_},{type:"insert-left",text:"Insert left column",icon:B.JM},{type:"insert-right",text:"Insert right column",icon:B.h7},{type:"move-left",text:"Move left",icon:B.xV},{type:"move-right",text:"Move Right",icon:B.VN},{type:"divider"},{type:"delete",text:"Delete column",icon:R.pJ}],ei=[{type:"rename",text:"Rename",icon:T.Mw},{type:"insert-right",text:"Insert right column",icon:B.h7}],en=class extends h.oi{constructor(){super(...arguments),this._onShowColumnType=e=>{this._columnTypePopup||(this._columnTypePopup=new K,this._columnTypePopup.changeColumnType=this._changeColumnType,this._columnTypePopup.columnId=e,J(this.targetColumn)||(this._columnTypePopup.columnType=this.targetColumn.type),this._container.appendChild(this._columnTypePopup),(0,D.fi)(this._container,this._columnTypePopup,{placement:"right-start",modifiers:[{name:"offset",options:{offset:[-9,12]}}]}))},this._onHideColumnType=()=>{this._columnTypePopup&&(this._columnTypePopup?.remove(),this._columnTypePopup=null)},this._changeColumnType=(e,t)=>{G(e,t,this.targetColumn,this.targetModel,this.columnRenderer),this.closePopup()},this._onActionClick=(e,t)=>{(function(e,t,i,n,o,r){if("rename"===e){o(t);return}if("insert-right"===e||"insert-left"===e){r("insert-right"===e?s.Right:s.Left);return}if("delete"===e){i.page.captureSync(),i.deleteColumn(t),i.deleteCellsByColumn(t),i.applyColumnUpdate();return}if("move-left"===e||"move-right"===e){i.page.captureSync(),i.moveColumn(n,"move-left"===e?n-1:n+1),i.applyColumnUpdate();return}if("duplicate"===e){i.page.captureSync();let e=i.getColumn(t);(0,y.kP)(e);let{id:o,...r}=e,a={...r},s=i.addColumn(a,n+1);i.applyColumnUpdate(),i.copyCellsByColumn(o,s)}})(e,t,this.targetModel,this.columnIndex,this.setTitleColumnEditId,this.insertColumn),this.closePopup()},this._renderActions=()=>{let e=J(this.targetColumn)?ei:et;return h.dy`
      ${e.map(e=>{if(U(e))return h.dy`<div class="action-divider"></div>`;if(0===this.columnIndex&&"move-left"===e.type||this.columnIndex===this.targetModel.columns.length-1&&"move-right"===e.type)return null;let t=J(this.targetColumn)?"-1":this.targetColumn.id,i=J(this.targetColumn)?void 0:"column-type"===e.type?()=>this._onShowColumnType(t):this._onHideColumnType;return h.dy`
          <div
            class="action ${e.type}"
            @mouseover=${i}
            @click=${()=>this._onActionClick(e.type,t)}
          >
            <div class="action-content">
              ${e.icon}<span>${e.text}</span>
            </div>
            ${"column-type"===e.type?R.ve:h.dy``}
          </div>
        `})}
    `}}render(){return h.dy`
      <div class="affine-database-edit-column-popup">
        ${this._renderActions()}
      </div>
    `}};en.styles=W,ee([(0,u.Cb)()],en.prototype,"targetModel",void 0),ee([(0,u.Cb)()],en.prototype,"columnRenderer",void 0),ee([(0,u.Cb)()],en.prototype,"targetColumn",void 0),ee([(0,u.Cb)()],en.prototype,"columnIndex",void 0),ee([(0,u.Cb)()],en.prototype,"closePopup",void 0),ee([(0,u.Cb)()],en.prototype,"setTitleColumnEditId",void 0),ee([(0,u.Cb)()],en.prototype,"insertColumn",void 0),ee([(0,u.IO)("input")],en.prototype,"titleInput",void 0),ee([(0,u.IO)(".affine-database-edit-column-popup")],en.prototype,"_container",void 0),en=ee([(0,u.Mo)("affine-database-edit-column-popup")],en);var eo=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let er=class extends h.oi{constructor(){super(...arguments),this.targetRect=null,this.scale=1}render(){if(!this.targetRect)return null;let e=this.targetRect,t=(0,w.V)({width:`${3*this.scale}px`,height:`${e.height}px`,transform:`translate(${e.left}px, ${e.top}px)`});return h.dy`
      <div class="affine-database-column-drag-indicator" style=${t}></div>
    `}};er.styles=h.iv`
    .affine-database-column-drag-indicator {
      position: fixed;
      z-index: 10;
      top: 0;
      left: 0;
      background: var(--affine-primary-color);
      transition-property: width, transform;
      transition-duration: 100ms;
      transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
      transition-delay: 0s;
      pointer-events: none;
    }
  `,eo([(0,u.Cb)()],er.prototype,"targetRect",void 0),eo([(0,u.Cb)()],er.prototype,"scale",void 0),er=eo([(0,u.Mo)("affine-database-column-drag-indicator")],er);let ea=class extends C.Zi{render(){return h.dy`
      <style>
        affine-database-column-drag-preview {
          display: flex;
          flex-direction: column;
          position: fixed;
          top: 0;
          left: 0;
          height: 220px;
          width: fit-content;
          border: 1px solid var(--affine-border-color);
          border-radius: 4px;
          overflow: hidden;
          cursor: none;
          user-select: none;
          pointer-events: none;
          caret-color: transparent;
          z-index: 100;
        }

        .preview-column-header {
          opacity: 0.8;
          border-bottom: 1px solid var(--affine-border-color);
          background: var(--affine-tertiary-color);
        }
        .preview-column-header .affine-database-column-move svg {
          cursor: grabbing;
          opacity: 1;
        }
        .preview-column-header .affine-database-column-move circle {
          fill: var(--affine-text-emphasis-color);
        }

        .preview-column-content {
          flex: 1;
          opacity: 0.8;
          background: var(--affine-white);
        }
      </style>
    `}};ea=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,u.Mo)("affine-database-column-drag-preview")],ea);let es=h.iv`
  .affine-database-column-header {
    position: relative;
    display: flex;
    flex-direction: row;
    height: 40px;
    border-bottom: 1px solid var(--affine-border-color);
  }
  .affine-database-column-header > .affine-database-column:first-child {
    background: var(--affine-hover-color);
  }

  .affine-database-column {
    position: relative;
    z-index: 1;
    cursor: pointer;
    background: var(--affine-white);
    transform: translateX(0);
  }
  .database-cell {
    min-width: ${j.vq}px;
  }
  .database-cell.add-column-button {
    flex: 1;
    min-width: ${j.jg}px;
    min-height: 100%;
    display: flex;
    align-items: center;
  }
  .affine-database-column-content {
    display: flex;
    align-items: center;
    gap: 6px;
    width: 100%;
    height: 100%;
    padding: 8px;
    border-right: 1px solid var(--affine-border-color);
  }
  .affine-database-column:last-child .affine-database-column-content {
    border-right: none;
  }
  .affine-database-column-drag-handle {
    position: absolute;
    z-index: 1;
    top: 0;
    left: -8px;
    width: 16px;
    height: 100%;
    cursor: col-resize;
  }
  .affine-database-column-drag-handle::before {
    content: ' ';
    display: none;
    position: absolute;
    width: 2px;
    height: 100%;
    left: 7px;
    background: var(--affine-text-emphasis-color);
    box-shadow: 0px 0px 8px rgba(84, 56, 255, 0.35);
  }
  .affine-database-column-drag-handle:hover::before,
  .affine-database-column-drag-handle.dragging::before {
    display: block;
  }
  .affine-database-column-content:hover,
  .affine-database-column-content.edit {
    background: linear-gradient(
        0deg,
        var(--affine-hover-color),
        var(--affine-hover-color)
      ),
      var(--affine-white);
  }
  .affine-database-column-content.edit .affine-database-column-text-icon {
    opacity: 1;
  }
  .affine-database-column-text {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 4px;
    /* https://stackoverflow.com/a/36247448/15443637 */
    overflow: hidden;
    color: var(--affine-text-secondary-color);
    font-size: 14px;
    font-weight: 600;
  }
  .affine-database-column-type-icon {
    display: flex;
    align-items: center;
    border: 1px solid transparent;
    border-radius: 4px;
  }
  .affine-database-column-type-icon.edit {
    background: linear-gradient(
        0deg,
        var(--affine-hover-color),
        var(--affine-hover-color)
      ),
      var(--affine-white);
    border-color: var(--affine-border-color);
  }
  .affine-database-column-type-icon.edit:hover {
    background: var(--affine-white);
  }
  .affine-database-column-type-icon svg {
    width: 16px;
    height: 16px;
    fill: var(--affine-icon-color);
  }
  .affine-database-column-text-content {
    flex: 1;
    display: flex;
    align-items: center;
    overflow: hidden;
  }
  .affine-database-column-content:hover .affine-database-column-text-icon {
    opacity: 1;
  }
  .affine-database-column-text-input {
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .affine-database-column-text-icon {
    display: flex;
    align-items: center;
    width: 16px;
    height: 16px;
    background: var(--affine-white);
    border: 1px solid var(--affine-border-color);
    border-radius: 4px;
    opacity: 0;
  }
  .affine-database-column-text-save-icon {
    display: flex;
    align-items: center;
    width: 16px;
    height: 16px;
    border: 1px solid transparent;
    border-radius: 4px;
    fill: var(--affine-icon-color);
  }
  .affine-database-column-text-save-icon:hover {
    background: var(--affine-white);
    border-color: var(--affine-border-color);
  }
  .affine-database-column-text-icon svg {
    fill: var(--affine-icon-color);
  }
  .affine-database-column-input {
    width: 100%;
    height: 24px;
    padding: 0;
    border: none;
    color: inherit;
    font-weight: 600;
    font-size: 14px;
    font-family: var(--affine-font-family);
    background: transparent;
  }
  .affine-database-column-input:focus {
    outline: none;
  }
  .affine-database-column-move {
    display: flex;
    align-items: center;
  }
  .affine-database-column-move svg {
    width: 10px;
    height: 14px;
    color: var(--affine-black-10);
    cursor: grab;
    opacity: 0;
  }
  .affine-database-column-content:hover svg {
    opacity: 1;
  }

  .affine-database-add-column-button {
    visibility: hidden;
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 38px;
    cursor: pointer;
  }
  .header-add-column-button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 100%;
    cursor: pointer;
  }

  .affine-database-column-move-preview {
    position: fixed;
    z-index: 100;
    width: 100px;
    height: 100px;
    background: var(--affine-text-emphasis-color);
  }
`;var el=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ed={select:B.uh,number:B.VI,checkbox:R.iH,progress:B.oX,"rich-text":R.VL,"multi-select":B.eD},ec=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this._editingColumnId="",this._changingColumnTypeId="",this._widthChangingIndex=-1,this._columnWidthDisposables=new O.S,this._columnMoveDisposables=new O.S,this._isHeaderHover=!1,this._indicator=null,this._editingColumnPopupIndex=-1,this.setEditingColumnId=e=>{this._editingColumnId=e},this.showAddColumnButton=e=>{let t=this.closest("affine-database");(0,I.kP)(t);let{right:i}=t.getBoundingClientRect(),{left:n}=this._headerAddColumnButton.getBoundingClientRect(),o=!0;e&&(o=e.offsetY<=j.O0&&e.offsetY>=0),i<=n&&this._isHeaderHover&&o?this._addColumnButton.style.visibility="visible":this._addColumnButton.style.visibility="hidden"},this._setChangingColumnIndex=e=>{this._widthChangingIndex!==e&&(this._widthChangingIndex=e)},this._onShowEditColumnPopup=(e,t,i)=>{if(this._editingColumnId||this.readonly)return;if(this._editingColumnPopupIndex===i){this._editingColumnPopupIndex=-1;return}this._editingColumnPopupIndex=i;let n=e.closest(".affine-database-column");(0,I.kP)(n);let o=new en;o.setTitleColumnEditId=this.setEditingColumnId,o.targetModel=this.targetModel,o.targetColumn=t,o.columnIndex=i-1,o.columnRenderer=this.columnRenderer,o.closePopup=()=>{this._editingColumnPopupIndex=-1,o.remove()},o.insertColumn=e=>{let t=e===s.Right?i:i-1;this.addColumn(t)},document.body.appendChild(o),(0,D.fi)(n,o,{placement:"bottom-start"}),V(o,(e,t)=>{t.closest(".affine-database-column-content")||(this._editingColumnPopupIndex=-1),e.remove()},"mousedown")},this._onShowColumnTypePopup=(e,t,i)=>{if(""===this._editingColumnId||this.readonly)return;if(this._changingColumnTypeId===t){this._changingColumnTypeId="";return}e.stopPropagation(),this._changingColumnTypeId=t;let n=new K;n.columnId=t,n.columnType=i.type,n.changeColumnType=(e,t)=>{G(e,t,i,this.targetModel,this.columnRenderer),this._changingColumnTypeId="",n.remove()},document.body.appendChild(n);let o=e.target,r=o.closest(".affine-database-column-content");(0,I.kP)(r),(0,D.fi)(r,n,{placement:"bottom-start"}),V(n,(e,t)=>{t.closest(".affine-database-column-type-icon")||(this._changingColumnTypeId=""),e.remove()},"mousedown")},this._onKeydown=(e,t,i)=>{if("Enter"===e.key){this.targetModel.page.captureSync(),this._saveColumnTitle(t,i);return}if("Escape"===e.key){this.setEditingColumnId("");return}},this._saveColumnTitle=(e,t)=>{if(""===this._editingColumnId)return;let i=this._titleColumnInput.value;"title"===e?this._onUpdateTitleColumn(i):((0,I.kP)(t),this._onUpdateNormalColumn(i,t)),this._editingColumnId===t?.id&&this.setEditingColumnId("")},this._onUpdateTitleColumn=e=>{this.targetModel.page.captureSync(),this.targetModel.page.updateBlock(this.targetModel,{titleColumnName:e}),this.setEditingColumnId("")},this._onUpdateNormalColumn=(e,t)=>{this.targetModel.page.captureSync(),this.targetModel.updateColumn({...t,name:e}),this.targetModel.applyColumnUpdate(),this.setEditingColumnId("")},this._onEditColumnTitle=(e,t)=>{e.stopPropagation(),this.setEditingColumnId(t)},this._onAddColumn=()=>{this.readonly||this.addColumn(this.targetModel.columns.length)}}get tableContainer(){return this.parentElement}get readonly(){return this.targetModel.page.readonly}firstUpdated(){if(this.readonly)return;this._initChangeColumnWidthHandlers(),this._initSetDragHandleHeightEffect(),this._initHeaderMousemoveHandlers(),this._initMoveColumnHandlers();let e=this.closest("affine-database");e&&this._initResizeEffect(e)}updated(e){if(super.updated(e),!this.readonly){if(e.has("_editingColumnId")&&this._editingColumnId){this._titleColumnInput.focus();let e=this._titleColumnInput.value.length;this._titleColumnInput.setSelectionRange(0,e)}e.has("columns")&&(this._initMoveColumnHandlers(),this._initChangeColumnWidthHandlers()),(0===e.size||e.has("columns"))&&this._setDragHandleHeight()}}disconnectedCallback(){super.disconnectedCallback(),this._columnWidthDisposables.dispose(),this._indicator&&(this._indicator.targetRect=null)}_initResizeEffect(e){let t=(0,H.U6)(this.targetModel.page),i=t?.viewportElement;if(i){let t=new ResizeObserver(t=>{for(let{target:n}of t)if(n===i){let{right:t}=e.getBoundingClientRect();this._addColumnButton.style.left=`${t}px`;break}});t.observe(i)}}_initSetDragHandleHeightEffect(){let e=new MutationObserver(()=>{this._setDragHandleHeight()}),t=this.closest(".affine-database-table-container");(0,I.kP)(t),e.observe(t,{childList:!0,subtree:!0}),this._disposables.add(()=>e.disconnect())}_setDragHandleHeight(){let e=this.closest("affine-database");if(!e)return;let t=e.querySelector(".affine-database-block-rows");(0,I.kP)(t);let i=t.clientHeight+j.O0-1,n=e.querySelectorAll(".affine-database-column-drag-handle");n.forEach(e=>{e.style.height=`${i}px`})}_initHeaderMousemoveHandlers(){this._disposables.addFromEvent(this._headerContainer,"mouseover",e=>{this._isHeaderHover=!0,this.showAddColumnButton(e)}),this._disposables.addFromEvent(this._headerContainer,"mouseleave",e=>{this._isHeaderHover=!1,this.showAddColumnButton(e)})}_initChangeColumnWidthHandlers(){let e=-1!==this._widthChangingIndex;if(e)return;this._columnWidthDisposables.dispose();let t=function(e,t,i,n){let o=null,r=(i,r)=>{i.stopPropagation();let a=Array.from(t.querySelectorAll(`.database-cell:nth-child(${r+1})`)),s=e.querySelector(`.database-cell:nth-child(${r+1})`);(0,I.kP)(s);let l=t.parentElement;(0,I.kP)(l),o={index:r,rowCells:a,scrollLeft:l.scrollLeft,lastClientX:i.clientX,startClientX:i.clientX,rawWidth:a[0].clientWidth,currentCell:s,rafId:void 0},n(r)},a=e=>{if(e.stopPropagation(),!o)return;let{rafId:i,rowCells:n,rawWidth:r,lastClientX:a,startClientX:s,scrollLeft:l}=o;if(e.clientX-a==0)return;let d=e.clientX-a>0?"right":"left";o.lastClientX=e.clientX;let c=()=>{let i=r+e.clientX-s<=j.vq?j.vq:r+e.clientX-s;n.forEach(e=>{e.style.width=`${i}px`;let t=e.querySelector(".affine-database-column-text-input");t&&(t.style.width=`${i-54}px`)});let o=t.parentElement;(0,I.kP)(o);let{right:a,left:c}=o.getBoundingClientRect(),h=e.clientX-a+j.jg;if(h>=0){if("right"===d)o.scrollLeft=Math.max(o.scrollLeft,l+h);else{let e=o.scrollLeft;h<=j.jg&&(e+=h),o.scrollLeft=Math.min(e,l+h)}return}let u=e.clientX-c-j.jg;u<=0&&o.scrollLeft>0&&(o.scrollLeft=l+u)};i&&cancelAnimationFrame(i),o.rafId=requestAnimationFrame(c)},s=e=>{if(e.stopPropagation(),n(-1),!o)return;let{rafId:t,index:r,rowCells:a}=o;t&&cancelAnimationFrame(t),o=null;let s=a[0].offsetWidth;if(i.page.captureSync(),0===r)i.page.updateBlock(i,{titleColumnWidth:s});else{let e=i.columns[r-1].id,t=i.getColumn(e);i.updateColumn({...t,width:s}),i.applyColumnUpdate()}},l=new O.S,d=e.querySelectorAll(".affine-database-column-drag-handle");return d.forEach((e,t)=>{l.addFromEvent(e,"pointerdown",e=>r(e,t))}),l.addFromEvent(document,"pointermove",a),l.addFromEvent(document,"pointerup",s),l}(this._headerContainer,this.tableContainer,this.targetModel,this._setChangingColumnIndex);this._columnWidthDisposables=t}_initMoveColumnHandlers(){this._columnMoveDisposables.dispose();let e=function(e,t,i){let n=null,o=null,r=document.querySelector("affine-database-column-drag-indicator");r||(r=new er,document.body.appendChild(r));let a=-1,s=i=>{i.stopPropagation(),(0,I.kP)(i.dataTransfer),i.dataTransfer.effectAllowed="move";let r=Array.from(e.querySelectorAll(".affine-database-column")).filter(e=>!e.classList.contains("add-column-button")),a=i.target,s=a.closest(".affine-database-column");(0,I.kP)(s);let l=r.indexOf(s)-1,d=t.closest("affine-database");(0,I.kP)(d);let{x:c,y:h}=s.getBoundingClientRect(),u=t.closest(".affine-database-block-table");(0,I.kP)(u);let{left:f,right:p}=u.getBoundingClientRect();o={dragIndex:l,tableBody:u,headerColumns:r,targetIndex:-1,indicatorHeight:t.clientHeight,previewBoundaries:{left:f,right:p},offset:{x:i.clientX-c,y:i.clientY-h}},n=function(e){let t=new ea;t.style.opacity="0";let i=document.createDocumentFragment(),n=e.target,o=n.closest(".affine-database-column");(0,I.kP)(o);let r=o.cloneNode(!0);r.classList.add("preview-column-header"),i.appendChild(r);let a=document.createElement("div");return a.classList.add("preview-column-content"),i.appendChild(a),t.appendChild(i),e.dataTransfer?.setDragImage(t,0,0),t}(i),t.appendChild(n)},l=e=>{if(!o)return;(0,I.kP)(n),"1"!==n.style.opacity&&(n.style.opacity="1");let t=e.clientX,i=e.clientY,{dragIndex:s,tableBody:l,previewBoundaries:d,indicatorHeight:c,headerColumns:h,offset:{x:u,y:f}}=o;n.style.transform=`translate(${t-u}px, ${i-f}px)`;let p=new H.E9(t,i),{element:g,index:m}=function(e,t){let i=null,n=-1,o=t.length;for(let r=0;r<o;r++){let o=t[r],a=o.getBoundingClientRect();if(e.x>=a.left&&e.x<=a.right){i=o,n=r;break}}if(!i){let r=t[0].getBoundingClientRect();e.x<=r.left?(i=t[0],n=0):(i=t[o-1],n=o-1)}return{element:i,index:n}}(p,h),v=g.getBoundingClientRect(),b=v.right<d.left||v.right>d.right,C=s===m||s===m-1||b?null:new DOMRect(v.right,v.top,1,c);(0,I.kP)(r),r.targetRect=C,o.targetIndex=m-1;let y=t<=d.left+50,x=t>=d.right-50,w=y||x,_=()=>{if(w)a=requestAnimationFrame(_);else{cancelAnimationFrame(a);return}x&&(l.scrollLeft+=10),y&&(l.scrollLeft-=10)};cancelAnimationFrame(a),a=requestAnimationFrame(_)},d=e=>{if(!o)return;let{dragIndex:t,targetIndex:a}=o;o=null,r&&(r.targetRect=null),n&&(n.remove(),n=null);let s=a+1;t!==s-1&&t!==s&&(i.page.captureSync(),i.moveColumn(t,s),i.applyColumnUpdate())},c=new O.S,h=e=>e.stopPropagation(),u=e.querySelectorAll(".affine-database-column-move");return u.forEach(e=>{c.addFromEvent(e,"pointerdown",h),c.addFromEvent(e,"pointermove",h),c.addFromEvent(e,"pointerup",h),c.addFromEvent(e,"click",h),c.addFromEvent(e,"dragstart",s),c.addFromEvent(e,"drag",l),c.addFromEvent(e,"dragend",d)}),c}(this._headerContainer,this.tableContainer,this.targetModel);this._columnMoveDisposables=e}render(){let e=(0,w.V)({width:`${this.targetModel.titleColumnWidth}px`}),t="-1"===this._editingColumnId&&!this.readonly;return A.dy`
      <div class="affine-database-column-header database-row">
        <div class="affine-database-column database-cell" style=${e}>
          <div
            class="affine-database-column-content ${"-1"===this._editingColumnId?"edit":""}"
            data-column-id="-1"
            @click=${e=>this._onShowEditColumnPopup(e.target,this.targetModel.titleColumnName,0)}
          >
            <div class="affine-database-column-text">
              <div class="affine-database-column-type-icon">${R.VL}</div>
              ${t?A.dy`<div class="affine-database-column-text-content">
                    <input
                      class="affine-database-column-input"
                      value=${this.targetModel.titleColumnName}
                      @keydown=${e=>this._onKeydown(e,"title")}
                      @pointerdown=${e=>e.stopPropagation()}
                    />
                    <div
                      class="affine-database-column-text-save-icon"
                      @click=${e=>{e.stopPropagation(),this._saveColumnTitle("title")}}
                    >
                      ${B._U}
                    </div>
                  </div>`:A.dy`<div class="affine-database-column-text-content">
                    <div class="affine-database-column-text-input">
                      ${this.targetModel.titleColumnName}
                    </div>
                    ${this.readonly?null:A.dy`<div
                          class="affine-database-column-text-icon"
                          @click=${e=>this._onEditColumnTitle(e,"-1")}
                        >
                          ${T.Mw}
                        </div>`}
                  </div>`}
            </div>
          </div>
        </div>
        ${(0,z.r)(this.columns,e=>e.id,(e,t)=>{let i=(0,w.V)({width:`${e.width}px`}),n=this._editingColumnId===e.id&&!this.readonly,o=this._changingColumnTypeId===e.id;return A.dy`
              <div class="affine-database-column database-cell" style=${i}>
                <div
                  class="affine-database-column-content ${n?"edit":""}"
                  data-column-id="${e.id}"
                  @click=${i=>this._onShowEditColumnPopup(i.target,e,t+1)}
                >
                  <div class="affine-database-column-text ${e.type}">
                    <div
                      class="affine-database-column-type-icon ${n?"edit":""} ${o?"active":""}"
                      @click=${t=>this._onShowColumnTypePopup(t,e.id,e)}
                    >
                      ${ed[e.type]}
                    </div>
                    ${n?A.dy`<div class="affine-database-column-text-content">
                          <input
                            class="affine-database-column-input"
                            value=${e.name}
                            @keydown=${t=>this._onKeydown(t,"normal",e)}
                            @pointerdown=${e=>e.stopPropagation()}
                          />
                          <div
                            class="affine-database-column-text-save-icon"
                            @click=${t=>{t.stopPropagation(),this._saveColumnTitle("normal",e)}}
                          >
                            ${B._U}
                          </div>
                        </div>`:A.dy`<div class="affine-database-column-text-content">
                          <div class="affine-database-column-text-input">
                            ${e.name}
                          </div>
                          ${this.readonly?null:A.dy`<div
                                class="affine-database-column-text-icon"
                                @click=${t=>this._onEditColumnTitle(t,e.id)}
                              >
                                ${T.Mw}
                              </div>`}
                        </div>`}
                  </div>
                  ${this.readonly?null:A.dy`<div
                        draggable="true"
                        class="affine-database-column-move"
                      >
                        ${B.e2}
                      </div>`}
                </div>
                ${this.readonly?null:A.dy`<div
                      class="affine-database-column-drag-handle ${this._widthChangingIndex===t?"dragging":""}"
                    ></div>`}
              </div>
            `})}
        <div class="affine-database-column database-cell add-column-button">
          ${this.readonly?null:A.dy`<div
                  class="affine-database-column-drag-handle  ${this._widthChangingIndex===this.columns.length?"dragging":""}"
                ></div>
                <div
                  class="header-add-column-button"
                  @click=${this._onAddColumn}
                >
                  ${B.ml}
                </div>`}
        </div>
        ${this.readonly?null:A.dy`<div
              class="affine-database-add-column-button"
              data-test-id="affine-database-add-column-button"
              @click=${this._onAddColumn}
            >
              ${B.ml}
            </div>`}
      </div>
    `}};ec.styles=es,el([(0,u.Cb)()],ec.prototype,"targetModel",void 0),el([(0,u.Cb)()],ec.prototype,"columns",void 0),el([(0,u.Cb)()],ec.prototype,"addColumn",void 0),el([(0,u.Cb)()],ec.prototype,"columnRenderer",void 0),el([(0,u.SB)()],ec.prototype,"_editingColumnId",void 0),el([(0,u.SB)()],ec.prototype,"_changingColumnTypeId",void 0),el([(0,u.IO)(".affine-database-column-input")],ec.prototype,"_titleColumnInput",void 0),el([(0,u.IO)(".affine-database-column-header")],ec.prototype,"_headerContainer",void 0),el([(0,u.IO)(".affine-database-add-column-button")],ec.prototype,"_addColumnButton",void 0),el([(0,u.IO)(".header-add-column-button")],ec.prototype,"_headerAddColumnButton",void 0),el([(0,u.SB)()],ec.prototype,"_widthChangingIndex",void 0),ec=el([(0,u.Mo)("affine-database-column-header")],ec);var eh=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class eu extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this.cell=null}}function ef(e,t,i,n,o){return{displayName:o.displayName,type:e,propertyCreator:t,components:n,defaultValue:i}}eh([(0,u.Cb)()],eu.prototype,"rowHost",void 0),eh([(0,u.Cb)()],eu.prototype,"databaseModel",void 0),eh([(0,u.Cb)()],eu.prototype,"rowModel",void 0),eh([(0,u.Cb)()],eu.prototype,"column",void 0),eh([(0,u.Cb)()],eu.prototype,"cell",void 0);class ep{constructor(){this._columns=new Map}register(e){let t=this._columns;if(t.has(e.type))throw Error("cannot register twice for "+e.type);t.set(e.type,e)}get(e){let t=this._columns.get(e);if(!t)throw Error("cannot find renderer");return t}list(){return[...this._columns.values()]}}var eg=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let em=class extends eu{constructor(){super(...arguments),this._isEditing=!1,this._onClick=e=>{this.readonly||(this._isEditing=!0,this.removeEventListener("click",this._onClick),setTimeout(()=>{V(this,()=>{this.addEventListener("click",this._onClick),this._isEditing=!1},"mousedown")}))},this.setEditing=e=>{this._isEditing=e,this._isEditing||setTimeout(()=>{this.addEventListener("click",this._onClick)})},this.setHeight=e=>{this.style.height=`${e+16}px`}}get readonly(){return this.databaseModel.page.readonly}connectedCallback(){super.connectedCallback();let e=this._disposables;e.addFromEvent(this,"click",this._onClick)}firstUpdated(){this.setAttribute("data-block-is-database-input","true"),this.setAttribute("data-row-id",this.rowModel.id),this.setAttribute("data-column-id",this.column.id)}setValue(e,t={captureSync:!0}){queueMicrotask(()=>{t.captureSync&&this.databaseModel.page.captureSync(),this.databaseModel.updateCell(this.rowModel.id,{columnId:this.column.id,value:e}),this.databaseModel.applyColumnUpdate(),this.requestUpdate()})}updateColumnProperty(e){let t=e(this.column);this.databaseModel.page.captureSync(),this.databaseModel.updateColumn({...this.column,...t})}render(){let e=this.columnRenderer.get(this.column.type),t=this.databaseModel.getCell(this.rowModel.id,this.column.id);if(!this.readonly&&this._isEditing&&null!==e.components.CellEditing){let i=e.components.CellEditing.tag;return A.dy`
        <${i}
          data-is-editing-cell="true"
          .rowHost=${this}
          .databaseModel=${this.databaseModel}
          .rowModel=${this.rowModel}
          .column=${this.column}
          .cell=${t}
        ></${i}>
      `}let i=e.components.Cell.tag;return A.dy`
      <${i}
        .rowHost=${this}
        .databaseModel=${this.databaseModel}
        .rowModel=${this.rowModel}
        .column=${this.column}
        .cell=${t}
      ></${i}>
    `}};em.styles=h.iv`
    affine-database-cell-container {
      display: flex;
      align-items: center;
      width: 100%;
      height: 100%;
      padding: 0 ${8}px;
      border-right: 1px solid var(--affine-border-color);
    }

    affine-database-cell-container * {
      box-sizing: border-box;
    }
  `,eg([(0,u.SB)()],em.prototype,"_isEditing",void 0),eg([(0,u.Cb)()],em.prototype,"columnRenderer",void 0),em=eg([(0,u.Mo)("affine-database-cell-container")],em);var ev=i(62554),eb=i(37666),eC=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ey=[{type:"database-type",text:"Database type",icon:R.Th},{type:"copy",text:"Copy",icon:R.TI},{type:"divider"},{type:"delete-database",text:"Delete database",icon:R.pJ}],ex=[{type:"table",text:"Table view",icon:R.Th},{type:"kanban",text:"Kanban view",icon:R.D3}],ew=class extends h.oi{render(){return h.dy`
      <div class="affine-database-type-popup">
        <div class="action database-type">
          <div class="action-content"><span>Database type</span></div>
        </div>
        <div class="action-divider"></div>
        ${ex.map(e=>{let t="kanban"===e.type,i=e.type===this.dbType&&!t;return h.dy`
            <div
              class="action ${e.type} ${i?"selected":""} ${t?"disabled":""}"
            >
              <div class="action-content">
                ${e.icon}<span>${e.text}</span>
              </div>
            </div>
          `})}
      </div>
    `}};ew.styles=h.iv`
    :host {
      width: 200px;
      padding: 8px;
      border: 1px solid var(--affine-border-color);
      border-radius: 8px;
      background: var(--affine-background-primary-color);
      box-shadow: 0px 0px 12px rgba(66, 65, 73, 0.14),
        inset 0px 0px 0px 0.5px var(--affine-border-color);
    }
    :host * {
      box-sizing: border-box;
    }
    ${N}
    .action > svg {
      width: 16px;
      height: 16px;
      fill: var(--affine-icon-color);
    }
    .database-type {
      height: 30px;
      padding: 0;
      color: var(--affine-text-secondary-color);
      font-size: 14px;
      cursor: unset;
    }
    .database-type:hover {
      background: none;
    }
    .selected {
      color: var(--affine-text-emphasis-color);
      background: rgba(0, 0, 0, 0.02);
    }
    .selected svg {
      color: var(--affine-text-emphasis-color);
    }
    .selected.table-view svg {
      fill: var(--affine-text-emphasis-color);
    }
    .action.disabled {
      cursor: not-allowed;
    }
    .action.disabled:hover {
      background: unset;
    }
  `,eC([(0,u.Cb)()],ew.prototype,"dbType",void 0),ew=eC([(0,u.Mo)("affine-database-type-popup")],ew);let e_=class extends h.oi{constructor(){super(...arguments),this._onActionClick=(e,t)=>{if(e.stopPropagation(),"delete-database"===t){let e=[this.targetModel,...this.targetModel.children];e.forEach(e=>this.targetModel.page.deleteBlock(e))}else"copy"===t&&((0,ev.p3)({type:"Block",models:[this.targetModel],startOffset:0,endOffset:0}),(0,eb.A)("Copied Database to clipboard"));this.close()},this._onShowDatabaseType=()=>{this._databaseTypePopup||(this._databaseTypePopup=new ew,this._databaseTypePopup.dbType="table",this._container.appendChild(this._databaseTypePopup),(0,D.fi)(this._container,this._databaseTypePopup,{placement:"right-start",modifiers:[{name:"offset",options:{offset:[-9,12]}}]}))},this._onHideDatabaseType=()=>{this._databaseTypePopup&&(this._databaseTypePopup?.remove(),this._databaseTypePopup=null)},this._renderActions=()=>h.dy`
      ${ey.map(e=>{if(U(e))return h.dy`<div class="action-divider"></div>`;let t="database-type"===e.type?this._onShowDatabaseType:this._onHideDatabaseType;return h.dy`
          <div
            class="action ${e.type}"
            @mouseover=${t}
            @click=${t=>this._onActionClick(t,e.type)}
          >
            <div class="action-content">
              ${e.icon}<span>${e.text}</span>
            </div>
            ${"database-type"===e.type?R.ve:h.dy``}
          </div>
        `})}
    `}render(){return h.dy`<div class="affine-database-toolbar-action-popup">
      ${this._renderActions()}
    </div>`}};e_.styles=h.iv`
    :host {
      width: 200px;
      height: 128px;
      padding: 8px;
      border: 1px solid var(--affine-border-color);
      border-radius: 8px;
      box-shadow: 0px 0px 12px rgba(66, 65, 73, 0.14),
        inset 0px 0px 0px 0.5px var(--affine-border-color);
      z-index: var(--affine-z-index-popover);
      background: var(--affine-white);
    }
    :host * {
      box-sizing: border-box;
    }
    ${N}
    .action-content > svg {
      width: 20px;
      height: 20px;
      fill: var(--affine-icon-color);
    }
    .action > svg {
      width: 16px;
      height: 16px;
      fill: var(--affine-icon-color);
    }
    .database-type > svg {
      transform: rotate(-90deg);
    }
  `,eC([(0,u.Cb)()],e_.prototype,"close",void 0),eC([(0,u.IO)(".affine-database-toolbar-action-popup")],e_.prototype,"_container",void 0),e_=eC([(0,u.Mo)("affine-database-toolbar-action-popup")],e_);var ek=i(91636),eM=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eS=class extends C.Zi{constructor(){super(...arguments),this.offset={x:0,y:0}}render(){return h.dy`
      <style>
        affine-database-new-record-preview {
          display: flex;
          align-items: center;
          justify-content: center;
          position: fixed;
          top: 0;
          left: 0;
          height: 32px;
          width: 32px;
          border: 1px solid var(--affine-border-color);
          border-radius: 50%;
          background: linear-gradient(
              0deg,
              rgba(96, 70, 254, 0.3),
              rgba(96, 70, 254, 0.3)
            ),
            linear-gradient(
              0deg,
              var(--affine-hover-color),
              var(--affine-hover-color)
            ),
            var(--affine-white);
          box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.05),
            0px 0px 0px 0.5px var(--affine-black-10);
          cursor: none;
          user-select: none;
          pointer-events: none;
          caret-color: transparent;
          z-index: 100;
        }
        affine-database-new-record-preview svg {
          width: 16px;
          height: 16px;
        }
        affine-database-new-record-preview path {
          fill: var(--affine-brand-color);
        }
      </style>
      ${T.pO}
    `}};eM([(0,u.Cb)()],eS.prototype,"offset",void 0),eS=eM([(0,u.Mo)("affine-database-new-record-preview")],eS);var eE=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eL=h.iv`
  .affine-database-toolbar {
    display: none;
    align-items: center;
    gap: 26px;
  }
  .affine-database-toolbar-search svg,
  .affine-database-toolbar svg {
    width: 16px;
    height: 16px;
    fill: var(--affine-icon-color);
  }
  .affine-database-toolbar-item {
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }
  .search-container.hidden {
    overflow: hidden;
  }
  .affine-database-toolbar-item.more-action {
    width: 32px;
    height: 32px;
    border-radius: 4px;
  }
  .affine-database-toolbar-item.more-action:hover,
  .more-action.active {
    background: var(--affine-hover-color);
  }
  .affine-database-search-container {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 16px;
    height: 32px;
    padding: 8px 0;
    border-radius: 8px;
    transition: all 0.3s ease;
  }
  .affine-database-search-container > svg {
    min-width: 16px;
    min-height: 16px;
  }
  .search-container-expand {
    width: 138px;
    padding: 8px 12px;
    background-color: var(--affine-hover-color);
  }
  .search-input-container {
    display: flex;
    align-items: center;
  }
  .search-input-container > .close-icon {
    display: flex;
    align-items: center;
  }
  .close-icon .code {
    width: 31px;
    height: 18px;
    padding: 2px 6px;
    border-radius: 4px;
    background: var(--affine-white-10);
  }
  .affine-database-search-input-icon {
    display: inline-flex;
  }
  .affine-database-search-input {
    flex: 1;
    height: 16px;
    width: 80px;
    border: none;
    font-family: var(--affine-font-family);
    font-size: var(--affine-font-sm);
    box-sizing: border-box;
    color: inherit;
    background: transparent;
  }
  .affine-database-search-input:focus {
    outline: none;
  }
  .affine-database-search-input::placeholder {
    color: var(--affine-placeholder-color);
    font-size: var(--affine-font-sm);
  }

  .affine-database-toolbar-item.new-record {
    display: flex;
    align-items: center;
    gap: 4px;
    width: 120px;
    height: 32px;
    padding: 6px 8px;
    border-radius: 8px;
    font-size: 14px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.05),
      0px 0px 0px 0.5px var(--affine-black-10);
    background: linear-gradient(
        0deg,
        var(--affine-hover-color),
        var(--affine-hover-color)
      ),
      var(--affine-white);
  }
  .new-record > tool-tip {
    max-width: 280px;
  }

  .show-toolbar {
    display: flex;
  }
`,e$=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this._recordAddDisposables=new y.SJ,this._onSearch=e=>{let t=e.target,i=t.value.trim();this.setSearchState(l.Searching),""===i&&this.setSearchState(l.SearchInput);let{_databaseMap:n}=this,o=Object.keys(n).filter(e=>n[e].findIndex(e=>e.toLocaleLowerCase().includes(i.toLocaleLowerCase()))>-1),r=this.targetModel.children.filter(e=>o.includes(e.id)).map(e=>e.id);this.setFilteredRowIds(r),requestAnimationFrame(()=>t.focus())},this._onSearchKeydown=e=>{"Escape"===e.key&&(this._searchInput.value?(this._searchInput.value="",this.setSearchState(l.SearchInput)):(this._resetSearchStatus(),this._searchContainer.classList.add("hidden")))},this._clearSearch=e=>{e.stopPropagation(),this._searchInput.value="",this.setSearchState(l.SearchInput)},this._onShowSearch=()=>{this.setSearchState(l.SearchInput);let e=V(this._searchContainer,()=>{this.searchState!==l.Searching&&(this._searchContainer.classList.add("hidden"),this.setSearchState(l.SearchIcon),e())},"click",!0)},this._onFocusSearchInput=()=>{this.searchState===l.SearchInput?(this._searchInput.focus(),this._searchContainer.classList.remove("hidden")):this._searchInput.blur()},this._onShowAction=()=>{if(!this.readonly){if(this._toolbarAction){this._closeToolbarAction();return}this.setSearchState(l.Action),this._toolbarAction=new e_,this._toolbarAction.targetModel=this.targetModel,this._toolbarAction.close=this._closeToolbarAction,this._moreActionContainer.appendChild(this._toolbarAction),(0,D.fi)(this._moreActionContainer,this._toolbarAction,{placement:"bottom"}),V(this._moreActionContainer,()=>{this._closeToolbarAction()},"mousedown")}},this._closeToolbarAction=()=>{this._toolbarAction?.remove(),this._toolbarAction=void 0},this._resetSearchStatus=()=>{this._searchInput.value="",this.setFilteredRowIds([]),this.setSearchState(l.SearchIcon)},this._onAddNewRecord=()=>{this.readonly||this.addRow(0)}}get readonly(){return this.targetModel.page.readonly}firstUpdated(){this.readonly||this._initAddRecordHandlers()}updated(e){super.updated(e),this.readonly||this._initAddRecordHandlers()}_initAddRecordHandlers(){this._recordAddDisposables.dispose();let e=function(e,t,i){let n=null,o=null,r=t.closest("affine-database");if(!r)return;let a=r.querySelector(".affine-database-block-rows");(0,y.kP)(a);let s=document.querySelector("affine-drag-indicator");if(!s){let e=document.createElement("affine-drag-indicator");document.body.appendChild(e)}let l=e=>{e.stopPropagation(),(0,y.kP)(e.dataTransfer),e.dataTransfer.effectAllowed="move",(o=new eS).style.opacity="0",e.dataTransfer?.setDragImage(o,0,0),t.appendChild(o);let i=Array.from(a.querySelectorAll(".affine-database-block-row"));n={index:-1,rows:i}},d=e=>{if(!n||!o)return;"1"!==o.style.opacity&&(o.style.opacity="1");let t=e.clientX,i=e.clientY;o.style.transform=`translate(${t}px, ${i}px)`;let a=new _.E9(t,i),l=function(e,t){let i=t.length;for(let n=0;n<i;n++){let o=t[n],{top:r,bottom:a}=o.getBoundingClientRect();if(e.y<=r+20&&e.y>=r-20)return{element:o,insertRowIndex:n,isLast:!1};if(n===i-1&&e.y>=a-20&&e.y<=a+20)return{element:o,insertRowIndex:n+1,isLast:!0}}return null}(a,n.rows);if((0,y.kP)(s),l){let{top:e,bottom:t}=l.element.getBoundingClientRect(),i=l.isLast?t:e,{width:o,left:a}=r.getBoundingClientRect();s.rect=_.UL.fromLWTH(a,o,i,3),n.index=l.insertRowIndex}else s.rect=null,n.index=-1},c=()=>{if(!n)return;let{index:e}=n;n=null,s&&(s.rect=null),o&&(o.remove(),o=null),-1!==e&&i(e)},h=new y.SJ,u=e=>{e.stopPropagation()};return h.addFromEvent(e,"pointerdown",u),h.addFromEvent(e,"pointermove",u),h.addFromEvent(e,"pointerup",u),h.addFromEvent(e,"dragstart",l),h.addFromEvent(e,"drag",d),h.addFromEvent(e,"dragend",c),h}(this._newRecord,this,this.addRow);e&&(this._recordAddDisposables=e)}get _databaseMap(){let e={};for(let t of this.targetModel.children)e[t.id]=[t.text?.toString()??""];let{cells:t}=this.targetModel,i=this.targetModel.children.map(e=>e.id);return i.forEach(i=>{let n=t[i];if(!n)return;let o=Object.keys(n).map(e=>{let t=n[e].value;return Array.isArray(t)?t.map(e=>e.value):n[e].value+""});e[i].push(...o.flat())}),e}render(){let e=this.searchState===l.SearchInput||this.searchState===l.Searching,t=this.searchState===l.Action,i=e?void 0:this._onShowSearch,n=this._searchInput?""===this._searchInput.value?null:B.ws:null,o=h.dy`
      <div
        class="affine-database-search-container ${e?"search-container-expand":""}"
        @click=${i}
        @transitionend=${this._onFocusSearchInput}
      >
        <div class="affine-database-search-input-icon">
          ${B.lC}
        </div>
        <div class="search-input-container">
          <input
            placeholder="Search..."
            class="affine-database-search-input"
            @input=${this._onSearch}
            @click=${e=>e.stopPropagation()}
            @keydown=${this._onSearchKeydown}
            @pointerdown=${ek.UW}
          />
          <div class="has-tool-tip close-icon" @click=${this._clearSearch}>
            ${n}
            <tool-tip inert arrow tip-position="top" role="tooltip">
              <span class="code">Esc</span> to clear all
            </tool-tip>
          </div>
        </div>
      </div>
    `;return h.dy`<div
      class="affine-database-toolbar ${this.hoverState?"show-toolbar":""}"
    >
      <div class="affine-database-toolbar-item search-container hidden">
        ${o}
      </div>
      ${this.readonly?null:h.dy`<div
              class="affine-database-toolbar-item more-action ${t?"active":""}"
              @click=${this._onShowAction}
            >
              ${T.xh}
            </div>
            <div
              class="has-tool-tip affine-database-toolbar-item new-record"
              draggable="true"
              @click=${this._onAddNewRecord}
            >
              ${T.pO}<span>New Record</span>
              <tool-tip inert arrow tip-position="top" role="tooltip"
                >You can drag this button to the desired location and add a
                record
              </tool-tip>
            </div>`}
    </div>`}};e$.styles=eL,eE([(0,u.Cb)()],e$.prototype,"targetModel",void 0),eE([(0,u.Cb)()],e$.prototype,"hoverState",void 0),eE([(0,u.Cb)()],e$.prototype,"searchState",void 0),eE([(0,u.Cb)()],e$.prototype,"addRow",void 0),eE([(0,u.Cb)()],e$.prototype,"setSearchState",void 0),eE([(0,u.Cb)()],e$.prototype,"setFilteredRowIds",void 0),eE([(0,u.IO)(".affine-database-search-input")],e$.prototype,"_searchInput",void 0),eE([(0,u.IO)(".more-action")],e$.prototype,"_moreActionContainer",void 0),eE([(0,u.IO)(".search-container")],e$.prototype,"_searchContainer",void 0),eE([(0,u.IO)(".new-record")],e$.prototype,"_newRecord",void 0),e$=eE([(0,u.Mo)("affine-database-toolbar")],e$);var eP=i(25005),eB=i(60803),eR=i(9288);class eT{constructor(e){this.yDoc=new eB.Doc,this._active=!0,this.type="default",this.maxLength=1/0;let{rootElement:t,yText:i=this.yDoc.getText(eT.YTEXT_NAME),maxLength:n,type:o}=e,r=i.toString();if(n&&(this.maxLength=n,r.length>n))throw Error("The text exceeds the limit length.");if(o&&(this.type=o),i instanceof eB.Text){if(i.doc)this.yText=i,this.yDoc=i.doc;else throw Error("Y.Text should be binded to Y.Doc.")}else this.yText=this.yDoc.getText(eT.YTEXT_NAME),this.yText.insert(0,r);this.undoManager=new eB.UndoManager(this.yText,{trackedOrigins:new Set([this.yDoc.clientID])}),this.undoManager.on("stack-item-added",e=>{let t=this.vEditor.getVRange();e.stackItem.meta.set("v-range",t)}),this.undoManager.on("stack-item-popped",e=>{let t=e.stackItem.meta.get("v-range");t&&this.vEditor.setVRange(t)}),this.vEditor=new x.gX(this.yText,{active:()=>eR.y.isActive(e.rootElement)&&this.active}),this.vEditor.mount(t),this.vEditor.bindHandlers({paste:e=>{e.stopPropagation();let t=e.clipboardData?.getData("text/plain")?.replace(/(\r\n|\r|\n)/g,"\n");if(!t)return;let i=this.vEditor.getVRange();if(i){i.length>0&&this.vEditor.yText.delete(i.index,i.length);let e=this.vEditor.yText.length,n=this.maxLength-e;if(n<=0)return;let o=t.length>n?t.slice(0,n):t;this.vEditor.insertText(i,o),this.vEditor.setVRange({index:i.index+o.length,length:0}),this.undoManager.stopCapturing()}},virgoInput:e=>{let t=this.vEditor.getVRange();if(!t)return e;let i=this.vEditor.yText.toString();t.length>0&&(i=`${i.substring(0,t.index)}${i.substring(t.index+t.length)}`);let n=`${i.substring(0,t.index)}${e.data??""}${i.substring(t.index)}`,o=!0;return n.length>=this.maxLength&&(e.skipDefault=!0,o=!1),o&&this.undoManager.stopCapturing(),e},virgoCompositionEnd:e=>{let t=this.vEditor.getVRange();if(!t)return e;let i=this.vEditor.yText.toString();t.length>0&&(i=`${i.substring(0,t.index)}${i.substring(t.index+t.length)}`);let n=`${i.substring(0,t.index)}${e.data}${i.substring(t.index)}`,o=!0;return n.length>=this.maxLength&&(e.data="",o=!1),o&&this.undoManager.stopCapturing(),e},keydown:e=>{e instanceof KeyboardEvent&&(e.ctrlKey||e.metaKey)&&("z"===e.key||"Z"===e.key)&&(e.preventDefault(),e.shiftKey?this.redo():this.undo())}}),t.addEventListener("blur",()=>{if("number"===this.type){let e=this.yText.toString(),t=parseFloat(e),i=isNaN(t)?"":t.toString();e!==i&&(this.setActive(!1),this.setValue(i),requestAnimationFrame(()=>{this.setActive(!0)}))}})}get value(){return this.yText.toString()}get active(){return this._active}setActive(e){this._active=e}setValue(e){if(e.length>this.maxLength)throw Error("The text exceeds the limit length.");this.yText.delete(0,this.yText.length),this.yText.insert(0,e),this.vEditor.setVRange({index:e.length,length:0}),this.undoManager.stopCapturing()}undo(){this.undoManager.undo()}redo(){this.undoManager.redo()}}eT.YTEXT_NAME="YTEXT_NAME";var eO=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eI=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this._titleVInput=null,this._handleKeyDown=e=>{if("Enter"===e.key){e.preventDefault(),this.addRow(0);return}},this._onTitleFocus=()=>{this._titleContainer.classList.remove("ellipsis"),this._titleVInput?.setActive(!0),this._titleVInput?.value==="Database"&&this._titleVInput?.setValue("")},this._onTitleBlur=()=>{this._titleContainer.classList.add("ellipsis"),this._titleVInput?.setActive(!1),this._titleVInput?.value===""&&this._titleVInput?.setValue(j.i2)}}firstUpdated(){this._initTitleVEditor();let e=this._disposables;e.addFromEvent(this._titleContainer,"focus",this._onTitleFocus),e.addFromEvent(this._titleContainer,"blur",this._onTitleBlur);let t=e=>e.stopPropagation();this._disposables.addFromEvent(this,"pointerdown",t),this._disposables.addFromEvent(this,"pointermove",t)}_initTitleVEditor(){this._titleVInput=new eT({yText:this.targetModel.title.yText,rootElement:this._titleContainer,maxLength:j.sJ}),(0,eP.m)(this.targetModel.page,this._titleVInput.vEditor),this._titleVInput.vEditor.setReadonly(this.targetModel.page.readonly),this._titleContainer.addEventListener("keydown",this._handleKeyDown),this.targetModel.title.yText.observe(()=>{this.requestUpdate()})}render(){let e=!this.targetModel.title||!this.targetModel.title.length;return h.dy`<div class="affine-database-title">
      <div
        class="database-title ${e?"database-title-empty":""}"
        data-block-is-database-title="true"
        title=${this.targetModel.title.toString()}
      ></div>
    </div>`}};eI.styles=h.iv`
    .affine-database-title {
      flex: 1;
      max-width: 300px;
      min-width: 300px;
      height: 30px;
    }

    .database-title {
      position: sticky;
      width: 300px;
      height: 30px;
      font-size: 18px;
      font-weight: 600;
      line-height: 24px;
      color: var(--affine-text-primary-color);
      font-family: inherit;
      /* overflow-x: scroll; */
      overflow: hidden;
      cursor: text;
    }

    .database-title [data-virgo-text='true'] {
      display: block;
      white-space: pre !important;
    }

    .database-title.ellipsis [data-virgo-text='true'] {
      white-space: nowrap !important;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    .database-title:focus {
      outline: none;
    }

    .database-title:disabled {
      background-color: transparent;
    }

    .database-title-empty::before {
      content: 'Database';
      color: var(--affine-placeholder-color);
      position: absolute;
      opacity: 0.5;
    }
  `,eO([(0,u.Cb)()],eI.prototype,"targetModel",void 0),eO([(0,u.Cb)()],eI.prototype,"addRow",void 0),eO([(0,u.IO)(".database-title")],eI.prototype,"_titleContainer",void 0),eI=eO([(0,u.Mo)("affine-database-title")],eI);var eD=i(29691),ez=i(77831);let eA=class extends eu{constructor(){super(...arguments),this.cellType="checkbox"}firstUpdated(){this._disposables.addFromEvent(this,"click",this._onChange)}_onChange(){let e=!this.cell?.value;this.rowHost.setValue(e)}render(){let e=this.cell?.value??!1,t=e?(0,ez.TF)():(0,ez.XN)();return h.dy`<div class="affine-database-checkbox-container">
      <div class="affine-database-checkbox checkbox ${e&&"checked"}">
        ${t}
      </div>
    </div>`}};eA.tag=A.i0`affine-database-checkbox-cell`,eA.styles=h.iv`
    affine-database-checkbox-cell {
      display: block;
      width: 100%;
      height: 100%;
      cursor: pointer;
    }

    .affine-database-checkbox-container {
      height: 100%;
    }

    .affine-database-checkbox {
      display: flex;
      align-items: center;
      height: 100%;
      width: 100%;
    }
  `,eA=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,u.Mo)("affine-database-checkbox-cell")],eA);let eH=ef("checkbox",()=>({}),()=>!1,{Cell:eA,CellEditing:null},{displayName:"Checkbox"});var eV=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eZ=class extends eu{constructor(){super(...arguments),this.cellType="multi-select"}render(){return A.dy`
      <affine-database-select-cell
        .rowHost=${this.rowHost}
        .databaseModel=${this.databaseModel}
        .rowModel=${this.rowModel}
        .column=${this.column}
        .cell=${this.cell}
      ></affine-database-select-cell>
    `}};eZ.styles=h.iv`
    :host {
      width: 100%;
    }
  `,eZ.tag=A.i0`affine-database-multi-select-cell`,eZ=eV([(0,u.Mo)("affine-database-multi-select-cell")],eZ);let eF=class extends eu{constructor(){super(...arguments),this.cellType="multi-select"}render(){return A.dy`
      <affine-database-select-cell-editing
        data-is-editing-cell="true"
        .rowHost=${this.rowHost}
        .databaseModel=${this.databaseModel}
        .rowModel=${this.rowModel}
        .column=${this.column}
        .cell=${this.cell}
        .mode=${d.Multi}
      ></affine-database-select-cell-editing>
    `}};eF.tag=A.i0`affine-database-multi-select-cell-editing`,eF=eV([(0,u.Mo)("affine-database-multi-select-cell-editing")],eF);let eU=ef("multi-select",()=>({selection:[]}),()=>[],{Cell:eZ,CellEditing:eF},{displayName:"Multi Select"});var ej=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eN=class extends eu{constructor(){super(...arguments),this.cellType="number",this._vInput=null,this._onClick=()=>{this.databaseModel.page.captureSync()},this._onInitVEditor=()=>{let e;if(this.cell?.value)e=this.cell.value;else{let t=new this.databaseModel.page.YText("");this.databaseModel.updateCell(this.rowModel.id,{columnId:this.column.id,value:t}),e=t}this._vInput=new eT({yText:e,rootElement:this._container,type:"number"}),(0,eP.m)(this.databaseModel.page,this.vEditor),this._container.addEventListener("keydown",e=>{if(this._vInput&&"Enter"===e.key){e.shiftKey||(this.rowHost.setEditing(!1),this._container.blur()),e.preventDefault();return}})}}get vEditor(){return(0,y.kP)(this._vInput),this._vInput.vEditor}firstUpdated(){this._disposables.addFromEvent(this,"click",this._onClick),this._onInitVEditor()}render(){return h.dy`<div class="affine-database-number number virgo-editor"></div>`}};eN.styles=h.iv`
    affine-database-number-cell-editing {
      display: block;
      width: 100%;
      height: 100%;
      cursor: text;
    }

    .affine-database-number {
      display: flex;
      align-items: center;
      height: 100%;
    }
    .affine-database-number:focus {
      outline: none;
    }
    .affine-database-number v-line {
      display: flex !important;
      align-items: center;
      height: 100%;
      width: 100%;
    }
    .affine-database-number v-line > div {
      flex-grow: 1;
    }
  `,eN.tag=A.i0`affine-database-number-cell-editing`,ej([(0,u.IO)(".affine-database-number")],eN.prototype,"_container",void 0),eN=ej([(0,u.Mo)("affine-database-number-cell-editing")],eN);let eW=ef("number",()=>({decimal:0}),e=>new e.YText(""),{Cell:eN,CellEditing:null},{displayName:"Number"});var eq=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eY=h.iv`
  affine-database-progress-cell-editing {
    display: block;
    width: 100%;
    height: 100%;
    padding: 0 4px;
  }

  affine-database-progress-cell-editing:hover
    .affine-database-progress-drag-handle {
    opacity: 1;
  }

  .affine-database-progress {
    display: flex;
    align-items: center;
    height: 100%;
    gap: 4px;
  }

  .affine-database-progress-bar {
    position: relative;
    width: 104px;
  }

  .affine-database-progress-bg {
    overflow: hidden;
    width: 100%;
    height: 13px;
    border-radius: 22px;
  }

  .affine-database-progress-fg {
    height: 100%;
  }

  .affine-database-progress-drag-handle {
    position: absolute;
    top: 0;
    left: 0;
    transform: translate(0px, -1px);
    width: 6px;
    height: 15px;
    border-radius: 2px;
    opacity: 0;
    cursor: ew-resize;
    background: var(--affine-primary-color);
    transition: opacity 0.2s ease-in-out;
  }

  .progress-number {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 18px;
    width: 25px;
    color: var(--affine-text-secondary-color);
    font-size: 14px;
  }
`,eX={empty:"var(--affine-black-10)",processing:"var(--affine-processing-color)",success:"var(--affine-success-color)"},eK=class extends eu{constructor(){super(...arguments),this.cellType="progress",this._dragConfig=null,this._progressBgWidth=0,this._onDocumentMove=()=>{this._dragConfig&&this._onPointerUp()},this._onPointerDown=e=>{e.stopPropagation();let{left:t,width:i}=this._progressBg.getBoundingClientRect(),n=i-6;this._dragConfig={stepWidth:n/100,boundLeft:t,containerWidth:n},this.databaseModel.page.captureSync()},this._onPointerMove=e=>{let t;if(e.stopPropagation(),!this._dragConfig)return;let i=e.clientX,{boundLeft:n,containerWidth:o,stepWidth:r}=this._dragConfig;t=i<=n?0:i-n>=o?100:Math.floor((i-n)/r),this.cell?.value!==t&&this.rowHost.setValue(t,{captureSync:!1})},this._onPointerUp=()=>{this._dragConfig=null,this.databaseModel.page.captureSync()}}firstUpdated(){let e=this._disposables;e.addFromEvent(this._dragHandle,"pointerdown",this._onPointerDown),e.addFromEvent(this,"pointermove",this._onPointerMove),e.addFromEvent(this,"pointerup",this._onPointerUp),e.addFromEvent(document,"pointermove",this._onDocumentMove);let{width:t}=this._progressBg.getBoundingClientRect();this._progressBgWidth=t-6;let i=this.cell?.value;i&&this._setDragHandlePosition(i)}_setDragHandlePosition(e){let t=this._progressBgWidth*(e/100);this._dragHandle.style.transform=`translate(${t}px, -1px)`}updated(e){super.updated(e),e.has("cell")&&this._setDragHandlePosition(this.cell?.value??0)}render(){let e=this.cell?.value??0,t=eX.processing;100===e&&(t=eX.success);let i=(0,w.V)({width:`${e}%`,backgroundColor:t}),n=(0,w.V)({backgroundColor:0===e?eX.empty:"var(--affine-hover-color)"});return h.dy`<div
      class="affine-database-progress"
      @mousedown=${e=>e.preventDefault()}
    >
      <div class="affine-database-progress-bar">
        <div class="affine-database-progress-bg" style=${n}>
          <div class="affine-database-progress-fg" style=${i}></div>
          <div class="affine-database-progress-drag-handle"></div>
        </div>
      </div>
      <div class="progress-number progress">${e}</div>
    </div>`}};eK.styles=eY,eK.tag=A.i0`affine-database-progress-cell-editing`,eq([(0,u.IO)(".affine-database-progress-drag-handle")],eK.prototype,"_dragHandle",void 0),eq([(0,u.IO)(".affine-database-progress-bg")],eK.prototype,"_progressBg",void 0),eK=eq([(0,u.Mo)("affine-database-progress-cell-editing")],eK);let eG=ef("progress",()=>({}),()=>0,{Cell:eK,CellEditing:null},{displayName:"Progress"});var eQ=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function eJ(e,t){let i=e.getVRange();if(!i)return;let n=e.rootElement;if(!n)return;let o=e.getDeltasByVRange(i),r={};for(let[e]of o){let t=e.attributes;t&&(r={...t})}let a=Object.fromEntries(Object.entries(t).map(([e,t])=>"boolean"==typeof t&&t===r[e]?[e,!t]:[e,t]));e.formatText(i,a,{mode:"merge"}),n.blur(),e.syncVRange()}let e1=class extends eu{constructor(){super(...arguments),this.vEditor=null,this.cellType="rich-text",this._initYText=e=>{let t=new this.databaseModel.page.YText(e);return this.databaseModel.updateCell(this.rowModel.id,{columnId:this.column.id,value:t}),t},this._handleKeyDown=e=>{if("Escape"!==e.key){if("Tab"===e.key){e.preventDefault();return}e.stopPropagation()}if(!this.vEditor)return;if("Enter"===e.key){e.shiftKey?this._onSoftEnter():(this.rowHost.setEditing(!1),this._container.blur()),e.preventDefault();return}let t=this.vEditor;switch(e.key){case"B":case"b":(e.metaKey||e.ctrlKey)&&(e.preventDefault(),eJ(this.vEditor,{bold:!0}));break;case"I":case"i":(e.metaKey||e.ctrlKey)&&(e.preventDefault(),eJ(this.vEditor,{italic:!0}));break;case"U":case"u":(e.metaKey||e.ctrlKey)&&(e.preventDefault(),eJ(this.vEditor,{underline:!0}));break;case"S":case"s":(e.metaKey||e.ctrlKey)&&e.shiftKey&&(e.preventDefault(),eJ(t,{strike:!0}));break;case"E":case"e":(e.metaKey||e.ctrlKey)&&e.shiftKey&&(e.preventDefault(),eJ(t,{code:!0}))}},this._onSoftEnter=()=>{if(this.cell&&this.vEditor){let e=this.vEditor.getVRange();(0,I.kP)(e);let t=this.databaseModel.page;t.captureSync();let i=new y.xv(this.vEditor.yText);i.replace(e.index,length,"\n"),this.vEditor.setVRange({index:e.index+1,length:0})}}}get readonly(){return this.databaseModel.page.readonly}firstUpdated(){this._onInitVEditor(),this._disposables.addFromEvent(this,"click",this._handleClick)}_handleClick(){this.databaseModel.page.captureSync()}_onInitVEditor(){let e;e=this.cell?.value?"string"==typeof this.cell.value?this._initYText(this.cell.value):this.cell.value:this._initYText(),this.vEditor=new x.gX(e,{active:()=>eR.y.isActive(this)}),(0,eP.m)(this.databaseModel.page,this.vEditor),this.vEditor.mount(this._container),this.vEditor.bindHandlers({keydown:this._handleKeyDown}),this.vEditor.setReadonly(this.readonly)}render(){return A.dy`<div class="affine-database-rich-text virgo-editor"></div>`}};e1.styles=h.iv`
    affine-database-rich-text-cell {
      display: flex;
      align-items: center;
      width: 100%;
      height: 100%;
      cursor: text;
    }

    .affine-database-rich-text {
      display: flex;
      flex-direction: column;
      justify-content: center;
      width: 100%;
      height: 100%;
      outline: none;
    }
    .affine-database-rich-text v-line {
      display: flex !important;
      align-items: center;
      height: 100%;
      width: 100%;
    }
    .affine-database-rich-text v-line > div {
      flex-grow: 1;
    }
  `,e1.tag=A.i0`affine-database-rich-text-cell`,eQ([(0,u.IO)(".affine-database-rich-text")],e1.prototype,"_container",void 0),e1=eQ([(0,u.Mo)("affine-database-rich-text-cell")],e1);let e2=ef("rich-text",()=>({}),e=>new e.YText(""),{Cell:e1,CellEditing:null},{displayName:"Rich Text"});var e0=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let e5=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this._onOptionFocus=()=>{this._container.classList.remove("ellipsis")},this._onOptionBlur=()=>{this._container.classList.add("ellipsis")}}get _vEditor(){return this._vInput.vEditor}updated(e){super.updated(e),e.has("editing")&&(this.editing&&this._vEditor.focusEnd(),this._vEditor.setReadonly(!this.editing),this._vEditor.setText(this.select.value)),e.has("select")&&this._vEditor.setText(this.select.value)}getSelectionValue(){return this._vEditor.yText.toString()}_onInitVEditor(){this._vInput=new eT({yText:this.select.value,rootElement:this._container,maxLength:j.VV}),(0,eP.m)(this.databaseModel.page,this._vEditor),this._vEditor.setReadonly(!this.editing),this._container.addEventListener("keydown",e=>{"Enter"===e.key&&(e.preventDefault(),this._vInput.value.length>0&&this.saveSelectionName(this.index)),"Escape"===e.key&&(e.stopPropagation(),e.preventDefault(),this.setEditingIndex(-1),this._container.blur())})}firstUpdated(){this._disposables.addFromEvent(this._container,"focus",this._onOptionFocus),this._disposables.addFromEvent(this._container,"blur",this._onOptionBlur),this._onInitVEditor()}render(){let e=(0,w.V)({backgroundColor:this.select.color,cursor:this.editing?"text":"pointer"});return h.dy`<div
      class="select-option-text virgo-editor"
      style=${e}
    ></div>`}};e5.styles=h.iv`
    affine-database-select-option {
      display: flex;
      align-items: center;
    }
    .select-option-text {
      display: inline-block;
      min-width: 22px;
      height: 100%;
      max-width: 100%;
      padding: 2px 10px;
      border-radius: 4px;
      background: var(--affine-tag-pink);
      overflow: hidden;
      cursor: text;
    }
    .select-option-text:focus {
      outline: none;
    }

    .select-option-text [data-virgo-text='true'] {
      display: block;
      white-space: nowrap !important;
      text-overflow: ellipsis;
      overflow: hidden;
    }
  `,e0([(0,u.Cb)()],e5.prototype,"databaseModel",void 0),e0([(0,u.Cb)()],e5.prototype,"select",void 0),e0([(0,u.Cb)()],e5.prototype,"editing",void 0),e0([(0,u.Cb)()],e5.prototype,"index",void 0),e0([(0,u.Cb)()],e5.prototype,"saveSelectionName",void 0),e0([(0,u.Cb)()],e5.prototype,"setEditingIndex",void 0),e0([(0,u.IO)(".select-option-text")],e5.prototype,"_container",void 0),e5=e0([(0,u.Mo)("affine-database-select-option")],e5);var e3=i(16025),e7=i(280),e4=i(11563);let e6=["Tab","Enter","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"],e8=["Tab","Escape"];class e9{constructor(e,t){this._disposables=new y.SJ,this._service=null,this._onClick=e=>{this._service?.clearCellLevelSelection()},this._onCellSelectionMove=e=>{let t=e.get("keyboardState"),i=t.raw;if(-1>=e6.indexOf(i.key))return;let n=(0,e7.getService)("affine:database"),o=n.getLastCellSelection();if(!o)return;i.preventDefault();let{databaseId:r,coords:a}=o;if("Enter"===i.key)n.setCellSelection({type:"edit",coords:a,databaseId:r});else{let e=(0,e4.VT)(a[0],r,i.key);n.setCellSelection({type:"select",coords:[e],databaseId:r})}return!0},this._add=(e,t)=>{this._disposables.add(this._dispatcher.add(e,t))},this.onCellSelectionChange=e=>{var t;if(t=e.key,!(e8.indexOf(t)>-1))return;e.preventDefault(),e.stopPropagation();let i=e.target;te(i,this._model.id,e.key)},this._dispatcher=e,this._model=t,this._service=(0,e7.getService)("affine:database"),this._add("click",this._onClick),this._add("keyDown",this._onCellSelectionMove)}dispose(){this._disposables.dispose()}}function te(e,t,i){let n=e.closest(".affine-database-block-rows"),o=e.closest(".database-cell");if(!n||!o)return;let r=o.querySelector(".virgo-editor");r?.blur(),(0,_.xT)(null);let a=(0,e4.VT)(o,t,i),s=(0,e7.getService)("affine:database"),l=null!==s.getLastRowSelection();l||s.setCellSelection({type:"select",coords:[a],databaseId:t})}var tt=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ti=[{type:"rename",text:"Rename",icon:T.Mw},{type:"divider"},{type:"delete",text:"Delete",icon:R.pJ}],tn=class extends h.oi{constructor(){super(...arguments),this._onAction=(e,t)=>{e.stopPropagation(),this.onAction(t,this.index),this.onClose()}}render(){return h.dy`
      <div class="affine-database-select-action">
        ${ti.map(e=>U(e)?h.dy`<div class="action-divider"></div>`:h.dy`
            <div
              class="action ${e.type}"
              @mousedown=${t=>this._onAction(t,e.type)}
            >
              <div class="action-content">
                ${e.icon}<span>${e.text}</span>
              </div>
            </div>
          `)}
      </div>
    `}};tn.styles=h.iv`
    :host {
      z-index: 11;
    }
    .affine-database-select-action {
      width: 200px;
      padding: 8px;
      border: 1px solid var(--affine-border-color);
      border-radius: 8px;
      background: var(--affine-white);
      box-shadow: var(--affine-menu-shadow);
    }
    ${N}
    .action {
      color: var(--affine-text-primary-color);
    }
    .action svg {
      width: 20px;
      height: 20px;
    }
    .rename,
    .delete {
      fill: var(--affine-icon-color);
    }
  `,tt([(0,u.Cb)()],tn.prototype,"index",void 0),tt([(0,u.Cb)()],tn.prototype,"onAction",void 0),tt([(0,u.Cb)()],tn.prototype,"onClose",void 0),tn=tt([(0,u.Mo)("affine-database-select-action-popup")],tn);var to=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let tr=["Enter","ArrowUp","ArrowDown"],ta=h.iv`
  affine-database-select-cell-editing {
    z-index: 2;
    border: 1px solid var(--affine-border-color);
    border-radius: 8px;
    background: var(--affine-background-primary-color);
    box-shadow: var(--affine-shadow-2);
  }
  .affine-database-select-cell-select {
    font-size: var(--affine-font-sm);
  }
  .select-input-container {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    min-height: 44px;
    padding: 10px 8px;
    background: var(--affine-hover-color);
  }
  .select-input {
    flex: 1 1 0%;
    height: 24px;
    border: none;
    font-family: var(--affine-font-family);
    color: inherit;
    background: transparent;
    line-height: 24px;
  }
  .select-input:focus {
    outline: none;
  }
  .select-input::placeholder {
    color: var(--affine-placeholder-color);
  }
  .select-option-container {
    padding: 8px;
    color: var(--affine-black-90);
  }
  .select-option-container-header {
    padding: 8px 0px;
    color: var(--affine-black-60);
  }
  .select-input-container .select-selected {
    display: flex;
    align-items: center;
    padding: 2px 10px;
    gap: 10px;
    height: 28px;
    background: var(--affine-tag-white);
    border-radius: 4px;
    color: var(--affine-black-90);
    background: var(--affine-tertiary-color);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .select-selected-text {
    width: calc(100% - 16px);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .select-selected > .close-icon {
    display: flex;
    align-items: center;
  }
  .select-selected > .close-icon:hover {
    cursor: pointer;
  }
  .select-selected > .close-icon > svg {
    fill: var(--affine-black-90);
  }
  .select-option-new {
    display: flex;
    flex-direction: row;
    align-items: center;
    height: 36px;
    padding: 4px;
    gap: 5px;
    border-radius: 4px;
    background: var(--affine-selected-color);
  }
  .select-option-new-text {
    flex: 1;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    height: 28px;
    padding: 2px 10px;
    border-radius: 4px;
    background: var(--affine-tag-red);
  }
  .select-option-new-icon {
    display: flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    color: var(--affine-text-primary-color);
  }
  .select-option-new-icon svg {
    width: 16px;
    height: 16px;
  }
  .select-option {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 36px;
    padding: 4px;
    border-radius: 4px;
    margin-bottom: 4px;
    cursor: pointer;
  }
  .select-option.selected,
  .select-option:hover {
    background: var(--affine-hover-color);
  }
  .select-option:hover .select-option-icon {
    display: flex;
  }
  .select-option-text-container {
    width: calc(100% - 28px);
    overflow: hidden;
  }
  .select-option-icon {
    display: none;
    justify-content: center;
    align-items: center;
    width: 28px;
    height: 28px;
    border-radius: 3px;
    cursor: pointer;
  }
  .select-option-icon:hover {
    background: var(--affine-hover-color);
  }
  .select-option-icon svg {
    width: 16px;
    height: 16px;
    pointer-events: none;
  }
  .editing {
    background: var(--affine-hover-color);
  }
  .editing .select-option-text [data-virgo-text='true'] {
    display: block;
    white-space: pre !important;
    overflow: unset;
    text-overflow: unset;
  }
  .editing .select-option-icon {
    display: flex;
    background: var(--affine-hover-background);
  }
`,ts=class extends eu{constructor(){super(...arguments),this.value=void 0,this.cellType="select",this.mode=d.Single,this._inputValue="",this._editingIndex=-1,this._selectedOptionIndex=-1,this._selectColor=void 0,this._onSelectOption=e=>{let t=e.key;if(-1>=tr.indexOf(t))return;e.preventDefault(),e.stopPropagation();let i=this.selectionList.length-1;if(this._selectedOptionIndex===i&&"ArrowDown"===t){this._selectedOptionIndex=0;return}if(this._selectedOptionIndex<=0&&"ArrowUp"===t){this._selectedOptionIndex=i;return}if("ArrowDown"===t)this._selectedOptionIndex++;else if("ArrowUp"===t)this._selectedOptionIndex--;else if("Enter"===t){let e=this._selectedOptionIndex;if(-1===e)return;this.isSingleMode&&(this._selectedOptionIndex=-1);let t=this.cell?.value??[],i=this.selectionList[e];this._onSelect(t,i);let n=this._selectOptionContainer.closest(".database-cell");(0,I.kP)(n),this._selectCell(n,"Escape")}},this._selectCell=(e,t,i=!1)=>{(this.isSingleMode||i)&&this.rowHost.setEditing(!1),te(e,this.databaseModel.id,t)},this._onDeleteSelected=(e,t)=>{let i=e.filter(e=>e!==t);this.rowHost.setValue(i)},this._onSelectSearchInput=e=>{let t=e.target.value;this._inputValue=t,this._selectColor||(this._selectColor=F())},this._onSelectOrAdd=(e,t)=>{let i=this._inputValue.trim();if("Backspace"===e.key&&""===i)this._onDeleteSelected(t,t[t.length-1]);else if("Enter"===e.key&&""!==i){if(-1!==this._selectedOptionIndex)return;let e=this.selectionList.find(e=>e.value===i);e?this._onSelect(t,e):this._onAddSelection(t)}else"Escape"===e.key?this._selectCell(e.target,"Escape",!0):"Tab"===e.key&&(e.preventDefault(),this._selectCell(e.target,"Tab",!0))},this._onSelect=(e,t)=>{if(-1!==this._editingIndex)return;let i=e.findIndex(e=>e.value===t.value)>-1;if(i)return;this.value=t;let n=e.indexOf(this.value)>-1;if(!n){let t=this.isSingleMode?[this.value]:[...e,this.value];this.rowHost.setValue(t),this.isSingleMode&&this.rowHost.setEditing(!1),!this.isSingleMode&&t.length>1&&this._calcRowHostHeight()}},this._onAddSelection=e=>{let t=this._inputValue.trim();if(""===t)return;t.length>j.VV&&(t=t.slice(0,j.VV));let i=this._selectColor??F();this._selectColor=void 0;let n={id:(0,y.x0)(),value:t,color:i};this.rowHost.updateColumnProperty(e=>{let i=e.selection;return{...e,selection:-1===i.findIndex(e=>e.value===t)?[...i,n]:i}});let o=this.isSingleMode?[n]:[...e,n];this.rowHost.setValue(o),this.rowHost.setEditing(!1),!this.isSingleMode&&o.length>1&&this._calcRowHostHeight()},this._calcRowHostHeight=()=>{setTimeout(()=>{let e=this.rowHost.shadowRoot?.children[0].shadowRoot?.children[0].shadowRoot,t=e?.querySelector(".affine-database-select-cell-container");if(t){let{height:e}=t.getBoundingClientRect();this.rowHost.setHeight(e)}})},this._onSelectAction=(e,t)=>{if("rename"===e){this._setEditingIndex(t);return}if("delete"===e){this.databaseModel.updateColumn({...this.column,selection:this.selectionList.filter((e,i)=>i!==t)});let e=this.selectionList[t];this.databaseModel.deleteSelectedCellTag(this.column.id,e);return}},this._showSelectAction=e=>{let t=this.querySelectorAll(".select-option").item(e);(0,I.kP)(t);let i=new tn;i.onAction=this._onSelectAction,i.index=e,t.appendChild(i);let n=()=>i.remove();i.onClose=n,(0,D.fi)({getBoundingClientRect:()=>{let e=t.querySelector(".select-option-icon");(0,I.kP)(e);let{height:n}=i.getBoundingClientRect(),o=e.getBoundingClientRect();return o.y=o.y+n+36,o.x=o.x+33,o}},i,{placement:"bottom-end"}),V(t,n,"mousedown")},this._onSaveSelectionName=e=>{let t=this._selectOptionContainer.querySelectorAll("affine-database-select-option").item(e),i=[...this.selectionList],n=t.getSelectionValue(),o=i.findIndex((t,i)=>i!==e&&t.value===n)>-1;if(o)return;let r=i[e],a={...r,value:n};i[e]=a,this.databaseModel.updateColumn({...this.column,selection:i}),this.databaseModel.renameSelectedCellTag(this.column.id,r,a),this._setEditingIndex(-1)},this._setEditingIndex=e=>{this._editingIndex=e}}get isSingleMode(){return this.mode===d.Single}get selectionList(){return this.column.selection}firstUpdated(){this.style.width=`${j.O2}px`,this._selectInput.focus()}connectedCallback(){super.connectedCallback(),this._disposables.addFromEvent(document.body,"keydown",this._onSelectOption),(0,D.fi)({getBoundingClientRect:()=>{let e=this.rowHost.getBoundingClientRect();return e.y=e.y-e.height-2,e.x=e.x-2,e}},this,{placement:"bottom-start",strategy:"fixed"})}updated(e){super.updated(e),e.has("cell")&&this._selectInput.focus()}render(){let e=this.selectionList.filter(e=>!this._inputValue||e.value.toLocaleLowerCase().indexOf(this._inputValue.toLocaleLowerCase())>-1),t=this.cell?.value??[],i=this._inputValue&&-1===e.findIndex(e=>e.value===this._inputValue),n=i?A.dy`<div class="select-option-new" @click=${this._onAddSelection}>
          <div class="select-option-new-icon">Create ${T.pO}</div>
          <span
            class="select-option-new-text"
            style=${(0,w.V)({backgroundColor:this._selectColor})}
            >${this._inputValue}</span
          >
        </div>`:null;return A.dy`
      <div class="affine-database-select-cell-select">
        <div class="select-input-container">
          ${t.map(e=>{let i=(0,w.V)({backgroundColor:e.color});return A.dy`<div class="select-selected" style=${i}>
              <div class="select-selected-text">${e.value}</div>
              <span
                class="close-icon"
                @click=${()=>this._onDeleteSelected(t,e)}
                >${B.ws}</span
              >
            </div>`})}
          <input
            class="select-input"
            placeholder="Type here..."
            maxlength=${j.VV}
            @input=${this._onSelectSearchInput}
            @keydown=${e=>this._onSelectOrAdd(e,t)}
          />
        </div>
        <div class="select-option-container">
          <div class="select-option-container-header">
            Select tag or create one
          </div>
          ${n}
          ${(0,z.r)(e,e=>e.id,(e,i)=>{let n=i===this._editingIndex,o=i===this._selectedOptionIndex,r=(0,e3.$)({"select-option":!0,selected:o,editing:n});return A.dy`
                <div class="${r}">
                  <div
                    class="select-option-text-container"
                    @click=${()=>this._onSelect(t,e)}
                  >
                    <affine-database-select-option
                      style=${(0,w.V)({cursor:n?"text":"pointer"})}
                      .databaseModel=${this.databaseModel}
                      .select=${e}
                      .editing=${n}
                      .index=${i}
                      .saveSelectionName=${this._onSaveSelectionName}
                      .setEditingIndex=${this._setEditingIndex}
                    ></affine-database-select-option>
                  </div>
                  <div class="select-option-icon" @click=${n?()=>this._onSaveSelectionName(i):()=>this._showSelectAction(i)}>
                    ${n?B._U:T.xh}
                  </div>
                </div>
              `})}
        </div>
      </div>
    `}};ts.styles=ta,ts.tag=A.i0`affine-database-select-cell-editing`,to([(0,u.Cb)()],ts.prototype,"mode",void 0),to([(0,u.IO)(".select-input")],ts.prototype,"_selectInput",void 0),to([(0,u.SB)()],ts.prototype,"_inputValue",void 0),to([(0,u.SB)()],ts.prototype,"_editingIndex",void 0),to([(0,u.SB)()],ts.prototype,"_selectedOptionIndex",void 0),to([(0,u.IO)(".select-option-container")],ts.prototype,"_selectOptionContainer",void 0),ts=to([(0,u.Mo)("affine-database-select-cell-editing")],ts);let tl=class extends eu{constructor(){super(...arguments),this.cellType="select"}render(){let e=this.cell?.value??[];return A.dy`
      <div
        class="affine-database-select-cell-container"
        style=${(0,w.V)({maxWidth:`${this.column.width}px`})}
      >
        ${e.map(e=>{let t=(0,w.V)({backgroundColor:e.color});return A.dy`<span class="select-selected" style=${t}
            >${e.value}</span
          >`})}
      </div>
    `}};tl.styles=h.iv`
    affine-database-select-cell {
      display: flex;
      align-items: center;
      width: calc(100% + 8px);
      height: 100%;
      margin: -2px -4px;
    }
    .affine-database-select-cell-container * {
      box-sizing: border-box;
    }
    .affine-database-select-cell-container {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px;
      width: 100%;
      cursor: pointer;
      font-size: var(--affine-font-sm);
    }
    .affine-database-select-cell-container .select-selected {
      height: 28px;
      padding: 2px 10px;
      border-radius: 4px;
      white-space: nowrap;
      background: var(--affine-tag-white);
    }
  `,tl.tag=A.i0`affine-database-select-cell`,tl=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,u.Mo)("affine-database-select-cell")],tl);let td=ef("select",()=>({selection:[]}),()=>[],{Cell:tl,CellEditing:ts},{displayName:"Select"});var tc=i(62610),th=i(67704);class tu{constructor(e,t){this._disposables=new y.SJ,this._service=null,this._startCell=null,this._database=null,this._columnWidthHandles=[],this._startRange=null,this._rowIds=[],this._isInDatabase=!1,this._onDragStart=e=>{let t=e.get("pointerState"),{clientX:i,clientY:n,target:o}=t.raw;if(this._isInDatabase=(0,th.pD)(o),!this._isInDatabase)return!1;let r=(0,y.Qo)(i,n);if(this._startRange=r,!(0,_.YK)(t)){let e=document.elementFromPoint(i,n);this._startCell=e?.closest(".database-cell")??null;let t=(0,th.uW)(this._startCell);this._database=t,this._columnWidthHandles=Array.from(t.querySelectorAll(".affine-database-column-drag-handle")),this._setColumnWidthHandleDisplay("none")}return!0},this._onDragMove=e=>{if(!this._isInDatabase)return!1;let t=e.get("pointerState");t.raw.preventDefault();let{clientX:i,clientY:n,target:o}=t.raw;if(!(0,th.pD)(o))return!1;let r=Array.from(document.elementsFromPoint(i,n)),a=r.find(e=>e.classList.contains("database-cell")),s=this._startCell;if(!a||!s||!this._database)return!1;if(a===s){let e=r.find(e=>e.classList.contains("virgo-editor"));if(e){let{left:n,right:o}=e.getBoundingClientRect();if(i<=n+1||i>=o-1)return!0;(0,_.cS)(this._startRange,t)}this._rowIds.length>0&&this._clearRowSelection()}else{t.raw.preventDefault(),(0,_.xT)(null);let e=(0,th.g5)(s,a),i=(0,th.wy)(this._database,e);this._rowIds=i;let n=(0,th.tJ)(a);this._service?.setRowSelection({type:"select",rowIds:i,databaseId:n})}return!0},this._onDragEnd=e=>{let t=e.get("pointerState"),i=t.raw.target;(0,th.pD)(i)&&(this._startRange=null,this._setColumnWidthHandleDisplay("block"))},this._onClick=e=>{let t=e.get("pointerState"),i=t.raw.target;if(i instanceof tc.DU)return;let n=this._service?.getLastRowSelection();n&&this._clearRowSelection()},this._onKeydown=e=>{let t=e.get("keyboardState"),i=t.raw,n=i.key;if("Delete"===n||"Backspace"===n)this._onRowSelectionDelete();else if("Escape"===n){let e=(0,e7.getService)("affine:database"),t=e.getLastCellSelection();if(t){let{databaseId:i,coords:[n]}=t;e.clearCellLevelSelection();let o=(0,e4.KP)(i),r=(0,th.wy)(o,[n.rowIndex]);e.setRowSelection({type:"select",rowIds:r,databaseId:i})}}},this._onRowSelectionDelete=()=>{let e=(0,e7.getService)("affine:database"),t=e.getLastRowSelection();if(!t)return;let{rowIds:i}=t,n=this._model.page,o=this._model.children;return n.captureSync(),o.length===i.length?n.deleteBlock(this._model):n.updateBlock(this._model,{children:o.filter(e=>-1===i.indexOf(e.id))}),e.clearRowSelection(),!0},this._add=(e,t)=>{this._disposables.add(this._dispatcher.add(e,t))},this._dispatcher=e,this._model=t,this._service=(0,e7.getService)("affine:database"),this._add("dragStart",this._onDragStart),this._add("dragMove",this._onDragMove),this._add("dragEnd",this._onDragEnd),this._add("click",this._onClick),this._add("keyDown",this._onKeydown)}_setColumnWidthHandleDisplay(e){this._columnWidthHandles.forEach(t=>{t.style.display=e})}_clearRowSelection(){this._rowIds=[],this._service?.clearRowSelection(),(0,_.xT)(null)}dispose(){this._disposables.dispose()}}var tf=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let tp=h.iv`
  affine-database-table {
    position: relative;
  }

  .affine-database-block-title-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 44px;
    margin: 18px 0 0;
  }

  .affine-database-block-table {
    position: relative;
    width: 100%;
    padding-bottom: 4px;
    overflow-x: scroll;
    overflow-y: hidden;
    border-top: 1.5px solid var(--affine-border-color);
  }
  .affine-database-block-table:hover {
    padding-bottom: 0px;
  }
  .affine-database-block-table::-webkit-scrollbar {
    -webkit-appearance: none;
    display: block;
  }
  .affine-database-block-table::-webkit-scrollbar:horizontal {
    height: 4px;
  }
  .affine-database-block-table::-webkit-scrollbar-thumb {
    border-radius: 2px;
    background-color: var(--affine-black-10);
  }
  .affine-database-block-table:hover::-webkit-scrollbar:horizontal {
    height: 8px;
  }
  .affine-database-block-table:hover::-webkit-scrollbar-thumb {
    border-radius: 16px;
    background-color: var(--affine-black-30);
  }
  .affine-database-block-table:hover::-webkit-scrollbar-track {
    background-color: var(--affine-hover-color);
  }

  .affine-database-table-container {
    position: relative;
    width: fit-content;
    min-width: 100%;
  }

  .affine-database-block-tag-circle {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    display: inline-block;
  }

  .affine-database-block-tag {
    display: inline-flex;
    border-radius: 11px;
    align-items: center;
    padding: 0 8px;
    cursor: pointer;
  }

  .affine-database-block-footer {
    display: flex;
    width: 100%;
    height: 28px;
    margin-top: -8px;
  }
  .affine-database-block-footer:hover {
    position: relative;
    z-index: 1;
    background-color: var(--affine-hover-color-filled);
  }
  .affine-database-block-footer:hover .affine-database-block-add-row {
    display: flex;
  }

  .affine-database-block-add-row {
    display: none;
    flex: 1;
    align-items: center;
    justify-content: center;
    gap: 4px;
    width: 100%;
    height: 100%;
    cursor: pointer;
    user-select: none;
    font-size: 14px;
  }
  .affine-database-block-add-row svg {
    width: 16px;
    height: 16px;
  }

  ${eD.a}
`,tg=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this.flavour="affine:database",this._searchState=l.SearchIcon,this._filteredRowIds=[],this._hoverState=!1,this._columnRenderer=function(){let e=new ep;return e.register(eW),e.register(td),e.register(eU),e.register(e2),e.register(eG),e.register(eH),e}(),this._initRowSelectionEvents=()=>{this._rowSelection=new tu(this.root.uiEventDispatcher,this.model)},this._initCellSelectionEvents=()=>{this._cellSelection=new e9(this.root.uiEventDispatcher,this.model)},this._setFilteredRowIds=e=>{this._filteredRowIds=e},this._setSearchState=e=>{this._searchState=e},this._onDatabaseScroll=e=>{this._columnHeaderComponent.showAddColumnButton()},this._onMouseOver=()=>{this._hoverState=!0},this._onMouseLeave=()=>{this._searchState===l.SearchIcon&&this._updateHoverState()},this._onClick=()=>{setTimeout(()=>{V(this,()=>{this._searchState!==l.Searching&&(this._resetHoverState(),this._resetSearchState())},"mousedown")})},this._addRow=e=>{if(this.readonly)return;let t=this._searchState;this._resetSearchState(),this._resetHoverState();let i=this.model.page;i.captureSync();let n=i.addBlock("affine:paragraph",{},this.model.id,e);(0,H.a6)(i,n),this._setSearchState(t)},this._addColumn=e=>{if(this.readonly)return;this.model.page.captureSync();let t=this.model.columns,i="multi-select",n=this._columnRenderer.get(i),o={type:i,name:`Column ${t.length+1}`,width:j.cV,hide:!1,...n.propertyCreator()},r=this.model.addColumn(o,e);this.model.applyColumnUpdate(),requestAnimationFrame(()=>{this._columnHeaderComponent.setEditingColumnId(r)})}}get columnRenderer(){return this._columnRenderer}get columns(){return this.model.columns}get readonly(){return this.model.page.readonly}connectedCallback(){super.connectedCallback(),this._updateHoverState(),this._initRowSelectionEvents(),this._initCellSelectionEvents();let e=this._disposables;e.addFromEvent(this,"mouseover",this._onMouseOver),e.addFromEvent(this,"mouseleave",this._onMouseLeave),e.addFromEvent(this,"click",this._onClick),e.addFromEvent(this,"keydown",this._cellSelection.onCellSelectionChange)}firstUpdated(){if(this.model.propsUpdated.on(()=>{this.requestUpdate(),this.querySelectorAll("affine-database-cell-container").forEach(e=>{e.requestUpdate()}),this.querySelector("affine-database-column-header")?.requestUpdate()}),this.model.childrenUpdated.on(()=>{this.requestUpdate(),this.querySelectorAll("affine-database-cell-container").forEach(e=>{e.requestUpdate()}),this.querySelector("affine-database-column-header")?.requestUpdate(),this._updateHoverState()}),this.readonly)return;let e=this._tableContainer.parentElement;(0,I.kP)(e),this._disposables.addFromEvent(e,"scroll",this._onDatabaseScroll)}_updateHoverState(){if(0===this.model.children.length){this._hoverState=!0;return}this._resetHoverState()}disconnectedCallback(){super.disconnectedCallback(),this._rowSelection.dispose(),this._cellSelection.dispose()}_resetSearchState(){this._searchState=l.SearchIcon}_resetHoverState(){this._hoverState=!1}render(){let e=function(e,t,i,n){let o=e.model,r=o.columns,a=i===l.Searching?o.children.filter(e=>t.indexOf(e.id)>-1):o.children;return h.dy`
    <style>
      .affine-database-block-rows {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
      }

      .affine-database-block-row {
        width: 100%;
        min-height: 44px;
        display: flex;
        flex-direction: row;
        border-bottom: 1px solid var(--affine-border-color);
      }
      .affine-database-block-row.selected > .database-cell {
        background: transparent;
      }
      .affine-database-block-row > .affine-database-block-row-cell:first-child {
        background: var(--affine-hover-color);
      }
      .affine-database-block-row > .database-cell {
        background: var(--affine-white);
      }

      .affine-database-block-row-cell-content {
        display: flex;
        align-items: center;
        height: 100%;
        min-height: 44px;
        padding: 0 8px;
        border-right: 1px solid var(--affine-border-color);
        transform: translateX(0);
      }
      .affine-database-block-row-cell-content > [data-block-id] {
        width: 100%;
      }
      .affine-database-block-row-cell-content > affine-paragraph {
        display: flex;
        align-items: center;
        width: 100%;
        height: 100%;
      }
      .affine-database-block-row-cell-content > affine-paragraph > .text {
        width: 100%;
        margin-top: unset;
      }
      .database-cell {
        min-width: ${j.vq}px;
      }
      .database-cell:last-child affine-database-cell-container {
        border-right: none;
      }
    </style>
    <div class="affine-database-block-rows">
      ${(0,z.r)(a,e=>e.id,(t,i)=>{let a=(0,w.V)({width:`${o.titleColumnWidth}px`});return h.dy`
            <div
              class="affine-database-block-row database-row"
              data-row-index="${i}"
              data-row-id="${t.id}"
            >
              <div
                class="affine-database-block-row-cell database-cell"
                style=${a}
              >
                <div class="affine-database-block-row-cell-content">
                  ${n.renderModel(t)}
                </div>
              </div>
              ${(0,z.r)(r,i=>h.dy`
                  <div
                    class="database-cell"
                    style=${(0,w.V)({width:`${i.width}px`})}
                  >
                    <affine-database-cell-container
                      .databaseModel=${o}
                      .rowModel=${t}
                      .column=${i}
                      .columnRenderer=${e.columnRenderer}
                    >
                    </affine-database-cell-container>
                  </div>
                `)}
              <div class="database-cell add-column-button"></div>
            </div>
          `})}
    </div>
  `}(this,this._filteredRowIds,this._searchState,this.root);return A.dy`
      <div class="affine-database-table">
        <div class="affine-database-block-title-container">
          <affine-database-title
            .addRow=${this._addRow}
            .targetModel=${this.model}
          ></affine-database-title>
          <affine-database-toolbar
            .addRow=${this._addRow}
            .targetModel=${this.model}
            .hoverState=${this._hoverState}
            .searchState=${this._searchState}
            .setSearchState=${this._setSearchState}
            .setFilteredRowIds=${this._setFilteredRowIds}
          ></affine-database-toolbar>
        </div>
        <div class="affine-database-block-table">
          <div class="affine-database-table-container">
            <affine-database-column-header
              .columns=${this.columns}
              .targetModel=${this.model}
              .addColumn=${this._addColumn}
              .columnRenderer=${this.columnRenderer}
            ></affine-database-column-header>
            ${e}
          </div>
        </div>
        ${this.readonly?null:A.dy`<div class="affine-database-block-footer">
              <div
                class="affine-database-block-add-row"
                data-test-id="affine-database-add-row-button"
                role="button"
                @click=${()=>this._addRow()}
              >
                ${T.pO}<span>New Record</span>
              </div>
            </div>`}
      </div>
    `}};tg.styles=tp,tf([(0,u.Cb)()],tg.prototype,"model",void 0),tf([(0,u.Cb)()],tg.prototype,"root",void 0),tf([(0,u.IO)(".affine-database-table-container")],tg.prototype,"_tableContainer",void 0),tf([(0,u.IO)("affine-database-column-header")],tg.prototype,"_columnHeaderComponent",void 0),tf([(0,u.SB)()],tg.prototype,"_searchState",void 0),tf([(0,u.SB)()],tg.prototype,"_filteredRowIds",void 0),tf([(0,u.SB)()],tg.prototype,"_hoverState",void 0),tg=tf([(0,u.Mo)("affine-database-table")],tg);var tm=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let tv=h.iv`
  affine-database-kanban {
    position: relative;
  }
`,tb=class extends(0,C.$T)(C.Zi){constructor(){super(...arguments),this.flavour="affine:database"}get slots(){return this.host.slots}get page(){return this.host.page}get clipboard(){return this.host.clipboard}get getService(){return this.host.getService}connectedCallback(){super.connectedCallback()}render(){return A.dy`<div class="affine-database-kanban">kanban view</div>`}};tb.styles=tv,tm([(0,u.Cb)()],tb.prototype,"model",void 0),tm([(0,u.Cb)()],tb.prototype,"host",void 0),tb=tm([(0,u.Mo)("affine-database-kanban")],tb);var tC=i(91519);let ty=class extends C.z3{connectedCallback(){super.connectedCallback(),(0,e7.registerService)("affine:database",tC.q),this.model.propsUpdated.on(()=>this.requestUpdate())}render(){let e=A.i0`affine-database-${(0,A.s2)(this.model.mode)}`;return A.dy`
      <${e}
        .root=${this.root}
        .model=${this.model}
        class="affine-block-element"
      ></${e}>
    `}};ty=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,u.Mo)("affine-database")],ty);var tx=i(72447),tw=i(50217),t_=i(23862);function tk(e){let t=window.getComputedStyle(e),i=t_.qn.reduce((e,i)=>{let n=t.getPropertyValue(i).trim();return e[i]=n,"--affine-palette-transparent"!==i||n||(e[i]="#00000000"),e},{});return i}class tM extends y.g7{constructor(){super(...arguments),this._mode="",this._cssVariables=null}get cssVariables(){return this._cssVariables}observer(e){this._observer?.disconnect(),this._cssVariables=tk(e),this._observer=new MutationObserver(()=>{let t=e.getAttribute("data-theme");this._mode!==t&&(this._cssVariables=tk(e),this.emit(this._cssVariables))}),this._observer.observe(e,{attributes:!0,attributeFilter:["data-theme"]})}dispose(){super.dispose(),this._observer?.disconnect()}}var tS=i(903),tE=i(68389),tL=i(50972),t$=i(48616),tP=i(63989),tB=i(70263),tR=i(62624),tT=i(22232),tO=i(56347),tI=i(71281),tD=i(91097),tz=i(1669),tA=i(64705),tH=i(11396),tV=i(73454),tZ=i(1908),tF=i(82179),tU=i(58046);let tj=new Map([[tF.h,A.i0`affine-default-page`],[P.f,A.i0`affine-surface`],[tZ.Q,A.i0`affine-list`],[tV.i,A.i0`affine-frame`],[tx.E,A.i0`affine-database`],[tA.q,A.i0`affine-divider`],[tz._,A.i0`affine-code`],[tH.R,A.i0`affine-embed`],[tU.v,A.i0`affine-paragraph`],[tT.mN,A.i0`affine-bookmark`]]),tN=new Map([[tF.h,A.i0`affine-edgeless-page`],[P.f,A.i0`affine-surface`],[tZ.Q,A.i0`affine-list`],[tV.i,A.i0`affine-frame`],[tx.E,A.i0`affine-database`],[tA.q,A.i0`affine-divider`],[tz._,A.i0`affine-code`],[tH.R,A.i0`affine-embed`],[tU.v,A.i0`affine-paragraph`],[tT.mN,A.i0`affine-bookmark`]]),tW="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},tq="__ $BLOCKSUITE_BLOCKS$ __";if(!0===tW[tq]&&console.error("@blocksuite/blocks was already imported. This breaks constructor checks and will lead to issues!"),"undefined"==typeof window)throw Error("Seems like you are importing @blocksuite/blocks in SSR mode. Which is not supported for now.");tW[tq]=!0},37960:function(e,t,i){"use strict";i.d(t,{EH:function(){return w},QT:function(){return _.Q},pu:function(){return g}}),i(84954);var n=i(67072),o=i(50634),r=i(13246),a=i(15486),s=i(32916),l=i(81366),d=i(9386),c=i(46646),h=i(280),u=i(59799),f=i(88523),p=i(7291);class g extends f.b{block2html(e,{childText:t="",begin:i,end:n}={}){let o=super.block2html(e,{childText:t,begin:i,end:n}),r=e.page.getPreviousSibling(e),a=e.page.getNextSibling(e);switch(e.type){case"bulleted":case"toggle":case"numbered":o=`<li>${o}</li>`;break;case"todo":o=`<li><input disabled type="checkbox" ${e.checked?"checked":""}>${o}</li>`}if(r?.flavour!==e.flavour||r.type!==e.type)switch(e.type){case"bulleted":case"toggle":case"todo":o=`<ul>${o}`;break;case"numbered":o=`<ol>${o}`}if(a?.flavour!==e.flavour||a.type!==e.type)switch(e.type){case"bulleted":case"toggle":case"todo":o=`${o}</ul>`;break;case"numbered":o=`${o}</ol>`}return o}async json2Block(e,t,i){let n="affine:list"!==t[0].flavour;return(0,p.V)(e,t,{range:i,convertToPastedIfEmpty:n})}}function m(e){let t="";for(;e>=0;)t=String.fromCharCode(e%26+97)+t,e=Math.floor(e/26)-1;return t}var v=i(77831);let b=e=>{let t=e.page.getParent(e)?.children||[],i=t.findIndex(t=>t===e),n=0;for(let o=0;o<i;o++)t[o].flavour===e.flavour&&t[o].type===e.type?n+=1:n=0;return n},C=e=>{let t=0,i=e.page.getParent(e);for(;i?.flavour===e.flavour;)t++,i=e.page.getParent(i);return t},y=e=>{let t=C(e),i=b(e);return{deep:t,index:i}};var x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=class extends o.z3{constructor(){super(...arguments),this.showChildren=!0,this.textSchema={attributesSchema:c.D,textRenderer:d.O},this._onClickIcon=e=>{if(e.stopPropagation(),"toggle"===this.model.type){this.showChildren=!this.showChildren;return}if("todo"===this.model.type){this.model.page.captureSync();let e={checked:!this.model.checked};this.model.page.updateBlock(this.model,e);return}this._select()}}_select(){let e=(0,l.De)(this.model);(0,r.kP)(e),e instanceof u.DefaultPageBlockComponent&&e.selection.selectOneBlock(this)}firstUpdated(){this.model.propsUpdated.on(()=>this.requestUpdate()),this.model.childrenUpdated.on(()=>this.requestUpdate())}connectedCallback(){super.connectedCallback(),(0,h.registerService)("affine:list",g)}render(){let{deep:e,index:t}=y(this.model),{model:i,showChildren:o,_onClickIcon:r}=this,s=function(e,t,i,n,o){let r=(()=>{switch(e.type){case"bulleted":return v.Ym[i%v.Ym.length];case"numbered":return function(e,t){let i=function(e,t){let i=[()=>t+1,m,()=>(function(e){let t={M:1e3,CM:900,D:500,CD:400,C:100,XC:90,L:50,XL:40,X:10,IX:9,V:5,IV:4,I:1},i="";for(let n in t)for(;e>=t[n];)i+=n,e-=t[n];return i})(t+1)];return i[e%i.length](t)}(t,e);return`${i} .`}(t,i);case"todo":return e.checked?(0,v.TF)():(0,v.XN)();case"toggle":return n?(0,v.VX)():(0,v.Bo)(e.children.length>0);default:return""}})();return a.dy`
    <div
      class="affine-list-block__prefix ${"todo"===e.type?"affine-list-block__todo-prefix":""}"
      @click="${e=>o(e)}"
    >
      ${r}
    </div>
  `}(i,t,e,o,r),l=a.dy`<div
      class="affine-block-children-container"
      style="padding-left: ${n.qL}px"
    >
      ${this.content}
    </div>`;return a.dy`
      <div
        class=${`affine-list-block-container ${0===t&&0===e?"affine-list-block-container--first":""}`}
      >
        <div
          class=${`affine-list-rich-text-wrapper ${this.model.checked?"affine-list--checked":""}`}
        >
          ${s}
          <rich-text
            .model=${this.model}
            .textSchema=${this.textSchema}
          ></rich-text>
        </div>
        ${this.showChildren?l:a.Ld}
      </div>
    `}};w.styles=a.iv`
    .affine-list-block-container {
      box-sizing: border-box;
      border-radius: 5px;
      margin-top: 2px;
    }
    .affine-list-block-container--first {
      margin-top: var(--affine-paragraph-space);
    }
    .affine-list-block-container .affine-list-block-container {
      margin-top: 0;
    }
    .affine-list-block-container.selected {
      background-color: var(--affine-hover-color);
    }
    .affine-list-rich-text-wrapper {
      display: flex;
      align-items: center;
    }
    .affine-list-rich-text-wrapper rich-text {
      flex: 1;
    }

    .affine-list-block__prefix {
      flex-shrink: 0;
      min-width: 26px;
      height: 26px;
      margin-right: 4px;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      align-self: flex-start;
      color: var(--affine-list-color);
      font-size: 14px;
      line-height: var(--affine-line-height);
      user-select: none;
    }
    .affine-list-block__todo-prefix {
      cursor: pointer;
    }
    .affine-list-block__todo {
      width: 16px;
      height: 16px;
      border-radius: 4px;
      border: 1px solid var(--affine-icon-color);
    }
    .affine-list-block__todo.affine-list-block__todo--active {
      background: var(--affine-icon-color);
    }

    .affine-list--checked {
      color: var(--affine-icon-color);
    }
  `,x([(0,s.SB)()],w.prototype,"showChildren",void 0),w=x([(0,s.Mo)("affine-list")],w);var _=i(1908)},77831:function(e,t,i){"use strict";i.d(t,{Bo:function(){return o},TF:function(){return a},VX:function(){return r},XN:function(){return s},Ym:function(){return l}});var n=i(15486);let o=(e=!0)=>n.dy`
    <svg
      xmlns="http://www.w3.org/2000/svg"
      data-is-toggle-icon="true"
      width="1em"
      height="1em"
      viewBox="0 0 20 20"
    >
      <path
        data-is-toggle-icon="true"
        fill="currentColor"
        opacity="${e?"1":"0.6"}"
        d="m15.795 11.272l-8 5A1.5 1.5 0 0 1 5.5 15V5a1.5 1.5 0 0 1 2.295-1.272l8 5a1.5 1.5 0 0 1 0 2.544Z"
      />
    </svg>
  `,r=()=>n.dy`
    <svg
      xmlns="http://www.w3.org/2000/svg"
      data-is-toggle-icon="true"
      width="1em"
      height="1em"
      viewBox="0 0 20 20"
      @mousedown="${e=>{}}"
    >
      <path
        data-is-toggle-icon="true"
        fill="currentColor"
        d="m8.728 15.795l-5-8A1.5 1.5 0 0 1 5 5.5h10a1.5 1.5 0 0 1 1.272 2.295l-5 8a1.5 1.5 0 0 1-2.544 0Z"
      />
    </svg>
  `,a=()=>n.dy`
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7 4C5.34315 4 4 5.34315 4 7V17C4 18.6569 5.34315 20 7 20H17C18.6569 20 20 18.6569 20 17V7C20 5.34315 18.6569 4 17 4H7ZM17.5665 9.56473C17.8785 9.25181 17.8776 8.74528 17.5647 8.43336C17.2518 8.12144 16.7453 8.12225 16.4334 8.43517L10.3547 14.5333L7.56666 11.7352C7.2548 11.4222 6.74827 11.4213 6.43529 11.7331C6.1223 12.045 6.12139 12.5515 6.43325 12.8645L9.64626 16.0891C10.037 16.4813 10.672 16.4814 11.0629 16.0893L17.5665 9.56473Z"
        fill="#A6ABB7"
      />
    </svg>
  `,s=()=>n.dy`
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M17 5.6H7C6.2268 5.6 5.6 6.2268 5.6 7V17C5.6 17.7732 6.2268 18.4 7 18.4H17C17.7732 18.4 18.4 17.7732 18.4 17V7C18.4 6.2268 17.7732 5.6 17 5.6ZM7 4C5.34315 4 4 5.34315 4 7V17C4 18.6569 5.34315 20 7 20H17C18.6569 20 20 18.6569 20 17V7C20 5.34315 18.6569 4 17 4H7Z"
        fill="#A6ABB7"
      />
    </svg>
  `,l=[n.dy`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <circle cx="12" cy="12" r="2" />
    </svg>
  `,n.dy`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12 13.5C12.8284 13.5 13.5 12.8284 13.5 12C13.5 11.1716 12.8284 10.5 12 10.5C11.1716 10.5 10.5 11.1716 10.5 12C10.5 12.8284 11.1716 13.5 12 13.5ZM12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14Z"
      />
    </svg>
  `,n.dy`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path
        d="M11.6056 10.1634C11.8234 9.94555 12.1766 9.94555 12.3944 10.1634L13.8366 11.6056C14.0545 11.8234 14.0545 12.1766 13.8366 12.3944L12.3944 13.8366C12.1766 14.0545 11.8234 14.0545 11.6056 13.8366L10.1634 12.3944C9.94555 12.1766 9.94555 11.8234 10.1634 11.6056L11.6056 10.1634Z"
      />
    </svg>
  `,n.dy`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M13.4422 12L12 10.5578L10.5578 12L12 13.4422L13.4422 12ZM12.3944 10.1634C12.1766 9.94555 11.8234 9.94555 11.6056 10.1634L10.1634 11.6056C9.94555 11.8234 9.94555 12.1766 10.1634 12.3944L11.6056 13.8366C11.8234 14.0545 12.1766 14.0545 12.3944 13.8366L13.8366 12.3944C14.0545 12.1766 14.0545 11.8234 13.8366 11.6056L12.3944 10.1634Z"
        fill="#7389FD"
      />
    </svg>
  `]},93251:function(e,t,i){"use strict";i.d(t,{DL:function(){return p},GN:function(){return d},Kf:function(){return h},Ql:function(){return u},_x:function(){return c},dx:function(){return m},rV:function(){return g}});var n=i(31054),o=i(36976),r=i(81366),a=i(280),s=i(91097),l=i(37666);async function d(e){let t;let i=await f(e);if(!i)return;let n=await i.arrayBuffer(),o=new Uint8Array(n);71===o[0]&&73===o[1]&&70===o[2]&&56===o[3]?t="image/gif":137===o[0]&&80===o[1]&&78===o[2]&&71===o[3]?t="image/png":255===o[0]&&216===o[1]&&255===o[2]&&224===o[3]?t="image/jpeg":(console.error("unknown image type"),t="image/png");let r=URL.createObjectURL(new Blob([n],{type:t})),a=document.createElement("a"),s=new MouseEvent("click");a.download="image",a.href=r,a.dispatchEvent(s),a.remove(),URL.revokeObjectURL(r)}async function c(e){(0,o.p3)({type:"Block",models:[e],startOffset:0,endOffset:0}),(0,l.A)("Copied image to clipboard")}async function h(e){let t=e.text?e.text.toDelta():[],i={data:[{type:e.type,flavour:e.flavour,sourceId:e.sourceId,text:t,children:[]}]},n=function(e){let t=!1,i=document.createElement("textarea");i.value="temp",document.body.appendChild(i),i.select(),i.setSelectionRange(0,i.value.length);let n=t=>{let o=t.clipboardData;o&&e.forEach(e=>o.setData(e.mimeType,e.data)),t.preventDefault(),t.stopPropagation(),i.removeEventListener("copy",n)};i.addEventListener("copy",n);try{t=document.execCommand("copy")}finally{i.removeEventListener("copy",n),document.body.removeChild(i)}return t}([{mimeType:"blocksuite/x-c+w",data:JSON.stringify(i)},{mimeType:"text/plain",data:e.text?.toString()||""}]);return n}function u(e){let t=(0,r._b)(e);(0,n.kP)(t);let i=t.querySelector(".affine-embed-wrapper-caption");i.classList.add("caption-show"),i.focus()}async function f(e){(0,n.kP)(e.sourceId);let t=await e.page.blobs,i=t?.get(e.sourceId);return i}function p(e){(0,o.p3)({type:"Block",models:[e],startOffset:0,endOffset:0}),(0,l.A)("Copied to clipboard")}function g(e){let t=[],i=e.children.slice(),n=e=>{for(let i of e)"affine:frame"!==i.flavour&&t.push(i),i.children.length&&n(i.children)};return n(i),t}function m(e){return new s.DU({container:e.mouseRoot,onDropCallback(t,i,o,s){if(!o||"none"===s)return;let{model:l}=o,d=e.page,c=(0,r.rc)(i).map(r.gc);if(1===c.length&&(0,r.k)(d,l,c[0]))return;d.captureSync();let h=d.getParent(l),u=d.getParent(c[0]);"database"===s?d.moveBlocks(c,l):((0,n.kP)(h),d.moveBlocks(c,h,l,"before"===s)),e.updateComplete.then(()=>{if(u&&(0,n.h$)(u,["affine:database"])){let e=(0,a.getService)("affine:database");e.refreshRowSelection()}if(h&&(0,n.h$)(h,["affine:database"])){e.selection.clear();return}requestAnimationFrame(()=>{e.selection.setSelectedBlocks(i.map(e=>(0,r.cP)(e.model.id)).filter(e=>!!e))})})},setDragType(t){e.selection.state.type=t?"block:drag":"block"},setSelectedBlock(t,i){if(i&&i.closest("affine-database")){let t=(0,a.getService)("affine:database"),n=t.toggleRowSelection(i);if(n){e.selection.clear();return}}let o=t?.model;if(o){let e=o.page.getParent(o);if(e&&(0,n.h$)(e,["affine:database"])){let e=(0,a.getService)("affine:database");e.setRowSelectionByElement(t.element);return}}e.selection.selectOneBlock(t?.element,t?.rect);let r=(0,a.getServiceOrRegister)("affine:database");Promise.resolve(r).then(e=>{let t=e.getLastRowSelection();t&&e.clearRowSelection()})},getSelectedBlocks:()=>e.selection.state.selectedBlocks,getClosestBlockElement:t=>(0,r.cy)(t,{rect:e.innerRect})})}document.createElement("div")},1398:function(e,t,i){"use strict";i.d(t,{EJ:function(){return h},Gs:function(){return p},Qm:function(){return u}});var n=i(7339),o=i(15486),r=i(32916),a=i(57891),s=i(91827),l=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class d extends Event{constructor(e,{detail:t,composed:i,bubbles:n}){super(e,{bubbles:n,composed:i}),this.detail=t}}let c=["--affine-palette-line-yellow","--affine-palette-line-orange","--affine-palette-line-tangerine","--affine-palette-line-red","--affine-palette-line-magenta","--affine-palette-line-purple","--affine-palette-line-green","--affine-palette-line-blue","--affine-palette-line-navy","--affine-palette-line-black","--affine-palette-line-grey","--affine-palette-line-white"],h="--affine-palette-line-black";function u(e){return"--affine-palette-transparent"===e.toLowerCase()}function f(e){return["--affine-palette-line-white","--affine-palette-shape-white"].includes(e.toLowerCase())}function p(e,{hollowCircle:t,letter:i}={}){var r;let a=(r=!!t,u(e)?function(e=!1){let t=e?o.dy`<div style=${(0,s.V)({position:"absolute",width:"10px",height:"10px",left:"3px",top:"3.5px",borderRadius:"50%",background:"var(--affine-popover-background)"})}></div>`:o.Ld;return o.dy`<div style=${(0,s.V)({position:"relative",width:"16px",height:"16px",stroke:"none"})}>
    ${n.wR} ${t}
  </div>`}(r):r?function(e){let t=f(e)?1:0,i={fill:`var(${e})`,stroke:"var(--affine-border-color)"};return o.dy`<svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M12.3125 8C12.3125 10.3817 10.3817 12.3125 8 12.3125C5.61827 12.3125 3.6875 10.3817 3.6875 8C3.6875 5.61827 5.61827 3.6875 8 3.6875C10.3817 3.6875 12.3125 5.61827 12.3125 8ZM8 15.5C12.1421 15.5 15.5 12.1421 15.5 8C15.5 3.85786 12.1421 0.5 8 0.5C3.85786 0.5 0.5 3.85786 0.5 8C0.5 12.1421 3.85786 15.5 8 15.5Z"
      stroke-width="${t}"
      style=${(0,s.V)(i)}
    />
  </svg> `}(e):o.Ld),l=t?{}:{background:`var(${e})`},d=f(e)&&!t?{border:"1px solid var(--affine-border-color)"}:{},c={display:"flex",alignItems:"center",justifyContent:"center",width:"16px",height:"16px",borderRadius:"50%",boxSizing:"border-box",overflow:"hidden",...d,...l};return o.dy`<div
    class="color-unit"
    style=${(0,s.V)(c)}
    aria-label=${e.toLowerCase()}
    data-letter=${i?"A":""}
  >
    ${a}
  </div>`}let g=class extends o.oi{constructor(){super(...arguments),this.options=c,this.showLetterMark=!1,this.hollowCircle=!1}_onSelect(e){this.dispatchEvent(new d("select",{detail:e,composed:!0,bubbles:!0})),this.value=e}render(){return(0,a.r)(this.options,e=>e,e=>{let t=p(e,{hollowCircle:this.hollowCircle,letter:this.showLetterMark});return o.dy`
          <div
            class="color-container"
            ?active=${e===this.value}
            @click=${()=>this._onSelect(e)}
          >
            ${t}
          </div>
        `})}};g.styles=o.iv`
    :host {
      display: flex;
      width: 204px;
      padding: 8px 12px;
      flex-direction: row;
      flex-wrap: wrap;
      gap: 12px;
      box-sizing: border-box;
      background: var(--affine-popover-background);
    }

    .color-container {
      display: flex;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      box-sizing: border-box;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      cursor: pointer;
    }

    .color-container[active] {
      border: 1px solid var(--affine-primary-color);
    }

    .color-unit::before {
      content: attr(data-letter);
      display: block;
      font-size: 12px;
    }
  `,l([(0,r.Cb)()],g.prototype,"value",void 0),l([(0,r.Cb)()],g.prototype,"options",void 0),l([(0,r.Cb)()],g.prototype,"showLetterMark",void 0),l([(0,r.Cb)()],g.prototype,"hollowCircle",void 0),l([(0,r.Mo)("edgeless-color-panel")],g)},83035:function(e,t,i){"use strict";i.d(t,{ZM:function(){return p},LF:function(){return g}});var n=i(7339),o=i(15486),r=i(32916),a=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let s=class extends o.oi{constructor(){super(...arguments),this.value="left"}_onSelect(e){this.value=e,this.onSelect&&this.onSelect(e)}render(){return o.dy`
      <div class="align-panel-container">
        <edgeless-tool-icon-button
          .tooltip=${"Left"}
          .active=${"left"===this.value}
          @click=${()=>{this._onSelect("left")}}
        >
          ${n.jQ}
        </edgeless-tool-icon-button>
        <edgeless-tool-icon-button
          .tooltip=${"Center"}
          .active=${"center"===this.value}
          @click=${()=>{this._onSelect("center")}}
        >
          ${n.UP}
        </edgeless-tool-icon-button>
        <edgeless-tool-icon-button
          .tooltip=${"Right"}
          .active=${"right"===this.value}
          @click=${()=>{this._onSelect("right")}}
        >
          ${n.mh}
        </edgeless-tool-icon-button>
      </div>
    `}};s.styles=o.iv`
    :host {
      display: block;
      z-index: 2;
    }
    .align-panel-container {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
      fill: none;
      stroke: currentColor;
    }
  `,a([(0,r.Cb)()],s.prototype,"value",void 0),a([(0,r.Cb)()],s.prototype,"onSelect",void 0),s=a([(0,r.Mo)("edgeless-align-panel")],s);var l=i(50634),d=i(70263),c=i(1398),h=i(24335),u=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let f=["--affine-palette-line-yellow","--affine-palette-line-orange","--affine-palette-line-tangerine","--affine-palette-line-red","--affine-palette-line-magenta","--affine-palette-line-purple","--affine-palette-line-navy","--affine-palette-line-blue","--affine-palette-line-green","--affine-palette-line-white","--affine-palette-line-black","--affine-palette-line-grey"],p="--affine-palette-line-white",g="--affine-palette-line-black",m=class extends(0,l.$T)(o.oi){constructor(){super(...arguments),this.texts=[],this._popperShow=!1,this._colorSelectorPopper=null,this._textAlignPopper=null}_setTextColor(e){this.texts.forEach(t=>{this.surface.updateElement(t.id,{color:e})}),this.slots.selectionUpdated.emit({...this.selectionState})}_setTextAlign(e){this.texts.forEach(t=>{this.surface.updateElement(t.id,{textAlign:e})}),this.slots.selectionUpdated.emit({...this.selectionState})}firstUpdated(e){let t=this._disposables;this._colorSelectorPopper=(0,h.Rx)(this._textColorButton,this._textColorMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._colorSelectorPopper),this._textAlignPopper=(0,h.Rx)(this._textAlignButton,this._textAlignMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._textAlignPopper),super.firstUpdated(e)}render(){let e=function(e){let t=(0,d.VF)(e,e=>e.color),i=(0,d.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.texts)??"--affine-palette-line-yellow",t=function(e){let t=(0,d.VF)(e,e=>e.textAlign),i=(0,d.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:"left"}(this.texts);return o.dy`
      <edgeless-tool-icon-button
        class="text-color-button"
        .tooltip=${this._popperShow?"":"Text Color"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._colorSelectorPopper?.toggle()}
      >
        ${(0,c.Gs)(e)}
      </edgeless-tool-icon-button>
      <div class="color-panel-container text-color">
        <edgeless-color-panel
          .value=${e}
          .options=${f}
          @select=${e=>{this._setTextColor(e.detail)}}
        ></edgeless-color-panel>
      </div>

      <menu-divider .vertical=${!0}></menu-divider>

      <edgeless-tool-icon-button
        class="text-align-button"
        .tooltip=${this._popperShow?"":"Alignment"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._textAlignPopper?.toggle()}
      >
        ${"left"===t?n.jQ:"center"===t?n.UP:n.mh}
      </edgeless-tool-icon-button>
      <div class="align-panel-container text-align">
        <edgeless-align-panel
          .value=${t}
          .onSelect=${e=>{this._setTextAlign(e)}}
        ></edgeless-align-panel>
      </div>
    `}};m.styles=o.iv`
    :host {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      color: var(--affine-text-primary-color);
      stroke: none;
      fill: currentColor;
    }

    .color-panel-container,
    .align-panel-container {
      display: none;
      padding: 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    .color-panel-container[data-show],
    .align-panel-container[data-show] {
      display: block;
    }
  `,u([(0,r.Cb)()],m.prototype,"texts",void 0),u([(0,r.Cb)()],m.prototype,"page",void 0),u([(0,r.Cb)()],m.prototype,"surface",void 0),u([(0,r.Cb)()],m.prototype,"selectionState",void 0),u([(0,r.Cb)()],m.prototype,"slots",void 0),u([(0,r.SB)()],m.prototype,"_popperShow",void 0),u([(0,r.IO)(".text-color-button")],m.prototype,"_textColorButton",void 0),u([(0,r.IO)(".color-panel-container.text-color")],m.prototype,"_textColorMenu",void 0),u([(0,r.IO)(".text-align-button")],m.prototype,"_textAlignButton",void 0),u([(0,r.IO)(".align-panel-container.text-align")],m.prototype,"_textAlignMenu",void 0),u([(0,r.Mo)("edgeless-change-text-button")],m)},24335:function(e,t,i){"use strict";i.d(t,{Rx:function(){return h},TO:function(){return s},ae:function(){return l},wK:function(){return d},zH:function(){return u}});var n=i(45598),o=i(66208),r=i(15486),a=i(91636);function s(e,t=!1,i=!1){return{"--affine-border-width":`${t?2:1}px`,left:e.x+"px",top:e.y+"px",width:e.width+"px",height:e.height+"px",backgroundColor:!t&&i?"var(--affine-hover-color)":""}}function l(e,t){if(0===e.length)return new DOMRect(0,0,0,0);let i=e.map(e=>{let{x:i,y:n,width:o,height:r}=(0,a.ry)(t,(0,a.XA)(e));return{x:i,y:n,w:o,h:r}}),o=(0,n.ci)(i);return new DOMRect(o?.x,o?.y,o?.w,o?.h)}function d(e){let t=new Map;for(let i of e){let e;e=(0,a.Zi)(i)?n.Mb.deserialize((0,a.XA)(i)):new n.Mb(i.x,i.y,i.w,i.h),t.set(i.id,e)}return t}let c="data-show";function h(e,t,i=()=>{}){let n=(0,o.fi)(e,t,{placement:"top",modifiers:[{name:"offset",options:{offset:[0,12]}}]}),r=()=>{t.setAttribute(c,""),n.setOptions(e=>({...e,modifiers:[...e.modifiers??[],{name:"eventListeners",enabled:!1}]})),n.update(),i({display:"show"})},a=()=>{t.removeAttribute(c),n.setOptions(e=>({...e,modifiers:[...e.modifiers??[],{name:"eventListeners",enabled:!1}]})),i({display:"hidden"})},s=()=>{t.hasAttribute(c)?a():r()},l=function(e,t){let i=i=>{let n=i.composedPath().includes(e);n||t()};return document.addEventListener("click",i),{dispose:()=>{document.removeEventListener("click",i)}}}(e,()=>a());return{popper:n,show:r,hide:a,toggle:s,dispose:()=>{n.destroy(),l.dispose()}}}function u(e,t){return r.dy`<span>${e}</span
    ><span style="margin-left: 10px;">(${t})</span>`}},91636:function(e,t,i){"use strict";i.d(t,{GB:function(){return S},yC:function(){return E},g5:function(){return L},xM:function(){return M},Iq:function(){return k},j4:function(){return _},AL:function(){return q},F4:function(){return X},T7:function(){return H},sI:function(){return Z},Xy:function(){return W},ml:function(){return U},zr:function(){return D},ry:function(){return T},XA:function(){return O},bt:function(){return N},i1:function(){return j},Xd:function(){return P},Zi:function(){return $},RT:function(){return Y},YC:function(){return R},D9:function(){return z},sU:function(){return B},UW:function(){return I},Js:function(){return K}});class n{constructor(e){this._content=[],this._scoreFunction=e}push(e){this._content.push(e),this.sinkDown(this._content.length-1)}pop(){let{_content:e}=this,t=e[0],i=e.pop();return e.length>0&&(e[0]=i,this.bubbleUp(0)),t}remove(e){let{_content:t,_scoreFunction:i}=this,n=t.indexOf(e),o=t.pop();n!==t.length-1&&(t[n]=o,i(o)<i(e)?this.sinkDown(n):this.bubbleUp(n))}size(){return this._content.length}rescoreElement(e){this.sinkDown(this._content.indexOf(e))}sinkDown(e){let{_content:t,_scoreFunction:i}=this,n=this._content[e];for(;e>0;){let o=(e+1>>1)-1,r=t[o];if(i(n)<i(r))t[o]=n,t[e]=r,e=o;else break}}bubbleUp(e){let{_content:t,_scoreFunction:i}=this,n=t.length,o=t[e],r=i(o);for(;;){let a=e+1<<1,s=a-1,l=null,d=null;if(s<n){let e=t[s];(d=i(e))<r&&(l=s)}if(a<n){let e=t[a],n=i(e);n<(null===l?r:d)&&(l=a)}if(null!==l)t[e]=t[l],t[l]=o,e=l;else break}}}function o(e,t){return Math.abs(e.x-t.x)+Math.abs(e.y-t.y)}class r{constructor(e){this.nodes={},this.edges={},this.connections=[],this.gridX=[],this.gridY=[],this._init(e)}_init(e){this._addGraphNodesAndInitGrid(e),this._linkGraphNodes()}_createGraphNode(e){return{x:e.x,y:e.y,parent:null,cost:t=>{let i=Math.abs(e.x-t.x)+Math.abs(e.y-t.y),n=!!t.parent&&(t.x===t.parent.x&&t.x!==e.x||t.y===t.parent.y&&t.y!==e.y);return i+(n?10:0)},f:0,h:0,g:0}}_addGraphNodesAndInitGrid(e){let t=new Set,i=new Set;e.forEach(e=>{let n=this._createGraphNode(e);t.add(e.x),i.add(e.y);let o=r.getKey(e);this.nodes[o]=n,this.edges[o]=new Set}),this.gridX=[...t.values()].sort((e,t)=>e-t),this.gridY=[...i.values()].sort((e,t)=>e-t)}_linkGraphNodes(){let{gridX:e,gridY:t}=this;for(let i=0;i<e.length;i++)for(let n=0;n<t.length;n++){let o=r.getKey({x:e[i],y:t[n]});if(this.nodes[o]){if(n>0){let a=r.getKey({x:e[i],y:t[n-1]});this.nodes[a]&&(this.edges[o].add(a),this.edges[a].add(o),this.connections.push([this.nodes[o],this.nodes[a]]))}if(i>0){let a=r.getKey({x:e[i-1],y:t[n]});this.nodes[a]&&(this.edges[o].add(a),this.edges[a].add(o),this.connections.push([this.nodes[o],this.nodes[a]]))}}}}neighbors(e){let t=r.getKey(e),i=[];return this.edges[t].forEach(e=>{i.push(this.nodes[e])}),i}getNode(e){let t=r.getKey(e);return this.nodes[t]}static getKey({x:e,y:t}){return`${e}:${t}`}static parseKey(e){let[t,i]=e.split(":").map(e=>Number(e));return{x:t,y:i}}}var a=i(92007);function s(e,t){let{graph:i}=function(e,t,i=[10,10]){if(function(e,t){if(!e.length)return!0;if(1!==e.length||2!==t.length)return!1;let i=t[0].x,n=t[0].y,o=t[1].x,r=t[1].y,a=e[0],{x:s,y:l,maxX:d,maxY:c}=a,h=i<=s&&o<=a.x;return!!h||i>=d&&o>=d||n<=l&&r<=l||n>=c&&r>=c}(e,t))return function(e,t){let i=1===e.length&&(t[0].y<=e[0].y&&t[1].y<=e[0].y||t[0].y>=e[0].maxY&&t[1].y>=e[0].maxY),n=i?[{x:t[0].x,y:(t[0].y+t[1].y)/2},{x:t[1].x,y:(t[0].y+t[1].y)/2}]:[{x:(t[0].x+t[1].x)/2,y:t[0].y},{x:(t[0].x+t[1].x)/2,y:t[1].y}],o=[...t,...n,{x:(t[0].x+t[1].x)/2,y:(t[0].y+t[1].y)/2}],a=new r(o);return{rectangles:e,points:t,inflatedRectangles:[],rulers:{rows:[],columns:[]},nodes:o,graph:a}}(e,t);let n=e.map(e=>e.inflate(i[0],i[1])),o=function(e,t,i){let n=new Set,o=new Set;e.forEach(e=>{n.add(e.minX),n.add(e.maxX),o.add(e.minY),o.add(e.maxY)}),t.forEach(e=>{n.add(e.x),o.add(e.y)});let r=[...n.values()].sort((e,t)=>e-t),a=[...o.values()].sort((e,t)=>e-t);return{columns:[r[0]-i[0],...r,r[r.length-1]+i[0]],rows:[a[0]-i[1],...a,a[a.length-1]+i[1]]}}(n,t,i),a=function(e,t,i){let n=(e,i)=>t.find(t=>t.contains(e,i)),{nodes:o,addPoint:a,hasPoint:s,getGrid:l}=function(e){let t=[],i=new Set,n=new Set,o=new Set,a=(a,s,l=!1)=>{if(!l&&e(a,s))return;let d={x:a,y:s},c=r.getKey(d);i.has(c)||(i.add(c),n.add(a),o.add(s),t.push(d))},s=(e,t)=>{let n=r.getKey({x:e,y:t});return i.has(n)};return{nodes:t,getGrid:()=>{let e=[...n.values()].sort((e,t)=>e-t),t=[...o.values()].sort((e,t)=>e-t);return{gridX:e,gridY:t}},addPoint:a,hasPoint:s}}(n);!function(e,t){let{rows:i,columns:n}=e;for(let e=0;e<i.length;e++){let o=0===e||e===i.length-2;for(let r=0;r<n.length;r++){let a=0===r||r===n.length-2,s=n[r],l=i[e];t(s,l);let d=a?void 0:n[r+1],c=o?void 0:i[e+1];d&&t((s+d)/2,l),c&&t(s,(l+c)/2),d&&c&&t((s+d)/2,(l+c)/2)}}}(e,a);let{gridX:d,gridY:c}=l();return!function(e,t,i,n,o,r){e.forEach(e=>{let a=r(e.x,e.y);if(a){let r=a.relativeDirection(e.x,e.y);switch(r){case"left":{let i=t.indexOf(e.x);for(;i>-1;){let r=t[i];if(o(r,e.y))break;n(r,e.y,!0),i--}break}case"right":{let i=t.indexOf(e.x);for(;i<t.length;){let r=t[i];if(o(r,e.y))break;n(r,e.y,!0),i++}break}case"top":{let t=i.indexOf(e.y);for(;t>-1;){let r=i[t];if(o(e.x,r))break;n(e.x,r,!0),t--}break}case"bottom":{let t=i.indexOf(e.y);for(;t<i.length;){let r=i[t];if(o(e.x,r))break;n(e.x,r,!0),t++}}}}})}(i,d,c,a,s,n),o}(o,n,t),s=new r(a);return{rectangles:e,points:t,inflatedRectangles:n,rulers:o,nodes:a,graph:s}}(e,t),s=i.getNode(t[0]),l=i.getNode(t[1]),d=function(e,t,i,r=o){let a=new n(e=>e.f);for(t.h=r(t,i),a.push(t);a.size()>0;){let t=a.pop();if(t===i)return function(e){let t=e,i=[];for(;t.parent;)i.unshift(t),t=t.parent;return i.unshift(t),i}(t);t.closed=!0;let n=e.neighbors(t);for(let e=0,o=n.length;e<o;++e){let o=n[e];if(o.closed)continue;let s=t.g+o.cost(t),l=o.visited;(!l||s<o.g)&&(o.visited=!0,o.parent=t,o.h=o.h||r(o,i),o.g=s,o.f=o.g+o.h,l?a.rescoreElement(o):a.push(o))}}return[]}(i,s,l),c=(0,a.S)(d);return c}var l=i(77597),d=i(45598),c=i(13246),h=i(60803),u=i(81366);i(65024);var f=i(83035),p=i(50634),g=i(29113),m=i(15486),v=i(32916),b=i(91827),C=i(23862),y=i(24335),x=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let w=class extends(0,p.$T)(p.Zi){constructor(){super(...arguments),this._vEditor=null,this._element=null,this._edgeless=null,this._keeping=!1}get vEditor(){return this._vEditor}setKeeping(e){this._keeping=e}_syncRect(){let e=this._edgeless,t=this._element;if(e&&t){let i=this._virgoContainer.getBoundingClientRect(),n=Array.from(this._virgoContainer.querySelectorAll("v-line")),o=n[0].getBoundingClientRect().height;e.surface.updateElement(t.id,{xywh:new d.Mb(t.x,t.y,i.width/e.surface.viewport.zoom,n.length/e.surface.viewport.zoom*o).serialize()}),e.slots.selectionUpdated.emit({selected:[t],active:!0})}}mount(e,t){this._element=e,this._edgeless=t,this._vEditor=new g.gX(e.text),this._vEditor.slots.updated.on(()=>{this._syncRect()}),this._disposables.add(t.slots.viewportUpdated.on(()=>{this.requestUpdate(),requestAnimationFrame(()=>{this._syncRect()})})),this.requestUpdate(),requestAnimationFrame(()=>{(0,c.kP)(this._vEditor),this._element?.setDisplay(!1),this._vEditor.mount(this._virgoContainer),this._virgoContainer.addEventListener("blur",()=>{this._keeping||this._unmount()},{once:!0})})}_unmount(){this.vEditor?.unmount(),this._element?.setDisplay(!0),0===this._element?.text.length&&this._edgeless?.surface.removeElement(this._element?.id),this.remove(),(0,c.kP)(this._edgeless),this._edgeless.slots.selectionUpdated.emit({selected:[],active:!1})}render(){let e=this._edgeless?.surface.viewport,t=(0,b.V)({});if(e&&this._element&&this._edgeless){let i=e.zoom,n=(0,y.ae)([this._element],this._edgeless.surface.viewport);t=(0,b.V)({position:"absolute",left:n.x+"px",top:n.y+"px",fontSize:this._element.fontSize+"px",fontFamily:this._element.fontFamily,lineHeight:"initial",outline:"none",transform:`scale(${i}, ${i})`,transformOrigin:"top left",color:(0,C.xZ)(this._element.color)?`var(${this._element.color})`:this._element.color})}return m.dy`<div style=${t} class="virgo-container"></div>`}};x([(0,v.IO)(".virgo-container")],w.prototype,"_virgoContainer",void 0),w=x([(0,v.Mo)("surface-text-editor")],w);let _=200,k=20,M=448,S=72,E=30,L=40;function $(e){return!!e&&"flavour"in e}function P(e){return!$(e)}function B(e,t,i){for(let n=e.length-1;n>=0;n--){let o=e[n];if(function(e,t,i){let[n,o,r,a]=(0,d.CV)(e.xywh);return(0,d.Gn)({x:n,y:o,w:r,h:a},t,i)}(o,t,i))return o}return null}function R(e,t){return e.filter(e=>{let[i,n,o,r]=(0,d.CV)(e.xywh),a={x:i,y:n,w:o,h:r};return(0,d.r3)(t,a)||(0,d.kK)(t,a)})}function T(e,t){let[i,n,o,r]=(0,d.CV)(t),[a,s]=e.toViewCoord(i,n);return new DOMRect(a,s,o*e.zoom,r*e.zoom)}function O(e){return $(e)?e.xywh:(0,d.cJ)(e.x,e.y,e.w,e.h)}function I(e){e.stopPropagation()}function D(e){switch(e.type){case"default":default:return"default";case"pan":return e.panning?"grabbing":"grab";case"brush":case"shape":case"connector":return"crosshair";case"text":return"text"}}function z(e,t,i,n,o){let[r,a]=e.viewport.toModelCoord(i,n),s=e.pickByPoint(r,a).filter(o);return s.length?s[s.length-1]:B(t.root?.children.filter(e=>"affine:frame"===e.flavour)??[],r,a)}function A(e,t,i){let n=t.root?.children.filter(e=>"affine:frame"===e.flavour)??[],o=e.pickById(i)||n.find(e=>e.id===i);return o}function H(e,t,i,n,o,r=d.oI.Orthogonal,l){if(r!==d.oI.Orthogonal)return[i,n];let c=1/0,h=-1;o.forEach((e,t)=>{e.customized&&(c=Math.min(c,t),h=Math.max(h,t))});let u=[];if(l&&h>-1){let r=o[c],d="start"===l?o.slice(0,c+1):s(e?[e]:[],[i,r]),f=o.slice(c,h+1),p=o[h],g="end"===l?o.slice(h):s(t?[t]:[],[p,n]);u=(0,a.S)([...d.slice(0,-1),...f,...g.slice(1)])}else u=s([e,t].filter(e=>!!e),[i,n]);return u.length<3&&(u=[i,n]),u}function V({x:e,y:t,w:i,h:n},o){switch(o){case"top":return{x:e+i/2,y:t};case"right":return{x:e+i,y:t+n/2};case"bottom":return{x:e+i/2,y:t+n};case"left":return{x:e,y:t+n/2};default:throw Error(`Unknown direction: ${o}`)}}function Z(e,t,i){if(!i||!i.contains(e,t))return{point:{x:e,y:t},position:null};let n=i.relativeDirection(e,t),o={x:(e-i.x)/i.w,y:(t-i.y)/i.h},r=V(i,n),a=Math.sqrt(Math.pow(e-r.x,2)+Math.pow(t-r.y,2));return a<20?{point:r,position:{x:(r.x-i.x)/i.w,y:(r.y-i.y)/i.h}}:{point:{x:e,y:t},position:o}}function F(e,t){let i=e.x+e.w*t.x,n=e.y+e.h*t.y,o=e.relativeDirection(i,n),r=V(e,o),a=Math.sqrt(Math.pow(i-r.x,2)+Math.pow(n-r.y,2));return a<20?r:{x:i,y:n}}function U(e,t,i){let{startElement:n,endElement:o}=e,r=n?.id?A(t,i,n.id):null,a=r?new l.A(...(0,d.CV)(O(r))):null,s=a&&n?F(a,n.position):{x:e.x+e.controllers[0].x,y:e.y+e.controllers[0].y},c=o?.id?A(t,i,o.id):null,h=c?new l.A(...(0,d.CV)(O(c))):null,u=h&&o?F(h,o.position):{x:e.x+e.controllers[e.controllers.length-1].x,y:e.y+e.controllers[e.controllers.length-1].y};return{start:{element:n,rect:a,point:s},end:{element:o,rect:h,point:u}}}function j(e,t){let i=t.find(t=>t.id===e.id);if(!i)return!1;let{startElement:n,endElement:o}=e,r=t.find(e=>e.id===n?.id),a=t.find(e=>e.id===o?.id);return!n&&!o||!n&&!!a||!o&&!!r||!!r&&!!a}function N(e,t,i,n){if("connector"!==e.type){let o=i.getBindingElements(e.id);o.forEach(o=>{if(o instanceof d.vy){if(j(o,t))return;let{startElement:r,endElement:a,id:s,x:l,y:d,controllers:c,mode:h}=o,{start:u,end:f}=U(o,i,n),p=r?.id===e.id?"end":a?.id===e.id?"start":void 0,g=H(u.rect,f.rect,u.point,f.point,c.map(e=>({...e,x:e.x+l,y:e.y+d})),h,p);i.updateElement(s,{controllers:g})}})}}function W(e,t,i,n){return{gap:20*(i<.5?2:1/(Math.floor(i)||1))*i,translateX:-e*i,translateY:-t*i,grid:n?"radial-gradient(var(--affine-edgeless-grid-color) 1px, var(--affine-background-primary-color) 1px)":"unset"}}function q(e,t,i,n=M){let o=e.addFrameWithPoint(new u.E9(i.point.x,i.point.y),{width:n});t.addBlock("affine:paragraph",{},o),e.slots.mouseModeUpdated.emit({type:"default"}),requestAnimationFrame(()=>{let n=t.root?.children.filter(e=>"affine:frame"===e.flavour)??[],r=n.find(e=>e.id===o);r&&(e.slots.selectionUpdated.emit({selected:[r],active:!0}),e.updateComplete.then(()=>{(0,u.bQ)(i.raw.clientX,i.raw.clientY)}))})}function Y(e,t){let i=new w,n=t.pageBlockContainer;n.appendChild(i),i.mount(e,t),i.vEditor?.focusEnd(),t.selection.switchToDefaultMode({selected:[e],active:!0})}function X(e,t){let i=e.surface.pickTop(t.x,t.y);if(!i){let[i,n]=e.surface.viewport.toModelCoord(t.x,t.y),o=(0,u.FV)(),r=e.surface.addElement("text",{xywh:new d.Mb(i,n,32,32).serialize(),text:new h.Text,textAlign:"left",fontSize:24,color:"dark"===o?f.ZM:f.LF});e.page.captureSync();let a=e.surface.pickById(r);(0,c.kP)(a),a instanceof d.Gy&&Y(a,e)}}function K(e){let[t,i,n,o]=(0,d.CV)(e.xywh);return{x:t,y:i,w:n,h:o}}},52933:function(e,t,i){"use strict";i.d(t,{nq:function(){return eh},Tq:function(){return ef},wp:function(){return N},PZ:function(){return tt},h6:function(){return ti.h},lO:function(){return to},xM:function(){return _.xM},Ps:function(){return _.Ps},tD:function(){return _.tD},rV:function(){return E.rV},Tb:function(){return _.Tb},vC:function(){return _.vC},I6:function(){return _.I6},X1:function(){return _.X1},DZ:function(){return _.DZ},OA:function(){return _.OA},hw:function(){return _.hw},Wo:function(){return _.Wo},ib:function(){return _.ib},vo:function(){return _.vo},FA:function(){return _.FA},HM:function(){return _.HM},A4:function(){return _.A4},ST:function(){return _.ST},Xf:function(){return _.Xf},uQ:function(){return _.uQ},WV:function(){return _.WV}});var n,o,r,a,s=i(92758),l=i(50634),d=i(13246),c=i(15486),h=i(32916);i(29045);var u=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let f=c.iv`
  :host {
    position: relative;
  }

  .btn {
    box-sizing: border-box;
    display: inline-flex;
    align-items: center;
    border: none;
    padding: 1px 4px;
    border-radius: 5px;
    gap: 4px;
    background: transparent;
    cursor: pointer;

    user-select: none;
    font-family: var(--affine-font-family);
    fill: var(--affine-text-secondary-color);
    color: var(--affine-text-secondary-color);
    pointer-events: auto;
  }

  .btn > span {
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }

  .btn:hover {
    background: var(--affine-hover-color);
  }

  .btn:active {
    background: var(--affine-hover-color);
  }

  .backlink-popover {
    position: absolute;
    left: 0;
    bottom: -8px;

    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    background: var(--affine-white);
    box-shadow: var(--affine-menu-shadow);
    border-radius: 12px;
    transform: translateY(100%);
    z-index: 1;
  }

  .backlink-popover .group-title {
    color: var(--affine-text-secondary-color);
    margin: 8px 12px;
  }

  .backlink-popover icon-button {
    padding: 8px;
    justify-content: flex-start;
    gap: 8px;
  }

  ::-webkit-scrollbar {
    -webkit-appearance: none;
    width: 4px;
  }
  ::-webkit-scrollbar-thumb {
    border-radius: 2px;
    background-color: #b1b1b1;
  }
`,p=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this._backlinks=[],this._showPopover=!1,this._onClickAway=e=>{e.target!==this&&this._showPopover&&(this._showPopover=!1)}}connectedCallback(){super.connectedCallback(),this.tabIndex=0;let e=this.page;(0,d.kP)(e);let t=e.workspace.indexer.backlink;this._backlinks=t.getBacklink(e.id),t.slots.indexUpdated.on(()=>{this._backlinks=t.getBacklink(e.id),this._backlinks.length||(this._showPopover=!1)}),this._disposables.addFromEvent(window,"mousedown",this._onClickAway)}onClick(){this._showPopover=!this._showPopover}render(){let e=this._backlinks.filter(({type:e})=>"LinkedPage"===e);return e.length?c.dy`<div class="btn" @click=${this.onClick}>
        ${s.Gt}<span>Backlinks (${e.length})</span
        >${s.ve}
      </div>
      ${this._showPopover?function(e,t){let i=e.page.workspace.meta.pageMetas;return c.dy`<div class="backlink-popover">
    <div class="group-title">Linked to this page</div>
    <div class="group" style="overflow-y: scroll; max-height: 372px;">
      ${t.map(({pageId:t,blockId:n,type:o})=>{let r="LinkedPage"===o?s.Tm:s.YA,a=i.find(e=>e.id===t);a||console.warn("Unexpected page meta not found",t);let l=a?.title||"Untitled";return c.dy`<icon-button
          width="248px"
          height="32px"
          text=${l}
          @click=${()=>{t!==e.page.id&&e.slots.pageLinkClicked.emit({pageId:t,blockId:n})}}
        >
          ${r}
        </icon-button>`})}
    </div>
  </div>`}(this.host,e):null}`:null}};p.styles=f,u([(0,h.Cb)()],p.prototype,"page",void 0),u([(0,h.Cb)()],p.prototype,"host",void 0),u([(0,h.SB)()],p.prototype,"_backlinks",void 0),u([(0,h.SB)()],p.prototype,"_showPopover",void 0),p=u([(0,h.Mo)("backlink-button")],p);var g=i(67072),m=i(31054),v=i(29113),b=i(36976),C=i(81366),y=i(280),x=i(9288),w=i(73745),_=i(67929),k=i(91827),M=i(29691),S=i(91636),E=i(93251);i(62610);var L=i(13371),$=i(76709),P=i(903);let B=g.zQ/2;function R(e){let t=(0,P.Wc)(e);if(!t||"Block"===t.type)return;let i={startOffset:t.startOffset,endOffset:t.endOffset,blockIds:t.models.map(e=>e.id)};e.awarenessStore.setLocalRange(e,i)}function T(e,t,i,n){if(e.selectedBlocks=i,n){t.selectedRectsUpdated.emit(n);return}let o=[];for(let e of(0,C.rc)(i))o.push((0,C.az)(e));t.selectedRectsUpdated.emit(o)}function O(e,t,i){let{state:n}=e,{y:o}=t.point,{viewportElement:r}=e,{viewport:a}=n,{scrollHeight:s,clientHeight:l}=a,{scrollTop:d}=a,c=s-l;i.init();let h=!0,u=()=>{if(h)n.rafID=requestAnimationFrame(u);else{n.clearRaf();return}if(Math.ceil(d)<c&&l-o<B){let e=(B-(l-o))*.25;d+=e,h=Math.ceil(d)<c,r.scrollTop=d,i.onScroll(e)}else if(d>0&&o<B){let e=(o-B)*.25;d+=e,h=d>0,r.scrollTop=d,i.onScroll(e)}else h=!1,i.onMove()};n.clearRaf(),n.rafID=requestAnimationFrame(u)}let I={onStart(e,t){let{state:i}=e;i.blur(),i.type="block",e.updateViewport();let{scrollLeft:n,scrollTop:o}=i.viewport;i.resetDraggingArea(t,{scrollTop:o,scrollLeft:n}),i.refreshBlockRectCache()},onMove(e,t){O(e,t,{init(){let{x:i,y:n}=t.point,{draggingArea:o,viewport:{scrollLeft:r,scrollTop:a}}=e.state;(0,m.kP)(o),o.end.x=i+r,o.end.y=n+a},onScroll(t){let{draggingArea:i}=e.state;(0,m.kP)(i),i.end.y+=t,e.updateDraggingArea(i)},onMove(){let{blockCache:t,draggingArea:i,viewportOffset:n}=e.state;(0,m.kP)(i);let o=e.updateDraggingArea(i);e.selectBlocksByDraggingArea(t,o,n)}})},onEnd(e,t){e.state.type="block",e.state.clearDraggingArea(),e.slots.draggingAreaUpdated.emit(null)}};var D=i(59799);class z{constructor(e,t){this._originPosition={x:0,y:0},this._dropContainer=null,this._dropContainerSize={w:0,h:0,left:0},this._dragMoveTarget="right",this.state=e,this.slots=t}onStart(e){this._originPosition.x=e.raw.pageX,this._originPosition.y=e.raw.pageY,this._dropContainer=e.raw.target.closest(".resizes");let t=this._dropContainer?.getBoundingClientRect();this._dropContainerSize.w=t.width,this._dropContainerSize.h=t.height,this._dropContainerSize.left=t.left,e.raw.target.className.includes("right")?this._dragMoveTarget="right":this._dragMoveTarget="left"}onMove(e){let t=this.state.activeComponent||this.state.selectedEmbeds[0];if(!t)return;let i=0,n=0,o=0;if((i="right"===this._dragMoveTarget?this._dropContainerSize.w+(e.raw.pageX-this._originPosition.x):this._dropContainerSize.w-(e.raw.pageX-this._originPosition.x))<t.getBoundingClientRect().width&&i>=50&&(o="right"===this._dragMoveTarget?this._dropContainerSize.left-(e.raw.pageX-this._originPosition.x)/2:this._dropContainerSize.left+(e.raw.pageX-this._originPosition.x)/2,n=i*(this._dropContainerSize.h/this._dropContainerSize.w),this._dropContainer)){this.slots.embedRectsUpdated.emit([new DOMRect(o,this._dropContainer.getBoundingClientRect().top,i,n)]);let e=this.state.activeComponent?.querySelector(".resizable-img");e&&(e.style.width=i+"px",e.style.height=n+"px")}}onEnd(){(0,m.kP)(this.state.activeComponent);let e=(0,D.getModelByElement)(this.state.activeComponent);e.page.captureSync(),(0,m.kP)(this._dropContainer);let{width:t,height:i}=this._dropContainer.getBoundingClientRect();e.page.updateBlock(e,{width:t,height:i})}}let A={onStart(e,t){e.state.resetStartRange(t),e.state.type="native"},onMove(e,t){O(e,t,{init(){e.state.lastPoint=new C.E9(t.raw.clientX,t.raw.clientY),(0,C.cS)(e.state.startRange,t)},onMove:C.ZT,onScroll:C.ZT})},onEnd(e,t){e.state.clearRaf()}},H={onStart(e,t){let{container:i,state:n}=e;n.blur(),i.components.dragHandle?.onDragStart((0,C.Ye)("dragstart",t.raw),!0)},onMove(e,t){O(e,t,{init(){let{state:i}=e,{raw:{clientX:n,clientY:o}}=t;i.lastPoint=new C.E9(n,o)},onScroll(t){let{container:i,state:{lastPoint:n}}=e;(0,m.kP)(n),i.components.dragHandle?.onDrag((0,C.Ye)("drag",new MouseEvent("mousemove",{clientX:n.x,clientY:n.y,screenY:1})),!0,!0)},onMove(){let{raw:i}=t,{container:n}=e;n.components.dragHandle?.onDrag((0,C.Ye)("drag",i),!0)}})},onEnd(e,t){let{container:i,state:n}=e;n.clearRaf(),n.lastPoint=null,i.components.dragHandle?.onDragEnd((0,C.Ye)("dragend",t.raw),!0)},clear(e){let{container:t}=e;t.components.dragHandle?.onDragEnd((0,C.Ye)("dragend"))}};var V=i(53905);class Z{constructor(e){this.viewport={left:0,top:0,scrollLeft:0,scrollTop:0,scrollHeight:0,clientHeight:0,clientWidth:0},this.draggingArea=null,this.selectedEmbeds=[],this.selectedBlocks=[],this.focusedBlock=null,this.lastPoint=null,this._startRange=null,this._richTextCache=new Map,this._blockCache=new Map,this._embedCache=new Map,this._activeComponent=null,this.type=e}get activeComponent(){return this._activeComponent}set activeComponent(e){this._activeComponent=e}get startRange(){return this._startRange}get richTextCache(){return this._richTextCache}get blockCache(){return this._blockCache}get embedCache(){return this._embedCache}get viewportOffset(){let{viewport:{left:e,top:t,scrollLeft:i,scrollTop:n}}=this;return{x:i-e,y:n-t}}resetStartRange(e){let{clientX:t,clientY:i}=e.raw;this._startRange=(0,V.Qo)(t,i),this.lastPoint=new C.E9(t,i)}resetDraggingArea(e,t={scrollLeft:0,scrollTop:0}){let{scrollLeft:i,scrollTop:n}=t,{x:o,y:r}=e.point;o+=i,r+=n;let a=new C.E9(o,r);this.draggingArea={start:a.clone(),end:a}}refreshBlockRectCache(){this._blockCache.clear();let e=(0,C.rr)(document);for(let t of e)this._blockCache.set(t,(0,C.az)(t))}blur(){(0,C.xT)(null),document.activeElement&&document.activeElement instanceof HTMLElement&&document.activeElement.blur()}clearRaf(){this.rafID&&(this.rafID=void cancelAnimationFrame(this.rafID))}clearDraggingArea(){this.clearRaf(),this.draggingArea=null}clearNativeSelection(){this.clearRaf(),this.type="none",this._richTextCache.clear(),this._startRange=null,this.lastPoint=null,(0,C.xT)(null)}clearBlockSelection(){this.type="none",this._activeComponent=null,this.focusedBlock=null,this.selectedBlocks=[],this.clearDraggingArea()}clearEmbedSelection(){this.type="none",this.selectedEmbeds=[],this._activeComponent=null}clearSelection(){this.clearBlockSelection(),this.clearEmbedSelection(),this.clearNativeSelection()}}function F(e){let t=e.target;return!!(t&&t instanceof HTMLElement)&&("INPUT"===t.tagName||"FORMAT-QUICK-BAR"===t.tagName)}class U extends C.nF{constructor({container:e,dispatcher:t,page:i,mouseRoot:n,slots:o}){super(e,t),this.state=new Z("none"),this._add=(e,t)=>{this._disposables.add(this._dispatcher.add(e,t))},this._onContainerDragStart=e=>{let t=e.get("pointerState"),i=t.raw.target;if((0,C.zv)(i)||(0,C.Rn)(i)){this.state.type="none";return}if((0,C.kK)(i)&&((0,C.hK)(i)||(0,C.IE)(i))){H.onStart(this,t);return}if((0,C.P2)(t)){this.state.type="embed",this._embedResizeManager.onStart(t);return}this.container.components.dragHandle?.setPointerEvents("none"),this.clear(),(0,C.YK)(t)?I.onStart(this,t):A.onStart(this,t)},this._onContainerDragMove=e=>{let t=e.get("pointerState");if("native"===this.state.type){A.onMove(this,t);return}if(!this.page.readonly){if("block:drag"===this.state.type){H.onMove(this,t);return}if("block"===this.state.type){I.onMove(this,t);return}if("embed"===this.state.type)return this._embedResizeManager.onMove(t)}},this._onContainerDragEnd=e=>{let t=e.get("pointerState");if(this.container.components.dragHandle?.setPointerEvents("auto"),"block:drag"===this.state.type){H.onEnd(this,t);return}if("native"===this.state.type?A.onEnd(this,t):"block"===this.state.type?I.onEnd(this,t):"embed"===this.state.type&&this._embedResizeManager.onEnd(),!this.page.readonly){if("native"===this.state.type){let{direction:e,selectedType:i}=(0,$.$U)(t);if("Caret"===i)return;(0,L.T)({page:this.page,container:this.container,direction:e,anchorEl:{getBoundingClientRect:()=>(0,$.EM)(e,this.state)}})}else if("block"===this.state.type){if(!this.page.awarenessStore.getFlag("enable_block_selection_format_bar")||!this.state.selectedBlocks.length)return;let e=t.start.y<t.point.y?"center-bottom":"center-top";(0,L.T)({page:this.page,container:this.container,direction:e,anchorEl:{getBoundingClientRect:()=>(0,$.EM)(e,this.state)}})}}},this._onContainerPointerDown=e=>{let t=e.get("pointerState");t.keys.shift&&t.raw.preventDefault()},this._onContainerClick=e=>{let t=e.get("pointerState"),{point:{x:i,y:n},raw:{target:o,clientX:r,clientY:a,pageX:s},keys:{shift:l}}=t,d=this._ensureFrameExists();d&&(0,C.zv)(o)&&requestAnimationFrame(()=>{(0,C.tq)(this.page,t,this.container)});let c=(0,C.Ne)(this.container);x.y.setActive(c);let{state:h}=this,{viewport:u}=h,{type:f}=h;if(s>=u.clientWidth+u.left||(0,C.kK)(o)&&(0,C.hK)(o))return;if(l){"none"===f&&(f=h.type="native"),"native"===f?(h.lastPoint=new C.E9(r,a),(0,C.cS)(h.startRange,t)):"block"===f&&this.selectedBlocksWithShiftClick(i,n);return}this.clear(),h.resetStartRange(t);let p=Array.from(document.querySelectorAll(".affine-embed-wrapper-caption"));p.forEach(e=>{e!==o&&e.blur()});let g=null,v=(0,C.cy)(new C.E9(r,a),{rect:this.container.innerRect});if(v&&(g={model:(0,C.gc)(v),rect:(0,C.fl)(v),element:v}),g&&g.model){let{element:e}=g;this.container.lastSelectionPosition="start",h.focusedBlock=e}if(g&&(0,m.h$)(g.model,["affine:embed","affine:divider"])){window.getSelection()?.removeAllRanges(),h.activeComponent=g.element,(0,m.kP)(this.state.activeComponent),"image"===g.model.type?(h.type="embed",h.selectedEmbeds.push(h.activeComponent),this.slots.embedRectsUpdated.emit([g.rect])):(h.type="block",h.selectedBlocks.push(h.activeComponent),this.slots.selectedRectsUpdated.emit([g.rect]));return}(0,C.zv)(o)||(0,C.Rn)(o)||o instanceof HTMLInputElement||(0,C.tq)(this.page,t,this.container)},this._onContainerDblClick=e=>{let t=e.get("pointerState");this.clear(),A.onStart(this,t);{let{raw:{clientX:e,clientY:i}}=t,n=(0,C.cy)(new C.E9(e,i),{rect:this.container.innerRect});if(n){let e=(0,C.gc)(n);"affine:embed"===e.flavour&&window.dispatchEvent(new CustomEvent("affine.embed-block-db-click",{detail:{blockId:e.id}}))}}(0,_.Xf)("double",t,this.page,this.container,this.state)},this._onContainerTripleClick=e=>{let t=e.get("pointerState");(0,_.Xf)("triple",t,this.page,this.container,this.state)},this._onContainerContextMenu=e=>{let t=e.get("defaultState");(0,$.R7)(t.event)},this._onContainerPointerMove=e=>{let t=e.get("pointerState"),{dragging:i,raw:n}=t;if(i||n.target.closest(".embed-editing-state"))return;let o=new C.E9(n.clientX,n.clientY),r=null,{innerRect:a}=this.container,s=(0,C.cy)(o.clone(),{rect:a});if(s){let{left:e,top:t,width:i,height:n}=(0,C.az)(s);r={element:s,model:(0,C.gc)(s),rect:new DOMRect(Math.max(e,a.left+g.H7),t,i,n)}}if(this.container.components.dragHandle?.onContainerMouseMove(t,r),r){let{model:e,element:t}=r,i=!0;if("image"===e.type){let{state:{viewport:{left:e,clientWidth:n}}}=this,a=(0,C.fl)(t),s=C.UL.fromDOMRect(a),l=a.right+60<e+n;s.right+=l?60:0,s.isPointIn(o)&&(a.x=a.right+(l?10:-50),r.rect=a,i=!1)}i&&(r=null)}this.slots.embedEditingStateUpdated.emit(r)},this._onSelectionChangeWithDebounce=()=>{let e=window.getSelection();if(!e||(0,C.zv)(e.anchorNode)||(0,C.zv)(e.focusNode)||!e.containsNode(this.container,!0))return;let t=(0,C.bR)(e);if(t.collapsed||this.page.readonly)return;let i=e.anchorOffset-e.focusOffset,n="none";i>0?n="right-left":i<0&&(n="left-right");let o="left-right"===n?"right-bottom":"left-top";(0,L.T)({page:this.page,container:this.container,direction:o,anchorEl:{getBoundingClientRect:()=>(0,$.EM)(o,this.state)}})},this._onSelectionChangeWithoutDebounce=()=>{R(this.page)},this.slots=o,this._embedResizeManager=new z(this.state,o);let r=!1;this._add("dragStart",e=>{let t=e.get("pointerState");F(t.raw)||((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||t.raw.preventDefault(),r=!0,this._onContainerDragStart(e))}),this._add("dragMove",e=>{let t=e.get("pointerState");F(t.raw)||((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||t.raw.preventDefault(),this._onContainerDragMove(e))}),this._dispatcher.add("dragEnd",e=>{let t=e.get("pointerState");(0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||t.raw.preventDefault(),r=!1,this._onContainerDragEnd(e)}),this._add("click",e=>{let t=e.get("pointerState");(0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||t.raw.preventDefault(),this._onContainerClick(e)}),this._add("doubleClick",e=>{let t=e.get("pointerState");F(t.raw)||this._onContainerDblClick(e)}),this._add("tripleClick",e=>{let t=e.get("pointerState");F(t.raw)||this._onContainerTripleClick(e)}),this._add("pointerDown",this._onContainerPointerDown),this._add("pointerMove",e=>{let t=e.get("pointerState");!F(t.raw)&&((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||t.raw.preventDefault(),this.page.hasFlavour("affine:frame")&&this._onContainerPointerMove(e))}),this._add("contextMenu",this._onContainerContextMenu),this._add("virgo-vrange-updated",()=>{this._onSelectionChangeWithoutDebounce()}),this._add("virgo-vrange-updated",(0,C.Ds)(e=>{let{event:t}=e.get("defaultState");if(!F(t)){if(r)return;this._onSelectionChangeWithDebounce()}},300))}_ensureFrameExists(){let e=this.page.hasFlavour("affine:frame");if(!e){let e=this.page.addBlock("affine:frame",{},this.page.root);return this.page.addBlock("affine:paragraph",{},e),!0}return!1}get viewportElement(){return this.container.viewportElement}updateDraggingArea(e){null!==this.state.focusedBlock&&(this.state.focusedBlock=null);let t=C.UL.fromPoints(e.start,e.end).toDOMRect();return this.slots.draggingAreaUpdated.emit(t),t}updateViewport(){let{viewportElement:e}=this.container,{clientHeight:t,clientWidth:i,scrollHeight:n,scrollLeft:o,scrollTop:r}=e,{top:a,left:s}=e.getBoundingClientRect();this.state.viewport={top:a,left:s,clientHeight:t,clientWidth:i,scrollHeight:n,scrollLeft:o,scrollTop:r}}updateRects(){let{type:e}=this.state;"block"===e?this.refreshSelectedBlocksRects():"embed"===e&&this.refreshEmbedRects()}refreshDraggingArea(e){let{blockCache:t,draggingArea:i}=this.state;i?this.selectBlocksByDraggingArea(t,C.UL.fromPoints(i.start,i.end).toDOMRect(),e,!0):(this.state.draggingArea=null,this.slots.draggingAreaUpdated.emit(null),this.refreshSelectedBlocksRects())}refreshSelectedBlocksRects(){let{focusedBlock:e,selectedBlocks:t}=this.state;if(0!==t.length){if(null===e){let e=(0,C.rc)(t).map(C.az);this.slots.selectedRectsUpdated.emit(e)}else this.slots.selectedRectsUpdated.emit([(0,C.az)(e)])}}refreshSelectedBlocksRectsByModels(e){this.state.selectedBlocks=e.map(C._b).filter(e=>null!==e),this.refreshSelectedBlocksRects()}refreshEmbedRects(e=null){let{activeComponent:t,selectedEmbeds:i,viewport:n}=this.state;if(t&&i.length){let i=(0,C.fl)(t),o=[new DOMRect(i.left,i.top,i.width,i.height)];if(e&&(0,C.Or)(t)){let t=i.right+60<n.left+n.clientWidth;i.x=i.right+(t?10:-50),e.rect=i}this.slots.embedRectsUpdated.emit(o)}}refreshRemoteSelection(){let e=this.container.querySelector("remote-selection");e&&e.requestUpdate()}selectOneBlock(e,t){if(this.clear(),this.state.blur(),this.state.type="block",this.state.focusedBlock=e,!e)return;t||(t=(0,C.az)(this.state.focusedBlock));let i=(0,C.Mb)([e]);T(this.state,this.slots,i,[t])}selectAllBlocks(){this.clear(),this.state.type="block",this.state.focusedBlock=null;let e=(0,C.rr)(this.container),t=(0,C.rc)(e).map(C.az);T(this.state,this.slots,e,t)}selectBlocksByDraggingArea(e,t,i,n=!1){n&&this.state.refreshBlockRectCache();let o=function(e,t,i){let n=Array.from(e.entries()),o=n.length,r=[];if(0===o)return r;let a=-1;for(let e=0;e<o;e++){let[o,s]=n[e];if(s.left+i.x<t.right&&s.right+i.x>t.left&&s.top+i.y<t.bottom&&s.bottom+i.y>t.top){if(-1===a)a=e;else{let t=n[a][0];if((0,C.r3)(t,o)){if((0,d.h$)(t.model,["affine:database"])||r.length>1)continue;a=e,r.shift()}else{let{previousElementSibling:i}=o;if(i&&i!==t&&(0,C.r3)(i,t)){let o=e,a=r.length;for(;o--;){if((t=n[o][0])===i){r.push({block:t,index:o});break}a>0&&(r.pop(),a--)}}a=e}}r.push({block:o,index:e})}}return r}(e,t,i),[r,a]=o.reduce((e,{block:t})=>(e[0].push(...(0,C.Mb)([t])),e[1].push((0,C.az)(t)),e),[[],[]]);T(this.state,this.slots,r,a)}selectedBlocksWithShiftClick(e,t){let i,n;let{state:o}=this,{viewport:{scrollLeft:r,scrollTop:a},viewportOffset:s,selectedBlocks:l}=o,d=l.length-1;if(-1===d)return;let c=0===d,h=l[0],u=c?h:l[d],f=(0,C.az)(h),p=c?f:(0,C.az)(u),g=C.UL.fromPoints(new C.E9(f.left+s.x,f.top+s.y),new C.E9(p.right+s.x,p.bottom+s.y)),m=new C.E9(e+r,t+a),v=!0;if(c){if(g.isPointIn(m))return;m.y<g.top?(i=m,n=g.max,v=!1):(i=g.min,n=m)}else g.isPointIn(m)?m.y>=g.top+g.height/2?(i=m,n=g.max,v=!1):(i=g.min,n=m):m.y<g.top?(i=m,n=g.max,v=!1):(i=g.min,n=m);i&&n&&this.selectBlocksByDraggingArea(o.blockCache,C.UL.fromPoints(i,n).toDOMRect(),s,!0);let b=v?"center-bottom":"center-top";(0,L.T)({page:this.page,container:this.container,direction:b,anchorEl:{getBoundingClientRect:()=>(0,$.EM)(b,o)}})}setSelectedBlocks(e,t){T(this.state,this.slots,e,t)}setFocusedBlock(e){this.state.focusedBlock=e}clear(){let{state:e,slots:t}=this,{type:i}=e;"block:drag"===i&&(H.clear(this),i="block"),"block"===i?(e.clearBlockSelection(),t.selectedRectsUpdated.emit([]),t.draggingAreaUpdated.emit(null),this.container.querySelector("format-quick-bar")?.remove()):"embed"===i?(e.clearEmbedSelection(),t.embedRectsUpdated.emit([]),t.embedEditingStateUpdated.emit(null)):"native"===i&&e.clearNativeSelection()}dispose(){this.slots.selectedRectsUpdated.dispose(),this.slots.draggingAreaUpdated.dispose(),this.slots.embedEditingStateUpdated.dispose(),this.slots.embedRectsUpdated.dispose(),this._disposables.dispose()}}var j=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let N=class extends l.z3{constructor(){super(...arguments),this.flavour="affine:page",this.clipboard=new b.jd(this),this.getService=y.getService,this.lastSelectionPosition="start",this.components={dragHandle:null},this._draggingArea=null,this._selectedRects=[],this._selectedEmbedRects=[],this._isComposing=!1,this._resizeObserver=null,this.slots={draggingAreaUpdated:new d.g7,selectedRectsUpdated:new d.g7,embedRectsUpdated:new d.g7,embedEditingStateUpdated:new d.g7,nativeSelectionToggled:new d.g7,pageLinkClicked:new d.g7},this._titleVEditor=null,this._updateTitleInMeta=()=>{this.page.workspace.setPageMeta(this.page.id,{title:this.model.title.toString()})},this._onTitleKeyDown=e=>{if(e.isComposing||this.page.readonly)return;let t=!this.page.isEmpty,{page:i,model:n}=this,o=n.children.find(e=>"affine:frame"===e.flavour);if("Enter"===e.key&&t){e.preventDefault(),(0,m.kP)(this._titleVEditor);let t=this._titleVEditor.getVRange();(0,m.kP)(t);let r=n.title.split(t.index),a=i.addBlock("affine:paragraph",{text:r},o,0);(0,C.a6)(i,a);return}if("ArrowDown"===e.key&&t){e.preventDefault();let t=o?.children.find(e=>(0,d.h$)(e,["affine:paragraph","affine:list","affine:code"]));if(t)(0,C.a6)(i,t.id);else{let e=i.addBlock("affine:paragraph",{},o,0);(0,C.a6)(i,e)}return}"Tab"===e.key&&e.preventDefault()},this._onTitlePaste=e=>{let t=this._titleVEditor;if(!t)return;let i=t.getVRange();if(!i)return;let n=e.clipboardData?.getData("text/plain");if(n){let e=n.replace(/(\r\n|\r|\n)/g,"\n");t.insertText(i,e),t.setVRange({index:i.index+e.length,length:0})}},this._onWheel=e=>{let{selection:t}=this,{state:i}=t,{type:n,viewport:o}=i;if("native"!==n&&n.startsWith("block")){e.preventDefault();let{viewportElement:r}=this,{scrollTop:a,scrollHeight:s,clientHeight:l}=o,d=s-l,c=e.deltaY/2;if(c>0){if(Math.ceil(a)===d)return;c=Math.min(c,d-a)}else if(c<0){if(0===a)return;c=Math.max(c,-a)}if(o.scrollTop+=c,r.scrollTop+=c,"block"===n){let{draggingArea:e}=i;e&&(e.end.y+=c,t.updateDraggingArea(e))}}},this._onScroll=e=>{let t;let{selection:i}=this,{type:n,viewport:o}=i.state,{scrollLeft:r,scrollTop:a}=e.target;if(o.scrollLeft=r,o.scrollTop=a,"block"===n){i.refreshDraggingArea(i.state.viewportOffset);return}if("embed"===n){i.refreshEmbedRects(this._embedEditingState);return}if("native"===n?t=i.state.startRange&&i.state.lastPoint:"block:drag"===n&&(t=i.state.lastPoint),t){let e=new PointerEvent("pointermove",{clientX:t.x,clientY:t.y});document.dispatchEvent(e)}},this._initDragHandle=()=>{let e=()=>{this.components.dragHandle=(0,E.dx)(this),this.components.dragHandle.getDropAllowedBlocks=e=>e&&1===e.length&&d.cQ.isInsideBlockByFlavour(this.page,e[0],"affine:database")?(0,E.rV)(this.page.getParent(e[0])):e&&1!==e.length?(0,E.rV)(this.model).filter(t=>!e?.includes(t.id)):(0,E.rV)(this.model)};this.page.awarenessStore.getFlag("enable_drag_handle")&&!this.components.dragHandle&&e(),this._disposables.add(this.page.awarenessStore.slots.update.subscribe(e=>e.state?.flags.enable_drag_handle,t=>{t?this.components.dragHandle||e():(this.components.dragHandle?.remove(),this.components.dragHandle=null)},{filter:e=>e.id===this.page.doc.clientID}))}}get titleVEditor(){return(0,m.kP)(this._titleVEditor),this._titleVEditor}get innerRect(){let{left:e,width:t}=this.pageBlockContainer.getBoundingClientRect(),{clientHeight:i,top:n}=this.selection.state.viewport;return C.UL.fromLWTH(e,Math.min(t,window.innerWidth),n,Math.min(i,window.innerHeight))}_initTitleVEditor(){let{model:e}=this,t=e.title;this._titleVEditor=new v.gX(t.yText,{active:()=>x.y.isActive(this)}),this._titleVEditor.mount(this._titleContainer),this._titleVEditor.bindHandlers({keydown:this._onTitleKeyDown,paste:this._onTitlePaste}),this._disposables.addFromEvent(this._titleContainer,"compositionstart",()=>this._isComposing=!0),this._disposables.addFromEvent(this._titleContainer,"compositionend",()=>this._isComposing=!1),this.model.title.yText.observe(()=>{this._updateTitleInMeta(),this.requestUpdate()}),this._titleVEditor.setReadonly(this.page.readonly)}updated(e){e.has("model")&&this.model&&!this._titleVEditor&&this._initTitleVEditor()}_initSlotEffects(){let{slots:e}=this;e.draggingAreaUpdated.on(e=>{this._draggingArea=e}),e.selectedRectsUpdated.on(e=>{this._selectedRects=e}),e.embedRectsUpdated.on(e=>{this._selectedEmbedRects=e,0===e.length&&(this._embedEditingState=null)}),e.embedEditingStateUpdated.on(e=>{this._embedEditingState=e}),this.model.childrenUpdated.on(()=>this.requestUpdate())}_initFrameSizeEffect(){(0,_.uQ)(this.page,1),this.addEventListener("keydown",e=>{e.ctrlKey||e.metaKey||e.shiftKey||(0,_.uQ)(this.page,1)})}_initResizeEffect(){let e=new ResizeObserver(e=>{for(let{target:t}of e)if(t===this.viewportElement){this.selection.updateViewport(),this.selection.updateRects();break}});e.observe(this.viewportElement),this._resizeObserver=e}firstUpdated(){let{page:e,selection:t}=this,i=C.AL.newScope(C.GF.AFFINE_PAGE);x.y.isActive(this)&&C.AL.setScope(i),this._disposables.add(x.y.activeSlot.on(()=>{x.y.isActive(this)&&C.AL.setScope(i)})),this._disposables.add(()=>C.AL.deleteScope(i)),C.AL.withScope(i,()=>{(0,w.Ps)(e,t)}),C.AL.enableHotkey(),this._initDragHandle(),this._initSlotEffects(),this._initFrameSizeEffect(),this._initResizeEffect(),this.mouseRoot.addEventListener("wheel",this._onWheel),this.viewportElement.addEventListener("scroll",this._onScroll),this.setAttribute(g.SF,this.model.id)}connectedCallback(){super.connectedCallback(),(0,y.registerService)("affine:page",to),this.clipboard.init(this.page),this.mouseRoot=this.parentElement,this.selection=new U({page:this.page,mouseRoot:this.mouseRoot,slots:this.slots,container:this,dispatcher:this.root.uiEventDispatcher})}disconnectedCallback(){super.disconnectedCallback(),this.clipboard.dispose(),this._disposables.dispose(),this.components.dragHandle?.remove(),(0,w.ST)(),this.selection.clear(),this.selection.dispose(),this._resizeObserver&&(this._resizeObserver.disconnect(),this._resizeObserver=null),this.mouseRoot.removeEventListener("wheel",this._onWheel),this.viewportElement.removeEventListener("scroll",this._onScroll)}render(){requestAnimationFrame(()=>{this.selection.refreshRemoteSelection()});let{page:e,selection:t}=this,{viewportOffset:i}=t.state,n=function(e){if(null===e)return null;let t={left:e.left+"px",top:e.top+"px",width:e.width+"px",height:e.height+"px"};return c.dy`
    <style>
      .affine-page-dragging-area {
        position: absolute;
        background: var(--affine-hover-color);
        z-index: 1;
        pointer-events: none;
      }
    </style>
    <div class="affine-page-dragging-area" style=${(0,k.V)(t)}></div>
  `}(this._draggingArea),o=c.dy`
    <style>
      .affine-page-selected-embed-rects-container > div {
        position: absolute;
        display: block;
        border: 2px solid var(--affine-primary-color);
        user-select: none;
      }
    </style>
    <div class="affine-page-selected-embed-rects-container resizable">
      ${this._selectedEmbedRects.map(e=>{let t={left:e.left+i.x+"px",top:e.top+i.y+"px",width:e.width+"px",height:e.height+"px"};return c.dy`
          <div class="resizes" style=${(0,k.V)(t)}>
            <div class="resize top-left"></div>
            <div class="resize top-right"></div>
            <div class="resize bottom-left"></div>
            <div class="resize bottom-right"></div>
          </div>
        `})}
    </div>
  `,r=function(e,t,i){if(!e)return null;let{rect:{x:n,y:o},model:r}=e,a={left:n+i.x+"px",top:o+i.y+"px"};return c.dy`
    <style>
      .affine-embed-editing-state-container > div {
        position: absolute;
        display: block;
        z-index: 1;
      }
      ${M.a}
    </style>

    <div
      class="affine-embed-editing-state-container"
      @pointerdown=${S.UW}
    >
      <div style=${(0,k.V)(a)} class="embed-editing-state">
        <format-bar-button
          class="has-tool-tip"
          width="100%"
          @click=${()=>{(0,E.Ql)(r),t.embedRectsUpdated.emit([])}}
        >
          ${s.ch}
          <tool-tip inert tip-position="right" role="tooltip">Caption</tool-tip>
        </format-bar-button>
        <format-bar-button
          class="has-tool-tip"
          width="100%"
          @click=${()=>{(0,E.GN)(r)}}
        >
          ${s._8}
          <tool-tip inert tip-position="right" role="tooltip"
            >Download
          </tool-tip>
        </format-bar-button>
        <format-bar-button
          class="has-tool-tip"
          width="100%"
          @click=${()=>{(0,E._x)(r)}}
        >
          ${s.TI}
          <tool-tip inert tip-position="right" role="tooltip"
            >Copy to clipboard
          </tool-tip>
        </format-bar-button>
        <format-bar-button
          class="has-tool-tip"
          width="100%"
          @click="${()=>{r.page.deleteBlock(r),t.embedRectsUpdated.emit([])}}"
        >
          ${s.pJ}
          <tool-tip inert tip-position="right" role="tooltip">Delete</tool-tip>
        </format-bar-button>
      </div>
    </div>
  `}(e.readonly?null:this._embedEditingState,this.slots,i),a=(!this.model.title||!this.model.title.length)&&!this._isComposing;return c.dy`
      <div class="affine-default-viewport">
        <div class="affine-default-page-block-container">
          <div class="affine-default-page-block-title-container">
            <div
              data-block-is-title="true"
              class="affine-default-page-block-title ${a?"affine-default-page-block-title-empty":""}"
            ></div>
            <backlink-button
              .host="${this}"
              .page="${this.page}"
            ></backlink-button>
          </div>
          ${this.content}
        </div>
        <affine-selected-blocks
          .mouseRoot="${this.mouseRoot}"
          .state="${{rects:this._selectedRects,grab:!n}}"
          .offset="${i}"
        ></affine-selected-blocks>
        ${n} ${o} ${r}
      </div>
    `}};N.styles=c.iv`
    .affine-default-viewport {
      position: relative;
      overflow-x: hidden;
      overflow-y: auto;
      height: 100%;
    }

    .affine-default-page-block-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      font-family: var(--affine-font-family);
      font-size: var(--affine-font-base);
      line-height: var(--affine-line-height);
      color: var(--affine-text-primary-color);
      font-weight: 400;
      max-width: var(--affine-editor-width);
      margin: 0 auto;
      /* cursor: crosshair; */
      cursor: default;
      padding-bottom: ${g.rj}px;

      /* Leave a place for drag-handle */
      padding-left: ${g.H7}px;
      padding-right: ${g.H7}px;
    }

    .affine-default-page-block-title {
      width: 100%;
      font-size: 40px;
      line-height: 50px;
      font-weight: 700;
      outline: none;
      resize: none;
      border: 0;
      font-family: inherit;
      color: inherit;
      cursor: text;
    }

    .affine-default-page-block-title-empty::before {
      content: 'Title';
      color: var(--affine-placeholder-color);
      position: absolute;
      opacity: 0.5;
    }

    .affine-default-page-block-title:disabled {
      background-color: transparent;
    }

    /*
    .affine-default-page-block-title-container {
    }
    */

    .affine-block-element {
      display: block;
    }
  `,j([(0,h.SB)()],N.prototype,"_draggingArea",void 0),j([(0,h.SB)()],N.prototype,"_selectedRects",void 0),j([(0,h.SB)()],N.prototype,"_selectedEmbedRects",void 0),j([(0,h.SB)()],N.prototype,"_embedEditingState",void 0),j([(0,h.SB)()],N.prototype,"_isComposing",void 0),j([(0,h.IO)(".affine-default-viewport")],N.prototype,"viewportElement",void 0),j([(0,h.IO)(".affine-default-page-block-container")],N.prototype,"pageBlockContainer",void 0),j([(0,h.IO)(".affine-default-page-block-title")],N.prototype,"_titleContainer",void 0),N=j([(0,h.Mo)("affine-default-page")],N);var W=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let q=class extends c.oi{constructor(){super(),this.disabled=!1,this.coming=!1,this.tipPosition="top",this.active=!1,this.activeMode="color",this.addEventListener("click",e=>{this.disabled&&(e.stopPropagation(),e.preventDefault())},{capture:!0})}render(){let e=this.coming?"(Coming soon)":this.tooltip,t=`icon-container has-tool-tip active-mode-${this.activeMode}`;return c.dy`
      <div
        class=${t}
        role="button"
        ?disabled=${this.disabled}
        ?active=${this.active}
      >
        <slot></slot>
        ${e?c.dy`<tool-tip
              inert
              role="tooltip"
              tip-position=${this.tipPosition}
              arrow
              >${e}</tool-tip
            >`:c.Ld}
      </div>
    `}};q.styles=c.iv`
    .icon-container {
      position: relative;
      display: flex;
      align-items: center;
      padding: 4px;
      color: var(--affine-icon-color);
      margin: 8px;
      border-radius: 5px;
      cursor: pointer;
    }

    .icon-container:hover {
      background: var(--affine-hover-color);
    }

    .icon-container.active-mode-color[active] {
      color: var(--affine-primary-color);
    }

    .icon-container.active-mode-background[active] {
      background: var(--affine-hover-color);
    }

    .icon-container[disabled] {
      pointer-events: none;
      cursor: not-allowed;
    }

    .icon-container[coming] {
      cursor: not-allowed;
      color: var(--affine-text-disable-color);
    }

    ${M.a}

    tool-tip {
      z-index: 12;
    }
  `,W([(0,h.Cb)()],q.prototype,"disabled",void 0),W([(0,h.Cb)()],q.prototype,"coming",void 0),W([(0,h.Cb)()],q.prototype,"tooltip",void 0),W([(0,h.Cb)()],q.prototype,"tipPosition",void 0),W([(0,h.Cb)()],q.prototype,"active",void 0),W([(0,h.Cb)()],q.prototype,"activeMode",void 0),q=W([(0,h.Mo)("edgeless-tool-icon-button")],q);var Y=i(1398),X=i(7339);let K=[{name:"rect",icon:X.Ps,tooltip:"Square",disabled:!1},{name:"ellipse",icon:X.Re,tooltip:"Ellipse",disabled:!1},{name:"diamond",icon:X.nb,tooltip:"Diamond",disabled:!1},{name:"triangle",icon:X.FE,tooltip:"Triangle",disabled:!1},{name:"roundedRect",icon:X.YX,tooltip:"Rounded rectangle",disabled:!1}],G=K.reduce((e,t)=>(e[t.name]=t,e),{});var Q=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let J=class extends c.oi{constructor(){super(...arguments),this.slots={select:new d.g7}}_onSelect(e){this.selectedShape=e,this.slots.select.emit(e)}disconnectedCallback(){this.slots.select.dispose(),super.disconnectedCallback()}render(){return c.dy`
      <div class="shape-menu-container">
        ${K.map(({name:e,icon:t,tooltip:i,disabled:n})=>c.dy`
            <edgeless-tool-icon-button
              .disabled=${n}
              .tooltip=${i}
              .active=${this.selectedShape===e}
              @click=${()=>{n||this._onSelect(e)}}
            >
              ${t}
            </edgeless-tool-icon-button>
          `)}
      </div>
    `}};J.styles=c.iv`
    :host {
      display: block;
      z-index: 2;
    }
    .shape-menu-container {
      display: flex;
      align-items: center;
      width: 240px;
      height: 48px;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
      fill: none;
      stroke: currentColor;
    }
  `,Q([(0,h.Cb)()],J.prototype,"selectedShape",void 0),J=Q([(0,h.Mo)("edgeless-shape-menu")],J);var ee=i(45598),et=i(70263);let ei=[c.iv`
    .edgeless-component-line-size-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 16px;
      height: 16px;
    }

    .edgeless-component-line-size-button div {
      border-radius: 50%;
      background-color: var(--affine-icon-color);
    }

    .edgeless-component-line-size-button.size-s div {
      width: 4px;
      height: 4px;
    }
    .edgeless-component-line-size-button.size-l div {
      width: 10px;
      height: 10px;
    }
  `];var en=i(57891);let eo=[c.iv`
    .edgeless-component-line-style-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 16px;
      height: 16px;
      color: var(--affine-icon-color);
    }
  `],er=[c.iv`
    .edgeless-component-panel-wrapper {
      display: flex;
      padding: 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }
  `],ea=[er,ei,eo];function es({onClick:e,selectedLineSize:t,selectedLineStyle:i,lineStyle:n=["solid","dash","none"]}={}){let o=(0,en.r)(["s","l"],e=>e,i=>(function({className:e,size:t,active:i,tooltip:n,onClick:o}){let r=`edgeless-component-line-size-button size-${t} ${i?"active":""}`;return c.dy`<edgeless-tool-icon-button
    class=${e}
    .active=${i}
    .activeMode=${"background"}
    .tooltip=${void 0!==n?n:({s:"Thin",l:"Thick"})[t]}
    @click=${o}
  >
    <div class=${r}>
      <div></div>
    </div>
  </edgeless-tool-icon-button>`})({size:i,active:i===t,onClick:()=>{e?.({type:"size",value:i})}})),r=(0,en.r)(n,e=>e,t=>(function({className:e,mode:t,active:i,tooltip:n,onClick:o}){let r=`edgeless-component-line-style-button mode-${t} ${i?"active":""}`,a=function(e){switch(e){case"solid":return X.Uw;case"dash":return X.PC;case"none":return X.SC}}(t);return c.dy`<edgeless-tool-icon-button
    class=${e}
    .active=${i}
    .activeMode=${"background"}
    .tooltip=${void 0!==n?n:({solid:"Solid",dash:"Dash",none:"None"})[t]}
    @click=${o}
  >
    <div class=${r}>${a}</div>
  </edgeless-tool-icon-button>`})({mode:t,active:t===i,onClick:()=>{e?.({type:"lineStyle",value:t})}}));return function({children:e,className:t}){let i=`edgeless-component-panel-wrapper ${t||""}`;return c.dy`<div class=${i}>${e}</div>`}({className:"line-style-panel",children:c.dy`
      ${o}
      <menu-divider .vertical=${!0}></menu-divider>
      ${r}
    `})}var el=i(24335),ed=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ec=["--affine-palette-shape-yellow","--affine-palette-shape-orange","--affine-palette-shape-tangerine","--affine-palette-shape-red","--affine-palette-shape-magenta","--affine-palette-shape-purple","--affine-palette-shape-green","--affine-palette-shape-blue","--affine-palette-shape-navy","--affine-palette-shape-black","--affine-palette-shape-white","--affine-palette-transparent"],eh=ec[11],eu=["--affine-palette-line-yellow","--affine-palette-line-orange","--affine-palette-line-tangerine","--affine-palette-line-red","--affine-palette-line-magenta","--affine-palette-line-purple","--affine-palette-line-green","--affine-palette-line-blue","--affine-palette-line-navy","--affine-palette-line-black","--affine-palette-line-white","--affine-palette-transparent"],ef=eu[9],ep=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this.elements=[],this._popperShow=!1,this._shapeMenuPopper=null,this._fillColorMenuPopper=null,this._strokeColorMenuPopper=null,this._lineStylesPanelPopper=null}_forceUpdateSelection(){this.slots.selectionUpdated.emit({...this.selectionState})}_setShapeFillColor(e){let t=!(0,Y.Qm)(e);this.elements.forEach(i=>{this.surface.updateElement(i.id,{filled:t,fillColor:e})}),this._forceUpdateSelection()}_setShapeStrokeColor(e){this.elements.forEach(t=>{this.surface.updateElement(t.id,{strokeColor:e})}),this._forceUpdateSelection()}_setShapeStrokeWidth(e){this.elements.forEach(t=>{this.surface.updateElement(t.id,{strokeWidth:e})}),this._forceUpdateSelection()}_setShapeStrokeStyle(e){this.elements.forEach(t=>{this.surface.updateElement(t.id,{strokeStyle:e})}),this._forceUpdateSelection()}_setShapeStyles({type:e,value:t}){if("size"===e)this._setShapeStrokeWidth("s"===t?4:10);else if("lineStyle"===e)switch(t){case"solid":this._setShapeStrokeStyle(ee.qb.Solid);break;case"dash":this._setShapeStrokeStyle(ee.qb.Dashed);break;case"none":this._setShapeStrokeStyle(ee.qb.None)}}firstUpdated(e){let t=this._disposables;this._shapeMenuPopper=(0,el.Rx)(this._changeShapeButton,this._shapeMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._shapeMenuPopper),t.add(this._shapeMenu.slots.select.on(e=>{let t="roundedRect"===e?{shapeType:"rect",radius:.1}:{shapeType:e,radius:0};this.page.captureSync(),this.elements.forEach(e=>{this.surface.updateElement(e.id,t)}),this._forceUpdateSelection()})),this._fillColorMenuPopper=(0,el.Rx)(this._fillColorButton,this._fillColorMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._fillColorMenuPopper),this._strokeColorMenuPopper=(0,el.Rx)(this._strokeColorButton,this._strokeColorMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._strokeColorMenuPopper),this._lineStylesPanelPopper=(0,el.Rx)(this._lineStylesButton,this._lineStylesPanel,({display:e})=>{this._popperShow="show"===e}),t.add(this._lineStylesPanelPopper),super.firstUpdated(e)}render(){let e=function(e){let t=(0,et.VF)(e,e=>"rect"===e.shapeType&&e.radius?"roundedRect":e.shapeType),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements),t=e?G[e].icon:null,i=function(e){let t=(0,et.VF)(e,e=>e.filled?e.fillColor:"--affine-palette-transparent"),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??ec[0],n=function(e){let t=(0,et.VF)(e,e=>e.strokeColor),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??eu[0],o=function(e){let t=(0,et.VF)(e,e=>4===e.strokeWidth?"s":"l"),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??"s",r=function(e){let t=(0,et.VF)(e,e=>{switch(e.strokeStyle){case ee.qb.Solid:return"solid";case ee.qb.Dashed:return"dash";case ee.qb.None:return"none"}}),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??"solid";return c.dy`
      <edgeless-tool-icon-button
        class="change-shape-button"
        .tooltip=${this._popperShow?"":"Switch type"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._shapeMenuPopper?.toggle()}
      >
        ${t}
      </edgeless-tool-icon-button>
      <edgeless-shape-menu .selectedShape=${e}>
      </edgeless-shape-menu>

      <menu-divider .vertical=${!0}></menu-divider>

      <edgeless-tool-icon-button
        class="fill-color-button"
        .tooltip=${this._popperShow?"":"Shape color"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._fillColorMenuPopper?.toggle()}
      >
        ${(0,Y.Gs)(i)}
      </edgeless-tool-icon-button>
      <div class="color-panel-container fill-color">
        <edgeless-color-panel
          .value=${i}
          .options=${ec}
          @select=${e=>this._setShapeFillColor(e.detail)}
        >
        </edgeless-color-panel>
      </div>

      <edgeless-tool-icon-button
        class="stroke-color-button"
        .tooltip=${this._popperShow?"":"Border color"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._strokeColorMenuPopper?.toggle()}
      >
        ${(0,Y.Gs)(n,{hollowCircle:!0})}
      </edgeless-tool-icon-button>
      <div class="color-panel-container stroke-color">
        <edgeless-color-panel
          .value=${n}
          .options=${eu}
          .hollowCircle=${!0}
          @select=${e=>this._setShapeStrokeColor(e.detail)}
        >
        </edgeless-color-panel>
      </div>

      <menu-divider .vertical=${!0}></menu-divider>

      <edgeless-tool-icon-button
        class="line-styles-button"
        .tooltip=${this._popperShow?"":"Border style"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._lineStylesPanelPopper?.toggle()}
      >
        ${X.oR}
      </edgeless-tool-icon-button>
      ${es({selectedLineSize:o,selectedLineStyle:r,onClick:e=>{this._setShapeStyles(e)}})}
    `}};ep.styles=[ei,ea,c.iv`
      :host {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        color: var(--affine-text-primary-color);
        stroke: none;
        fill: currentColor;
      }

      menu-divider {
        height: 24px;
      }

      edgeless-shape-menu {
        display: none;
      }

      edgeless-shape-menu[data-show] {
        display: block;
      }

      .change-shape-button {
        fill: none;
        stroke: currentColor;
      }

      .color-panel-container {
        display: none;
        padding: 4px;
        justify-content: center;
        align-items: center;
        background: var(--affine-background-overlay-panel-color);
        box-shadow: var(--affine-shadow-2);
        border-radius: 8px;
      }

      .color-panel-container[data-show] {
        display: block;
      }

      .shape-color-button-indicator {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 24px;
        height: 24px;
        box-sizing: border-box;
        border-radius: 4px;
        cursor: pointer;
      }

      .shape-color-button-indicator div {
        border-radius: 50%;
        width: 16px;
        height: 16px;
      }

      .line-style-panel {
        display: none;
      }
      .line-style-panel[data-show] {
        display: flex;
      }
    `],ed([(0,h.Cb)()],ep.prototype,"elements",void 0),ed([(0,h.Cb)()],ep.prototype,"page",void 0),ed([(0,h.Cb)()],ep.prototype,"surface",void 0),ed([(0,h.Cb)()],ep.prototype,"selectionState",void 0),ed([(0,h.Cb)()],ep.prototype,"slots",void 0),ed([(0,h.SB)()],ep.prototype,"_popperShow",void 0),ed([(0,h.IO)(".change-shape-button")],ep.prototype,"_changeShapeButton",void 0),ed([(0,h.IO)("edgeless-shape-menu")],ep.prototype,"_shapeMenu",void 0),ed([(0,h.IO)(".fill-color-button")],ep.prototype,"_fillColorButton",void 0),ed([(0,h.IO)(".color-panel-container.fill-color")],ep.prototype,"_fillColorMenu",void 0),ed([(0,h.IO)(".stroke-color-button")],ep.prototype,"_strokeColorButton",void 0),ed([(0,h.IO)(".color-panel-container.stroke-color")],ep.prototype,"_strokeColorMenu",void 0),ed([(0,h.IO)(".line-styles-button")],ep.prototype,"_lineStylesButton",void 0),ed([(0,h.IO)(".line-style-panel")],ep.prototype,"_lineStylesPanel",void 0),ep=ed([(0,h.Mo)("edgeless-change-shape-button")],ep);var eg=i(62624),em=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ev=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this.elements=[],this._popperShow=!1,this._colorPanelPopper=null}_setBrushSize(e){this.page.captureSync(),this.elements.forEach(t=>{t.lineWidth!==e&&this.surface.updateElement(t.id,{lineWidth:e})}),this.slots.selectionUpdated.emit({...this.selectionState})}_setBrushColor(e){this.page.captureSync(),this.elements.forEach(t=>{t.color!==e&&this.surface.updateElement(t.id,{color:e})})}firstUpdated(e){let t=this._disposables;this._colorPanelPopper=(0,el.Rx)(this,this._colorPanel,({display:e})=>{this._popperShow="show"===e}),t.add(this._colorPanelPopper),super.firstUpdated(e)}render(){let e=function(e){let t=(0,et.VF)(e,e=>e.color),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??Y.EJ,t={backgroundColor:`var(${e})`},i=function(e){let t=(0,et.VF)(e,e=>e.lineWidth),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?Number(i[0]):null}(this.elements);return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${"Thin"}
        @click=${()=>this._setBrushSize(eg.h.Thin)}
      >
        <div
          class="brush-size-button"
          ?active=${i===eg.h.Thin}
        >
          <div class="thin"></div>
        </div>
      </edgeless-tool-icon-button>
      <edgeless-tool-icon-button
        .tooltip=${"Thick"}
        @click=${()=>this._setBrushSize(eg.h.Thick)}
      >
        <div
          class="brush-size-button"
          ?active=${i===eg.h.Thick}
        >
          <div class="thick"></div>
        </div>
      </edgeless-tool-icon-button>
      <menu-divider .vertical=${!0}></menu-divider>
      <edgeless-tool-icon-button
        .tooltip=${this._popperShow?"":"Color"}
        .active=${!1}
        @click=${()=>this._colorPanelPopper?.toggle()}
      >
        <div class="brush-size-button">
          <div class="thick" style=${(0,k.V)(t)}></div>
        </div>
      </edgeless-tool-icon-button>
      <div class="color-panel-container">
        <edgeless-color-panel
          .value=${e}
          @select=${e=>this._setBrushColor(e.detail)}
        >
        </edgeless-color-panel>
      </div>
    `}};ev.styles=c.iv`
    :host {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      color: var(--affine-text-primary-color);
      fill: currentColor;
    }

    menu-divider {
      height: 24px;
    }

    .color-panel-container {
      display: none;
      padding: 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    .color-panel-container[data-show] {
      display: block;
    }

    .brush-size-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 24px;
      height: 24px;
      box-sizing: border-box;
      border-radius: 4px;
      cursor: pointer;
    }

    .brush-size-button div {
      border-radius: 50%;
      background-color: var(--affine-icon-color);
    }

    .brush-size-button[active] div {
      background-color: var(--affine-blue);
    }

    .brush-size-button .thin {
      width: 4px;
      height: 4px;
    }

    .brush-size-button .thick {
      width: 10px;
      height: 10px;
    }
  `,em([(0,h.Cb)()],ev.prototype,"elements",void 0),em([(0,h.Cb)({type:Object})],ev.prototype,"selectionState",void 0),em([(0,h.Cb)()],ev.prototype,"page",void 0),em([(0,h.Cb)()],ev.prototype,"surface",void 0),em([(0,h.Cb)()],ev.prototype,"slots",void 0),em([(0,h.SB)()],ev.prototype,"_popperShow",void 0),em([(0,h.IO)(".color-panel-container")],ev.prototype,"_colorPanel",void 0),ev=em([(0,h.Mo)("edgeless-change-brush-button")],ev);var eb=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eC=class extends c.oi{constructor(){super(...arguments),this.elements=[],this._colorPanelPopper=null,this._disposables=new d.SJ,this._lineStylesPanelPopper=null,this._popperShow=!1}_forceUpdateSelection(){this.slots.selectionUpdated.emit({...this.selectionState})}_setConnectorMode(e){this.page.captureSync(),this.elements.forEach(t=>{if(t.mode!==e){if(t.mode===ee.oI.Orthogonal){let i=[t.controllers[0],t.controllers[t.controllers.length-1]].map(e=>({...e,x:e.x+t.x,y:e.y+t.y}));this.surface.updateElement(t.id,{controllers:i,mode:e})}else{let{start:i,end:n}=(0,S.ml)(t,this.surface,this.page),o=(0,S.T7)(i.rect,n.rect,i.point,n.point,[]);this.surface.updateElement(t.id,{controllers:o,mode:e})}}}),this._forceUpdateSelection()}_setConnectorColor(e){this.page.captureSync(),this.elements.forEach(t=>{t.color!==e&&this.surface.updateElement(t.id,{color:e})})}_setShapeStrokeWidth(e){this.elements.forEach(t=>{this.surface.updateElement(t.id,{lineWidth:e})}),this._forceUpdateSelection()}_setShapeStrokeStyle(e){this.elements.forEach(t=>{this.surface.updateElement(t.id,{strokeStyle:e})}),this._forceUpdateSelection()}_setShapeStyles({type:e,value:t}){if("size"===e)this._setShapeStrokeWidth("s"===t?4:10);else if("lineStyle"===e)switch(t){case"solid":this._setShapeStrokeStyle(ee.qb.Solid);break;case"dash":this._setShapeStrokeStyle(ee.qb.Dashed);break;case"none":this._setShapeStrokeStyle(ee.qb.None)}}firstUpdated(e){let t=this._disposables;this._colorPanelPopper=(0,el.Rx)(this._colorButton,this._colorPanel),t.add(this._colorPanelPopper),this._lineStylesPanelPopper=(0,el.Rx)(this._lineStylesButton,this._lineStylesPanel,({display:e})=>{this._popperShow="show"===e}),t.add(this._lineStylesPanelPopper),super.firstUpdated(e)}render(){let e=function(e){let t=(0,et.VF)(e,e=>e.color),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??Y.EJ,t={backgroundColor:`var(${e})`},i=function(e){let t=(0,et.VF)(e,e=>e.mode),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?Number(i[0]):null}(this.elements),n=function(e){let t=(0,et.VF)(e,e=>4===e.lineWidth?"s":"l"),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??"s",o=function(e){let t=(0,et.VF)(e,e=>{switch(e.strokeStyle){case ee.qb.Solid:return"solid";case ee.qb.Dashed:return"dash";case ee.qb.None:return"none"}}),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.elements)??"solid";return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${"Straight line"}
        .tipPosition=${"bottom"}
        @click=${()=>this._setConnectorMode(ee.oI.Straight)}
      >
        <div
          class="connector-mode-button"
          ?active=${i===ee.oI.Straight}
        >
          ${X.Uw}
        </div>
      </edgeless-tool-icon-button>
      <edgeless-tool-icon-button
        .tooltip=${"Connector"}
        .tipPosition=${"bottom"}
        @click=${()=>this._setConnectorMode(ee.oI.Orthogonal)}
      >
        <div
          class="connector-mode-button"
          ?active=${i===ee.oI.Orthogonal}
        >
          ${X.Nb}
        </div>
      </edgeless-tool-icon-button>
      <menu-divider .vertical=${!0}></menu-divider>
      <edgeless-tool-icon-button
        class="connector-color-button"
        .tooltip=${"Color"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._colorPanelPopper?.toggle()}
      >
        <div>
          <div class="color" style=${(0,k.V)(t)}></div>
        </div>
      </edgeless-tool-icon-button>
      <div class="color-panel-container">
        <edgeless-color-panel
          .value=${e}
          @select=${e=>this._setConnectorColor(e.detail)}
        >
        </edgeless-color-panel>
      </div>

      <edgeless-tool-icon-button
        class="line-styles-button"
        .tooltip=${this._popperShow?"":"Border style"}
        .tipPosition=${"bottom"}
        .active=${!1}
        @click=${()=>this._lineStylesPanelPopper?.toggle()}
      >
        ${X.oR}
      </edgeless-tool-icon-button>
      ${es({selectedLineSize:n,selectedLineStyle:o,lineStyle:["solid","dash"],onClick:e=>{this._setShapeStyles(e)}})}
    `}};eC.styles=[ei,ea,c.iv`
      :host {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        color: var(--affine-text-primary-color);
        fill: currentColor;
      }

      menu-divider {
        height: 24px;
      }

      .color-panel-container {
        display: none;
        padding: 4px;
        justify-content: center;
        align-items: center;
        background: var(--affine-background-overlay-panel-color);
        box-shadow: var(--affine-shadow-2);
        border-radius: 8px;
      }

      .color-panel-container[data-show] {
        display: block;
      }

      .connector-mode-button {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 24px;
        height: 24px;
        box-sizing: border-box;
        border-radius: 4px;
        cursor: pointer;
      }

      .connector-mode-button[active] {
        background-color: var(--affine-hover-color);
      }

      .connector-color-button .color {
        width: 16px;
        height: 16px;
        border-radius: 50%;
      }

      .line-style-panel {
        display: none;
      }
      .line-style-panel[data-show] {
        display: flex;
      }
    `],eb([(0,h.Cb)()],eC.prototype,"elements",void 0),eb([(0,h.Cb)({type:Object})],eC.prototype,"selectionState",void 0),eb([(0,h.Cb)()],eC.prototype,"page",void 0),eb([(0,h.Cb)()],eC.prototype,"surface",void 0),eb([(0,h.Cb)()],eC.prototype,"slots",void 0),eb([(0,h.IO)(".connector-color-button")],eC.prototype,"_colorButton",void 0),eb([(0,h.IO)(".color-panel-container")],eC.prototype,"_colorPanel",void 0),eb([(0,h.IO)(".line-styles-button")],eC.prototype,"_lineStylesButton",void 0),eb([(0,h.IO)(".line-style-panel")],eC.prototype,"_lineStylesPanel",void 0),eC=eb([(0,h.Mo)("edgeless-change-connector-button")],eC);var ey=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ex=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this.frames=[],this._popperShow=!1,this._colorSelectorPopper=null}_renderSelectedColor(e){let t={backgroundColor:`var(${e})`};return c.dy`<div class="selected-background" style=${(0,k.V)(t)}>
      A
    </div>`}_setBlockBackground(e){this.frames.forEach(t=>{this.page.updateBlock(t,{background:e})}),this.slots.selectionUpdated.emit({...this.selectionState})}firstUpdated(e){let t=this._disposables;this._colorSelectorPopper=(0,el.Rx)(this,this._colorSelector,({display:e})=>{this._popperShow="show"===e}),t.add(this._colorSelectorPopper),super.firstUpdated(e)}render(){let e=function(e){let t=(0,et.VF)(e,e=>e.background),i=(0,et.UT)(Object.entries(t),([e,t])=>t);return i?i[0]:null}(this.frames)||g.je[0];return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${this._popperShow?"":"Color"}
        .active=${!1}
        @click=${()=>this._colorSelectorPopper?.toggle()}
      >
        ${this._renderSelectedColor(e)}
      </edgeless-tool-icon-button>
      <edgeless-color-panel
        .value=${e}
        .options=${g.je}
        .showLetterMark=${!0}
        @select=${e=>{this._setBlockBackground(e.detail)}}
      ></edgeless-color-panel>
    `}};ex.styles=c.iv`
    :host {
      display: block;
      color: var(--affine-text-primary-color);
      fill: currentColor;
    }

    edgeless-color-panel {
      display: none;
      width: 108px;
      height: 68px;
      padding: 8px 12px;
      flex-wrap: wrap;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    edgeless-color-panel[data-show] {
      display: flex;
    }

    .selected-background {
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      width: 16px;
      height: 16px;
      box-sizing: border-box;
      border-radius: 50%;
      color: var(--affine-text-primary-color);
      font-size: 12px;
    }
  `,ey([(0,h.Cb)()],ex.prototype,"frames",void 0),ey([(0,h.Cb)()],ex.prototype,"page",void 0),ey([(0,h.Cb)()],ex.prototype,"selectionState",void 0),ey([(0,h.Cb)()],ex.prototype,"slots",void 0),ey([(0,h.SB)()],ex.prototype,"_popperShow",void 0),ey([(0,h.IO)("edgeless-color-panel")],ex.prototype,"_colorSelector",void 0),ex=ey([(0,h.Mo)("edgeless-change-frame-button")],ex),i(83035);var ew=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let e_=[{name:"Bring to front",type:"front"},{name:"Bring forward",type:"forward"},{name:"Send backward",type:"backward"},{name:"Send to back",type:"back"},{name:"Delete",type:"delete"}],ek=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this.elements=[],this._popperShow=!1,this._actionsMenuPopper=null,this._runAction=({type:e})=>{switch(e){case"delete":this._delete();break;case"front":case"forward":case"backward":case"back":{let{frames:t,shapes:i}=this._splitElements();t.length&&this.slots.reorderingFramesUpdated.emit({elements:t,type:e}),i.length&&this.slots.reorderingShapesUpdated.emit({elements:i,type:e})}}this._actionsMenuPopper?.hide()}}_splitElements(){let e=[],t=[];return this.elements.forEach(i=>{(0,S.Zi)(i)?e.push(i):t.push(i)}),{frames:e,shapes:t}}_delete(){this.page.captureSync(),this.elements.forEach(e=>{if((0,S.Zi)(e)){let t=this.page.root?.children??[];t.length>1&&this.page.deleteBlock(e)}else this.surface.removeElement(e.id)}),this.slots.selectionUpdated.emit({selected:[],active:!1})}firstUpdated(e){let t=this._disposables;this._actionsMenuPopper=(0,el.Rx)(this,this._actionsMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._actionsMenuPopper),super.firstUpdated(e)}render(){var e;let t=(e=this._runAction,(0,en.r)(e_,e=>e.type,t=>c.dy`<div
        class="action-item"
        @click=${()=>e(t)}
        ?data-disabled=${t.disabled}
      >
        ${t.name}
      </div>`));return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${this._popperShow?"":"More"}
        .active=${!1}
        @click=${()=>this._actionsMenuPopper?.toggle()}
      >
        ${X.xh}
      </edgeless-tool-icon-button>
      <div class="more-actions-container">${t}</div>
    `}};ek.styles=c.iv`
    :host {
      display: block;
      color: var(--affine-text-primary-color);
      fill: currentColor;
    }

    .more-actions-container {
      display: none;
      width: 158px;
      padding: 8px 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
      font-size: 16px;
      line-height: 22px;
    }

    .more-actions-container[data-show] {
      display: block;
    }

    .action-item {
      width: 100%;
      height: 32px;
      box-sizing: border-box;
      padding: 5px 12px;
      border-radius: 5px;
      overflow: hidden;
      text-overflow: ellipsis;
      cursor: pointer;
    }

    .action-item:hover {
      background-color: var(--affine-hover-color);
    }

    .action-item[data-disabled] {
      cursor: not-allowed;
    }
  `,ew([(0,h.Cb)()],ek.prototype,"elements",void 0),ew([(0,h.Cb)()],ek.prototype,"page",void 0),ew([(0,h.Cb)()],ek.prototype,"surface",void 0),ew([(0,h.Cb)()],ek.prototype,"slots",void 0),ew([(0,h.SB)()],ek.prototype,"_popperShow",void 0),ew([(0,h.IO)(".more-actions-container")],ek.prototype,"_actionsMenu",void 0),ek=ew([(0,h.Mo)("edgeless-more-button")],ek);var eM=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eS=class extends c.oi{constructor(){super(...arguments),this.selected=[]}_groupSelected(){let e=(0,et.vM)(this.selected,e=>(0,S.Zi)(e)?"frame":e.type);return e}_getShapeButton(e){let t=e?.length?c.dy`<edgeless-change-shape-button
          .elements=${e}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${this.selectionState}
        >
        </edgeless-change-shape-button>`:null;return t}_getBrushButton(e){return e?.length?c.dy`<edgeless-change-brush-button
          .elements=${e}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${this.selectionState}
        >
        </edgeless-change-brush-button>`:null}_getConnectorButton(e){return e?.length?c.dy` <edgeless-change-connector-button
          .elements=${e}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${this.selectionState}
        >
        </edgeless-change-connector-button>`:null}_getFrameButton(e){return e?.length?c.dy`<edgeless-change-frame-button
          .frames=${e}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${this.selectionState}
        >
        </edgeless-change-frame-button>`:null}_getTextButton(e){return e?.length?c.dy`<edgeless-change-text-button
          .texts=${e}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${this.selectionState}
        >
        </edgeless-change-text-button>`:null}render(){let e=this._groupSelected(),{shape:t,brush:i,connector:n,frame:o,text:r}=e,a=(0,et.Ky)(Object.values(e),e=>!!e.length,2),s=a?[]:[this._getShapeButton(t),this._getBrushButton(i),this._getConnectorButton(n),this._getFrameButton(o),this._getTextButton(r)].filter(e=>!!e),l=s.length?c.dy`<menu-divider .vertical=${!0}></menu-divider>`:c.Ld;return c.dy`<div class="container" @pointerdown=${S.UW}>
      ${/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function*(e,t){let i="function"==typeof t;if(void 0!==e){let n=-1;for(let o of e)n>-1&&(yield i?t(n):t),n++,yield o}}(s,()=>"")} ${l}
      <edgeless-more-button
        .elements=${this.selected}
        .page=${this.page}
        .surface=${this.surface}
        .slots=${this.slots}
      >
      </edgeless-more-button>
    </div>`}};eS.styles=c.iv`
    :host {
      display: block;
      user-select: none;
    }

    .container {
      display: flex;
      align-items: center;
      height: 48px;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    menu-divider {
      height: 24px;
    }
  `,eM([(0,h.Cb)()],eS.prototype,"selected",void 0),eM([(0,h.Cb)({type:Object})],eS.prototype,"selectionState",void 0),eM([(0,h.Cb)()],eS.prototype,"page",void 0),eM([(0,h.Cb)()],eS.prototype,"surface",void 0),eM([(0,h.Cb)()],eS.prototype,"slots",void 0),eS=eM([(0,h.Mo)("edgeless-component-toolbar")],eS);var eE=i(66208);function eL(e,t){let i=i=>{i.stopPropagation(),t&&t(i,e)};return c.dy`<div
    aria-label=${`handle-${e}`}
    @pointerdown=${i}
  ></div>`}(n=r||(r={})).Left="left",n.Right="right",n.TopLeft="top-left",n.BottomLeft="bottom-left",n.TopRight="top-right",n.BottomRight="bottom-right";class e${constructor(e,t){this._dragDirection=r.Left,this._dragPos={start:{x:0,y:0},end:{x:0,y:0}},this._bounds=new Map,this._commonBound=[0,0,0,0],this._aspectRatio=1,this._resizeMode="none",this._zoom=1,this._shiftKey=!1,this.onPointerDown=(e,t,i,n,o)=>{e.stopPropagation(),this._bounds=i;let{x:r,y:a,w:s,h:l}=(0,ee.ci)([...i.values()]);this._commonBound=[r,a,r+s,a+l],this._dragDirection=t,this._dragPos.start={x:e.x,y:e.y},this._dragPos.end={x:e.x,y:e.y},this._aspectRatio=s/l,this._resizeMode=n,this._zoom=o;let d=e=>{"none"!==n&&(this._shiftKey||(this._shiftKey=e.shiftKey),this._dragPos.end={x:e.x,y:e.y},this._resize(this._shiftKey))},c=e=>{this._onResizeEnd(),this._bounds.clear(),this._dragPos={start:{x:0,y:0},end:{x:0,y:0}},this._commonBound=[0,0,0,0],document.removeEventListener("pointermove",d),document.removeEventListener("pointerup",c)};document.addEventListener("pointermove",d),document.addEventListener("pointerup",c)},this._onResizeMove=e,this._onResizeEnd=t}_resize(e=!1){let{_aspectRatio:t,_dragDirection:i,_dragPos:n,_resizeMode:o,_zoom:a,_commonBound:s}=this,l="corner"===o,{x:d,y:c}=n.start,{x:h,y:u}=n.end,f=(h-d)/a,[p,g,m,v]=s,b=m-p,C=v-g,[y,x,w,_]=s,k=0,M=0,S=!1,E=!1;if(l){let n=(u-c)/a;switch(i){case r.TopLeft:y+=f,x+=n;break;case r.BottomRight:w+=f,_+=n;break;case r.TopRight:w+=f,x+=n;break;case r.BottomLeft:y+=f,_+=n}let o=w-y,s=_-x;if(S=o/b<0,E=s/C<0,e&&l){let e=Math.abs(o),n=Math.abs(s),a=t<e/n,l=e/t*(E?1:-1),d=n*t*(S?1:-1);switch(i){case r.TopLeft:a?x=_+l:y=w+d;break;case r.BottomRight:a?_=x-l:w=y-d;break;case r.TopRight:a?x=_+l:w=y-d;break;case r.BottomLeft:a?_=x-l:y=w+d}}}else{switch(i){case r.Left:y+=f;break;case r.Right:w+=f}S=w<y}if(S){let e=w;w=y,y=e}if(E){let e=_;_=x,x=e}k=Math.abs(w-y),M=Math.abs(_-x);let L={x:y,y:x,w:k,h:M},$=new Map;this._bounds.forEach((e,t)=>{let{x:i,y:n,w:o,h:r}=e,a=(S?m-i-o:i-p)/b,s=(E?v-n-r:n-g)/C,l=L.w*a+L.x,d=L.h*s+L.y,c=L.w*(o/b),h=L.h*(r/C);$.set(t,new ee.Mb(l,d,c,h))}),this._onResizeMove($)}onPressShiftKey(e){this._shiftKey!==e&&(this._shiftKey=e,this._resize(e))}}var eP=i(77597),eB=i(92007);function eR(e,t,i,n,o,r,a){let s=e.clientX,l=e.clientY,d=n.controllers.map(e=>({...e,x:e.x+n.x,y:e.y+n.y})),c="start"===o?d[0]:d[d.length-1],h=c.x,u=c.y,f=e=>{let c;let{clientX:f,clientY:p}=e,{zoom:g}=t.viewport,m=h+(f-s)/g,v=u+(p-l)/g,[b,C]=t.toViewCoord(m,v),{start:y,end:x}=(0,S.ml)(n,t,i),w=(0,S.D9)(t,i,b,C,e=>e.id!==n.id&&"connector"!==e.type),_=w?new eP.A(...(0,ee.CV)((0,S.XA)(w))):null,{point:k,position:M}=(0,S.sI)(m,v,_);c="start"===o?(0,S.T7)(_,x.rect,k,x.point,d,r,"end"):(0,S.T7)(y.rect,_,y.point,k,d,r,"start"),"start"===o?t.updateElement(n.id,{controllers:c,startElement:w&&M?{id:w.id,position:M}:void 0}):t.updateElement(n.id,{controllers:c,endElement:w&&M?{id:w.id,position:M}:void 0}),a()},p=()=>{document.removeEventListener("pointermove",f),document.removeEventListener("pointerup",p)};document.addEventListener("pointermove",f),document.addEventListener("pointerup",p)}var eT=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eO=class extends(0,l.$T)(c.oi){constructor(){super(),this._componentToolbarPopper=null,this._lock=!1,this._onDragMove=e=>{let{page:t,state:i,surface:n}=this,o=new Map(i.selected.map(e=>[e.id,e]));e.forEach((e,i)=>{let r=o.get(i);if(r){if((0,S.Zi)(r)){let i=e.x,n=e.y,o=e.w,a=(0,ee.CV)(r.xywh)[3];o<S.j4&&(o=S.j4,i=e.x),a<S.Iq&&(a=S.Iq,n=e.y),t.updateBlock(r,{xywh:JSON.stringify([i,n,o,a])})}else if(r instanceof ee.Gy){let t=e.h/r.h;e.w=r.w*t,n.updateElement(i,{xywh:(0,ee.cJ)(e.x,e.y,e.w,e.h),fontSize:r.fontSize*t})}else n.setElementBound(r.id,e);(0,S.bt)(r,[r],n,t)}}),this.requestUpdate()},this._onDragEnd=()=>{this._lock&&this.page.captureSync(),this._lock=!1},this._resizeManager=new e$(this._onDragMove,this._onDragEnd),this.addEventListener("pointerdown",S.UW)}get zoom(){return this.surface.viewport.zoom}get resizeMode(){if(1===this.state.selected.length&&"connector"===this.state.selected[0].type)return"none";let e=this.state.selected.find(e=>(0,S.Zi)(e));return e?"edge":"corner"}firstUpdated(){let{_disposables:e,slots:t}=this;if(e.add(t.viewportUpdated.on(()=>this.requestUpdate())),e.add(t.pressShiftKeyUpdated.on(e=>this._resizeManager.onPressShiftKey(e))),this._componentToolbarPopper=this._componentToolbar?(0,eE.fi)(this._selectedRect,this._componentToolbar,{placement:"top",modifiers:[{name:"offset",options:{offset:[0,12]}},{name:"flip",options:{fallbackPlacements:["bottom"]}}]}):null,e.add(()=>this._componentToolbarPopper?.destroy()),this._componentToolbar){let t=new ResizeObserver(()=>this._componentToolbarPopper?.update());t.observe(this._componentToolbar),e.add(()=>t.disconnect())}}updated(e){this._componentToolbarPopper?.update(),super.updated(e)}render(){let{state:e}=this,{active:t,selected:i}=e;if(0===i.length||t&&i[0]instanceof ee.Gy)return c.Ld;let{page:n,surface:o,resizeMode:a,_resizeManager:s}=this,l=(0,el.ae)(i,o.viewport),d=(0,el.TO)(l,t,!0),h=!t&&!n.readonly,u=h?function(e,t){switch(e){case"corner":{let e=eL(r.TopLeft,t),i=eL(r.TopRight,t),n=eL(r.BottomLeft,t),o=eL(r.BottomRight,t);return c.dy`
        ${e}
        ${i}
        ${n}
        ${o}
      `}case"edge":{let e=eL(r.Left,t),i=eL(r.Right,t);return c.dy`${e} ${i}`}case"none":return c.Ld}}(a,(e,t)=>{let n=(0,el.wK)(i);s.onPointerDown(e,t,n,a,this.zoom)}):c.Ld,f=1===i.length&&"connector"===i[0].type?function(e,t,i,n){let{controllers:o,mode:r}=e,a=r===ee.oI.Orthogonal?function(e){let t=[];for(let i=0;i<e.length-1;i++){let n=e[i],o=e[i+1],r=n.x===o.x,a=r?{x:n.x,y:(n.y+o.y)/2,position:i,isVertical:r}:{x:(n.x+o.x)/2,y:n.y,position:i,isVertical:r};t.push(a)}return t}(o):[],s=t.viewport.zoom,l={position:"absolute",left:`${o[0].x*s}px`,top:`${o[0].y*s}px`},d={position:"absolute",left:`${o[o.length-1].x*s}px`,top:`${o[o.length-1].y*s}px`};return c.dy`
    <style>
      .line-controller {
        position: absolute;
        width: 9px;
        height: 9px;
        box-sizing: border-box;
        border-radius: 50%;
        border: 2px solid var(--affine-text-emphasis-color);
        background-color: var(--affine-background-primary-color);
        transform: translate(-50%, -50%);
        cursor: pointer;
        z-index: 10;
        pointer-events: all;
        /**
         * Fix: pointerEvent stops firing after a short time.
         * When a gesture is started, the browser intersects the touch-action values of the touched element and its ancestors,
         * up to the one that implements the gesture (in other words, the first containing scrolling element)
         * https://developer.mozilla.org/en-US/docs/Web/CSS/touch-action
         */
        touch-action: none;
      }
    </style>
    <div
      class="line-controller line-start"
      style=${(0,k.V)(l)}
      @pointerdown=${o=>{o.stopPropagation(),eR(o,t,i,e,"start",r,n)}}
    ></div>
    <div
      class="line-controller line-end"
      style=${(0,k.V)(d)}
      @pointerdown=${o=>{o.stopPropagation(),eR(o,t,i,e,"end",r,n)}}
    ></div>
    ${(0,en.r)(a,e=>Math.random(),i=>{let o={left:`${i.x*s}px`,top:`${i.y*s}px`,cursor:i.isVertical?"col-resize":"row-resize"};return c.dy`<div
          class="line-controller"
          style=${(0,k.V)(o)}
          @pointerdown=${o=>{o.stopPropagation(),function(e,t,i,n,o,r){let a=e.clientX,s=e.clientY,{controllers:l,x:d,y:c}=n,h=e=>{let{isVertical:i,position:h}=o,{zoom:u}=t.viewport,f=l.map(e=>({...e,x:e.x+d,y:e.y+c})),p=i?e.clientX-a:0,g=i?0:e.clientY-s,m=f[h],v={x:m.x+p/u,y:m.y+g/u,customized:!0},b=f[h+1],C={x:b.x+p/u,y:b.y+g/u,customized:!0};0===h?(f.splice(h+1,0,v),f[h+2]=C):h===f.length-2?(f[h]=v,f.splice(h+1,0,C)):(f[h]=v,f[h+1]=C),t.updateElement(n.id,{controllers:(0,eB.S)(f)}),r()},u=e=>{document.removeEventListener("pointermove",h),document.removeEventListener("pointerup",u)};document.addEventListener("pointermove",h),document.addEventListener("pointerup",u)}(o,t,0,e,i,n)}}
        ></div>`})}
  `}(i[0],this.surface,this.page,()=>{this.slots.selectionUpdated.emit({...e})}):c.Ld,p=t?c.Ld:c.dy`<edgeless-component-toolbar
          .selected=${i}
          .page=${this.page}
          .surface=${this.surface}
          .slots=${this.slots}
          .selectionState=${e}
        >
        </edgeless-component-toolbar>`;return c.dy`
      <div class="affine-edgeless-selected-rect" style=${(0,k.V)(d)}>
        ${u} ${f}
      </div>
      ${p}
    `}};eO.styles=c.iv`
    :host {
      display: block;
      user-select: none;
    }

    .affine-edgeless-selected-rect {
      position: absolute;
      border-radius: 0;
      pointer-events: none;
      box-sizing: border-box;
      z-index: 1;
      border: var(--affine-border-width) solid var(--affine-blue);
    }

    .affine-edgeless-selected-rect > [aria-label^='handle'] {
      position: absolute;
      width: 12px;
      height: 12px;
      box-sizing: border-box;
      border-radius: 6px;
      z-index: 10;
      border: 2px var(--affine-blue) solid;
      background: white;
      pointer-events: auto;
      user-select: none;
      outline: none;

      /**
       * Fix: pointerEvent stops firing after a short time.
       * When a gesture is started, the browser intersects the touch-action values of the touched element and its ancestors,
       * up to the one that implements the gesture (in other words, the first containing scrolling element)
       * https://developer.mozilla.org/en-US/docs/Web/CSS/touch-action
       */
      touchaction: none;
    }

    :host([disabled='true'])
      .affine-edgeless-selected-rect
      > [aria-label^='handle'] {
      pointer-events: none;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-top-left'] {
      cursor: nwse-resize;
      left: -6px;
      top: -6px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-top-right'] {
      cursor: nesw-resize;
      top: -6px;
      right: -6px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-bottom-right'] {
      cursor: nwse-resize;
      right: -6px;
      bottom: -6px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-bottom-left'] {
      cursor: nesw-resize;
      bottom: -6px;
      left: -6px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-left'],
    .affine-edgeless-selected-rect > [aria-label='handle-right'] {
      cursor: ew-resize;
      top: 0;
      bottom: 0;
      height: 100%;
      width: 6px;
      border: 0;
      background: transparent;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-left'] {
      left: -3.5px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-right'] {
      right: -3.5px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-left']:after,
    .affine-edgeless-selected-rect > [aria-label='handle-right']:after {
      position: absolute;
      width: 12px;
      height: 12px;
      box-sizing: border-box;
      border-radius: 6px;
      z-index: 10;
      border: 2px var(--affine-blue) solid;
      content: '';
      top: calc(50% - 6px);
      background: white;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-left']:after {
      left: -3px;
    }

    .affine-edgeless-selected-rect > [aria-label='handle-right']:after {
      right: -3px;
    }

    edgeless-component-toolbar {
      /* greater than handle */
      z-index: 11;
    }
  `,eT([(0,h.Cb)({type:d.T3})],eO.prototype,"page",void 0),eT([(0,h.Cb)({type:ee.Bo})],eO.prototype,"surface",void 0),eT([(0,h.Cb)({type:Object})],eO.prototype,"state",void 0),eT([(0,h.Cb)()],eO.prototype,"slots",void 0),eT([(0,h.IO)(".affine-edgeless-selected-rect")],eO.prototype,"_selectedRect",void 0),eT([(0,h.IO)("edgeless-component-toolbar")],eO.prototype,"_componentToolbar",void 0),eO=eT([(0,h.Mo)("edgeless-selected-rect")],eO);var eI=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eD=class extends(0,l.$T)(c.oi){constructor(){super(...arguments),this._popperShow=!1,this._shapeMenuPopper=null}_toggleShapeMenu(){this._shapeMenuPopper?.toggle()}firstUpdated(e){let t=this._disposables;this._shapeMenuPopper=(0,el.Rx)(this,this._shapeMenu,({display:e})=>{this._popperShow="show"===e}),t.add(this._shapeMenuPopper),t.add(this._shapeMenu.slots.select.on(e=>{this.setMouseMode({type:"shape",shape:e,fillColor:eh,strokeColor:ef})})),super.firstUpdated(e)}disconnectedCallback(){this._disposables?.dispose(),super.disconnectedCallback()}render(){let e=this.mouseMode?.type,t="shape"===e?this.mouseMode.shape:void 0;return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${this._popperShow?"":(0,el.zH)("Shape","S")}
        .active=${"shape"===e}
        @click=${()=>{this.setMouseMode({type:"shape",shape:"rect",fillColor:eh,strokeColor:ef}),this._toggleShapeMenu()}}
      >
        ${X.NL}
      </edgeless-tool-icon-button>
      <edgeless-shape-menu .selectedShape=${t}>
      </edgeless-shape-menu>
    `}};eD.styles=c.iv`
    :host {
      display: flex;
    }

    edgeless-shape-menu {
      display: none;
    }

    edgeless-shape-menu[data-show] {
      display: block;
    }
  `,eI([(0,h.Cb)()],eD.prototype,"mouseMode",void 0),eI([(0,h.Cb)()],eD.prototype,"edgeless",void 0),eI([(0,h.Cb)()],eD.prototype,"setMouseMode",void 0),eI([(0,h.SB)()],eD.prototype,"_popperShow",void 0),eI([(0,h.IO)("edgeless-shape-menu")],eD.prototype,"_shapeMenu",void 0),eD=eI([(0,h.Mo)("edgeless-shape-tool-button")],eD);var ez=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eA=class extends c.oi{constructor(){super(...arguments),this._setBrushColor=e=>{if("brush"!==this.mouseMode.type)return;let{lineWidth:t}=this.mouseMode;this.edgeless.slots.mouseModeUpdated.emit({type:"brush",color:e,lineWidth:t})},this._setBrushWidth=e=>{if("brush"!==this.mouseMode.type)return;let{color:t}=this.mouseMode;this.edgeless.slots.mouseModeUpdated.emit({type:"brush",color:t,lineWidth:e})}}render(){if("brush"!==this.mouseMode.type)return c.Ld;let{color:e}=this.mouseMode,t=function(e,t){if("brush"!==e.type)return c.Ld;let{lineWidth:i}=e;return c.dy`
    <div class="brush-size-button-group has-tool-tip">
      <!-- This tooltip is for the last button(Thick) -->
      <tool-tip inert role="tooltip" tip-position="top" arrow>Thick</tool-tip>

      <div
        class="brush-size-button has-tool-tip"
        ?active=${i===C.hY.Thin}
        @click=${()=>t(C.hY.Thin)}
      >
        <div class="thin"></div>
        <tool-tip inert role="tooltip" tip-position="top" arrow>
          Thin
        </tool-tip>
      </div>

      <div
        class="brush-size-button"
        ?active=${i===C.hY.Thick}
        @click=${()=>t(C.hY.Thick)}
      >
        <div class="thick"></div>
      </div>
    </div>
  `}(this.mouseMode,this._setBrushWidth);return c.dy`
      <div class="container">
        ${t}
        <menu-divider .vertical=${!0}></menu-divider>
        <edgeless-color-panel
          .value=${e}
          @select=${e=>this._setBrushColor(e.detail)}
        ></edgeless-color-panel>
      </div>
    `}};eA.styles=c.iv`
    :host {
      width: 260px;
      z-index: 1;
    }
    .container {
      display: flex;
      padding: 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    .brush-size-button-group {
      display: flex;
      flex-direction: column;
    }

    .brush-size-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 32px;
      height: 32px;
      box-sizing: border-box;
      border-radius: 4px;
      cursor: pointer;
    }

    .brush-size-button[active],
    .brush-size-button:hover {
      background-color: var(--affine-hover-color);
    }

    .brush-size-button div {
      border-radius: 50%;
      background-color: var(--affine-icon-color);
    }

    .brush-size-button .thin {
      width: 4px;
      height: 4px;
    }

    .brush-size-button .thick {
      width: 10px;
      height: 10px;
    }

    menu-divider {
      height: 62px;
    }

    ${M.a}
  `,ez([(0,h.Cb)()],eA.prototype,"mouseMode",void 0),ez([(0,h.Cb)()],eA.prototype,"edgeless",void 0),eA=ez([(0,h.Mo)("edgeless-brush-menu")],eA);var eH=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eV=class extends c.oi{constructor(){super(...arguments),this._popperShow=!1,this._brushMenu=null}_toggleBrushMenu(){this._brushMenu?(this._brushMenu.dispose(),this._brushMenu=null,this._popperShow=!1):(this._brushMenu=function(e){let t=document.createElement("edgeless-brush-menu");(0,d.kP)(e.shadowRoot),e.shadowRoot.appendChild(t);let i=(0,eE.fi)(e,t,{placement:"top",modifiers:[{name:"offset",options:{offset:[0,12]}}]});return{element:t,dispose:()=>{t.remove(),i.destroy()}}}(this),this._brushMenu.element.mouseMode=this.mouseMode,this._brushMenu.element.edgeless=this.edgeless,this._popperShow=!0)}updated(e){e.has("mouseMode")&&("brush"!==this.mouseMode.type&&(this._brushMenu?.dispose(),this._brushMenu=null),this._brushMenu&&(this._brushMenu.element.mouseMode=this.mouseMode,this._brushMenu.element.edgeless=this.edgeless))}disconnectedCallback(){this._brushMenu?.dispose(),this._brushMenu=null,super.disconnectedCallback()}render(){let e=this.mouseMode?.type;return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${this._popperShow?"":(0,el.zH)("Pen","P")}
        .active=${"brush"===e}
        @click=${()=>{this.setMouseMode({type:"brush",lineWidth:4,color:Y.EJ}),this._toggleBrushMenu()}}
      >
        ${X.Mw}
      </edgeless-tool-icon-button>
    `}};eV.styles=c.iv`
    :host {
      display: flex;
    }
  `,eH([(0,h.Cb)()],eV.prototype,"mouseMode",void 0),eH([(0,h.Cb)()],eV.prototype,"edgeless",void 0),eH([(0,h.Cb)()],eV.prototype,"setMouseMode",void 0),eH([(0,h.SB)()],eV.prototype,"_popperShow",void 0),eV=eH([(0,h.Mo)("edgeless-brush-tool-button")],eV);var eZ=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let eF=class extends c.oi{constructor(){super(...arguments),this._setConnectorColor=e=>{if("connector"!==this.mouseMode.type)return;let{mode:t}=this.mouseMode;this.edgeless.slots.mouseModeUpdated.emit({type:"connector",color:e,mode:t})},this._setConnectorMode=e=>{if("connector"!==this.mouseMode.type)return;let{color:t}=this.mouseMode;this.edgeless.slots.mouseModeUpdated.emit({type:"connector",color:t,mode:e})}}render(){if("connector"!==this.mouseMode.type)return c.Ld;let{color:e}=this.mouseMode,t=function(e,t){if("connector"!==e.type)return c.Ld;let{mode:i}=e,n=(0,el.zH)("Straight line","L"),o=(0,el.zH)("Connector","X");return c.dy`
    <div class="connector-mode-button-group has-tool-tip">
      <!-- This tooltip is for the last button(Thick) -->
      <tool-tip inert role="tooltip" tip-position="top" arrow>
        ${o}
      </tool-tip>

      <div
        class="connector-mode-button has-tool-tip"
        ?active=${i===ee.oI.Straight}
        @click=${()=>t(ee.oI.Straight)}
      >
        ${X.Uw}
        <tool-tip inert role="tooltip" tip-position="top" arrow>
          ${n}
        </tool-tip>
      </div>

      <div
        class="connector-mode-button"
        ?active=${i===ee.oI.Orthogonal}
        @click=${()=>t(ee.oI.Orthogonal)}
      >
        ${X.Nb}
      </div>
    </div>
  `}(this.mouseMode,this._setConnectorMode);return c.dy`
      <div class="container">
        ${t}
        <menu-divider .vertical=${!0}></menu-divider>
        <edgeless-color-panel
          .value=${e}
          @select=${e=>this._setConnectorColor(e.detail)}
        ></edgeless-color-panel>
      </div>
    `}};eF.styles=c.iv`
    :host {
      width: 260px;
      z-index: 1;
    }
    .container {
      display: flex;
      padding: 4px;
      justify-content: center;
      align-items: center;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
    }

    .connector-mode-button-group {
      display: flex;
      flex-direction: column;
    }

    .connector-mode-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 32px;
      height: 32px;
      box-sizing: border-box;
      border-radius: 4px;
      cursor: pointer;
    }

    .connector-mode-button[active],
    .connector-mode-button:hover {
      background-color: var(--affine-hover-color);
    }

    .connector-mode-button div {
      border-radius: 50%;
      background-color: var(--affine-icon-color);
    }

    menu-divider {
      height: 62px;
    }

    ${M.a}
  `,eZ([(0,h.Cb)()],eF.prototype,"mouseMode",void 0),eZ([(0,h.Cb)()],eF.prototype,"edgeless",void 0),eF=eZ([(0,h.Mo)("edgeless-connector-menu")],eF);var eU=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ej=class extends c.oi{constructor(){super(...arguments),this._menu=null}_toggleMenu(){this._menu?(this._menu.dispose(),this._menu=null):(this._menu=function(e){let t=document.createElement("edgeless-connector-menu");(0,d.kP)(e.shadowRoot),e.shadowRoot.appendChild(t);let i=(0,eE.fi)(e,t,{placement:"top",modifiers:[{name:"offset",options:{offset:[0,12]}}]});return{element:t,dispose:()=>{t.remove(),i.destroy()}}}(this),this._menu.element.mouseMode=this.mouseMode,this._menu.element.edgeless=this.edgeless)}updated(e){e.has("mouseMode")&&("connector"!==this.mouseMode.type&&(this._menu?.dispose(),this._menu=null),this._menu&&(this._menu.element.mouseMode=this.mouseMode,this._menu.element.edgeless=this.edgeless))}disconnectedCallback(){this._menu?.dispose(),this._menu=null,super.disconnectedCallback()}render(){let e=this.mouseMode?.type;return c.dy`
      <edgeless-tool-icon-button
        .tooltip=${"Connector"}
        .active=${"connector"===e}
        @click=${()=>{this.setMouseMode({type:"connector",mode:ee.oI.Orthogonal,color:Y.EJ}),this._toggleMenu()}}
      >
        ${X.p7}
      </edgeless-tool-icon-button>
    `}};ej.styles=c.iv`
    :host {
      display: flex;
    }
  `,eU([(0,h.Cb)()],ej.prototype,"mouseMode",void 0),eU([(0,h.Cb)()],ej.prototype,"edgeless",void 0),eU([(0,h.Cb)()],ej.prototype,"setMouseMode",void 0),ej=eU([(0,h.Mo)("edgeless-connector-tool-button")],ej);let eN=class extends(0,l.$T)(c.oi){constructor(e){super(),this._imageLoading=!1,this._rafId=null,this.setMouseMode=e=>{this.edgeless.selection.setMouseMode(e)},this.edgeless=e}get mouseMode(){return this.edgeless.mouseMode}get zoom(){return this.edgeless.surface.viewport.zoom}_setCenter(e,t){this.edgeless.surface.viewport.setCenter(e,t),this.edgeless.slots.viewportUpdated.emit()}_setZoom(e,t){this.edgeless.surface.viewport.setZoom(e,t),this.edgeless.slots.viewportUpdated.emit()}_setZoomByStep(e){this._smoothZoom((0,C.uZ)(this.zoom+e,ee.tm,ee.yF))}_smoothZoom(e,t){let i=e-this.zoom,n=()=>{this._rafId&&cancelAnimationFrame(this._rafId),this._rafId=requestAnimationFrame(()=>{let o=this._cutoff(this.zoom+i/10,e,i>0?1:-1);this._setZoom(o,t),o!=e&&n()})};n()}_cutoff(e,t,i){return i>0&&e>t||i<0&&e<t?t:e}_zoomToFit(){let e=[],t=this.edgeless.frames[0];if(t){let i=(0,ee.CV)(t.xywh),n=new ee.Mb(...i);e.push(n)}let i=this.edgeless.surface.getElementsBound();i&&e.push(i);let{viewport:n}=this.edgeless.surface,{centerX:o,centerY:r,zoom:a}=n;if(e.length){let{width:t,height:i}=n,s=(0,ee.ci)(e);(0,m.kP)(s),a=Math.min((t-200)/s.w,(i-200)/s.h),o=s.x+s.w/2,r=s.y+s.h/2}else a=1;let s=this.zoom,l=a,d=s/l;if(1===d)this._smoothTranslate(o,r);else{let e=n.center,t=new C.E9(o,r),i=t.subtract(e.scale(d)).scale(1/(1-d));this._smoothZoom(a,i)}}_smoothTranslate(e,t){let{viewport:i}=this.edgeless.surface,n={x:e-i.centerX,y:t-i.centerY},o=()=>{this._rafId&&cancelAnimationFrame(this._rafId),this._rafId=requestAnimationFrame(()=>{let r={x:n.x/10,y:n.y/10},a={x:i.centerX+r.x,y:i.centerY+r.y},s=n.x>0?1:-1,l=n.y>0?1:-1;a.x=this._cutoff(a.x,e,s),a.y=this._cutoff(a.y,t,l),this._setCenter(a.x,a.y),(a.x!=e||a.y!=t)&&o()})};o()}async _addImage(){this._imageLoading=!0;let e={width:0,height:0,offsetX:0,offsetY:0},t=await (0,C.mw)(this.edgeless.page,t=>Object.assign(e,t)),{left:i,width:n,top:o,height:r}=this.edgeless.pageBlockContainer.getBoundingClientRect();if(e.width&&e.height){let t=n/r,i=r>100?r-100:r,o=e.width/e.height;if(t>=1)e.height=e.height>i?i:Math.min(e.height,i),e.width=o*e.height;else{let n=i*t;e.width=e.width>n?n:Math.min(e.width,n),e.height=e.width/o}}let{zoom:a}=this.edgeless.surface.viewport,s=i+n/2,l=o+r/2,d=0,c=0;a>1?(d=s-e.width/2,c=l-e.height/2,e.width/=a,e.height/=a):(d=s-e.width*a/2,c=l-e.height*a/2);let{frameId:h}=this.edgeless.addNewFrame(t,new C.E9(d,c),e),u=this.edgeless.frames.find(e=>e.id===h);(0,m.kP)(u),this.edgeless.selection.switchToDefaultMode({selected:[u],active:!1}),this._imageLoading=!1}setZoomByAction(e){switch(e){case"fit":this._zoomToFit();break;case"reset":this._smoothZoom(1);break;case"in":case"out":this._setZoomByStep(ee.V4*("in"===e?1:-1))}}firstUpdated(){let{_disposables:e,edgeless:{slots:t}}=this;e.add(t.mouseModeUpdated.on(()=>this.requestUpdate())),e.add(t.viewportUpdated.on(()=>this.requestUpdate()))}render(){let{type:e}=this.mouseMode,t=`${Math.round(100*this.zoom)}%`;return c.dy`
      <div
        class="edgeless-toolbar-container"
        @dblclick=${S.UW}
        @mousedown=${S.UW}
        @mouseup=${S.UW}
        @pointerdown=${S.UW}
      >
        <edgeless-tool-icon-button
          .tooltip=${(0,el.zH)("Select","V")}
          .active=${"default"===e}
          @click=${()=>this.setMouseMode({type:"default"})}
        >
          ${X.GV}
        </edgeless-tool-icon-button>
        <edgeless-tool-icon-button
          .tooltip=${(0,el.zH)("Text","T")}
          .active=${"text"===e}
          @click=${()=>this.setMouseMode({type:"text"})}
        >
          ${s.i5}
        </edgeless-tool-icon-button>
        <edgeless-shape-tool-button
          .mouseMode=${this.mouseMode}
          .edgeless=${this.edgeless}
          .setMouseMode=${this.setMouseMode}
        ></edgeless-shape-tool-button>
        <edgeless-tool-icon-button
          .disabled=${this._imageLoading}
          .tooltip=${"Image"}
          @click=${()=>this._addImage()}
        >
          ${X.XB}
        </edgeless-tool-icon-button>
        <edgeless-connector-tool-button
          .mouseMode=${this.mouseMode}
          .edgeless=${this.edgeless}
          .setMouseMode=${this.setMouseMode}
        ></edgeless-connector-tool-button>
        <edgeless-brush-tool-button
          .mouseMode=${this.mouseMode}
          .edgeless=${this.edgeless}
          .setMouseMode=${this.setMouseMode}
        ></edgeless-brush-tool-button>
        <edgeless-tool-icon-button
          .tooltip=${(0,el.zH)("Hand","H")}
          .active=${"pan"===e}
          @click=${()=>this.setMouseMode({type:"pan",panning:!1})}
        >
          ${X.q$}
        </edgeless-tool-icon-button>
        <edgeless-tool-icon-button
          .tooltip=${(0,el.zH)("Note","N")}
          .active=${"note"===e}
          @click=${()=>this.setMouseMode({type:"note",background:g.je[0]})}
        >
          ${X.Zi}
        </edgeless-tool-icon-button>
        <div class="divider"></div>
        <edgeless-tool-icon-button
          .tooltip=${"Fit to screen"}
          @click=${()=>this._zoomToFit()}
        >
          ${X.AQ}
        </edgeless-tool-icon-button>
        <edgeless-tool-icon-button
          .tooltip=${"Zoom out"}
          @click=${()=>this._setZoomByStep(-ee.V4)}
        >
          ${X.V_}
        </edgeless-tool-icon-button>
        <span class="zoom-percent" @click=${()=>this._smoothZoom(1)}>
          ${t}
        </span>
        <edgeless-tool-icon-button
          .tooltip=${"Zoom in"}
          @click=${()=>this._setZoomByStep(ee.V4)}
        >
          ${X.pO}
        </edgeless-tool-icon-button>
      </div>
    `}};eN.styles=c.iv`
    :host {
      position: absolute;
      z-index: 2;
      bottom: 28px;
      left: calc(50%);
      display: flex;
      justify-content: center;
      transform: translateX(-50%);
      user-select: none;
    }

    .edgeless-toolbar-container {
      display: flex;
      align-items: center;
      height: 48px;
      background: var(--affine-background-overlay-panel-color);
      box-shadow: var(--affine-shadow-2);
      border-radius: 8px;
      fill: currentcolor;
    }

    .edgeless-toolbar-container[level='second'] {
      position: absolute;
      bottom: 8px;
      transform: translateY(-100%);
    }

    .edgeless-toolbar-container[hidden] {
      display: none;
    }

    .divider {
      width: 1px;
      height: 24px;
      margin: 0 7px;
      background-color: var(--affine-border-color);
    }

    .zoom-percent {
      display: block;
      box-sizing: border-box;
      width: 48px;
      height: 32px;
      line-height: 22px;
      padding: 5px;
      border-radius: 5px;
      font-size: 14px;
      font-weight: 500;
      text-align: center;
      cursor: pointer;
      color: var(--affine-icon-color);
    }

    .zoom-percent:hover {
      color: var(--affine-primary-color);
      background-color: var(--affine-hover-color);
    }
  `,eN=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a}([(0,h.Mo)("edgeless-toolbar")],eN);var eW=i(23862),eq=i(63863),eY=i(91097);class eX{constructor(e){this._draggingArea=null,this.enableHover=!1,this._edgeless=e}get draggingArea(){return this._draggingArea}get _surface(){return this._edgeless.surface}get _page(){return this._edgeless.page}get _blocks(){return this._edgeless.sortedFrames}}(o=a||(a={})).ContentMoving="content-moving",o.Selecting="selecting",o.NativeEditing="native-editing",o.None="none",o.PreviewDragging="preview-dragging",o.AltCloning="alt-cloning";class eK extends eX{constructor(){super(...arguments),this.mouseMode={type:"default"},this.enableHover=!0,this.dragType=a.None,this._startRange=null,this._dragStartPos={x:0,y:0},this._dragLastPos={x:0,y:0},this._lock=!1,this._isDoubleClickedOnMask=!1}get draggingArea(){return this.dragType===a.Selecting?{start:new DOMPoint(this._dragStartPos.x,this._dragStartPos.y),end:new DOMPoint(this._dragLastPos.x,this._dragLastPos.y)}:null}get selectedBlocks(){return this._edgeless.selection.selectedBlocks}get state(){return this._edgeless.selection.state}get isActive(){return this._edgeless.selection.state.active}_pick(e,t){let{surface:i}=this._edgeless,[n,o]=i.viewport.toModelCoord(e,t),r=i.pickTop(n,o);return r||(0,S.sU)(this._blocks,n,o)}_setNoneSelectionState(){this._edgeless.slots.selectionUpdated.emit({selected:[],active:!1}),(0,C.xT)(null)}_setSelectionState(e,t){this._edgeless.slots.selectionUpdated.emit({selected:e,active:t})}_handleClickOnSelected(e,t){let{selected:i,active:n}=this.state;if(this._edgeless.clearSelectedBlocks(),n&&1===i.length&&i[0]===e){(0,C.bQ)(t.raw.clientX,t.raw.clientY);return}if(!t.keys.shift&&1===i.length&&(0,S.Zi)(e)&&(i[0]===e&&!n||n&&i[0]!==e)){this._setSelectionState([e],!0),this._edgeless.slots.selectedBlocksUpdated.emit([]);return}if(t.keys.shift){let t=[...i];i.includes(e)?this._setSelectionState(t.filter(t=>t!==e),!1):this._setSelectionState([...t,e],!1)}else this._setSelectionState([e],!1)}_handleDragMoveEffect(e){(0,S.bt)(e,this.state.selected,this._edgeless.surface,this._page)}_handleSurfaceDragMove(e,t){this._lock||(this._lock=!0,this._page.captureSync());let{surface:i}=this._edgeless,{zoom:n}=i.viewport,o=this._dragLastPos.x-t.x,r=this._dragLastPos.y-t.y,a=e.x-o/n,s=e.y-r/n,l=e.w,d=e.h;("connector"!==e.type||e instanceof ee.vy&&(0,S.i1)(e,this.state.selected))&&i.setElementBound(e.id,{x:a,y:s,w:l,h:d}),this._handleDragMoveEffect(e)}_handleBlockDragMove(e,t){let[i,n,o,r]=JSON.parse(e.xywh),{zoom:a}=this._edgeless.surface.viewport,s=JSON.stringify([i+t.delta.x/a,n+t.delta.y/a,o,r]);this._page.updateBlock(e,{xywh:s}),this._handleDragMoveEffect(e),this.selectedBlocks.length&&this._edgeless.slots.selectedBlocksUpdated.emit(this.selectedBlocks)}_isInSelectedRect(e,t){let{selected:i}=this.state;if(!i.length)return!1;let n=(0,ee.ci)(i.map(e=>{if((0,S.Zi)(e)){let[t,i,n,o]=(0,ee.CV)((0,S.XA)(e));return{x:t,y:i,w:n,h:o}}return e})),[o,r]=this._surface.toModelCoord(e,t);return!!(n&&(0,ee.Gn)(n,o,r))}_forceUpdateSelection(){this._edgeless.slots.selectionUpdated.emit({...this.state})}_tryDeleteEmptyBlocks(){let e=this._blocks.filter(e=>(0,C.xb)(e));e.length===this._blocks.length&&e.shift(),e.length&&(this._page.captureSync(),e.forEach(e=>this._page.deleteBlock(e)))}_updateDragHandle(e){let t=this.state.selected[0];if(!t||!(0,S.Zi)(t))return;let i=(0,C._b)(t);(0,m.kP)(i);let{raw:{clientX:n,clientY:o}}=e,r=new C.E9(n,o),a=(0,C.cy)(r,{container:i,rect:C.UL.fromDOM(i)},this._edgeless.surface.viewport.zoom),s=null;a&&(s={element:a,model:(0,C.gc)(a),rect:(0,C.az)(a)},this._edgeless.components.dragHandle?.onContainerMouseMove(e,s))}onContainerClick(e){this._tryDeleteEmptyBlocks();let t=this._pick(e.x,e.y);t?this._handleClickOnSelected(t,e):this._setNoneSelectionState(),this._isDoubleClickedOnMask=!1}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){let t=this._pick(e.x,e.y);if(t){if(t instanceof ee.Gy){(0,S.RT)(t,this._edgeless);return}}else{(0,S.F4)(this._edgeless,e);return}if(e.raw.target&&e.raw.target instanceof HTMLElement&&e.raw.target.classList.contains("affine-edgeless-mask")){this.onContainerClick(e),this._isDoubleClickedOnMask=!0;return}(0,_.Xf)("double",e,this._page,this._edgeless)}onContainerTripleClick(e){this._isDoubleClickedOnMask||(0,_.Xf)("triple",e,this._page,this._edgeless)}_determineDragType(e){if(this._isInSelectedRect(e.x,e.y))return this.state.active?a.NativeEditing:a.ContentMoving;{let t=this._pick(e.x,e.y);return t?(this._setSelectionState([t],!1),a.ContentMoving):a.Selecting}}async _cloneContent(e){this._lock=!0;let{surface:t}=this._edgeless,i=await Promise.all(this.state.selected.map(async e=>await this._cloneSelected(e,t)));this._setSelectionState(i,!1)}async _cloneSelected(e,t){if((0,S.Zi)(e)){let t=this._edgeless.getService("affine:frame"),i=this._page.addBlock("affine:frame",{xywh:e.xywh},this._page.root?.id),n=this._page.getBlockById(i);return(0,m.kP)(n),await t.json2Block(n,t.block2Json(e).children),this._page.getBlockById(i)}{let i=t.addElement(e.type,e.serialize());return t.pickById(i)}}async onContainerDragStart(e){let t=this._determineDragType(e);e.keys.alt&&t===a.ContentMoving&&(t=a.AltCloning,await this._cloneContent(e)),this.initializeDragState(e,t)}initializeDragState(e,t){this.dragType=t,this._startRange=(0,V.Qo)(e.x,e.y),this._dragStartPos={x:e.x,y:e.y},this._dragLastPos={x:e.x,y:e.y}}onContainerDragMove(e){switch(this.dragType){case a.Selecting:{let t=this._dragStartPos.x,i=this._dragStartPos.y,n=Math.min(t,e.x),o=Math.min(i,e.y),[r,a]=this._surface.toModelCoord(n,o),s=Math.abs(t-e.x),l=Math.abs(i-e.y),{zoom:d}=this._surface.viewport,c={x:r,y:a,w:s/d,h:l/d},h=(0,S.YC)(this._blocks,c),u=this._surface.pickByBound(c);this._setSelectionState([...h,...u],!1);break}case a.AltCloning:case a.ContentMoving:this.state.selected.forEach(t=>{(0,S.Xd)(t)?this._handleSurfaceDragMove(t,e):this._handleBlockDragMove(t,e)}),this._forceUpdateSelection();break;case a.NativeEditing:(0,C.cS)(this._startRange,e)}this._dragLastPos={x:e.x,y:e.y}}onContainerDragEnd(e){if(this._lock&&(this._page.captureSync(),this._lock=!1),this.isActive){let{direction:t,selectedType:i}=(0,$.$U)(e);if("Caret"===i)return;(0,L.T)({page:this._page,container:this._edgeless,direction:t,anchorEl:{getBoundingClientRect:()=>(0,$.EM)(t)}})}this.dragType=a.None,this._dragStartPos={x:0,y:0},this._dragLastPos={x:0,y:0},this._forceUpdateSelection()}onContainerMouseMove(e){this.dragType!==a.PreviewDragging&&this._updateDragHandle(e)}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}var eG=i(48616);class eQ{constructor(){this._cachedElements=new Map,this._lastRects=new Map,this.slots={resize:new d.g7},this._onResize=e=>{let t=new Map;e.forEach(e=>{let i=e.target.closest(`[${g.SF}]`),n=i?.getAttribute(g.SF);if(n){if(this._lastRects.has(n)){let t=this._lastRects.get(n);if(t&&(0,et.dA)(t.x,e.contentRect.x)&&(0,et.dA)(t.y,e.contentRect.y)&&(0,et.dA)(t.width,e.contentRect.width)&&(0,et.dA)(t.height,e.contentRect.height))return}this._lastRects.set(n,e.contentRect),t.set(n,e.contentRect)}}),t.size&&this.slots.resize.emit(t)},this._observer=new ResizeObserver((0,et.P2)(this._onResize,1e3/60))}resetListener(e){let t=new Set(this._cachedElements.keys());e.root?.children.forEach(e=>{let i=e.id;t.delete(i);let n=(0,eG._b)(e),o=n?.querySelector(".affine-frame-block-container"),r=this._cachedElements.get(i);if(r){if(o===r)return;this._observer.unobserve(r),this._cachedElements.delete(i)}o&&(this._observer.observe(o),this._cachedElements.set(i,o))}),t.forEach(e=>{let t=this._cachedElements.get(e);t&&this._observer.unobserve(t)})}dispose(){this._observer.disconnect(),this.slots.resize.dispose(),this._cachedElements.clear(),this._lastRects.clear()}}var eJ=i(6635),e1=i(95033);function e2(e,t,i=!1){(i||!e.selection.isActive)&&e.selection.setMouseMode(t)}class e0 extends eX{constructor(){super(...arguments),this.mouseMode={type:"brush",color:Y.EJ,lineWidth:4},this._draggingElementId=null,this._draggingPathPoints=null}onContainerClick(e){(0,C.ZT)()}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){if(!this._page.awarenessStore.getFlag("enable_surface"))return;this._page.captureSync();let{viewport:t}=this._edgeless.surface,[i,n]=t.toModelCoord(e.point.x,e.point.y),{color:o,lineWidth:r}=this.mouseMode,a=[[i,n]],s=this._surface.addElement("brush",{points:a,color:o,lineWidth:r});this._draggingElementId=s,this._draggingPathPoints=a,this._edgeless.slots.surfaceUpdated.emit()}onContainerDragMove(e){if(!this._page.awarenessStore.getFlag("enable_surface")||!this._draggingElementId)return;(0,m.kP)(this._draggingElementId),(0,m.kP)(this._draggingPathPoints);let{lineWidth:t}=this.mouseMode,[i,n]=this._edgeless.surface.toModelCoord(e.point.x,e.point.y),o=[...this._draggingPathPoints,[i,n]];this._draggingPathPoints=o,this._surface.updateElement(this._draggingElementId,{points:o,lineWidth:t}),this._edgeless.slots.surfaceUpdated.emit()}onContainerDragEnd(e){this._draggingElementId=null,this._draggingPathPoints=null,this._page.captureSync(),this._edgeless.slots.surfaceUpdated.emit()}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}class e5 extends eX{constructor(){super(...arguments),this.mouseMode={type:"connector"},this._draggingElementId=null,this._draggingArea=null,this._draggingStartElement=null,this._draggingStartRect=null}_pickBy(e,t,i){let{surface:n}=this._edgeless;return(0,S.D9)(n,this._page,e,t,i)}onContainerClick(e){(0,C.ZT)()}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){if(!this._page.awarenessStore.getFlag("enable_surface"))return;this._page.captureSync();let{viewport:t}=this._edgeless.surface,{mode:i,color:n}=this.mouseMode,[o,r]=t.toModelCoord(e.x,e.y);this._draggingStartElement=this._pickBy(e.x,e.y,e=>"connector"!==e.type),this._draggingStartRect=this._draggingStartElement?new eP.A(...(0,ee.CV)((0,S.XA)(this._draggingStartElement))):null;let{point:a,position:s}=(0,S.sI)(o,r,this._draggingStartRect);this._draggingStartPoint=a;let l=this._surface.addElement("connector",{color:n,mode:i,controllers:[{x:o,y:r},{x:o+1,y:r+1}],lineWidth:4,strokeStyle:ee.qb.Solid,startElement:this._draggingStartElement&&s?{id:this._draggingStartElement.id,position:s}:void 0});this._draggingElementId=l,this._draggingArea={start:new DOMPoint(e.x,e.y),end:new DOMPoint(e.x,e.y)},this._edgeless.slots.surfaceUpdated.emit()}onContainerDragMove(e){if(!this._page.awarenessStore.getFlag("enable_surface"))return;(0,m.kP)(this._draggingElementId),(0,m.kP)(this._draggingArea);let{viewport:t}=this._edgeless.surface,{mode:i}=this.mouseMode;this._draggingArea.end=new DOMPoint(e.x,e.y);let n=this._draggingElementId,o=this._draggingStartPoint.x,r=this._draggingStartPoint.y,[a,s]=t.toModelCoord(e.x,e.y),l=this._pickBy(e.x,e.y,e=>e.id!==n&&"connector"!==e.type),d=l&&l.id!==n?new eP.A(...(0,ee.CV)((0,S.XA)(l))):null,{point:{x:c,y:h},position:u}=(0,S.sI)(a,s,d),f=(0,S.T7)(this._draggingStartRect,d,{x:o,y:r},{x:c,y:h},[],i);this._surface.updateElement(n,{controllers:f,endElement:l&&u?{id:l.id,position:u}:void 0}),this._edgeless.slots.surfaceUpdated.emit()}onContainerDragEnd(e){let t=this._draggingElementId;(0,m.kP)(t),this._draggingElementId=null,this._draggingArea=null,this._page.captureSync();let i=this._surface.pickById(t);(0,m.kP)(i),this._edgeless.selection.switchToDefaultMode({selected:[i],active:!1})}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}class e3 extends eX{constructor(){super(...arguments),this.mouseMode={type:"note"},this._dragStartEvent=null}_addNote(e,t=S.xM){(0,S.AL)(this._edgeless,this._page,e,t)}onContainerClick(e){this._addNote(e)}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){this._dragStartEvent=e,this._draggingArea={start:new DOMPoint(e.x,e.y),end:new DOMPoint(e.x,e.y)}}onContainerDragMove(e){this._draggingArea&&(this._draggingArea.end=new DOMPoint(e.x,e.y),this._edgeless.slots.hoverUpdated.emit())}onContainerDragEnd(e){if(this._dragStartEvent){let t=e.x>this._dragStartEvent.x?this._dragStartEvent:e,i=Math.max(Math.abs(e.x-this._dragStartEvent.x),S.xM);this._addNote(t,i)}this._dragStartEvent=null,this._draggingArea=null}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}class e7 extends eX{constructor(){super(...arguments),this.mouseMode={type:"pan"},this._lastPoint=null}onContainerClick(e){(0,C.ZT)()}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){this._page.awarenessStore.getFlag("enable_surface")&&(this._lastPoint=[e.x,e.y],this._edgeless.slots.mouseModeUpdated.emit({type:"pan",panning:!0}))}onContainerDragMove(e){if(!this._page.awarenessStore.getFlag("enable_surface")||!this._lastPoint)return;let{viewport:t}=this._edgeless.surface,{zoom:i}=t,[n,o]=this._lastPoint,r=n-e.x,a=o-e.y;this._lastPoint=[e.x,e.y],t.applyDeltaCenter(r/i,a/i),this._edgeless.slots.viewportUpdated.emit()}onContainerDragEnd(){this._lastPoint=null,this._edgeless.slots.mouseModeUpdated.emit({type:"pan",panning:!1})}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}class e4 extends eX{constructor(){super(...arguments),this.mouseMode={type:"shape",shape:"rect",fillColor:eh,strokeColor:ef},this._draggingElementId=null,this._draggingArea=null}onContainerClick(e){(0,C.ZT)()}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){if(!this._page.awarenessStore.getFlag("enable_surface"))return;this._page.captureSync();let{viewport:t}=this._edgeless.surface,[i,n]=t.toModelCoord(e.point.x,e.point.y),o=new ee.Mb(i,n,0,0),{shape:r,fillColor:a,strokeColor:s}=this.mouseMode,l=this._surface.addElement("shape",{shapeType:"roundedRect"===r?"rect":r,xywh:o.serialize(),strokeColor:s,fillColor:a,filled:!(0,Y.Qm)(a),radius:"roundedRect"===r?.1:0,strokeWidth:4,strokeStyle:ee.qb.Solid});this._draggingElementId=l,this._draggingArea={start:new DOMPoint(e.x,e.y),end:new DOMPoint(e.x,e.y)},this._edgeless.slots.surfaceUpdated.emit()}onContainerDragMove(e){this._page.awarenessStore.getFlag("enable_surface")&&((0,m.kP)(this._draggingElementId),(0,m.kP)(this._draggingArea),this._draggingArea.end=new DOMPoint(e.x,e.y),this._resize(e.keys.shift||this._edgeless.selection.shiftKey))}onContainerDragEnd(e){let t=this._draggingElementId;(0,m.kP)(t),this._draggingElementId=null,this._draggingArea=null,this._page.captureSync();let i=this._surface.pickById(t);(0,m.kP)(i),this._edgeless.selection.switchToDefaultMode({selected:[i],active:!1})}onPressShiftKey(e){let t=this._draggingElementId;t&&this._resize(e)}_resize(e=!1){let{_draggingElementId:t,_draggingArea:i,_edgeless:n}=this;(0,m.kP)(t),(0,m.kP)(i);let{slots:o,surface:r}=n,{viewport:a}=r,{zoom:s}=a,{start:{x:l,y:d},end:c}=i,{x:h,y:u}=c;if(e){let e=Math.abs(h-l),t=Math.abs(u-d),i=Math.max(e,t);h=l+(h>l?i:-i),u=d+(u>d?i:-i)}let[f,p]=a.toModelCoord(Math.min(l,h),Math.min(d,u)),g=Math.abs(l-h)/s,v=Math.abs(d-u)/s,b=new ee.Mb(f,p,g,v);r.setElementBound(t,b),o.surfaceUpdated.emit()}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}}class e6 extends eX{constructor(){super(...arguments),this.mouseMode={type:"text"}}onContainerClick(e){(0,S.F4)(this._edgeless,e)}onContainerContextMenu(e){(0,C.ZT)()}onContainerDblClick(e){(0,C.ZT)()}onContainerTripleClick(e){(0,C.ZT)()}onContainerDragStart(e){(0,C.ZT)()}onContainerDragMove(e){(0,C.ZT)()}onContainerDragEnd(e){(0,C.ZT)()}onContainerMouseMove(e){(0,C.ZT)()}onContainerMouseOut(e){(0,C.ZT)()}onPressShiftKey(e){(0,C.ZT)()}}function e8(e){let t=e.target;return!!(t&&t instanceof HTMLElement)&&("INPUT"===t.tagName||"FORMAT-QUICK-BAR"===t.tagName||"AFFINE-DRAG-HANDLE"===t.tagName)}class e9 extends C.nF{get isActive(){return this.state.active}get lastMousePos(){return this._lastMousePos}get mouseMode(){return this._mouseMode}set mouseMode(e){this._mouseMode=e,this._controllers[this._mouseMode.type].mouseMode=this._mouseMode}get currentController(){return this._controllers[this.mouseMode.type]}get draggingArea(){if(!this.currentController.draggingArea)return null;let{start:e,end:t}=this.currentController.draggingArea,i=Math.min(e.x,t.x),n=Math.min(e.y,t.y),o=Math.max(e.x,t.x),r=Math.max(e.y,t.y);return new DOMRect(i,n,o-i,r-n)}get shiftKey(){return this._shiftKey}set shiftKey(e){this._shiftKey=e,this.currentController.onPressShiftKey(e)}constructor(e,t){super(e,t),this._mouseMode={type:"default"},this._lastMousePos={x:0,y:0},this._rightClickTimer=null,this._shiftKey=!1,this.selectedBlocks=[],this.lastState=null,this.state={selected:[],active:!1},this._add=(e,t)=>{this._disposables.add(this._dispatcher.add(e,t))},this._onContainerDragStart=e=>{if(!this.page.readonly&&(2!==e.button||"pan"===this.mouseMode.type))return this.currentController.onContainerDragStart(e)},this._onContainerDragMove=e=>{if(!this.page.readonly&&(2!==e.button||"pan"===this.mouseMode.type))return this.currentController.onContainerDragMove(e)},this._onContainerDragEnd=e=>{if(!this.page.readonly&&(2!==e.button||"pan"===this.mouseMode.type))return this.currentController.onContainerDragEnd(e)},this._onContainerClick=e=>{let t=(0,C.Ne)(this.container);return x.y.setActive(t),this.currentController.onContainerClick(e)},this._onContainerDblClick=e=>this.currentController.onContainerDblClick(e),this._onContainerTripleClick=e=>this.currentController.onContainerTripleClick(e),this._onContainerPointerMove=e=>(this._updateLastMousePos(e),this.container.slots.hoverUpdated.emit(),this._controllers[this.mouseMode.type].onContainerMouseMove(e)),this._onContainerPointerOut=e=>this._controllers[this.mouseMode.type].onContainerMouseOut(e),this._onContainerContextMenu=e=>{e.raw.preventDefault();let t=this.mouseMode;"pan"===t.type||this._rightClickTimer||(this._rightClickTimer={mouseMode:t,timeStamp:e.raw.timeStamp,timer:window.setTimeout(()=>{this._controllers.pan.onContainerDragStart(e)},233)})},this._onContainerPointerUp=e=>{if(2===e.button&&this._rightClickTimer){let{timer:t,timeStamp:i,mouseMode:n}=this._rightClickTimer;e.raw.timeStamp-i>233?this.container.slots.mouseModeUpdated.emit(n):clearTimeout(t),this._rightClickTimer=null}},this._onSelectionChangeWithoutDebounce=()=>{R(this.page)},this.setMouseMode=(e,t={selected:[],active:!1})=>{this.mouseMode!==e&&("default"===e.type?!t.selected.length&&this.lastState?(t=this.lastState,this.lastState=null):this.lastState=t:this.state.selected.length&&(this.lastState=this.state),this.container.slots.mouseModeUpdated.emit(e),this.container.slots.selectionUpdated.emit(t))},this._controllers={default:new eK(this.container),text:new e6(this.container),shape:new e4(this.container),brush:new e0(this.container),pan:new e7(this.container),note:new e3(this.container),connector:new e5(this.container)},this._initMouseAndWheelEvents()}_updateLastMousePos(e){this._lastMousePos={x:e.x,y:e.y}}async _initMouseAndWheelEvents(){this.container.surface||await new Promise(e=>requestAnimationFrame(e)),this._add("dragStart",e=>{let t=e.get("pointerState");e8(t.raw)||((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||(0,C.ok)(t.raw.target)||t.raw.preventDefault(),this._onContainerDragStart(t))}),this._add("dragMove",e=>{let t=e.get("pointerState");e8(t.raw)||((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||(0,C.ok)(t.raw.target)||t.raw.preventDefault(),this._onContainerDragMove(t))}),this._add("dragEnd",e=>{let t=e.get("pointerState");(0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||(0,C.ok)(t.raw.target)||t.raw.preventDefault(),this._onContainerDragEnd(t)}),this._add("click",e=>{let t=e.get("pointerState");(0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||(0,C.ok)(t.raw.target)||t.raw.preventDefault(),this._onContainerClick(t)}),this._add("doubleClick",e=>{let t=e.get("pointerState");e8(t.raw)||this._onContainerDblClick(t)}),this._add("tripleClick",e=>{let t=e.get("pointerState");e8(t.raw)||this._onContainerTripleClick(t)}),this._add("pointerMove",e=>{let t=e.get("pointerState");e8(t.raw)||((0,C.zv)(t.raw.target)||(0,C.Rn)(t.raw.target)||(0,C.ok)(t.raw.target)||t.raw.preventDefault(),this._onContainerPointerMove(t))}),this._add("pointerUp",e=>{let t=e.get("pointerState");this._onContainerPointerUp(t)}),this._add("pointerOut",e=>{let t=e.get("pointerState");this._onContainerPointerOut(t)}),this._add("contextMenu",e=>{let t=e.get("pointerState");this._onContainerContextMenu(t)}),this._add("selectionChange",()=>{this._onSelectionChangeWithoutDebounce()}),this._add("wheel",e=>{let t=e.get("defaultState"),i=t.event;if(!(i instanceof WheelEvent))return;i.preventDefault();let n=this.container,{viewport:o}=n.surface;if((0,C.KO)(i)){let e=n.getBoundingClientRect(),[t,r]=n.surface.toModelCoord(i.clientX-e.x,i.clientY-e.y),a=(0,ee.rQ)(i.deltaY,o.zoom);o.setZoom(a,new C.E9(t,r)),n.slots.viewportUpdated.emit()}else{let e=i.deltaX/o.zoom,t=i.deltaY/o.zoom;o.applyDeltaCenter(e,t),n.slots.viewportUpdated.emit()}})}refreshRemoteSelection(){let e=document.querySelector("remote-selection");e&&e.requestUpdate()}getHoverState(){if(!this.currentController.enableHover)return null;let{surface:e}=this.container,t=(this.page.root?.children??[]).filter(e=>"affine:frame"===e.flavour),{x:i,y:n}=this._lastMousePos,[o,r]=e.toModelCoord(i,n),a=e.pickTop(o,r)||(0,S.sU)(t,o,r);if((0,S.Zi)(a)&&"default"===this.mouseMode.type&&this.state.active&&this.state.selected[0].id===a.id||this.container.components.dragHandle?.hide(),!a||this.state.active)return null;let s=(0,S.XA)(a);return{rect:(0,S.ry)(e.viewport,s),content:a}}switchToDefaultMode(e){this.setMouseMode({type:"default"},e)}clear(){this.selectedBlocks=[],this.lastState=null,this.state={selected:[],active:!1}}dispose(){this._disposables.dispose()}}var te=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let tt=class extends l.z3{constructor(){super(...arguments),this.flavour="edgeless",this.components={dragHandle:null,toolbar:null},this.showGrid=!0,this.mouseMode={type:"default"},this._rectsOfSelectedBlocks=[],this.clipboard=new b.rn(this.page,this),this.slots={viewportUpdated:new d.g7,selectedBlocksUpdated:new d.g7,selectionUpdated:new d.g7,hoverUpdated:new d.g7,surfaceUpdated:new d.g7,mouseModeUpdated:new d.g7,reorderingFramesUpdated:new d.g7,reorderingShapesUpdated:new d.g7,zoomUpdated:new d.g7,pressShiftKeyUpdated:new d.g7,subpageLinked:new d.g7,subpageUnlinked:new d.g7,pageLinkClicked:new d.g7},this.indexes={max:"a0",min:"a0"},this.getService=y.getService,this._resizeObserver=null,this._frameResizeObserver=new eQ,this._initDragHandle=()=>{let e=()=>{var e;this.components.dragHandle=(e=this,new eY.DU({container:e.mouseRoot,onDropCallback(t,i,n,o){let r=(0,C.rc)(i);if(!r.length)return;let a=r.map(C.gc);if(!a.length)return;let s=e.page;if(n&&"none"!==o){let{model:i}=n;if(1===a.length&&(0,C.k)(s,i,a[0]))return;let r=a[0].id,l=(0,C.lK)(i.id,e);(0,d.kP)(l);let c=(0,C.lK)(r,e);if((0,d.kP)(c),s.captureSync(),"database"===o)s.moveBlocks(a,i);else{let e=s.getParent(i);(0,d.kP)(e),s.moveBlocks(a,e,i,"before"===o)}e.setSelection(l.model.id,!0,r,t);return}s.captureSync();let l=s.getParent(a[0]);(0,d.kP)(l);let c=l.children.findIndex(e=>e.id===a[0].id),h=l.children.findIndex(e=>e.id===a[a.length-1].id);if(e.moveBlocksWithNewFrame(a,t,{rect:(0,C.az)(r[0]),focus:!0,frameIndex:0===c?0:void 0}),0!==c&&h!==l.children.length-1){let t=(0,C._b)(l?.children[h]);(0,d.kP)(t);let i=(0,C.az)(t);e.moveBlocksWithNewFrame(l?.children.slice(h),new C.E9(i.x,i.y),{rect:i})}},setDragType(t){let{selection:i}=e;if("default"===i.mouseMode.type){let e=i.currentController;e.dragType=t?a.PreviewDragging:a.None}},setSelectedBlock(t){let i=[];t&&i.push(t.element),e.slots.selectedBlocksUpdated.emit(i)},getSelectedBlocks:()=>e.selection.selectedBlocks,getClosestBlockElement(t){if("default"!==e.mouseMode.type)return null;let i=(0,C.ev)(t);return i?(0,C.cy)(t,{container:i,rect:C.UL.fromDOM(i)},e.surface.viewport.zoom):null}}))};this.page.awarenessStore.getFlag("enable_drag_handle")&&!this.components.dragHandle&&e(),this._disposables.add(this.page.awarenessStore.slots.update.subscribe(e=>e.state?.flags.enable_drag_handle,t=>{if(t){if(this.components.dragHandle)return;e();return}this.components.dragHandle?.remove(),this.components.dragHandle=null},{filter:e=>e.id===this.page.doc.clientID}))},this.reorderFrames=({elements:e,type:t})=>{let i=(e,t)=>{this.updateIndexes(e,t,e=>{let t=e[0];t<this.indexes.min&&(this.indexes.min=t);let i=e[e.length-1];i>this.indexes.max&&(this.indexes.max=i)})};switch(t){case"front":this._reorderTo(e,()=>({start:this.indexes.max,end:null}),i);break;case"forward":this._reorder(e,e=>({start:(0,ee.vk)(null,e[0].index),end:null}),()=>this.getSortedElementsWithViewportBounds(e),C.jR,i);break;case"backward":this._reorder(e,e=>({start:null,end:e[e.length-1].index}),()=>this.getSortedElementsWithViewportBounds(e),C.JP,i);break;case"back":this._reorderTo(e,()=>({start:null,end:this.indexes.min}),i)}},this.reorderShapes=({elements:e,type:t})=>{let i=(e,t)=>{this.surface.updateIndexes(e,t,e=>{let t=e[0];t<this.surface.indexes.min&&(this.surface.indexes.min=t);let i=e[e.length-1];i>this.surface.indexes.max&&(this.surface.indexes.max=i)})};switch(t){case"front":this._reorderTo(e,()=>({start:this.surface.indexes.max,end:null}),i);break;case"forward":this._reorder(e,e=>({start:(0,ee.vk)(null,e[0].index),end:null}),()=>this.surface.getSortedElementsWithViewportBounds(),C.jR,i);break;case"backward":this._reorder(e,e=>({start:null,end:e[e.length-1].index}),()=>this.surface.getSortedElementsWithViewportBounds(),C.JP,i);break;case"back":this._reorderTo(e,()=>({start:null,end:this.surface.indexes.min}),i)}}}get frames(){return this.model.children.filter(e=>"affine:frame"===e.flavour)}get sortedFrames(){return this.frames.sort(ee.qu)}_clearSelection(){requestAnimationFrame(()=>{this.selection.isActive||(0,C.xT)(null)})}_initSurface(){let{page:e,parentElement:t}=this,i=this.model.children.find(e=>"affine:surface"===e.flavour);(0,d.kP)(t),(0,d.kP)(i);let n=e.getYBlockById(i.id);(0,d.kP)(n);let o=n.get("elements");o||(o=new e.YMap,n.set("elements",o)),this.surface=new ee.Bo(o,e=>{if((0,eW.xZ)(e)){let i=(0,eq.cx)(t,e);return void 0===i&&console.error(Error(`All variables should have a value. Please check for any dirty data or variable renaming.Variable: ${e}`)),i??e}return e}),this._disposables.add((0,eq.zp)(this,()=>{this.surface.refresh()}))}_handleToolbarFlag(){let e=()=>{let e=new eN(this);this.appendChild(e),this.components.toolbar=e};this.page.awarenessStore.getFlag("enable_edgeless_toolbar")&&!this.components.toolbar&&e(),this._disposables.add(this.page.awarenessStore.slots.update.subscribe(e=>e.state?.flags.enable_edgeless_toolbar,t=>{if(t){if(this.components.toolbar)return;e();return}this.components.toolbar?.remove(),this.components.toolbar=null},{filter:e=>e.id===this.page.doc.clientID}))}_initSlotEffects(){let{_disposables:e,slots:t}=this;e.add(t.viewportUpdated.on(()=>{let e=this.style.getPropertyValue("--affine-zoom"),i=this.surface.viewport.zoom;e&&+e===i||(this.style.setProperty("--affine-zoom",`${i}`),this.components.dragHandle?.setScale(i)),this.components.dragHandle?.hide(),this.selection.selectedBlocks.length&&t.selectedBlocksUpdated.emit([...this.selection.selectedBlocks]),this.requestUpdate()})),e.add(t.selectedBlocksUpdated.on(e=>{this.selection.selectedBlocks=e,requestAnimationFrame(()=>{this._rectsOfSelectedBlocks=e.map(C.az)})})),e.add(t.hoverUpdated.on(()=>this.requestUpdate())),e.add(t.selectionUpdated.on(e=>{this.selection.state=e,this._clearSelection(),this.requestUpdate()})),e.add(t.surfaceUpdated.on(()=>this.requestUpdate())),e.add(t.mouseModeUpdated.on(e=>{"default"!==e.type&&this.components.dragHandle?.hide(),this.mouseMode=e})),e.add(this.page.slots.historyUpdated.on(()=>{this._clearSelection(),this.requestUpdate()})),e.add(this.selection),e.add(this.surface),e.add(function(e){let t=e1.A.newScope(e1.G.AFFINE_EDGELESS);x.y.isActive(e)&&e1.A.setScope(t);let i=x.y.activeSlot.on(()=>{x.y.isActive(e)&&e1.A.setScope(t)});return e1.A.withScope(t,()=>{let t,i;e1.A.addListener(g.LM.UP,t=>(0,_.vo)(t,e.page,{zoom:e.surface.viewport.zoom})),e1.A.addListener(g.LM.DOWN,t=>(0,_.DZ)(t,e.page,{zoom:e.surface.viewport.zoom})),e1.A.addListener("v",()=>e2(e,{type:"default"})),e1.A.addListener("t",()=>e2(e,{type:"text"})),e1.A.addListener("h",()=>e2(e,{type:"pan",panning:!1})),e1.A.addListener("n",()=>e2(e,{type:"note",background:g.je[0]})),e1.A.addListener("p",()=>e2(e,{type:"brush",color:Y.EJ,lineWidth:eg.h.Thin})),e1.A.addListener("s",()=>e2(e,{type:"shape",shape:"rect",fillColor:eh,strokeColor:ef})),e1.A.addListener(g.LM.ESC,()=>{e.slots.selectionUpdated.emit({selected:[],active:!1}),e2(e,{type:"default"},!0)}),e1.A.addListener(g.LM.SELECT_ALL,t=>{t.preventDefault(),e.slots.selectionUpdated.emit({selected:[...e.frames,...e.surface.getElements()],active:!1})}),e1.A.addListener(`${eJ.jQ}+1`,t=>{t.preventDefault(),e.slots.zoomUpdated.emit("fit")}),e1.A.addListener(`${eJ.jQ}+-`,t=>{t.preventDefault(),e.slots.zoomUpdated.emit("out")}),e1.A.addListener(`${eJ.jQ}+0`,t=>{t.preventDefault(),e.slots.zoomUpdated.emit("reset")}),e1.A.addListener(`${eJ.jQ}+=`,t=>{t.preventDefault(),e.slots.zoomUpdated.emit("in")}),t=!1,i=null,e1.A.addListener(g.LM.SPACE,n=>{let{mouseMode:o,state:r}=e.selection;if("keydown"===n.type){if("pan"===o.type||"default"===o.type&&r.active)return;t=!0,i=o,e2(e,{type:"pan",panning:!1});return}"keyup"===n.type&&("pan"===o.type&&t&&i&&e2(e,i),t=!1)},{keydown:!0,keyup:!0}),function(e){function t(t){(0,_.tD)(e.page);let{selected:i}=e.selection.state;i.forEach(t=>{if((0,S.Zi)(t)){let i=e.page.root?.children??[];i.length>1&&e.page.deleteBlock(t)}else e.surface.removeElement(t.id)}),e.selection.clear(),e.slots.selectionUpdated.emit(e.selection.state)}e1.A.addListener(g.LM.BACKSPACE,t),e1.A.addListener(g.LM.DELETE,t)}(e),function(e,t="shift",i=!1){e1.A.addListener(g.LM.ANY_KEY,n=>{n.key.toLowerCase()===t&&i!==n.shiftKey&&(i=n.shiftKey,e.slots.pressShiftKeyUpdated.emit(i))},{keydown:!0,keyup:!0})}(e),(0,_.xM)(e.page)}),()=>{e1.A.deleteScope(t),i.dispose()}}(this)),e.add(this._frameResizeObserver),e.add(this._frameResizeObserver.slots.resize.on(e=>{let i=this.page;e.forEach((e,t)=>{let n=i.getBlockById(t),{index:o,xywh:r}=n,[a,s,l,d]=(0,ee.CV)(r);o<this.indexes.min?this.indexes.min=o:o>this.indexes.max&&(this.indexes.max=o);let c=e.height+2*g.I;(0,C.dA)(c,d)||i.updateBlock(n,{xywh:JSON.stringify([a,s,l,Math.round(c)])})}),t.selectionUpdated.emit({...this.selection.state})})),e.add(t.reorderingFramesUpdated.on(this.reorderFrames)),e.add(t.reorderingShapesUpdated.on(this.reorderShapes)),e.add(t.zoomUpdated.on(e=>this.components.toolbar?.setZoomByAction(e))),e.add(t.pressShiftKeyUpdated.on(e=>{this.selection.shiftKey=e,this.requestUpdate()}))}_reorderTo(e,t,i){(0,C.YT)(e,ee.qu,t,(e,t,i)=>(0,ee.zJ)(e,t,i),i)}_reorder(e,t,i,n,o){(0,C.HP)(e,ee.qu,i,t,n,(e,t,i)=>(0,ee.zJ)(e,t,i),o)}updateIndexes(e,t,i){let n,o;let r=0,a=t.length;for(;r<a;r++)n=e[r],(o=t[r]).index!==n&&this.page.updateBlock(o,{index:n});i(e)}getSortedElementsWithViewportBounds(e){let t=this.surface.viewport.viewportBounds;return this.sortedFrames.filter(i=>!!e.includes(i)||(0,ee.kK)(t,(0,S.Js)(i)))}addFrameWithPoint(e,t={}){let{width:i=S.xM,height:n=S.GB,offsetX:o=S.yC,offsetY:r=S.g5,parentId:a=this.page.root?.id,frameIndex:s}=t,[l,d]=this.surface.toModelCoord(e.x,e.y);return this.page.addBlock("affine:frame",{xywh:(0,ee.cJ)(l-o,d-r,i,n),index:this.indexes.max},a,s)}addNewFrame(e,t,i){this.page.captureSync();let{left:n,top:o}=this.surface.viewport;t.x-=n,t.y-=o;let r=this.addFrameWithPoint(t,i),a=this.page.addBlocks(e.map(({flavour:e,...t})=>((0,d.kP)(e),{flavour:e,blockProps:t})),r);return{frameId:r,ids:a}}moveBlocksWithNewFrame(e,t,{rect:i,focus:n,parentId:o,frameIndex:r}={}){let{left:a,top:s,zoom:l}=this.surface.viewport,d=i?.width?i.width/l+2*g.I:S.xM;t.x-=a,t.y-=s;let c=this.addFrameWithPoint(t,{width:d,parentId:o,frameIndex:r}),h=this.page.getBlockById(c);this.page.moveBlocks(e,h),n&&this.setSelection(c,!0,e[0].id,t)}setSelection(e,t=!0,i,n){let o=this.frames.find(t=>t.id===e);(0,d.kP)(o),requestAnimationFrame(()=>{this.slots.selectedBlocksUpdated.emit([]),this.slots.selectionUpdated.emit({selected:[o],active:t}),this.updateComplete.then(()=>{i?(0,C.a6)(this.page,i):n&&(0,C.bQ)(n.x,n.y)})})}clearSelectedBlocks(){this.selection.selectedBlocks.length&&this.slots.selectedBlocksUpdated.emit([])}update(e){e.has("page")&&(this._initSurface(),this.selection=new e9(this,this.root.uiEventDispatcher)),e.has("mouseMode")&&(this.selection.mouseMode=this.mouseMode),super.update(e)}_initResizeEffect(){let e=new ResizeObserver(e=>{this.surface.onResize(),this.slots.selectedBlocksUpdated.emit([...this.selection.selectedBlocks]),this.slots.selectionUpdated.emit({...this.selection.state})});e.observe(this.pageBlockContainer),this._resizeObserver=e}firstUpdated(){this._initSlotEffects(),this._initDragHandle(),this._initResizeEffect(),this.clipboard.init(this.page),(0,_.uQ)(this.page,this.surface.viewport.zoom),requestAnimationFrame(()=>{this.surface.attach(this._surfaceContainer);let e=this.frames.find(e=>"affine:frame"===e.flavour);if(e){let[t,i,n,o]=(0,ee.CV)(e.xywh);this.surface.viewport.setCenter(t+n/2,i+o/2)}this._handleToolbarFlag(),this._frameResizeObserver.resetListener(this.page),this.requestUpdate()}),this._clearSelection(),this.page.root?.childrenUpdated.on(()=>{requestAnimationFrame(()=>{this._frameResizeObserver.resetListener(this.page)})})}updated(e){super.updated(e)}connectedCallback(){super.connectedCallback(),(0,y.registerService)("affine:page",D.PageBlockService),this.mouseRoot=this.parentElement}disconnectedCallback(){super.disconnectedCallback(),this.clipboard.dispose(),this.components.dragHandle?.remove(),this._resizeObserver&&(this._resizeObserver.disconnect(),this._resizeObserver=null)}render(){requestAnimationFrame(()=>{this.selection.refreshRemoteSelection()}),this.setAttribute(g.SF,this.model.id);let{mouseMode:e,page:t,selection:i,surface:n,_rectsOfSelectedBlocks:o}=this,{state:r,draggingArea:a}=i,{viewport:s}=n,l=c.dy`
    ${(0,en.r)(this.sortedFrames,e=>e.id,(e,t)=>(function(e,t,i,n){let{xywh:o,background:r}=t,[a,s,l,d]=(0,ee.CV)(o),h={position:"absolute",transform:`translate(${a}px, ${s}px)`,transformOrigin:"0 0",width:l+"px",height:d+"px",padding:`${g.I}px`,background:`var(${r||g.je[0]})`,pointerEvents:"all",zIndex:`${e}`,boxSizing:"border-box",borderRadius:"8px",border:"2px solid var(--affine-white-10)",boxShadow:"var(--affine-shadow-3)"},u=i?c.Ld:c.dy`
    <div class="affine-edgeless-mask" style=${(0,k.V)({position:"absolute",top:"0",left:"0",bottom:"0",right:"0",zIndex:"1"})}></div>
  `;return c.dy`
    <div class="affine-edgeless-block-child" style=${(0,k.V)(h)}>
      ${n(t)} ${u}
    </div>
  `})(t,e,r.active,this.root.renderModel))}
  `,{zoom:d,viewportX:h,viewportY:u,left:f,top:p}=s,m=function(e){if(null===e)return c.dy``;let t={left:e.left+"px",top:e.top+"px",width:e.width+"px",height:e.height+"px"};return c.dy`
    <style>
      .affine-edgeless-dragging-area {
        position: absolute;
        background: var(--affine-hover-color);
        z-index: 1;
        pointer-events: none;
      }
    </style>
    <div class="affine-edgeless-dragging-area" style=${(0,k.V)(t)}></div>
  `}(a),v=i.getHoverState(),b=function(e,t){if(!e)return null;let i=e.rect,n=(0,el.TO)(i);return c.dy`
    <div class="affine-edgeless-hover-rect" style=${(0,k.V)(n)}></div>
  `}(v,0),{grid:C,gap:y,translateX:x,translateY:w}=(0,S.Xy)(h,u,d,this.showGrid),_={cursor:(0,S.zr)(e),"--affine-edgeless-gap":`${y}px`,"--affine-edgeless-grid":C,"--affine-edgeless-x":`${x}px`,"--affine-edgeless-y":`${w}px`};return c.dy`
      <div class="affine-edgeless-surface-block-container">
        <!-- attach canvas later in Phasor -->
      </div>
      <div
        class="affine-edgeless-page-block-container"
        style=${(0,k.V)(_)}
      >
        <div class="affine-block-children-container edgeless">
          <div class="affine-edgeless-layer">${l}</div>
        </div>
        <affine-selected-blocks
          .mouseRoot=${this.mouseRoot}
          .state=${{rects:o,grab:!1}}
          .offset=${{x:-f,y:-p}}
        ></affine-selected-blocks>
        ${b} ${m}
        ${r.selected.length?c.dy`
              <edgeless-selected-rect
                disabled=${"pan"===e.type}
                .page=${t}
                .state=${r}
                .slots=${this.slots}
                .surface=${n}
              ></edgeless-selected-rect>
            `:c.Ld}
      </div>
    `}};tt.styles=c.iv`
    .affine-edgeless-page-block-container {
      position: relative;
      box-sizing: border-box;
      overflow: hidden;
      height: 100%;
      font-family: var(--affine-font-family);
      font-size: var(--affine-font-base);
      line-height: var(--affine-line-height);
      color: var(--affine-text-primary-color);
      font-weight: 400;
    }

    .affine-edgeless-surface-block-container {
      position: absolute;
      width: 100%;
      height: 100%;
    }

    .affine-edgeless-surface-block-container canvas {
      width: 100%;
      height: 100%;
      position: relative;
      z-index: 1;
      pointer-events: none;
    }

    .affine-block-children-container.edgeless {
      padding-left: 0;
      position: relative;
      overflow: hidden;
      height: 100%;
      /**
       * Fix: pointerEvent stops firing after a short time.
       * When a gesture is started, the browser intersects the touch-action values of the touched element and its ancestors,
       * up to the one that implements the gesture (in other words, the first containing scrolling element)
       * https://developer.mozilla.org/en-US/docs/Web/CSS/touch-action
       */
      touch-action: none;

      background-size: var(--affine-edgeless-gap) var(--affine-edgeless-gap);
      background-position: var(--affine-edgeless-x) var(--affine-edgeless-y);
      background-color: var(--affine-background-primary-color);
      background-image: var(--affine-edgeless-grid);
      z-index: 0;
    }

    .affine-edgeless-layer {
      position: absolute;
      contain: layout style size;
      transform: translate(var(--affine-edgeless-x), var(--affine-edgeless-y))
        scale(var(--affine-zoom));
    }

    .affine-edgeless-hover-rect {
      position: absolute;
      border-radius: 0;
      pointer-events: none;
      box-sizing: border-box;
      z-index: 1;
      border: var(--affine-border-width) solid var(--affine-blue);
    }
  `,te([(0,h.SB)()],tt.prototype,"mouseMode",void 0),te([(0,h.SB)()],tt.prototype,"_rectsOfSelectedBlocks",void 0),te([(0,h.IO)(".affine-edgeless-surface-block-container")],tt.prototype,"_surfaceContainer",void 0),te([(0,h.IO)(".affine-edgeless-page-block-container")],tt.prototype,"pageBlockContainer",void 0),tt=te([(0,h.Mo)("affine-edgeless-page")],tt);var ti=i(82179),tn=i(88523);class to extends tn.b{block2html(e,{childText:t="",begin:i,end:n}={}){return`<div>${e.title.toString()}${t}</div>`}block2Text(e,{childText:t="",begin:i,end:n}={}){let o=(e.title.toString()||"").slice(i||0,n);return`${o}${t}`}_getAllSubTexts(e){if("affine:database"===e.flavour)return[];let t=(e.text||[]).filter(e=>!e.attributes?.link);return e.children&&e.children.forEach(e=>{t.push(...this._getAllSubTexts(e))}),t}async json2Block(e,t){if(t.length>0&&(0===t[0].children.length||"affine:page"===t[0].flavour)){let i=this._getAllSubTexts(t[0]);e.title.applyDelta(i),t=t.slice(1)}let i=e.page.addBlock("affine:frame",{},e.id),n=e.page.getBlockById(i);(0,d.kP)(n);let o=(0,y.getService)("affine:frame");return o.json2Block(n,t)}}},73745:function(e,t,i){"use strict";i.d(t,{A4:function(){return v},DZ:function(){return C},Ps:function(){return y},ST:function(){return x},vo:function(){return b},xM:function(){return m}});var n=i(69692),o=i(67072),r=i(31054),a=i(81366),s=i(50217),l=i(280),d=i(903),c=i(42424),h=i(65024),u=i(67929),f=i(17164),p=i(62623),g=i(54131);function m(e){e.readonly||(g.W.forEach(({hotkey:t,action:i})=>{a.AL.addListener(t,t=>{t.preventDefault(),e.awarenessStore.isReadonly(e)||i({page:e})})}),f.D.forEach(({hotkey:t,action:i,enabledWhen:n})=>{t&&a.AL.addListener(t,t=>{t.preventDefault(),n(e)&&(e.awarenessStore.isReadonly(e)||i({page:e}))})}),n.I_.forEach(({flavour:t,type:i,hotkey:n})=>{n&&a.AL.addListener(n,()=>{let n=(0,d.zE)(e);n&&(0,p.WV)(n.models,t,i)})}),a.AL.addListener(o.LM.UNDO,t=>{t.preventDefault(),e.canUndo&&(0,h.MO)(e),e.undo()}),a.AL.addListener(o.LM.REDO,t=>{t.preventDefault(),e.canRedo&&(0,h.MO)(e),e.redo()}),a.AL.addListener(o.LM.ANY_KEY,t=>{if(!(0,a.Ty)(t)||e.readonly)return;let i=(0,d.zE)(e);if(!i)return;if("Block"===i.type){(0,u.hw)({page:e,keyboardEvent:t,selectedBlocks:i.models});return}let n=(0,a.yd)(i);n&&(0,a.zl)(n)&&(0,p.tD)(e)}))}function v(){a.AL.removeListener([...g.W.map(({hotkey:e})=>e),...n.I_.map(({hotkey:e})=>e).filter(e=>!!e),o.LM.UNDO,o.LM.REDO,o.LM.ANY_KEY])}function b(e,t,{selection:i,zoom:n}={zoom:1}){let o=(0,d.zE)(t);if(o){if("Block"===o.type){if(!i){console.error("Failed to handle up: selection is not provided",o);return}let n=(0,h.mt)(i.state.selectedBlocks[0]);i.clear();let s=(0,a.U6)(t);(0,r.kP)(s),(0,h.CL)(n,s.lastSelectionPosition instanceof h.E9?s.lastSelectionPosition:"end"),e.preventDefault();return}if("Native"===o.type){(0,r.Y8)(o.models.length,1,"Failed to handle up! range is not collapsed");let e=o.models[0],i=(0,h.nt)(e),s=(0,h.bR)(),{left:l,top:d}=s.getBoundingClientRect();if(!i&&(0,a.im)(t)){(0,h.$k)(t);return}if(0===l&&0===d){if(!(s.startContainer instanceof HTMLElement)){console.warn("Failed to calculate caret position! range.getBoundingClientRect() is zero and it's startContainer not an HTMLElement.",s),(0,h.CL)(e);return}let t=s.startContainer.getBoundingClientRect();(0,h.CL)(e,new h.E9(t.left,t.top),n);return}(0,h.CL)(e,new h.E9(l,d),n)}}}function C(e,t,{selection:i,zoom:n}={zoom:1}){let o=(0,d.zE)(t);if(o){if("Block"===o.type){if(!i){console.error("Failed to handle down: selection is not provided",o);return}let n=i.state.selectedBlocks.at(-1);if(!n)throw Error("Failed to handleDown! Can't find last selected element!");let s=(0,h.mt)(n);i.clear();let l=(0,a.U6)(t);(0,r.kP)(l),(0,h.rq)(s,l.lastSelectionPosition instanceof h.E9?l.lastSelectionPosition:"start"),e.preventDefault()}if("Native"===o.type){(0,r.Y8)(o.models.length,1,"Failed to handle down! range is not collapsed");let e=o.models[0];if((0,r.h$)(e,["affine:code"])||(0,r.h$)(e,["affine:page"]))return;let t=(0,h.bR)(),i=(0,c.q)(t),{left:a,bottom:s}=t.getBoundingClientRect();if(i||0===a&&0===s){let t=(0,h.Et)(e);(0,r.kP)(t);let i=t.getBoundingClientRect();(0,h.rq)(e,new h.E9(i.left,i.top),n);return}(0,h.rq)(e,new h.E9(a,s),n)}}}function y(e,t){let{BACKSPACE:i,SELECT_ALL:n,SHIFT_UP:c,SHIFT_DOWN:f,UP:g,DOWN:v,LEFT:y,RIGHT:x,ENTER:w,TAB:_,SPACE:k}=o.LM;m(e),a.AL.addListener(n,e=>{e.preventDefault(),(0,u.ib)(t),t.state.type="block"}),e.readonly||(a.AL.addListener(w,i=>{let n=(0,d.zE)(e);if(!n)return;if("Block"===n.type){i.preventDefault();let o=n.models[n.models.length-1],a=e.getParent(o),s=a?.children.indexOf(o);(0,r.kP)(s),(0,r.kP)(a);let l=e.addBlock("affine:paragraph",{type:"text"},a,s+1);(0,h.a6)(e,l),t.clear();return}i.preventDefault();let o=n.models[0];o.text?.delete(n.startOffset,o.text.length-n.startOffset);let s=n.models[n.models.length-1];s.text?.delete(0,n.endOffset),n.models.slice(1,-1).forEach(t=>{e.deleteBlock(t)});let l=(0,h.gj)(s);l?.slots.updated.once(()=>{(0,a.$x)(s,"start")})}),a.AL.addListener(i,t=>{(0,p.tD)(e),t.preventDefault()}),a.AL.addListener(g,i=>{let n=(0,d.zE)(e);if(!n)return;let o=e.getParent(n.models[0]);if(o&&(0,r.h$)(o,["affine:database"])){let e=(0,l.getService)("affine:database");if(e.getLastCellSelection())return}b(i,e,{selection:t})}),a.AL.addListener(v,i=>{let n=(0,d.zE)(e);if(!n)return;let o=e.getParent(n.models[0]);if(o&&(0,r.h$)(o,["affine:database"])){let e=(0,l.getService)("affine:database");if(e.getLastCellSelection())return}C(i,e,{selection:t})}),a.AL.addListener(y,t=>{let i=(0,d.zE)(e);if(i&&"Block"!==i.type){if(i.models.length>1){t.preventDefault();let e=getSelection();if(e){let t=i.nativeRange.cloneRange();t.collapse(!0),e.removeAllRanges(),e.addRange(t)}return}(0,h.CL)(i.models[0],"end")}}),a.AL.addListener(x,t=>{let i=(0,d.zE)(e);if(i){if((0,r.h$)(i.models[0],["affine:database"])){let e=(0,l.getService)("affine:database");if(e.getLastCellSelection())return}if("Block"!==i.type){if(i.models.length>1){t.preventDefault();let e=getSelection();if(e){let t=i.nativeRange.cloneRange();t.collapse(!1),e.removeAllRanges(),e.addRange(t)}return}(0,h.rq)(i.models[0],"start")}}}),a.AL.addListener(_,i=>(function(e,t,i){let n=(0,d.zE)(t);if(!n)return;e.preventDefault();let o=n.models;(0,s.handleMultiBlockIndent)(t,o),"Block"===n.type&&requestAnimationFrame(()=>{i.refreshSelectedBlocksRectsByModels(o)})})(i,e,t)),a.AL.addListener(c,e=>{}),a.AL.addListener(f,e=>{}),a.AL.addListener(k,e=>{"block"===t.state.type&&e.preventDefault()}))}function x(){v(),a.AL.removeListener([o.LM.BACKSPACE,o.LM.SELECT_ALL,o.LM.SHIFT_UP,o.LM.SHIFT_DOWN,o.LM.UP,o.LM.DOWN,o.LM.LEFT,o.LM.RIGHT,o.LM.ENTER,o.LM.TAB,o.LM.SPACE])}},17164:function(e,t,i){"use strict";i.d(t,{D:function(){return C}});var n=i(92758),o=i(6635),r=i(13246),a=i(62554),s=i(4937),l=i(31054),d=i(15486),c=i(32916),h=i(81366);let u=d.iv`
  :host {
    font-family: var(--affine-font-family);
  }
  :host * {
    box-sizing: border-box;
  }
  .overlay-mask {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.6);
    z-index: var(--affine-z-index-modal);
  }
  .modal-container {
    position: absolute;
    z-index: var(--affine-z-index-modal);
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: 720px;
    padding: 24px 40px;
    border-radius: 24px;
    background: var(--affine-background-overlay-panel-color);
  }
  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .modal-header-title {
    color: var(--affine-text-primary-color);
    font-size: 20px;
    font-weight: 600;
  }
  .modal-header-close-icon {
    display: flex;
    align-items: center;
    color: var(--affine-icon-color);
    cursor: pointer;
  }
  .modal-header-close-icon svg {
    width: 24px;
    height: 24px;
  }
  .modal-footer {
    color: var(--affine-text-secondary-color);
    font-size: 14px;
    text-align: center;
  }
  .modal-body {
    padding: 24px 0;
  }
  .modal-desc {
    margin-bottom: 38px;
    color: var(--affine-text-primary-color);
    font-size: 14px;
  }
  .modal-view-container {
    display: flex;
    justify-content: center;
    gap: 18px;
  }
  .modal-view-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
    cursor: pointer;
  }
  .modal-view-item.coming-soon {
    cursor: not-allowed;
  }
  .modal-view-item.coming-soon .modal-view-item-content {
    pointer-events: none;
  }
  .modal-view-item-content:hover {
    background: var(--affine-hover-color);
  }
  .modal-view-item-content:hover .modal-view-item-text,
  .modal-view-item-content:hover svg {
    fill: var(--affine-primary-color);
    color: var(--affine-primary-color);
  }
  .modal-view-item-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 18px 0;
    gap: 6px;
    width: 108px;
    height: 108px;
    border: 2px solid var(--affine-border-color);
    border-radius: 8px;
  }
  .modal-view-item-icon {
    width: 42px;
    height: 42px;
  }
  .modal-view-item-icon svg {
    width: 42px;
    height: 42px;
    fill: var(--affine-black-50);
  }
  .modal-view-item-text {
    font-size: 14px;
    color: var(--affine-black-50);
  }
  .modal-view-item-description {
    font-size: 12px;
    color: var(--affine-text-secondary-color);
    text-align: center;
  }
`;var f=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let p=[{type:"table",text:"Table view",icon:n.Th},{type:"kanban",text:"Kanban view",icon:n.D3,description:"Coming soon",isComingSoon:!0}],g=class extends d.oi{constructor(){super(...arguments),this._selectedView="table"}_convertToDatabase(e){if("table"!==e)return;this._hide(),this.page.captureSync();let t=(0,h.zE)(this.page);(0,l.kP)(t);let i=t.models,n=this.page.getParent(i[0]);(0,l.kP)(n);let o=this.page.addBlock("affine:database",{columns:[],titleColumnName:"Title"},n,n.children.indexOf(i[0])),r=this.page.getBlockById(o);(0,l.kP)(r),r.updateColumn({name:"Tag",type:"multi-select",width:200,hide:!1,selection:[]}),r.applyColumnUpdate(),this.page.moveBlocks(i,r);let a=(0,h.U6)(this.page);(0,l.kP)(a),a.selection&&a.selection.clear()}_hide(){this.abortController.abort()}render(){return d.dy`<div class="overlay-root">
      <div class="overlay-mask" @click=${this._hide}></div>
      <div class="modal-container">
        <div class="modal-header">
          <div class="modal-header-title">Select Database View</div>
          <div class="modal-header-close-icon" @click=${this._hide}>
            ${s.ws}
          </div>
        </div>
        <div class="modal-body">
          <div class="modal-desc">
            Group as Database can quickly convert selected blocks into Database
            for easy structuring of data.
          </div>
          <div class="modal-view-container">
            ${p.map(e=>{let t=e.type===this._selectedView;return d.dy`
                <div
                  class="modal-view-item ${e.type} ${e.isComingSoon?"coming-soon":""}"
                  @click=${()=>this._convertToDatabase(e.type)}
                >
                  <div
                    class="modal-view-item-content ${t?"selected":""}"
                  >
                    <div class="modal-view-item-icon">${e.icon}</div>
                    <div class="modal-view-item-text">${e.text}</div>
                  </div>
                  <div class="modal-view-item-description">
                    ${e.description}
                  </div>
                </div>
              `})}
          </div>
        </div>
        <div class="modal-footer">More views are on the way.</div>
      </div>
    </div>`}};g.styles=u,f([(0,c.Cb)()],g.prototype,"page",void 0),f([(0,c.SB)()],g.prototype,"_selectedView",void 0),f([(0,c.Cb)()],g.prototype,"abortController",void 0),g=f([(0,c.Mo)("affine-database-modal")],g);var m=i(37666),v=i(29045);let b=["affine:list","affine:paragraph"],C=[{id:"copy",name:"Copy",disabledToolTip:void 0,icon:n.TI,hotkey:void 0,showWhen:()=>!0,enabledWhen:()=>!0,action:({page:e})=>{let t=(0,v.zE)(e);(0,r.kP)(t),(0,a.p3)(t),(0,m.A)("Copied to clipboard")}},{id:"convert-to-database",name:"Group as Database",disabledToolTip:"Contains Block types that cannot be converted to Database. Learn more",icon:n.Th,hotkey:`${o.jQ}+g`,showWhen:(e,t)=>{if(1===t.length&&(0,r.h$)(t[0],["affine:database"]))return!1;let i=(0,v.zE)(e),n=i?.type==="Block";return n},enabledWhen:e=>{let t=(0,v.zE)(e);return!!t&&t.models.every(e=>b.includes(e.flavour))},action:({page:e})=>{!function({page:e,container:t=document.body,abortController:i=new AbortController}){let n=new r.SJ;i.signal.addEventListener("abort",()=>n.dispose());let o=new g;o.page=e,o.abortController=i,t.appendChild(o),n.add(()=>o.remove())}({page:e})}}]},62623:function(e,t,i){"use strict";i.d(t,{FA:function(){return k},HM:function(){return _},OA:function(){return y},Tb:function(){return b},WV:function(){return v},Wo:function(){return m},X1:function(){return p},Xf:function(){return S},hw:function(){return w},ib:function(){return x},tD:function(){return g},uQ:function(){return M},vC:function(){return C}});var n=i(67072),o=i(31054),r=i(45598),a=i(13246),s=i(81366),l=i(903),d=i(68389),c=i(25005),h=i(13371),u=i(40063),f=i(76709);function p(e,t){let i=e.getParent(t[0]);(0,o.kP)(i);let n=i.children.indexOf(t[0]);e.captureSync(),t.forEach(t=>e.deleteBlock(t));let r=e.addBlock("affine:paragraph",{type:"text"},i,n),a=e.getBlockById(r),l=(0,s.U6)(t[0].page);return l?(l.selection.clear(),(0,d.a6)(e,r),a):null}function g(e,t=(0,l.zE)(e)){if(!t)return null;if("Block"===t.type){let i=p(e,t.models);return i}let i=t.models[0],n=t.models[t.models.length-1];if(!i.text||!n.text)throw Error("startModel or endModel does not have text");let r=(0,s.gj)(i);return((0,o.kP)(r),i===n)?(e.captureSync(),t.startOffset===t.endOffset&&t.startOffset>0||(i.text.delete(t.startOffset,t.endOffset-t.startOffset),r.setVRange({index:t.startOffset,length:0})),i):(e.captureSync(),i.text.delete(t.startOffset,i.text.length-t.startOffset),n.text.delete(0,t.endOffset),i.text.join(n.text),t.models.slice(1).forEach(t=>{e.deleteBlock(t)}),r.setVRange({index:t.startOffset,length:0}),i)}function m(e,t){!(!(0,s.E7)()||(0,s.d2)())&&(0,s.zl)()&&(t.preventDefault(),g(e))}function v(e,t,i){if(!e.length)return[];let n=e[0].page,r=e.every(e=>e.page===n);r||console.error("Not all models have the same page instanceof, the result for update text type may not be correct",e),n.captureSync();let s=(0,l.zE)(n);if("affine:code"===t){let t=function(e,t){let i=e.getParent(t[0]);(0,o.kP)(i);let n=i.children.indexOf(t[0]),r=t.map(e=>e.text instanceof a.xv?e.text.toString():null).filter(Boolean).join("\n");t.map(t=>e.deleteBlock(t));let s=e.addBlock("affine:code",{text:new a.xv(r)},i,n);return s}(n,e),i=n.getBlockById(t);if(!i)throw Error("Failed to get model after merge code block!");return[i]}if("affine:divider"===t){let t=e.at(-1);if(!t)return[];let i=n.getParent(t);if(!i)return[];let o=i.children.indexOf(t),r=n.getNextSibling(t),a=r?.id,s=n.addBlock("affine:divider",{},i,o+1);r||(a=n.addBlock("affine:paragraph",{},i)),(0,d.a6)(n,a);let l=n.getBlockById(s);if(!l)throw Error("Failed to get model after add divider block!");return[l]}let c=[];e.forEach(e=>{if((0,o.nc)(e,["affine:paragraph","affine:list","affine:code"]),e.flavour===t){n.updateBlock(e,{type:i}),c.push(e);return}let r=function(e,t,i){let n=e.page,r=n.getParent(e);(0,o.kP)(r);let a={type:i,text:e?.text?.clone(),children:e.children},s=r.children.indexOf(e);return n.deleteBlock(e),n.addBlock(t,a,r,s)}(e,t,i),a=n.getBlockById(r);if(!a)throw Error("Failed to get new model after transform block!");s&&(0,l.y3)(s,e,a),c.push(a)});let h=s?.models.map(e=>new Promise(t=>_(e,t)));return h&&s&&Promise.all(h).then(()=>{(0,l.vq)(s)}),c}function b(e,t=!1){if(1===e.models.length){let i=(0,s.gj)(e.models[0]);(0,o.kP)(i);let n=i.getFormat({index:e.startOffset,length:e.endOffset-e.startOffset},t);return n}let i=[],n=e.models[0];if(!(0,o.h$)(n,["affine:code"])&&n.text&&n.text.length){let r=(0,s.gj)(n);(0,o.kP)(r);let a=r.getFormat({index:e.startOffset,length:r.yText.length-e.startOffset},t);i.push(a)}let r=e.models[e.models.length-1];if(!(0,o.h$)(r,["affine:code"])&&r.text&&r.text.length){let n=(0,s.gj)(r);(0,o.kP)(n);let a=n.getFormat({index:0,length:e.endOffset},t);i.push(a)}return e.models.slice(1,-1).filter(e=>!(0,o.h$)(e,["affine:code"])).filter(e=>e.text&&e.text.length).forEach(e=>{let t=(0,s.gj)(e);(0,o.kP)(t);let n=t.getFormat({index:0,length:t.yText.length-1});i.push(n)},t),i.length?t?i.reduce((e,t)=>({...e,...t})):i.reduce((e,t)=>{let i={};for(let n in e){let o=n;e[o]===t[o]&&(i[o]=e[o])}return i}):{}}function C(e,t=!1){let i=(0,l.zE)(e);return!i||i.models.every(e=>!e.text)?{}:b(i,t)}function y(e,t){let i=(0,l.zE)(e);i&&(e.captureSync(),function(e,t){let{startOffset:i,endOffset:n}=e,r=e.models[0],a=e.models[e.models.length-1];if(1===e.models.length&&i===n){let e=(0,s.gj)(r),n=e?.getDeltaByRangeIndex(i);if(!e||!n)return;e.setMarks({...e.marks,[t]:(!e.marks||!e.marks[t])&&(!n.attributes||!n.attributes[t])||null}),(0,c.F)(e);return}let d=b(e);if(1===e.models.length){if((0,o.h$)(r,["affine:code"]))return;let a=(0,s.gj)(r);a?.slots.updated.once(()=>{(0,l.vq)(e)}),r.text?.format(i,n-i,{[t]:!d[t]||null});return}if((0,o.h$)(r,["affine:code"])||r.text?.format(i,r.text.length-i,{[t]:!d[t]||null}),(0,o.h$)(a,["affine:code"])||a.text?.format(0,n,{[t]:!d[t]||null}),e.models.slice(1,-1).filter(e=>!(0,o.h$)(e,["affine:code"])).forEach(e=>{e.text?.format(0,e.text.length,{[t]:!d[t]||null})}),"Native"===e.type){let t=e.models.filter(e=>!(0,o.h$)(e,["affine:code"])).map(e=>new Promise(t=>{let i=(0,s.gj)(e);i?.slots.updated.once(()=>{t(i)})}));Promise.all(t).then(()=>{(0,l.vq)(e)})}}(i,t))}function x(e){let t=window.getSelection();0===e.state.selectedBlocks.length&&t?.focusNode?.nodeName==="#text"?e.selectOneBlock((0,s.I8)(t.focusNode.parentElement)):e.selectAllBlocks(),(0,s.xT)(null)}function w({page:e,keyboardEvent:t,selectedBlocks:i}){let{key:n}=t,r=e.getParent(i[0]),a=r?.children.indexOf(i[0]);i.forEach(t=>{e.deleteBlock(t)});let l=e.addBlock("affine:paragraph",{text:new e.Text(n)},r,a);requestAnimationFrame(()=>{let t=(0,s.U6)(e),i=e.getBlockById(l);if(t?.selection.clear(),(0,s.$x)(i,"end"),"/"===n){let t=(0,s.bR)(),i=e.getBlockById(l);(0,o.kP)(i),(0,u.M)({model:i,range:t})}})}async function _(e,t){let i=await (0,s.w_)(e);i?.vEditor?.slots.updated.once(()=>{t(i)})}async function k(e,t){let i=await (0,s.jo)(e);i&&t(i)}function M(e,t){requestAnimationFrame(()=>{if(!e.root)return;let i=e.root.children.filter(e=>"affine:frame"===e.flavour);i.forEach(i=>{let o=(0,s._b)(i);if(!o)return;let a=o.getBoundingClientRect(),[l,d,c,h]=(0,r.CV)(i.xywh),u=a.height/t+2*n.I;(0,s.dA)(u,h)||e.updateBlock(i,{xywh:JSON.stringify([l,d,c,Math.round(u)])})})})}function S(e,t,i,n,o){let r="double"===e?(0,s.jx)():(0,s.nE)(t);if(t.raw.target instanceof HTMLTextAreaElement||!r||r.collapsed||i.readonly)return;let a="center-bottom";(0,h.T)({page:i,container:n,direction:a,anchorEl:{getBoundingClientRect:()=>(0,f.EM)(a,o)}})}},54131:function(e,t,i){"use strict";i.d(t,{W:function(){return s}});var n=i(92758),o=i(6635),r=i(98094),a=i(62623);let s=[{id:"bold",name:"Bold",icon:n.mY,hotkey:`${o.jQ}+b`,activeWhen:e=>"bold"in e,showWhen:e=>l(e),action:({page:e})=>{(0,a.OA)(e,"bold")}},{id:"italic",name:"Italic",icon:n.h3,hotkey:`${o.jQ}+i`,activeWhen:e=>"italic"in e,showWhen:e=>l(e),action:({page:e})=>{(0,a.OA)(e,"italic")}},{id:"underline",name:"Underline",icon:n.Ad,hotkey:`${o.jQ}+u`,activeWhen:e=>"underline"in e,showWhen:e=>l(e),action:({page:e})=>{(0,a.OA)(e,"underline")}},{id:"strike",name:"Strikethrough",icon:n.dw,hotkey:`${o.jQ}+shift+s`,activeWhen:e=>"strike"in e,showWhen:e=>l(e),action:({page:e})=>{(0,a.OA)(e,"strike")}},{id:"code",name:"Code",icon:n.ux,hotkey:`${o.jQ}+e`,activeWhen:e=>"code"in e,showWhen:e=>l(e),action:({page:e})=>{(0,a.OA)(e,"code")}},{id:"link",name:"Link",icon:n.xP,hotkey:`${o.jQ}+k`,activeWhen:e=>"link"in e,showWhen:e=>1===e.length&&l(e)&&!(0,a.vC)(e[0].page,!0).reference,action:({page:e,abortController:t,format:i})=>{(0,r.E)(e),!i||!t||"link"in i||t.abort()}}];function l(e){return!e.every(e=>"affine:code"===e.flavour)}},67929:function(e,t,i){"use strict";i.d(t,{A4:function(){return n.A4},DZ:function(){return n.DZ},FA:function(){return o.FA},HM:function(){return o.HM},I6:function(){return r.I6},OA:function(){return o.OA},Ps:function(){return n.Ps},ST:function(){return n.ST},Tb:function(){return o.Tb},WV:function(){return o.WV},Wo:function(){return o.Wo},X1:function(){return o.X1},Xf:function(){return o.Xf},hw:function(){return o.hw},ib:function(){return o.ib},tD:function(){return o.tD},uQ:function(){return o.uQ},vC:function(){return o.vC},vo:function(){return n.vo},xM:function(){return n.xM}});var n=i(73745),o=i(62623),r=i(76709)},76709:function(e,t,i){"use strict";i.d(t,{$U:function(){return l},Ak:function(){return d},EM:function(){return c},I6:function(){return s},Ne:function(){return h},R7:function(){return a},W$:function(){return f},Xz:function(){return u}});var n=i(53905),o=i(81366),r=i(42424);function a(e){let t=window.getSelection(),i=t&&t.rangeCount&&t.getRangeAt(0),r=(0,n.Qo)(e.x,e.y);i&&r&&i.isPointInRange(r.startContainer,r.startOffset)&&i.isPointInRange(r.endContainer,r.endOffset)?requestAnimationFrame(()=>{(0,o.xT)(i)}):e.preventDefault()}function s(e){let t=e.start.x,i=e.start.y,n=e.point.x,r=e.point.y,a=(0,o.bR)(),s=!(0,o.us)(a);return n>t?s||r>=i?"right-bottom":"right-top":s||r<=i?"left-top":"left-bottom"}function l(e){let t=(0,o.bR)(),i=s(e),n=t.collapsed||0===t.toString().length;return{selectedType:n?"Caret":"Text",direction:i}}function d(e,t){let{startContainer:i,startOffset:n,endContainer:o,endOffset:a}=e,s=t.includes("top"),[l,d]=s?[i,n]:[o,a],c=new Range;if(t.includes("center"))c.setStart(i,n),c.setEnd(o,a);else{c.setStart(l,d);let e=l.nodeType===Node.TEXT_NODE||l.nodeType===Node.COMMENT_NODE||l.nodeType===Node.CDATA_SECTION_NODE;if(e||(c.setStart(i,n),c.setEnd(o,a)),t.includes("left")){let e=(0,r.q)(c);e&&(c.setStart(e.startContainer,e.startOffset),c.setEnd(e.endContainer,e.endOffset))}}let h=c.getBoundingClientRect(),u=t.includes("bottom"),f={x:h.x+h.width/2,y:h.y+(u?h.height:0)};return f}function c(e,t){if(!t||!t.selectedBlocks.length){if(!(0,o.E7)())throw Error("Failed to get anchor element! There's no block selection or native selection.");let t=(0,o.bR)(),i=d(t,e);return i}let i=t.selectedBlocks,n=i[0],r=i[i.length-1],a=e.includes("bottom")?r:n,s=a.getBoundingClientRect(),l=s.x+s.width/2,c=e.includes("bottom")?s.bottom:s.top;return{x:l,y:c}}function h({positioningPoint:e,objRect:t={width:0,height:0},boundaryRect:i=document.body.getBoundingClientRect(),offsetX:n=0,offsetY:r=0,edgeGap:a=20}){let s=(0,o.uZ)(e.x+n,a,i.width-t.width-a),l=e.y+r;return{x:s,y:l}}function u(e,t=document.body,i=20){let n=e.getBoundingClientRect(),o=t.getBoundingClientRect(),r=n.top-o.top,a=o.bottom-n.bottom,s=r>a?"top":"bottom";return{placement:s,height:("top"===s?r:a)-i}}function f(e,t,{gap:i=12,offsetY:n=5}={}){e||console.warn("The popper element is not exist. Popper position maybe incorrect");let{placement:o,height:r}=u(t,document.body,i+n),a=t.getBoundingClientRect(),s={x:a.x,y:a.y+("bottom"===o?a.height:0)},l=document.body.getBoundingClientRect(),d=e?.getBoundingClientRect(),c=h({positioningPoint:s,objRect:d,boundaryRect:l,offsetY:"bottom"===o?n:-n});return{placement:o,height:r,x:`${c.x}px`,y:"bottom"===o?`${c.y}px`:`calc(${c.y}px - 100%)`}}},28392:function(e,t,i){"use strict";i.d(t,{n_:function(){return y},vQ:function(){return x.v},Vs:function(){return v}}),i(84954);var n=i(92758),o=i(67072),r=i(31054),a=i(43312),s=i(50634),l=i(15486),d=i(32916),c=i(91827),h=i(81366),u=i(9386),f=i(46646),p=i(280),g=i(88523),m=i(7291);class v extends g.b{block2html(e,{childText:t="",begin:i,end:n}={}){let o=super.block2html(e,{childText:t,begin:i,end:n});switch(e.type){case"text":return`<p>${o}</p>`;case"h1":case"h2":case"h3":case"h4":case"h5":case"h6":return`<${e.type}>${o}</${e.type}>`;case"quote":return`<blockquote>${o}</blockquote>`;default:return o}}async json2Block(e,t,i){let n="text"!==e.type;return(0,m.V)(e,t,{range:i,convertToPastedIfEmpty:n})}}var b=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function C(e){e.preventDefault()}let y=class extends s.z3{constructor(){super(...arguments),this.tipsPos={top:"50%",transform:"translateY(-50%)",left:"2px"},this._tipsPlaceholderTemplate=l.dy``,this._isComposing=!1,this._isFocus=!1,this.textSchema={attributesSchema:f.D,textRenderer:u.O},this._placeholderDisposables=new a.S,this._updatePlaceholder=()=>{if(0!==this.model.text.length||this._isComposing||"text"===this.model.type&&!this._isFocus){this._tipsPlaceholderTemplate=l.dy``;return}if(this._richTextElement){let e=this._richTextElement.parentElement?.getBoundingClientRect(),t=this._richTextElement.getBoundingClientRect(),i=t.top-e.top,n=t.left-e.left;this.tipsPos={top:`${i}px`,transform:"",left:`${n+2}px`}}this._tipsPlaceholderTemplate=function(e,t){if(!(0,r.h$)(e,["affine:paragraph"]))throw Error("TipsPlaceholder can't be used for this model");if("text"===e.type){if(!(0,h.im)(e.page))return l.dy`<div class="tips-placeholder" style=${(0,c.V)(t)}>
        Type '/' for commands
      </div> `;let i=document.querySelector("affine-block-hub");if(!i)return l.dy`<div class="tips-placeholder" style=${(0,c.V)(t)}>
        Type '/' for commands
      </div>`;let o=()=>{if(!i)throw Error("Failed to find blockHub!");i.toggleMenu()};return l.dy`
      <div
        class="tips-placeholder"
        @click=${o}
        @pointerdown=${C}
        style=${(0,c.V)(t)}
      >
        Click ${n.v_} to insert blocks, type '/' for commands
      </div>
    `}return l.dy`<div class="tips-placeholder">${({h1:"Heading 1",h2:"Heading 2",h3:"Heading 3",h4:"Heading 4",h5:"Heading 5",h6:"Heading 6",quote:""})[e.type]}</div> `}(this.model,this.tipsPos)},this._onFocusIn=e=>{this._isFocus=!0,this._updatePlaceholder(),this.model.text.yText.observe(this._updatePlaceholder),this._placeholderDisposables.add(()=>this.model.text.yText.unobserve(this._updatePlaceholder)),this._placeholderDisposables.addFromEvent(this,"compositionstart",()=>{this._isComposing=!0,this._updatePlaceholder()}),this._placeholderDisposables.addFromEvent(this,"compositionend",()=>{this._isComposing=!1,this._updatePlaceholder()})},this._onFocusOut=e=>{this._isFocus=!1,this._updatePlaceholder(),this._placeholderDisposables.dispose(),this._placeholderDisposables=new a.S},this.isInDatabase=()=>{let e=this.parentElement;for(;e&&e!==document.body;){if("affine-database"===e.tagName.toLowerCase())return!0;e=e.parentElement}return!1}}connectedCallback(){super.connectedCallback(),this._updatePlaceholder(),(0,p.registerService)("affine:paragraph",v)}firstUpdated(){this.model.propsUpdated.on(()=>{this._updatePlaceholder(),this.requestUpdate()}),this.model.childrenUpdated.on(()=>this.requestUpdate())}render(){let{type:e}=this.model,t=this.isInDatabase()?"":this._tipsPlaceholderTemplate,i=l.dy`<div
      class="affine-block-children-container"
      style="padding-left: ${o.qL}px"
    >
      ${this.content}
    </div>`;return l.dy`
      <div class="affine-paragraph-block-container ${e}">
        ${t}
        <rich-text
          .model=${this.model}
          .textSchema=${this.textSchema}
          @focusin=${this._onFocusIn}
          @focusout=${this._onFocusOut}
          style=${(0,c.V)({fontWeight:/^h[1-6]$/.test(e)?"600":void 0})}
        ></rich-text>
        ${i}
      </div>
    `}};y.styles=l.iv`
    .affine-paragraph-block-container {
      position: relative;
      border-radius: 5px;
    }
    .affine-paragraph-block-container.selected {
      background-color: var(--affine-hover-color);
    }
    .h1 {
      font-size: var(--affine-font-h-1);
      line-height: calc(1em + 12px);
      margin-top: calc(var(--affine-paragraph-space) + 24px);
    }
    .h1 code {
      font-size: calc(var(--affine-font-base) + 8px);
    }
    .h2 {
      font-size: var(--affine-font-h-2);
      line-height: calc(1em + 10px);
      margin-top: calc(var(--affine-paragraph-space) + 20px);
    }
    .h2 code {
      font-size: calc(var(--affine-font-base) + 6px);
    }
    .h3 {
      font-size: var(--affine-font-h-3);
      line-height: calc(1em + 8px);
      margin-top: calc(var(--affine-paragraph-space) + 16px);
    }
    .h3 code {
      font-size: calc(var(--affine-font-base) + 4px);
    }
    .h4 {
      font-size: var(--affine-font-h-4);
      line-height: calc(1em + 10px);
      margin-top: calc(var(--affine-paragraph-space) + 12px);
    }
    .h4 code {
      font-size: calc(var(--affine-font-base) + 2px);
    }
    .h5 {
      font-size: var(--affine-font-h-5);
      line-height: calc(1em + 8px);
      margin-top: calc(var(--affine-paragraph-space) + 8px);
    }
    .h5 code {
      font-size: calc(var(--affine-font-base));
    }
    .h6 {
      font-size: var(--affine-font-h-6);
      line-height: calc(1em + 8px);
      margin-top: calc(var(--affine-paragraph-space) + 4px);
    }
    .h6 code {
      font-size: calc(var(--affine-font-base) - 2px);
    }
    .quote {
      line-height: 26px;
      padding-left: 12px;
      margin-top: var(--affine-paragraph-space);
      position: relative;
    }
    .quote::after {
      content: '';
      width: 4px;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background: var(--affine-quote-color);
      border-radius: 4px;
    }
    .text {
      margin-top: var(--affine-paragraph-space);
      font-size: var(--affine-font-base);
    }

    .tips-placeholder {
      position: absolute;
      display: flex;
      align-items: center;
      gap: 4px;
      pointer-events: none;
      color: var(--affine-placeholder-color);
      fill: var(--affine-placeholder-color);
    }

    .tips-placeholder > svg {
      cursor: pointer;
      pointer-events: all;
    }
    .tips-placeholder > svg:hover {
      fill: var(--affine-primary-color);
    }
  `,b([(0,d.SB)()],y.prototype,"tipsPos",void 0),b([(0,d.SB)()],y.prototype,"_tipsPlaceholderTemplate",void 0),b([(0,d.SB)()],y.prototype,"_isComposing",void 0),b([(0,d.SB)()],y.prototype,"_isFocus",void 0),b([(0,d.IO)("rich-text")],y.prototype,"_richTextElement",void 0),y=b([(0,d.Mo)("affine-paragraph")],y);var x=i(58046)},29045:function(e,t,i){"use strict";i.d(t,{E9:function(){return n.E9},FV:function(){return n.FV},UL:function(){return n.UL},YK:function(){return n.YK},a6:function(){return n.a6},bR:function(){return n.bR},cS:function(){return n.cS},ev:function(){return n.ev},gj:function(){return n.gj},lK:function(){return n.lK},uZ:function(){return n.uZ},xT:function(){return n.xT},zE:function(){return n.zE}});var n=i(65024)},77597:function(e,t,i){"use strict";i.d(t,{A:function(){return n}});class n{constructor(e,t,i,n){this.id=Math.random().toString(16).slice(2),this.x=e,this.y=t,this.w=i,this.h=n}get minX(){return this.x}get maxX(){return this.x+this.w}get minY(){return this.y}get maxY(){return this.y+this.h}inflate(e,t){return new n(this.x-e,this.y-t,this.w+2*e,this.h+2*t)}contains(e,t){return e>=this.minX&&e<=this.maxX&&t>=this.minY&&t<=this.maxY}relativeDirection(e,t){let i;let n={left:Math.abs(e-this.x),right:Math.abs(e-this.x-this.w),top:Math.abs(t-this.y),bottom:Math.abs(t-this.y-this.h)},o="top";return Object.entries(n).forEach(([e,t])=>{void 0===i?(i=t,o=e):t<i&&(i=t,o=e)}),o}}},92007:function(e,t,i){"use strict";function n(e,t=0,i){if(e.length<=2)return e;let n=void 0!==t?t*t:1;return e=function(e,t){let i=e.length-1,n=[e[0]];return!function e(t,i,n,o,r){let a=o,s=-1;for(let e=i+1;e<n;e++){let o=function(e,t,i){let n=t.x,o=t.y,r=i.x-n,a=i.y-o;if(0!==r||0!==a){let t=((e.x-n)*r+(e.y-o)*a)/(r*r+a*a);t>1?(n=i.x,o=i.y):t>0&&(n+=r*t,o+=a*t)}return(r=e.x-n)*r+(a=e.y-o)*a}(t[e],t[i],t[n]);o>a&&(s=e,a=o)}a>o&&(s-i>1&&e(t,i,s,o,r),r.push(t[s]),n-s>1&&e(t,s,n,o,r))}(e,0,i,t,n),n.push(e[i]),n}(e=i?e:function(e,t){let i,n=e[0],o=[n];for(let r=1,a=e.length;r<a;r++)(function(e,t){let i=e.x-t.x,n=e.y-t.y;return i*i+n*n})(i=e[r],n)>t&&(o.push(i),n=i);return n!==i&&o.push(i),o}(e,n),n)}i.d(t,{S:function(){return n}})},69692:function(e,t,i){"use strict";i.d(t,{I_:function(){return a},VA:function(){return l},Xr:function(){return d},s9:function(){return s}});var n=i(92758),o=i(7339),r=i(6635);let a=[{flavour:"affine:paragraph",type:"text",name:"Text",hotkey:`${r.jQ}+option+0,${r.jQ}+shift+0`,icon:n.VL},{flavour:"affine:paragraph",type:"h1",name:"Heading 1",hotkey:`${r.jQ}+option+1,${r.jQ}+shift+1`,icon:n.LV},{flavour:"affine:paragraph",type:"h2",name:"Heading 2",hotkey:`${r.jQ}+option+2,${r.jQ}+shift+2`,icon:n.bM},{flavour:"affine:paragraph",type:"h3",name:"Heading 3",hotkey:`${r.jQ}+option+3,${r.jQ}+shift+3`,icon:n.g3},{flavour:"affine:paragraph",type:"h4",name:"Heading 4",hotkey:`${r.jQ}+option+4,${r.jQ}+shift+4`,icon:n.fw},{flavour:"affine:paragraph",type:"h5",name:"Heading 5",hotkey:`${r.jQ}+option+5,${r.jQ}+shift+5`,icon:n.Zr},{flavour:"affine:paragraph",type:"h6",name:"Heading 6",hotkey:`${r.jQ}+option+6,${r.jQ}+shift+6`,icon:n.mF},{flavour:"affine:list",type:"bulleted",name:"Bulleted List",hotkey:`${r.jQ}+option+8,${r.jQ}+shift+8`,icon:n.W0},{flavour:"affine:list",type:"numbered",name:"Numbered List",hotkey:`${r.jQ}+option+9,${r.jQ}+shift+9`,icon:n.kS},{flavour:"affine:list",type:"todo",name:"To-do List",hotkey:null,icon:n.iH},{flavour:"affine:code",type:void 0,name:"Code Block",hotkey:"command+option+c,ctrl+alt+c",icon:n.MM},{flavour:"affine:paragraph",type:"quote",name:"Quote",hotkey:null,icon:n.PE},{flavour:"affine:divider",type:"divider",name:"Divider",hotkey:`${r.jQ}+option+d,${r.jQ}+shift+d`,icon:n.RK}],s=[{flavour:"affine:paragraph",type:"text",name:"Text",description:"Start typing with plain text.",icon:n.VL,tooltip:"Drag/Click to insert Text block"},{flavour:"affine:paragraph",type:"h1",name:"Heading 1",description:"Headings in the largest font.",icon:n.LV,tooltip:"Drag/Click to insert Heading 1"},{flavour:"affine:paragraph",type:"h2",name:"Heading 2",description:"Headings in the 2nd font size.",icon:n.bM,tooltip:"Drag/Click to insert Heading 2"},{flavour:"affine:paragraph",type:"h3",name:"Heading 3",description:"Headings in the 3rd font size.",icon:n.g3,tooltip:"Drag/Click to insert Heading 3"},{flavour:"affine:paragraph",type:"h4",name:"Heading 4",description:"Heading in the 4th font size.",icon:n.fw,tooltip:"Drag/Click to insert Heading 4"},{flavour:"affine:paragraph",type:"h5",name:"Heading 5",description:"Heading in the 5th font size.",icon:n.Zr,tooltip:"Drag/Click to insert Heading 5"},{flavour:"affine:paragraph",type:"h6",name:"Heading 6",description:"Heading in the 6th font size.",icon:n.mF,tooltip:"Drag/Click to insert Heading 6"},{flavour:"affine:code",type:null,name:"Code Block",description:"Capture a code snippet.",icon:n.MM,tooltip:"Drag/Click to insert Code Block"},{flavour:"affine:paragraph",type:"quote",name:"Quote",description:"Capture a quote.",icon:n.PE,tooltip:"Drag/Click to insert Quote"},{flavour:"affine:divider",type:null,name:"Divider",description:"A visual divider.",icon:n.RK,tooltip:"A visual divider"}],l=[{flavour:"affine:list",type:"bulleted",name:"Bulleted List",description:"A simple bulleted list.",icon:n.W0,tooltip:"Drag/Click to insert Bulleted List"},{flavour:"affine:list",type:"numbered",name:"Numbered List",description:"A list with numbering.",icon:n.kS,tooltip:"Drag/Click to insert Numbered List"},{flavour:"affine:list",type:"todo",name:"To-do List",description:"Track tasks with a to-do list.",icon:n.iH,tooltip:"Drag/Click to insert To-do List"}],d=[{flavour:"affine:embed",type:"image",name:"Image",description:"Upload images.",icon:o.XB,tooltip:"Drag/Click to insert Image"},{flavour:"affine:bookmark",type:"bookmark",name:"Bookmark",description:"Insert a link in card view.",icon:o.pl,tooltip:"Drag/Click to insert Bookmark"}]},4937:function(e,t,i){"use strict";i.d(t,{JM:function(){return a},VI:function(){return h},VN:function(){return d},_U:function(){return g},e2:function(){return b},eD:function(){return c},f_:function(){return r},h7:function(){return s},lC:function(){return o},ml:function(){return v},oX:function(){return f},uh:function(){return u},ws:function(){return p},xV:function(){return l}});var n=i(15486);let o=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11 3.75C6.99594 3.75 3.75 6.99594 3.75 11C3.75 15.0041 6.99594 18.25 11 18.25C13.0026 18.25 14.8156 17.4381 16.1276 16.1254L16.1287 16.1243C17.4393 14.8125 18.25 13.0008 18.25 11C18.25 6.99594 15.0041 3.75 11 3.75ZM17.6965 16.6324C18.9779 15.1104 19.75 13.1453 19.75 11C19.75 6.16751 15.8325 2.25 11 2.25C6.16751 2.25 2.25 6.16751 2.25 11C2.25 15.8325 6.16751 19.75 11 19.75C13.1471 19.75 15.1136 18.9767 16.6361 17.6933L20.4694 21.5301C20.7622 21.8231 21.2371 21.8233 21.5301 21.5306C21.8231 21.2378 21.8233 20.7629 21.5306 20.4699L17.6965 16.6324Z"
  />
</svg>`;n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M14 6.20314L5.5 15L4 20L9 18.5L17.7969 10M14 6.20314L15.3595 4.79619C16.4211 3.73461 18.1422 3.7346 19.2038 4.79619C20.2654 5.85777 20.2654 7.57894 19.2038 8.64052L17.7969 10M14 6.20314L17.7969 10"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>`,n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M4 6H20M16 6L15.7294 5.18807C15.4671 4.40125 15.3359 4.00784 15.0927 3.71698C14.8779 3.46013 14.6021 3.26132 14.2905 3.13878C13.9376 3 13.523 3 12.6936 3H11.3064C10.477 3 10.0624 3 9.70951 3.13878C9.39792 3.26132 9.12208 3.46013 8.90729 3.71698C8.66405 4.00784 8.53292 4.40125 8.27064 5.18807L8 6M18 6V16.2C18 17.8802 18 18.7202 17.673 19.362C17.3854 19.9265 16.9265 20.3854 16.362 20.673C15.7202 21 14.8802 21 13.2 21H10.8C9.11984 21 8.27976 21 7.63803 20.673C7.07354 20.3854 6.6146 19.9265 6.32698 19.362C6 18.7202 6 17.8802 6 16.2V6M14 10V17M10 10V17"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>`;let r=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M11.25 9C11.25 9.41421 11.5858 9.75 12 9.75H13.1893L7.46967 15.4697C7.17678 15.7626 7.17678 16.2374 7.46967 16.5303C7.76256 16.8232 8.23744 16.8232 8.53033 16.5303L14.25 10.8107V12C14.25 12.4142 14.5858 12.75 15 12.75C15.4142 12.75 15.75 12.4142 15.75 12V9.1C15.75 9.08264 15.7495 9.0654 15.7485 9.04829C15.7618 8.84059 15.6891 8.62841 15.5303 8.46967C15.3716 8.31093 15.1594 8.23823 14.9517 8.25155C14.9346 8.25052 14.9174 8.25 14.9 8.25H12C11.5858 8.25 11.25 8.58579 11.25 9Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.8304 3.25H11.1696C10.6354 3.24999 10.1896 3.24998 9.82533 3.27974C9.44545 3.31078 9.08879 3.37789 8.75153 3.54973C8.23408 3.81338 7.81339 4.23408 7.54973 4.75153C7.37789 5.08879 7.31078 5.44545 7.27974 5.82533C7.24998 6.18956 7.24999 6.63541 7.25 7.16956L7.25 7.25L7.16957 7.25C6.63542 7.24999 6.18956 7.24998 5.82533 7.27974C5.44545 7.31078 5.08879 7.37789 4.75153 7.54973C4.23408 7.81339 3.81338 8.23408 3.54973 8.75153C3.37789 9.08879 3.31078 9.44545 3.27974 9.82533C3.24998 10.1896 3.24999 10.6354 3.25 11.1696V16.8304C3.24999 17.3646 3.24998 17.8104 3.27974 18.1747C3.31078 18.5546 3.37789 18.9112 3.54973 19.2485C3.81338 19.7659 4.23408 20.1866 4.75153 20.4503C5.08879 20.6221 5.44545 20.6892 5.82533 20.7203C6.18956 20.75 6.6354 20.75 7.16955 20.75H12.8305C13.3646 20.75 13.8104 20.75 14.1747 20.7203C14.5546 20.6892 14.9112 20.6221 15.2485 20.4503C15.7659 20.1866 16.1866 19.7659 16.4503 19.2485C16.6221 18.9112 16.6892 18.5546 16.7203 18.1747C16.75 17.8105 16.75 17.3646 16.75 16.8305V16.75H16.8305C17.3646 16.75 17.8105 16.75 18.1747 16.7203C18.5546 16.6892 18.9112 16.6221 19.2485 16.4503C19.7659 16.1866 20.1866 15.7659 20.4503 15.2485C20.6221 14.9112 20.6892 14.5546 20.7203 14.1747C20.75 13.8104 20.75 13.3646 20.75 12.8305V7.16955C20.75 6.6354 20.75 6.18956 20.7203 5.82533C20.6892 5.44545 20.6221 5.08879 20.4503 4.75153C20.1866 4.23408 19.7659 3.81338 19.2485 3.54973C18.9112 3.37789 18.5546 3.31078 18.1747 3.27974C17.8104 3.24998 17.3646 3.24999 16.8304 3.25ZM7.25 11V8.75H7.2C6.62757 8.75 6.24336 8.75058 5.94748 8.77476C5.66036 8.79822 5.52307 8.8401 5.43251 8.88624C5.19731 9.00608 5.00608 9.19731 4.88624 9.43251C4.8401 9.52307 4.79822 9.66036 4.77476 9.94748C4.75058 10.2434 4.75 10.6276 4.75 11.2V16.8C4.75 17.3724 4.75058 17.7566 4.77476 18.0525C4.79822 18.3396 4.8401 18.4769 4.88624 18.5675C5.00608 18.8027 5.19731 18.9939 5.43251 19.1138C5.52307 19.1599 5.66036 19.2018 5.94748 19.2252C6.24336 19.2494 6.62757 19.25 7.2 19.25H12.8C13.3724 19.25 13.7566 19.2494 14.0525 19.2252C14.3396 19.2018 14.4769 19.1599 14.5675 19.1138C14.8027 18.9939 14.9939 18.8027 15.1138 18.5675C15.1599 18.4769 15.2018 18.3396 15.2252 18.0525C15.2494 17.7566 15.25 17.3724 15.25 16.8V16.75H13C12.5858 16.75 12.25 16.4142 12.25 16C12.25 15.5858 12.5858 15.25 13 15.25H16.8C17.3724 15.25 17.7566 15.2494 18.0525 15.2252C18.3396 15.2018 18.4769 15.1599 18.5675 15.1138C18.8027 14.9939 18.9939 14.8027 19.1138 14.5675C19.1599 14.4769 19.2018 14.3396 19.2252 14.0525C19.2494 13.7566 19.25 13.3724 19.25 12.8V7.2C19.25 6.62757 19.2494 6.24336 19.2252 5.94748C19.2018 5.66036 19.1599 5.52307 19.1138 5.43251C18.9939 5.19731 18.8027 5.00608 18.5675 4.88624C18.4769 4.8401 18.3396 4.79822 18.0525 4.77476C17.7566 4.75058 17.3724 4.75 16.8 4.75H11.2C10.6276 4.75 10.2434 4.75058 9.94748 4.77476C9.66036 4.79822 9.52307 4.8401 9.43251 4.88624C9.19731 5.00608 9.00608 5.19731 8.88624 5.43251C8.8401 5.52307 8.79822 5.66036 8.77476 5.94748C8.75058 6.24336 8.75 6.62757 8.75 7.2V11C8.75 11.4142 8.41422 11.75 8 11.75C7.58579 11.75 7.25 11.4142 7.25 11Z"
  />
</svg>`,a=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12.25 6C12.25 4.48122 13.4812 3.25 15 3.25H18C19.5188 3.25 20.75 4.48122 20.75 6V18C20.75 19.5188 19.5188 20.75 18 20.75H15C13.4812 20.75 12.25 19.5188 12.25 18V6ZM15 4.75C14.3096 4.75 13.75 5.30964 13.75 6V18C13.75 18.6904 14.3096 19.25 15 19.25H18C18.6904 19.25 19.25 18.6904 19.25 18V6C19.25 5.30964 18.6904 4.75 18 4.75H15Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 12C3.25 11.5858 3.58579 11.25 4 11.25L10 11.25C10.4142 11.25 10.75 11.5858 10.75 12C10.75 12.4142 10.4142 12.75 10 12.75L4 12.75C3.58579 12.75 3.25 12.4142 3.25 12Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7 15.75C6.58579 15.75 6.25 15.4142 6.25 15L6.25 9C6.25 8.58579 6.58579 8.25 7 8.25C7.41421 8.25 7.75 8.58579 7.75 9L7.75 15C7.75 15.4142 7.41421 15.75 7 15.75Z"
  />
</svg>`,s=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11.75 6C11.75 4.48122 10.5188 3.25 9 3.25H6C4.48122 3.25 3.25 4.48122 3.25 6V18C3.25 19.5188 4.48122 20.75 6 20.75H9C10.5188 20.75 11.75 19.5188 11.75 18V6ZM9 4.75C9.69036 4.75 10.25 5.30964 10.25 6V18C10.25 18.6904 9.69036 19.25 9 19.25H6C5.30964 19.25 4.75 18.6904 4.75 18V6C4.75 5.30964 5.30964 4.75 6 4.75H9Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.75 12C20.75 11.5858 20.4142 11.25 20 11.25L14 11.25C13.5858 11.25 13.25 11.5858 13.25 12C13.25 12.4142 13.5858 12.75 14 12.75L20 12.75C20.4142 12.75 20.75 12.4142 20.75 12Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M17 15.75C17.4142 15.75 17.75 15.4142 17.75 15V9C17.75 8.58579 17.4142 8.25 17 8.25C16.5858 8.25 16.25 8.58579 16.25 9V15C16.25 15.4142 16.5858 15.75 17 15.75Z"
  />
</svg>`,l=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M4 4V20M8 12H20M8 12L12 8M8 12L12 16"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>`,d=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M20 4V20M4 12H16M16 12L12 8M16 12L12 16"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
  />
</svg>`,c=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M4 5L6.42929 7.42929C6.46834 7.46834 6.53166 7.46834 6.57071 7.42929L9 5"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M4 11L6.42929 13.4293C6.46834 13.4683 6.53166 13.4683 6.57071 13.4293L9 11"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M4 17L6.42929 19.4293C6.46834 19.4683 6.53166 19.4683 6.57071 19.4293L9 17"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M12 6L20 6"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M12 12L20 12"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M12 18L20 18"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
</svg>`,h=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M18.5 4L12.5 20"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M12 4L6 20"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M20 8.5H5.5"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
  <path
    d="M19 15L4 15"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
  />
</svg>`,u=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 7.44365 16.5563 3.75 12 3.75ZM2.25 12C2.25 6.61522 6.61522 2.25 12 2.25C17.3848 2.25 21.75 6.61522 21.75 12C21.75 17.3848 17.3848 21.75 12 21.75C6.61522 21.75 2.25 17.3848 2.25 12Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.46967 10.4697C7.76256 10.1768 8.23744 10.1768 8.53033 10.4697L12 13.9393L15.4697 10.4697C15.7626 10.1768 16.2374 10.1768 16.5303 10.4697C16.8232 10.7626 16.8232 11.2374 16.5303 11.5303L12.601 15.4596C12.2691 15.7916 11.7309 15.7916 11.399 15.4596L7.46967 11.5303C7.17678 11.2374 7.17678 10.7626 7.46967 10.4697Z"
  />
</svg>`,f=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M15 4.25C15.4142 4.25 15.75 4.58579 15.75 5V6.25H18C20.0711 6.25 21.75 7.92893 21.75 10V14C21.75 16.0711 20.0711 17.75 18 17.75H15.75V19C15.75 19.4142 15.4142 19.75 15 19.75C14.5858 19.75 14.25 19.4142 14.25 19V17.75H6C3.92893 17.75 2.25 16.0711 2.25 14V10C2.25 7.92893 3.92893 6.25 6 6.25H14.25V5C14.25 4.58579 14.5858 4.25 15 4.25ZM14.25 7.75H6C4.75736 7.75 3.75 8.75736 3.75 10V14C3.75 15.2426 4.75736 16.25 6 16.25H14.25V7.75ZM15.75 16.25H18C19.2426 16.25 20.25 15.2426 20.25 14V10C20.25 8.75736 19.2426 7.75 18 7.75H15.75V16.25ZM6 9.25C6.41421 9.25 6.75 9.58579 6.75 10V14C6.75 14.4142 6.41421 14.75 6 14.75C5.58579 14.75 5.25 14.4142 5.25 14L5.25 10C5.25 9.58579 5.58579 9.25 6 9.25ZM9 9.25C9.41421 9.25 9.75 9.58579 9.75 10L9.75 14C9.75 14.4142 9.41421 14.75 9 14.75C8.58579 14.75 8.25 14.4142 8.25 14L8.25 10C8.25 9.58579 8.58579 9.25 9 9.25ZM12 9.25C12.4142 9.25 12.75 9.58579 12.75 10V14C12.75 14.4142 12.4142 14.75 12 14.75C11.5858 14.75 11.25 14.4142 11.25 14V10C11.25 9.58579 11.5858 9.25 12 9.25Z"
  />
</svg>`,p=n.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  xmlns="http://www.w3.org/2000/svg"
  fill="none"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4.22872 4.22878C4.42398 4.03352 4.74057 4.03352 4.93583 4.22878L7.99996 7.29291L11.0641 4.22878C11.2593 4.03352 11.5759 4.03352 11.7712 4.22878C11.9665 4.42405 11.9665 4.74063 11.7712 4.93589L8.70707 8.00002L11.7712 11.0641C11.9665 11.2594 11.9665 11.576 11.7712 11.7713C11.5759 11.9665 11.2593 11.9665 11.0641 11.7713L7.99996 8.70713L4.93583 11.7713C4.74057 11.9665 4.42398 11.9665 4.22872 11.7713C4.03346 11.576 4.03346 11.2594 4.22872 11.0641L7.29285 8.00002L4.22872 4.93589C4.03346 4.74063 4.03346 4.42405 4.22872 4.22878Z"
  />
</svg>`,g=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.5322 5.97152C20.824 6.26543 20.8224 6.7403 20.5285 7.03217L9.45156 18.0322C9.15909 18.3226 8.68706 18.3226 8.3946 18.0322L3.47152 13.1433C3.17761 12.8514 3.17595 12.3765 3.46783 12.0826C3.7597 11.7887 4.23457 11.7871 4.52848 12.0789L8.92308 16.443L19.4715 5.96783C19.7654 5.67595 20.2403 5.67761 20.5322 5.97152Z"
  />
</svg>`,m=`
  width: 12px;
  height: 12px;
  fill: var(--affine-text-primary-color);
`,v=n.dy`<svg
  viewBox="0 0 16 16"
  style=${m}
>
  <path
    d="M7.977 14.963c.407 0 .747-.324.747-.723V8.72h5.362c.399 0 .74-.34.74-.747a.746.746 0 00-.74-.738H8.724V1.706c0-.398-.34-.722-.747-.722a.732.732 0 00-.739.722v5.529h-5.37a.746.746 0 00-.74.738c0 .407.341.747.74.747h5.37v5.52c0 .399.332.723.739.723z"
  ></path>
</svg>`,b=n.dy`<svg
  width="10"
  height="14"
  viewBox="0 0 10 14"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <rect width="10" height="14" rx="2" />
  <rect width="10" height="14" rx="2" fill-opacity="0.08" />
  <g clip-path="url(#clip0_179_9218)">
    <circle cx="3" cy="3" r="1" fill="var(--affine-icon-color)" />
    <circle cx="3" cy="6.79163" r="1" fill="var(--affine-icon-color)" />
    <circle cx="3" cy="10.5833" r="1" fill="var(--affine-icon-color)" />
    <circle cx="7" cy="3" r="1" fill="var(--affine-icon-color)" />
    <circle cx="7" cy="6.79163" r="1" fill="var(--affine-icon-color)" />
    <circle cx="7" cy="10.5833" r="1" fill="var(--affine-icon-color)" />
  </g>
  <defs>
    <clipPath id="clip0_179_9218">
      <rect width="6" height="10" transform="translate(2 2)" />
    </clipPath>
  </defs>
</svg>`},7339:function(e,t,i){"use strict";i.d(t,{AQ:function(){return x},FE:function(){return v},FL:function(){return d},GV:function(){return o},Mw:function(){return u},NL:function(){return r},Nb:function(){return M},PC:function(){return E},Ps:function(){return p},Re:function(){return g},SC:function(){return L},UP:function(){return R},Uw:function(){return S},V_:function(){return C},XB:function(){return s},YX:function(){return b},Zi:function(){return $},_c:function(){return P},jQ:function(){return B},mh:function(){return T},nb:function(){return m},oR:function(){return k},p7:function(){return h},pO:function(){return y},pl:function(){return c},q$:function(){return f},u7:function(){return l},wR:function(){return w},xh:function(){return _}});var n=i(15486);let o=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M10.3383 3.88231L18.071 8.69778C19.0571 9.31182 19.8404 9.79964 20.4017 10.2216C20.9493 10.6333 21.4318 11.0842 21.62 11.6695C21.8868 12.4988 21.7381 13.4034 21.2188 14.1027C20.852 14.5967 20.2493 14.8668 19.599 15.0782C18.9323 15.2949 18.0344 15.5017 16.9044 15.7619L14.4307 16.3314C14.0188 16.4263 13.91 16.4546 13.8157 16.4966C13.7187 16.5398 13.6281 16.5952 13.546 16.6612C13.4669 16.7248 13.3935 16.807 13.1235 17.1285L11.9305 18.5487C11.162 19.4637 10.552 20.1898 10.0419 20.6983C9.54488 21.1937 9.0177 21.6165 8.39807 21.7155C7.52714 21.8546 6.63964 21.5686 6.0146 20.9464C5.56965 20.5035 5.39026 19.852 5.27806 19.16C5.1629 18.4498 5.09457 17.5048 5.00849 16.3143L4.36527 7.41939C4.2957 6.4575 4.23967 5.68281 4.25165 5.08075C4.26359 4.48099 4.34126 3.90703 4.65756 3.44031C5.11363 2.76734 5.84836 2.33594 6.65832 2.25865C7.21739 2.2053 7.76104 2.406 8.30191 2.67862C8.84485 2.95229 9.51023 3.36666 10.3383 3.88231ZM7.62675 4.01809C7.14246 3.77397 6.9194 3.74055 6.80081 3.75187C6.43097 3.78716 6.10155 3.98334 5.89928 4.28182C5.83742 4.37309 5.762 4.57571 5.75136 5.11059C5.74092 5.635 5.79114 6.34017 5.8642 7.35039L6.50172 16.1665C6.59131 17.4054 6.65553 18.2835 6.75873 18.92C6.86617 19.5826 6.99326 19.8041 7.07279 19.8833C7.35743 20.1666 7.76348 20.2978 8.16142 20.2342C8.27334 20.2164 8.507 20.1103 8.98299 19.6359C9.44028 19.1801 10.0077 18.5057 10.8074 17.5536L11.975 16.1637C11.9876 16.1487 12 16.1338 12.0123 16.1192C12.2275 15.8628 12.3982 15.6594 12.606 15.4923C12.7891 15.345 12.9907 15.222 13.2055 15.1264C13.4489 15.018 13.7084 14.9583 14.0374 14.8828C14.0561 14.8785 14.075 14.8741 14.0941 14.8697L16.5295 14.3089C17.7063 14.038 18.5392 13.8455 19.1353 13.6517C19.7553 13.4501 19.9497 13.2958 20.0146 13.2084C20.2446 12.8987 20.3109 12.4982 20.1921 12.1288C20.1582 12.0234 20.0225 11.8131 19.5003 11.4206C18.9982 11.0431 18.2715 10.5897 17.2448 9.95034L9.57801 5.17595C8.70973 4.63525 8.10185 4.25756 7.62675 4.01809Z"
  />
</svg>`,r=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 3.25C12.2691 3.25 12.5177 3.39421 12.6512 3.6279L16.2067 9.85012C16.3394 10.0822 16.3384 10.3674 16.2042 10.5987C16.07 10.8299 15.8229 10.9722 15.5556 10.9722H8.44444C8.17709 10.9722 7.92995 10.8299 7.79576 10.5987C7.66157 10.3674 7.66062 10.0822 7.79326 9.85012L11.3488 3.6279C11.4823 3.39421 11.7309 3.25 12 3.25ZM9.73683 9.47222H14.2632L12 5.51167L9.73683 9.47222ZM7.11111 14.5278C5.80711 14.5278 4.75 15.5849 4.75 16.8889C4.75 18.1929 5.80711 19.25 7.11111 19.25C8.41512 19.25 9.47222 18.1929 9.47222 16.8889C9.47222 15.5849 8.41512 14.5278 7.11111 14.5278ZM3.25 16.8889C3.25 14.7565 4.97868 13.0278 7.11111 13.0278C9.24354 13.0278 10.9722 14.7565 10.9722 16.8889C10.9722 19.0213 9.24354 20.75 7.11111 20.75C4.97868 20.75 3.25 19.0213 3.25 16.8889ZM13.0278 13.7778C13.0278 13.3636 13.3636 13.0278 13.7778 13.0278H20C20.4142 13.0278 20.75 13.3636 20.75 13.7778V20C20.75 20.4142 20.4142 20.75 20 20.75H13.7778C13.3636 20.75 13.0278 20.4142 13.0278 20V13.7778ZM14.5278 14.5278V19.25H19.25V14.5278H14.5278Z"
  />
</svg>`,a=n.YP`<path
fill-rule="evenodd"
clip-rule="evenodd"
d="M15 6.25C13.4812 6.25 12.25 7.48122 12.25 9C12.25 10.5188 13.4812 11.75 15 11.75C16.5188 11.75 17.75 10.5188 17.75 9C17.75 7.48122 16.5188 6.25 15 6.25ZM13.75 9C13.75 8.30964 14.3096 7.75 15 7.75C15.6904 7.75 16.25 8.30964 16.25 9C16.25 9.69036 15.6904 10.25 15 10.25C14.3096 10.25 13.75 9.69036 13.75 9Z"
/>
<path
fill-rule="evenodd"
clip-rule="evenodd"
d="M5 4.25C3.48122 4.25 2.25 5.48122 2.25 7V17C2.25 18.5188 3.48122 19.75 5 19.75H16.9863C16.9956 19.7502 17.0049 19.7502 17.0142 19.75H19C20.5188 19.75 21.75 18.5188 21.75 17V7C21.75 5.48122 20.5188 4.25 19 4.25H5ZM17.3356 18.25H19C19.4585 18.25 19.8593 18.0031 20.0769 17.6351L18.6231 16.1718C18.2208 15.7541 17.9502 15.4738 17.7245 15.275C17.5054 15.0819 17.3784 15.0117 17.2815 14.9786C17.0293 14.8926 16.7562 14.8895 16.5021 14.9697C16.4045 15.0005 16.276 15.0678 16.0524 15.2558C15.8542 15.4224 15.6213 15.6486 15.2976 15.9689L17.3356 18.25ZM20.25 15.681V7C20.25 6.30964 19.6904 5.75 19 5.75H5C4.30964 5.75 3.75 6.30964 3.75 7V17C3.75 17.1543 3.77795 17.302 3.82907 17.4385L7.50733 13.8054L7.52247 13.7897C7.89807 13.4008 8.21139 13.0763 8.48886 12.8325C8.7781 12.5783 9.07737 12.3666 9.43913 12.2436C9.99371 12.0551 10.594 12.0486 11.1525 12.2251C11.5168 12.3402 11.8206 12.5454 12.1153 12.7932C12.398 13.031 12.7182 13.3486 13.1022 13.7293L14.2639 14.8814C14.5765 14.5722 14.8455 14.3108 15.087 14.1077C15.382 13.8597 15.6861 13.6542 16.0508 13.5392C16.6099 13.3628 17.2107 13.3697 17.7656 13.5589C18.1276 13.6823 18.4269 13.8947 18.7161 14.1495C18.9936 14.3939 19.3068 14.7192 19.6824 15.1091L19.6996 15.127L20.25 15.681ZM5.142 18.25H15.3241L13.7197 16.4542L12.0677 14.816C11.6564 14.4081 11.3797 14.1346 11.1498 13.9412C10.9266 13.7535 10.7982 13.6862 10.7006 13.6554C10.4468 13.5752 10.1739 13.5781 9.92184 13.6638C9.825 13.6967 9.6981 13.7667 9.47895 13.9593C9.25327 14.1576 8.98257 14.4371 8.58019 14.8537L8.56773 14.8663L5.142 18.25Z"
/>`,s=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  ${a}
</svg>`,l=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  ${a}
</svg>`,d=n.dy`
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3334_82005)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M5.144 3.54166H14.856C15.3035 3.54166 15.6722 3.54165 15.9726 3.56312C16.2832 3.58533 16.5712 3.63292 16.8445 3.75478C17.2675 3.94339 17.6272 4.25139 17.8584 4.64842C18.0131 4.91401 18.0726 5.19494 18.0996 5.48406C18.125 5.75652 18.125 6.08757 18.125 6.47237V13.5276C18.125 13.9124 18.125 14.2435 18.0996 14.5159C18.0726 14.8051 18.0131 15.086 17.8584 15.3516C17.6272 15.7486 17.2675 16.0566 16.8445 16.2452C16.5712 16.3671 16.2832 16.4147 15.9726 16.4369C15.6722 16.4583 15.3034 16.4583 14.856 16.4583H5.144C4.69656 16.4583 4.32777 16.4583 4.02744 16.4369C3.71685 16.4147 3.42883 16.3671 3.15552 16.2452C2.73246 16.0566 2.37275 15.7486 2.14156 15.3516C1.9869 15.086 1.92741 14.8051 1.90042 14.5159C1.87497 14.2435 1.87499 13.9124 1.875 13.5276V6.4724C1.87499 6.08759 1.87497 5.75652 1.90042 5.48406C1.92741 5.19494 1.9869 4.91401 2.14156 4.64842C2.37275 4.25139 2.73247 3.94339 3.15552 3.75478C3.42883 3.63292 3.71685 3.58533 4.02744 3.56312C4.32777 3.54165 4.69655 3.54166 5.144 3.54166ZM3.125 8.4375V13.5C3.125 13.9201 3.12563 14.1923 3.145 14.3997C3.16342 14.597 3.19476 14.6762 3.22176 14.7226C3.31014 14.8743 3.46036 15.0125 3.66452 15.1035C3.74772 15.1406 3.87132 15.1725 4.11657 15.1901C4.36702 15.208 4.69092 15.2083 5.16667 15.2083H14.8333C15.3091 15.2083 15.633 15.208 15.8834 15.1901C16.1287 15.1725 16.2523 15.1406 16.3355 15.1035C16.5396 15.0125 16.6899 14.8743 16.7782 14.7226C16.8052 14.6762 16.8366 14.597 16.855 14.3997C16.8744 14.1923 16.875 13.9201 16.875 13.5V8.4375H3.125ZM16.875 7.1875H3.125V6.5C3.125 6.07986 3.12563 5.80768 3.145 5.60027C3.16342 5.40303 3.19476 5.3238 3.22176 5.27744C3.31014 5.12566 3.46036 4.98747 3.66452 4.89645C3.74772 4.85935 3.87132 4.82748 4.11657 4.80994C4.36702 4.79204 4.69092 4.79166 5.16667 4.79166H14.8333C15.3091 4.79166 15.633 4.79204 15.8834 4.80994C16.1287 4.82748 16.2523 4.85935 16.3355 4.89645C16.5396 4.98747 16.6899 5.12566 16.7782 5.27744C16.8052 5.3238 16.8366 5.40303 16.855 5.60027C16.8744 5.80768 16.875 6.07986 16.875 6.5V7.1875Z"
        fill="currentColor"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M8.86926 9.56896C9.10731 9.81892 9.09766 10.2145 8.8477 10.4526L7.57292 11.6667L8.8477 12.8807C9.09766 13.1188 9.10731 13.5144 8.86926 13.7644C8.6312 14.0143 8.23559 14.024 7.98563 13.7859L6.23563 12.1193C6.11177 12.0013 6.04167 11.8377 6.04167 11.6667C6.04167 11.4956 6.11177 11.332 6.23563 11.2141L7.98563 9.54741C8.23559 9.30936 8.6312 9.31901 8.86926 9.56896ZM11.1307 9.56896C11.3688 9.31901 11.7644 9.30936 12.0144 9.54741L13.7644 11.2141C13.8882 11.332 13.9583 11.4956 13.9583 11.6667C13.9583 11.8377 13.8882 12.0013 13.7644 12.1193L12.0144 13.7859C11.7644 14.024 11.3688 14.0143 11.1307 13.7644C10.8927 13.5144 10.9023 13.1188 11.1523 12.8807L12.4271 11.6667L11.1523 10.4526C10.9023 10.2145 10.8927 9.81892 11.1307 9.56896Z"
        fill="currentColor"
      />
      <path
        d="M5.08333 6.04166C5.08333 6.38684 4.80351 6.66666 4.45833 6.66666C4.11316 6.66666 3.83333 6.38684 3.83333 6.04166C3.83333 5.69649 4.11316 5.41666 4.45833 5.41666C4.80351 5.41666 5.08333 5.69649 5.08333 6.04166Z"
        fill="currentColor"
      />
      <path
        d="M6.75008 6.04166C6.75008 6.38684 6.47026 6.66666 6.12508 6.66666C5.77991 6.66666 5.50008 6.38684 5.50008 6.04166C5.50008 5.69649 5.77991 5.41666 6.12508 5.41666C6.47026 5.41666 6.75008 5.69649 6.75008 6.04166Z"
        fill="currentColor"
      />
      <path
        d="M8.41675 6.04166C8.41675 6.38684 8.13693 6.66666 7.79175 6.66666C7.44657 6.66666 7.16675 6.38684 7.16675 6.04166C7.16675 5.69649 7.44657 5.41666 7.79175 5.41666C8.13693 5.41666 8.41675 5.69649 8.41675 6.04166Z"
        fill="currentColor"
      />
    </g>
    <defs>
      <clipPath id="clip0_3334_82005">
        <rect width="20" height="20" fill="white" />
      </clipPath>
    </defs>
  </svg>
`,c=n.dy`
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3433_78963)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        fill="currentColor"
        d="M4.16667 4.79167C3.59137 4.79167 3.125 5.25804 3.125 5.83334V14.1667C3.125 14.742 3.59137 15.2083 4.16667 15.2083H15.8333C16.4086 15.2083 16.875 14.742 16.875 14.1667V10C16.875 9.65483 17.1548 9.375 17.5 9.375C17.8452 9.375 18.125 9.65483 18.125 10V14.1667C18.125 15.4323 17.099 16.4583 15.8333 16.4583H4.16667C2.90101 16.4583 1.875 15.4323 1.875 14.1667V5.83334C1.875 4.56768 2.90101 3.54167 4.16667 3.54167H10C10.3452 3.54167 10.625 3.82149 10.625 4.16667C10.625 4.51185 10.3452 4.79167 10 4.79167H4.16667Z"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        fill="currentColor"
        d="M13.6063 3.48363C14.64 2.44991 16.316 2.44991 17.3497 3.48363C18.3834 4.51735 18.3834 6.19334 17.3497 7.22706L16.2774 8.29939C16.0333 8.54347 15.6376 8.54347 15.3935 8.29939C15.3371 8.24297 15.2937 8.17845 15.2634 8.10958C15.2915 8.82166 15.0338 9.54296 14.4902 10.0866L13.0604 11.5164C12.0267 12.5501 10.3507 12.5501 9.31696 11.5164C8.28324 10.4827 8.28324 8.80667 9.31696 7.77295L10.3893 6.70062C10.6334 6.45654 11.0291 6.45654 11.2732 6.70062C11.3296 6.75703 11.373 6.82155 11.4033 6.89043C11.3751 6.17834 11.6329 5.45705 12.1765 4.9134L13.6063 3.48363ZM11.4445 7.26331C11.4215 7.38099 11.3643 7.49333 11.2732 7.5845L10.2008 8.65683C9.65528 9.2024 9.65528 10.0869 10.2008 10.6325C10.7464 11.1781 11.6309 11.1781 12.1765 10.6325L13.6063 9.20272C14.1518 8.65716 14.1518 7.77262 13.6063 7.22706C13.5203 7.1411 13.4267 7.06921 13.3279 7.01087C13.0307 6.83533 12.932 6.45209 13.1076 6.15488C13.2831 5.85767 13.6664 5.75903 13.9636 5.93457C14.1521 6.04591 14.3293 6.18228 14.4902 6.34317C14.8849 6.73788 15.1289 7.22622 15.2221 7.7367C15.2452 7.61901 15.3023 7.50668 15.3935 7.4155L16.4658 6.34317C17.0114 5.79761 17.0114 4.91307 16.4658 4.36751C15.9203 3.82194 15.0357 3.82194 14.4902 4.36751L13.0604 5.79728C12.5148 6.34285 12.5148 7.22738 13.0604 7.77295C13.1463 7.8589 13.24 7.9308 13.3388 7.98914C13.636 8.16467 13.7346 8.54791 13.5591 8.84512C13.3835 9.14234 13.0003 9.24097 12.7031 9.06544C12.5146 8.9541 12.3374 8.81773 12.1765 8.65683C11.7818 8.26213 11.5378 7.77378 11.4445 7.26331Z"
      />
    </g>
    <defs>
      <clipPath id="clip0_3433_78963">
        <rect width="20" height="20" fill="white" />
      </clipPath>
    </defs>
  </svg>
`,h=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M17.5 4.75C16.5335 4.75 15.75 5.5335 15.75 6.5C15.75 7.4665 16.5335 8.25 17.5 8.25C18.4665 8.25 19.25 7.4665 19.25 6.5C19.25 5.5335 18.4665 4.75 17.5 4.75ZM14.25 6.5C14.25 4.70507 15.7051 3.25 17.5 3.25C19.2949 3.25 20.75 4.70507 20.75 6.5C20.75 8.29493 19.2949 9.75 17.5 9.75C16.8901 9.75 16.3194 9.58197 15.8317 9.28968L9.28968 15.8317C9.58197 16.3194 9.75 16.8901 9.75 17.5C9.75 19.2949 8.29493 20.75 6.5 20.75C4.70507 20.75 3.25 19.2949 3.25 17.5C3.25 15.7051 4.70507 14.25 6.5 14.25C7.1415 14.25 7.73958 14.4359 8.24335 14.7567L14.7567 8.24335C14.4359 7.73958 14.25 7.1415 14.25 6.5ZM6.5 15.75C5.5335 15.75 4.75 16.5335 4.75 17.5C4.75 18.4665 5.5335 19.25 6.5 19.25C7.4665 19.25 8.25 18.4665 8.25 17.5C8.25 16.5335 7.4665 15.75 6.5 15.75Z"
  />
</svg>`,u=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M15.894 5.32233L15.0516 6.19412L17.8059 8.94836L18.6776 8.106C19.4422 7.33698 19.4408 6.09381 18.6735 5.32652C17.9062 4.55923 16.663 4.55783 15.894 5.32233ZM16.727 9.99082L14.0092 7.27298L6.16599 15.3901L5.11859 18.8814L8.60991 17.834L16.727 9.99082ZM14.8291 4.26586C16.1836 2.91138 18.3797 2.91138 19.7341 4.26586C21.0886 5.62033 21.0886 7.81637 19.7341 9.17085L19.725 9.17995L9.52114 19.0394C9.43501 19.1226 9.33021 19.184 9.2155 19.2184L4.2155 20.7184C3.95122 20.7977 3.66476 20.7254 3.46966 20.5303C3.27456 20.3352 3.20234 20.0488 3.28162 19.7845L4.78162 14.7845C4.81603 14.6698 4.87742 14.565 4.96064 14.4788L14.8291 4.26586Z"
  />
</svg>`,f=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M14.8114 20.999C13.2447 20.9679 11.7002 20.6209 10.2699 19.9787L4.67482 17.3458C4.12742 17.0853 3.70531 16.6178 3.501 16.0458C3.29668 15.4737 3.32684 14.8437 3.58486 14.2938C3.84271 13.7454 4.30714 13.3222 4.87604 13.1172C5.44494 12.9122 6.07173 12.9422 6.61858 13.2006L7.66312 13.6926C7.17264 12.0254 6.19168 9.26496 4.72024 7.65243L3.81194 6.9145C3.37099 6.55513 3.08591 6.03846 3.01648 5.47286C2.94705 4.90727 3.09867 4.33669 3.43953 3.88077C3.78344 3.42341 4.29072 3.11757 4.85476 3.02753C5.4188 2.93748 5.99569 3.07025 6.46417 3.39792C7.56208 4.18419 8.52532 5.14417 9.31623 6.24033C9.58326 5.83988 9.97184 5.53639 10.4244 5.37486C10.7041 5.27066 11.002 5.22422 11.3001 5.23831C11.5982 5.2524 11.8904 5.32672 12.1592 5.45685C12.4015 5.57016 12.6227 5.72422 12.8132 5.91236C13.058 5.63326 13.371 5.42289 13.7215 5.30197C13.9828 5.20656 14.2604 5.16466 14.5381 5.17874C14.8158 5.19282 15.0879 5.2626 15.3383 5.38396C15.6253 5.51414 15.8775 5.71086 16.074 5.95792C16.1756 5.89185 16.2856 5.83976 16.401 5.80304C16.7997 5.65961 17.2388 5.68073 17.622 5.86179C18.0052 6.04285 18.301 6.36905 18.4446 6.76873L20.6155 12.818C21.1282 14.2647 21.1282 15.8444 20.6155 17.2911C20.3444 18.0579 19.9061 18.7544 19.3326 19.3296C18.759 19.9049 18.0647 20.3445 17.3002 20.6164C16.4979 20.8833 15.6566 21.0127 14.8114 20.999ZM5.75747 14.4032C5.62583 14.3751 5.4278 14.3671 5.32879 14.4032C5.21385 14.4428 5.108 14.5051 5.01751 14.5865C4.92702 14.6678 4.85373 14.7666 4.80198 14.8769C4.74874 14.9866 4.71803 15.106 4.71166 15.2278C4.7053 15.3497 4.72341 15.4716 4.76492 15.5863C4.80643 15.7011 4.8705 15.8062 4.95332 15.8957C5.03614 15.9851 5.13602 16.0569 5.24704 16.1068L10.8058 18.7943C10.8058 18.7943 14.0939 20.3249 16.8006 19.3501C17.3787 19.1551 17.9049 18.8307 18.3392 18.4013C18.7736 17.9719 19.1048 17.449 19.3075 16.8721C19.7157 15.7262 19.7157 14.474 19.3075 13.3282L17.1276 7.27891C17.1185 7.2489 17.1033 7.22112 17.083 7.19728C17.0626 7.17344 17.0376 7.15407 17.0095 7.14038C16.9813 7.1267 16.9507 7.119 16.9194 7.11775C16.8882 7.11651 16.857 7.12174 16.8279 7.13314C16.7706 7.1556 16.7243 7.19958 16.6989 7.25572C16.6734 7.31186 16.6708 7.37574 16.6916 7.43378L17.0004 8.34481C17.0366 8.43122 17.0546 8.52416 17.0534 8.61785C17.0522 8.71153 17.0318 8.80397 16.9934 8.88941C16.9551 8.97485 16.8997 9.05147 16.8305 9.11451C16.7614 9.17755 16.6801 9.22565 16.5917 9.25584C16.5056 9.29207 16.4129 9.31014 16.3195 9.30893C16.2261 9.30772 16.1339 9.28726 16.0487 9.24881C15.9636 9.21036 15.8872 9.15474 15.8243 9.08543C15.7615 9.01611 15.7135 8.93458 15.6834 8.84588L15.0839 7.16959C15.0101 6.98388 14.8712 6.8316 14.6934 6.7414C14.6028 6.70307 14.5055 6.68331 14.4072 6.68331C14.309 6.68331 14.2117 6.70307 14.1211 6.7414C13.9396 6.80212 13.7882 6.93063 13.6986 7.10026C13.609 7.2699 13.5879 7.46763 13.6397 7.65243L13.8941 8.60902C13.9389 8.7793 13.9156 8.96042 13.829 9.11365C13.7424 9.26688 13.5995 9.38005 13.4308 9.42894C13.2645 9.4814 13.0845 9.46702 12.9285 9.38884C12.7726 9.31065 12.6531 9.17476 12.5952 9.00986L11.9957 7.35179C11.9119 7.12856 11.7441 6.94721 11.5284 6.84671C11.3127 6.7462 11.0663 6.73457 10.8422 6.81429C10.6196 6.89838 10.4388 7.06666 10.3386 7.283C10.2384 7.49933 10.2268 7.74646 10.3063 7.97129L10.7423 9.19208C10.7784 9.27848 10.7964 9.37141 10.7952 9.4651C10.794 9.55878 10.7736 9.65122 10.7352 9.73666C10.6969 9.8221 10.6415 9.89872 10.5724 9.96176C10.5033 10.0248 10.422 10.0729 10.3335 10.1031C10.2474 10.1393 10.1547 10.1574 10.0613 10.1562C9.96791 10.155 9.87575 10.1345 9.79056 10.0961C9.70538 10.0576 9.62899 10.002 9.56614 9.93269C9.50329 9.86338 9.45533 9.78183 9.42523 9.69313C8.68278 7.68202 7.3454 5.94647 5.5922 4.71891C5.41716 4.59322 5.19975 4.54185 4.98718 4.57597C4.7746 4.61008 4.58403 4.72692 4.45683 4.90112C4.32552 5.07405 4.33703 5.23645 4.36245 5.45231C4.38787 5.66818 4.49591 5.8657 4.66377 6.00319L5.57207 6.76845L5.63565 6.83222C8.11531 9.50154 9.26884 14.7126 9.31426 14.9313C9.34154 15.0568 9.33301 15.1875 9.28963 15.3083C9.24625 15.4292 9.1698 15.5353 9.06902 15.6146C8.96956 15.6916 8.85101 15.74 8.72616 15.7544C8.60131 15.7689 8.47489 15.7489 8.36055 15.6966L6.77594 14.8769C6.38102 14.6614 6.29788 14.5865 5.75747 14.4032Z"
  />
</svg>`,p=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <rect x="4" y="4" width="16" height="16" stroke-width="1.5" />
</svg>`,g=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <circle cx="12" cy="12" r="9" stroke-width="1.5" />
</svg>`,m=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path d="M3 12L12 3L21 12L12 21L3 12Z" stroke-width="1.5" />
</svg>`,v=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path d="M12 4L20.6603 19H3.33975L12 4Z" stroke-width="1.5" />
</svg>`,b=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <rect x="3" y="5" width="18" height="14" rx="2" stroke-width="1.5" />
</svg>`;n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 3.25C12.4142 3.25 12.75 3.58579 12.75 4V14.1893L15.4697 11.4697C15.7626 11.1768 16.2374 11.1768 16.5303 11.4697C16.8232 11.7626 16.8232 12.2374 16.5303 12.5303L12.5303 16.5303C12.2374 16.8232 11.7626 16.8232 11.4697 16.5303L7.46967 12.5303C7.17678 12.2374 7.17678 11.7626 7.46967 11.4697C7.76256 11.1768 8.23744 11.1768 8.53033 11.4697L11.25 14.1893V4C11.25 3.58579 11.5858 3.25 12 3.25ZM3.25 20C3.25 19.5858 3.58579 19.25 4 19.25H20C20.4142 19.25 20.75 19.5858 20.75 20C20.75 20.4142 20.4142 20.75 20 20.75H4C3.58579 20.75 3.25 20.4142 3.25 20Z"
  />
</svg>`;let C=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.25 12C5.25 11.5858 5.58579 11.25 6 11.25H18C18.4142 11.25 18.75 11.5858 18.75 12C18.75 12.4142 18.4142 12.75 18 12.75H6C5.58579 12.75 5.25 12.4142 5.25 12Z"
  />
</svg>`,y=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 5.25C12.4142 5.25 12.75 5.58579 12.75 6V11.25H18C18.4142 11.25 18.75 11.5858 18.75 12C18.75 12.4142 18.4142 12.75 18 12.75H12.75V18C12.75 18.4142 12.4142 18.75 12 18.75C11.5858 18.75 11.25 18.4142 11.25 18V12.75H6C5.58579 12.75 5.25 12.4142 5.25 12C5.25 11.5858 5.58579 11.25 6 11.25H11.25V6C11.25 5.58579 11.5858 5.25 12 5.25Z"
  />
</svg>`,x=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M3.25 20C2.83579 20 2.5 19.6642 2.5 19.25V4.75C2.5 4.33579 2.83579 4 3.25 4C3.66421 4 4 4.33579 4 4.75L4 19.25C4 19.6642 3.66421 20 3.25 20Z"
  />
  <path
    d="M9.16494 8.43945C9.47453 8.71464 9.50241 9.18869 9.22722 9.49828L7.67013 11.25H16.3299L14.7728 9.49828C14.4976 9.18869 14.5255 8.71464 14.8351 8.43945C15.1446 8.16426 15.6187 8.19215 15.8939 8.50174L18.5606 11.5017C18.8131 11.7859 18.8131 12.2141 18.5606 12.4983L15.8939 15.4983C15.6187 15.8079 15.1446 15.8358 14.8351 15.5606C14.5255 15.2854 14.4976 14.8113 14.7728 14.5017L16.3299 12.75H7.67013L9.22722 14.5017C9.50241 14.8113 9.47453 15.2854 9.16494 15.5606C8.85535 15.8358 8.3813 15.8079 8.10611 15.4983L5.43944 12.4983C5.18685 12.2141 5.18685 11.7859 5.43944 11.5017L8.10611 8.50174C8.3813 8.19215 8.85535 8.16426 9.16494 8.43945Z"
  />
  <path
    d="M21.5 4.75C21.5 4.33579 21.1642 4 20.75 4C20.3358 4 20 4.33579 20 4.75V19.25C20 19.6642 20.3358 20 20.75 20C21.1642 20 21.5 19.6642 21.5 19.25V4.75Z"
  />
</svg>`,w=n.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M-0.939238 4.14286C-0.979281 4.4228 -1 4.70898 -1 5V6.71429H1.57143V9.28571H-1V11C-1 11.291 -0.979281 11.5772 -0.939238 11.8571H1.57143V14.4286H0.0754482C0.481795 15.0111 0.988871 15.5182 1.57143 15.9246V14.4286L4.14286 14.4286V16.9392C4.4228 16.9793 4.70898 17 5 17H6.71429V14.4286H9.28571V17H11C11.291 17 11.5772 16.9793 11.8571 16.9392V14.4286H14.4286L14.4286 15.9246C15.0111 15.5182 15.5182 15.0111 15.9246 14.4286L14.4286 14.4286V11.8571H16.9392C16.9793 11.5772 17 11.291 17 11V9.28571H14.4286V6.71429H17V5C17 4.70898 16.9793 4.4228 16.9392 4.14286H14.4286V1.57143H15.9246C15.5182 0.988871 15.0111 0.481795 14.4286 0.075448L14.4286 1.57143H11.8571V-0.939238C11.5772 -0.979281 11.291 -1 11 -1H9.28571V1.57143H6.71429V-1H5C4.70898 -1 4.4228 -0.979281 4.14286 -0.939238V1.57143H1.57143V0.0754479C0.988871 0.481795 0.481795 0.988871 0.0754479 1.57143H1.57143V4.14286H-0.939238ZM4.14286 4.14286V1.57143H6.71429V4.14286H4.14286ZM4.14286 6.71429H1.57143V4.14286H4.14286V6.71429ZM6.71429 6.71429V4.14286H9.28571V6.71429H6.71429ZM6.71429 9.28571V6.71429H4.14286V9.28571H1.57143V11.8571H4.14286V14.4286H6.71429V11.8571H9.28571V14.4286H11.8571V11.8571H14.4286V9.28571H11.8571V6.71429H14.4286V4.14286H11.8571V1.57143H9.28571V4.14286H11.8571V6.71429H9.28571V9.28571H6.71429ZM6.71429 9.28571V11.8571H4.14286V9.28571H6.71429ZM9.28571 9.28571H11.8571V11.8571H9.28571V9.28571Z"
    fill="#D9D9D9"
  />
</svg>`,_=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M10 5.00004C9.53978 5.00004 9.16669 4.62694 9.16669 4.16671C9.16669 3.70647 9.53978 3.33337 10 3.33337C10.4603 3.33337 10.8334 3.70647 10.8334 4.16671C10.8334 4.62694 10.4603 5.00004 10 5.00004Z"
  />
  <path
    d="M10 10.8334C9.53978 10.8334 9.16669 10.4603 9.16669 10C9.16669 9.5398 9.53978 9.16671 10 9.16671C10.4603 9.16671 10.8334 9.5398 10.8334 10C10.8334 10.4603 10.4603 10.8334 10 10.8334Z"
  />
  <path
    d="M10 16.6667C9.53978 16.6667 9.16669 16.2936 9.16669 15.8334C9.16669 15.3731 9.53978 15 10 15C10.4603 15 10.8334 15.3731 10.8334 15.8334C10.8334 16.2936 10.4603 16.6667 10 16.6667Z"
  />
  <path
    d="M10 5.00004C9.53978 5.00004 9.16669 4.62694 9.16669 4.16671C9.16669 3.70647 9.53978 3.33337 10 3.33337C10.4603 3.33337 10.8334 3.70647 10.8334 4.16671C10.8334 4.62694 10.4603 5.00004 10 5.00004Z"
  />
  <path
    d="M10 10.8334C9.53978 10.8334 9.16669 10.4603 9.16669 10C9.16669 9.5398 9.53978 9.16671 10 9.16671C10.4603 9.16671 10.8334 9.5398 10.8334 10C10.8334 10.4603 10.4603 10.8334 10 10.8334Z"
  />
  <path
    d="M10 16.6667C9.53978 16.6667 9.16669 16.2936 9.16669 15.8334C9.16669 15.3731 9.53978 15 10 15C10.4603 15 10.8334 15.3731 10.8334 15.8334C10.8334 16.2936 10.4603 16.6667 10 16.6667Z"
  />
</svg>`,k=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.70825 3.33325C2.70825 2.98807 2.98807 2.70825 3.33325 2.70825H5.83325C6.17843 2.70825 6.45825 2.98807 6.45825 3.33325C6.45825 3.67843 6.17843 3.95825 5.83325 3.95825H3.33325C2.98807 3.95825 2.70825 3.67843 2.70825 3.33325Z"
    fill="#77757D"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.12492 3.33325C8.12492 2.98807 8.40474 2.70825 8.74992 2.70825L11.2499 2.70825C11.5951 2.70825 11.8749 2.98807 11.8749 3.33325C11.8749 3.67843 11.5951 3.95825 11.2499 3.95825L8.74992 3.95825C8.40474 3.95825 8.12492 3.67843 8.12492 3.33325Z"
    fill="#77757D"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.6666 3.95825L14.1666 3.95825C13.8214 3.95825 13.5416 3.67843 13.5416 3.33325C13.5416 2.98807 13.8214 2.70825 14.1666 2.70825L16.6666 2.70825C17.0118 2.70825 17.2916 2.98807 17.2916 3.33325C17.2916 3.67843 17.0118 3.95825 16.6666 3.95825Z"
    fill="#77757D"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.70825 9.99992C2.70825 9.65474 2.98807 9.37492 3.33325 9.37492H16.6666C17.0118 9.37492 17.2916 9.65474 17.2916 9.99992C17.2916 10.3451 17.0118 10.6249 16.6666 10.6249H3.33325C2.98807 10.6249 2.70825 10.3451 2.70825 9.99992Z"
    fill="#77757D"
  />
  <path
    d="M2.70825 16.2499C2.70825 15.6746 3.17462 15.2083 3.74992 15.2083H16.2499C16.8252 15.2083 17.2916 15.6746 17.2916 16.2499C17.2916 16.8252 16.8252 17.2916 16.2499 17.2916H3.74992C3.17462 17.2916 2.70825 16.8252 2.70825 16.2499Z"
    fill="#77757D"
  />
</svg>`,M=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11.25 7C11.25 5.48122 12.4812 4.25 14 4.25H21C21.4142 4.25 21.75 4.58579 21.75 5C21.75 5.41421 21.4142 5.75 21 5.75H14C13.3096 5.75 12.75 6.30964 12.75 7V17C12.75 18.5188 11.5188 19.75 10 19.75H3C2.58579 19.75 2.25 19.4142 2.25 19C2.25 18.5858 2.58579 18.25 3 18.25H10C10.6904 18.25 11.25 17.6904 11.25 17V7Z"
  />
</svg>`,S=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.5303 3.53034C20.8232 3.82323 20.8232 4.29811 20.5303 4.591L4.591 20.5303C4.29811 20.8232 3.82323 20.8232 3.53034 20.5303C3.23745 20.2374 3.23745 19.7626 3.53034 19.4697L19.4697 3.53034C19.7626 3.23745 20.2374 3.23745 20.5303 3.53034Z"
  />
</svg>`,E=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.5303 3.53034C20.8232 3.82323 20.8232 4.29811 20.5303 4.591L17.341 7.78034C17.0481 8.07323 16.5732 8.07323 16.2803 7.78034C15.9874 7.48745 15.9874 7.01257 16.2803 6.71968L19.4697 3.53034C19.7626 3.23745 20.2374 3.23745 20.5303 3.53034Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M14.1553 9.90534C14.4482 10.1982 14.4482 10.6731 14.1553 10.966L10.966 14.1553C10.6731 14.4482 10.1982 14.4482 9.90534 14.1553C9.61245 13.8624 9.61245 13.3876 9.90534 13.0947L13.0947 9.90534C13.3876 9.61245 13.8624 9.61245 14.1553 9.90534Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.78034 16.2803C8.07323 16.5732 8.07323 17.0481 7.78034 17.341L4.591 20.5303C4.29811 20.8232 3.82323 20.8232 3.53034 20.5303C3.23745 20.2374 3.23745 19.7626 3.53034 19.4697L6.71968 16.2803C7.01257 15.9874 7.48745 15.9874 7.78034 16.2803Z"
  />
</svg>`,L=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.72068 18.34L18.34 6.72068C19.5331 8.15171 20.25 9.99158 20.25 12C20.25 16.5563 16.5563 20.25 12 20.25C9.99158 20.25 8.15171 19.5331 6.72068 18.34ZM17.2793 5.66002L5.66002 17.2793C4.46691 15.8483 3.75 14.0084 3.75 12C3.75 7.44365 7.44365 3.75 12 3.75C14.0084 3.75 15.8483 4.46691 17.2793 5.66002ZM5.10571 18.8943C6.86929 20.6579 9.30782 21.75 12 21.75C17.3848 21.75 21.75 17.3848 21.75 12C21.75 9.30782 20.6579 6.86929 18.8943 5.10571C17.1307 3.34213 14.6922 2.25 12 2.25C6.61522 2.25 2.25 6.61522 2.25 12C2.25 14.6922 3.34213 17.1307 5.10571 18.8943Z"
  />
</svg>`,$=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 6C3.25 4.48122 4.48122 3.25 6 3.25H14C14.4142 3.25 14.75 3.58579 14.75 4C14.75 4.41421 14.4142 4.75 14 4.75H6C5.30964 4.75 4.75 5.30964 4.75 6V20C4.75 20.4142 4.41421 20.75 4 20.75C3.58579 20.75 3.25 20.4142 3.25 20V6Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.75 18C20.75 19.5188 19.5188 20.75 18 20.75H10C9.58579 20.75 9.25 20.4142 9.25 20C9.25 19.5858 9.58579 19.25 10 19.25L18 19.25C18.6904 19.25 19.25 18.6904 19.25 18L19.25 4C19.25 3.58579 19.5858 3.25 20 3.25C20.4142 3.25 20.75 3.58579 20.75 4L20.75 18Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 9C8.25 8.0335 9.0335 7.25 10 7.25H14C14.9665 7.25 15.75 8.0335 15.75 9V11C15.75 11.9665 14.9665 12.75 14 12.75H10C9.0335 12.75 8.25 11.9665 8.25 11V9ZM10 8.75C9.86193 8.75 9.75 8.86193 9.75 9V11C9.75 11.1381 9.86193 11.25 10 11.25H14C14.1381 11.25 14.25 11.1381 14.25 11V9C14.25 8.86193 14.1381 8.75 14 8.75H10Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 16C8.25 15.5858 8.58579 15.25 9 15.25H15C15.4142 15.25 15.75 15.5858 15.75 16C15.75 16.4142 15.4142 16.75 15 16.75H9C8.58579 16.75 8.25 16.4142 8.25 16Z"
  />
</svg>`,P=n.dy`<svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.00004 0.708313C8.34522 0.708313 8.62504 0.988135 8.62504 1.33331V8.71332L9.78032 7.55804C10.0244 7.31396 10.4201 7.31396 10.6642 7.55804C10.9083 7.80211 10.9083 8.19784 10.6642 8.44192L8.44198 10.6641C8.32477 10.7814 8.1658 10.8472 8.00004 10.8472C7.83428 10.8472 7.67531 10.7814 7.5581 10.6641L5.33588 8.44192C5.0918 8.19784 5.0918 7.80211 5.33588 7.55804C5.57996 7.31396 5.97568 7.31396 6.21976 7.55804L7.37504 8.71332V1.33331C7.37504 0.988135 7.65486 0.708313 8.00004 0.708313ZM3.67888 5.15276L4.29634 5.15276C4.64152 5.15276 4.92134 5.43258 4.92134 5.77776C4.92134 6.12294 4.64152 6.40276 4.29634 6.40276H3.70375C3.27858 6.40276 2.99729 6.40324 2.78161 6.42087C2.57322 6.43789 2.48168 6.46775 2.42602 6.49611C2.26486 6.57822 2.13384 6.70925 2.05173 6.8704C2.02337 6.92606 1.99351 7.0176 1.97648 7.22599C1.95886 7.44167 1.95837 7.72296 1.95837 8.14813V12.2963C1.95837 12.7214 1.95886 13.0027 1.97648 13.2184C1.99351 13.4268 2.02337 13.5183 2.05173 13.574C2.13384 13.7352 2.26486 13.8662 2.42602 13.9483C2.48168 13.9767 2.57322 14.0065 2.78161 14.0235C2.99729 14.0412 3.27858 14.0416 3.70375 14.0416H12.2963C12.7215 14.0416 13.0028 14.0412 13.2185 14.0235C13.4269 14.0065 13.5184 13.9767 13.5741 13.9483C13.7352 13.8662 13.8662 13.7352 13.9484 13.574C13.9767 13.5183 14.0066 13.4268 14.0236 13.2184C14.0412 13.0027 14.0417 12.7214 14.0417 12.2963V8.14813C14.0417 7.72296 14.0412 7.44167 14.0236 7.22599C14.0066 7.0176 13.9767 6.92607 13.9484 6.87041C13.8662 6.70925 13.7352 6.57822 13.5741 6.49611C13.5184 6.46775 13.4269 6.43789 13.2185 6.42087C13.0028 6.40324 12.7215 6.40276 12.2963 6.40276H11.7037C11.3586 6.40276 11.0787 6.12294 11.0787 5.77776C11.0787 5.43258 11.3586 5.15276 11.7037 5.15276L12.3212 5.15276C12.7149 5.15275 13.0476 5.15274 13.3203 5.17502C13.606 5.19836 13.8803 5.24924 14.1416 5.38235C14.5379 5.58431 14.8602 5.90656 15.0621 6.30292C15.1952 6.56416 15.2461 6.83851 15.2694 7.1242C15.2917 7.39687 15.2917 7.72958 15.2917 8.12324V12.3212C15.2917 12.7148 15.2917 13.0475 15.2694 13.3202C15.2461 13.6059 15.1952 13.8802 15.0621 14.1415C14.8602 14.5378 14.5379 14.8601 14.1416 15.0621C13.8803 15.1952 13.606 15.246 13.3203 15.2694C13.0476 15.2917 12.7149 15.2917 12.3212 15.2916H3.67886C3.2852 15.2917 2.95248 15.2917 2.67982 15.2694C2.39413 15.246 2.11978 15.1952 1.85853 15.0621C1.46217 14.8601 1.13992 14.5378 0.937968 14.1415C0.804856 13.8802 0.753976 13.6059 0.730635 13.3202C0.708356 13.0475 0.708365 12.7148 0.708374 12.3211V8.12326C0.708365 7.72959 0.708356 7.39687 0.730635 7.1242C0.753976 6.83851 0.804856 6.56416 0.937968 6.30292C1.13992 5.90656 1.46217 5.58431 1.85853 5.38235C2.11978 5.24924 2.39413 5.19836 2.67982 5.17502C2.95249 5.15274 3.28521 5.15275 3.67888 5.15276Z"
    fill="#77757D"
  />
</svg>`,B=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g clip-path="url(#clip0_2131_19971)">
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.7085 6.16675C4.7085 5.82157 4.98832 5.54175 5.3335 5.54175H18.6668C19.012 5.54175 19.2918 5.82157 19.2918 6.16675C19.2918 6.51193 19.012 6.79175 18.6668 6.79175H5.3335C4.98832 6.79175 4.7085 6.51193 4.7085 6.16675Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.7085 12.0001C4.7085 11.6549 4.98832 11.3751 5.3335 11.3751H13.6668C14.012 11.3751 14.2918 11.6549 14.2918 12.0001C14.2918 12.3453 14.012 12.6251 13.6668 12.6251H5.3335C4.98832 12.6251 4.7085 12.3453 4.7085 12.0001Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.7085 17.8334C4.7085 17.4882 4.98832 17.2084 5.3335 17.2084H15.3335C15.6787 17.2084 15.9585 17.4882 15.9585 17.8334C15.9585 18.1786 15.6787 18.4584 15.3335 18.4584H5.3335C4.98832 18.4584 4.7085 18.1786 4.7085 17.8334Z"
      fill="#77757D"
    />
  </g>
  <defs>
    <clipPath id="clip0_2131_19971">
      <rect width="20" height="20" fill="white" transform="translate(2 2)" />
    </clipPath>
  </defs>
</svg>`,R=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g clip-path="url(#clip0_2131_19972)">
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.7085 6.16675C4.7085 5.82157 4.98832 5.54175 5.3335 5.54175H18.6668C19.012 5.54175 19.2918 5.82157 19.2918 6.16675C19.2918 6.51193 19.012 6.79175 18.6668 6.79175H5.3335C4.98832 6.79175 4.7085 6.51193 4.7085 6.16675Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.2085 12.0001C7.2085 11.6549 7.48832 11.3751 7.8335 11.3751H16.1668C16.512 11.3751 16.7918 11.6549 16.7918 12.0001C16.7918 12.3453 16.512 12.6251 16.1668 12.6251H7.8335C7.48832 12.6251 7.2085 12.3453 7.2085 12.0001Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.37516 17.8334C6.37516 17.4882 6.65498 17.2084 7.00016 17.2084H17.0002C17.3453 17.2084 17.6252 17.4882 17.6252 17.8334C17.6252 18.1786 17.3453 18.4584 17.0002 18.4584H7.00016C6.65498 18.4584 6.37516 18.1786 6.37516 17.8334Z"
      fill="#77757D"
    />
  </g>
  <defs>
    <clipPath id="clip0_2131_19972">
      <rect width="20" height="20" fill="white" transform="translate(2 2)" />
    </clipPath>
  </defs>
</svg>`,T=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <g clip-path="url(#clip0_2131_19973)">
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.7085 6.16675C4.7085 5.82157 4.98832 5.54175 5.3335 5.54175H18.6668C19.012 5.54175 19.2918 5.82157 19.2918 6.16675C19.2918 6.51193 19.012 6.79175 18.6668 6.79175H5.3335C4.98832 6.79175 4.7085 6.51193 4.7085 6.16675Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M9.7085 12.0001C9.7085 11.6549 9.98832 11.3751 10.3335 11.3751H18.6668C19.012 11.3751 19.2918 11.6549 19.2918 12.0001C19.2918 12.3453 19.012 12.6251 18.6668 12.6251H10.3335C9.98832 12.6251 9.7085 12.3453 9.7085 12.0001Z"
      fill="#77757D"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M8.04183 17.8334C8.04183 17.4882 8.32165 17.2084 8.66683 17.2084H18.6668C19.012 17.2084 19.2918 17.4882 19.2918 17.8334C19.2918 18.1786 19.012 18.4584 18.6668 18.4584H8.66683C8.32165 18.4584 8.04183 18.1786 8.04183 17.8334Z"
      fill="#77757D"
    />
  </g>
  <defs>
    <clipPath id="clip0_2131_19973">
      <rect width="20" height="20" fill="white" transform="translate(2 2)" />
    </clipPath>
  </defs>
</svg>`},92758:function(e,t,i){"use strict";i.d(t,{ve:function(){return ee},US:function(){return U},v_:function(){return F},xo:function(){return j},mY:function(){return M},W0:function(){return m},P9:function(){return J},ch:function(){return K},MM:function(){return w},q1:function(){return W},TI:function(){return T},aM:function(){return V},D3:function(){return y},Th:function(){return C},pJ:function(){return I},RK:function(){return k},_8:function(){return G},yR:function(){return ed},Gt:function(){return ec},NA:function(){return O},dY:function(){return q},E:function(){return R},eG:function(){return eo},H0:function(){return en},LV:function(){return d},bM:function(){return c},g3:function(){return h},fw:function(){return u},Zr:function(){return f},mF:function(){return p},ux:function(){return $},h3:function(){return S},xP:function(){return B},Md:function(){return X},Tm:function(){return ea},IY:function(){return es},p_:function(){return H},kS:function(){return b},oP:function(){return v},YA:function(){return er},PE:function(){return _},W1:function(){return N},dw:function(){return L},VL:function(){return s},i5:function(){return l},$M:function(){return D},iH:function(){return x},Gz:function(){return z},Ad:function(){return E},ZJ:function(){return Y},ug:function(){return Q},l3:function(){return A}});var n=i(15486);function o(e,t=20){let i=t/16,o=`
    width: ${i}em;
    height: ${i}em;
    vertical-align: middle;
    font-size: inherit;
    margin-bottom: 0.1em;
  `;return n.dy`<svg
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    style=${o}
  >
    ${e}
  </svg>`}function r(e,t=24){return n.dy`<svg
    width="${t}"
    height="${t}"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
  >
    ${e}
  </svg>`}let a=n.YP`<path
  fill-rule="evenodd"
  clip-rule="evenodd"
  d="M3.25 4C3.25 3.58579 3.58579 3.25 4 3.25H20C20.4142 3.25 20.75 3.58579 20.75 4V6.66667C20.75 7.08088 20.4142 7.41667 20 7.41667C19.5858 7.41667 19.25 7.08088 19.25 6.66667V4.75H12.75V19.25H16C16.4142 19.25 16.75 19.5858 16.75 20C16.75 20.4142 16.4142 20.75 16 20.75H8C7.58579 20.75 7.25 20.4142 7.25 20C7.25 19.5858 7.58579 19.25 8 19.25H11.25V4.75H4.75V6.66667C4.75 7.08088 4.41421 7.41667 4 7.41667C3.58579 7.41667 3.25 7.08088 3.25 6.66667V4Z"
/>`,s=r(a,20),l=r(a),d=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.7499 6.81081C16.7231 6.83762 16.6947 6.86599 16.6646 6.89602L14.5303 9.03033C14.2374 9.32322 13.7626 9.32322 13.4697 9.03033C13.1768 8.73744 13.1768 8.26256 13.4697 7.96967L15.604 5.83536C15.6113 5.82808 15.6185 5.82081 15.6258 5.81357C15.8211 5.61819 16.0018 5.43743 16.1578 5.30688C16.3005 5.18739 16.5575 4.98807 16.9019 4.96096C17.3008 4.92957 17.6906 5.09103 17.9505 5.3953C18.1749 5.65804 18.2157 5.98068 18.2321 6.16609C18.25 6.36867 18.25 6.62428 18.25 6.90057C18.25 6.91081 18.25 6.92108 18.25 6.93137V18.25H21C21.4142 18.25 21.75 18.5858 21.75 19C21.75 19.4142 21.4142 19.75 21 19.75H14C13.5858 19.75 13.25 19.4142 13.25 19C13.25 18.5858 13.5858 18.25 14 18.25H16.75V6.93137C16.75 6.88891 16.75 6.84878 16.7499 6.81081Z"
  />
</svg>`,c=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.9057 6.75035C16.3267 6.802 15.7718 7.01946 15.3049 7.3801C14.8318 7.74548 14.4682 8.24309 14.2591 8.81605C14.1172 9.20517 13.6866 9.40552 13.2975 9.26355C12.9084 9.12157 12.708 8.69103 12.85 8.30191C13.155 7.46589 13.6877 6.73376 14.388 6.19294C15.0884 5.65199 15.927 5.32534 16.8055 5.25346L16.8277 5.25164L16.8499 5.25115C17.8967 5.22771 18.9191 5.56392 19.7537 6.20306C20.5868 6.84102 21.1843 7.74329 21.4548 8.76409C21.7891 9.97619 21.5425 11.1146 21.1354 12.0147C20.7302 12.9106 20.1448 13.6215 19.7055 14.0279L19.6986 14.0343L19.6916 14.0405C18.9491 14.6937 18.1744 15.3076 17.3705 15.88C16.4743 16.5815 15.6527 17.3759 14.9186 18.25H21.2C21.6142 18.25 21.95 18.5858 21.95 19C21.95 19.4142 21.6142 19.75 21.2 19.75H13.5917C12.9084 19.75 12.4943 18.9759 12.9002 18.4076C13.9053 16.9999 15.1041 15.7469 16.4602 14.6877L16.4735 14.6773L16.4872 14.6675C17.2512 14.1242 17.9876 13.5412 18.6934 12.9208C19.0046 12.631 19.4584 12.0827 19.7687 11.3966C20.0787 10.7111 20.2239 9.93968 20.008 9.16007L20.0056 9.15134C19.8193 8.44582 19.4083 7.82782 18.8418 7.394C18.2815 6.965 17.6006 6.73982 16.9057 6.75035Z"
  />
</svg>`,h=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M17.3196 6.75154C16.8178 6.78189 16.3346 6.95347 15.926 7.24657C15.5153 7.54113 15.1968 7.94629 15.0075 8.41487C14.8523 8.79893 14.4152 8.98449 14.0312 8.82933C13.6471 8.67418 13.4616 8.23706 13.6167 7.853C13.9125 7.1209 14.4101 6.48789 15.0517 6.02769C15.6933 5.56749 16.4525 5.29903 17.2408 5.25359L17.2482 5.25316L17.2557 5.25288C18.2533 5.21525 19.2296 5.54803 19.9965 6.18714C20.7634 6.82626 21.2668 7.72652 21.4097 8.71457L21.4143 8.74618L21.4161 8.77807C21.4603 9.53257 21.2968 10.2847 20.9433 10.9528C20.6919 11.4279 20.3514 11.8475 19.9423 12.1898C20.4639 12.4619 20.9143 12.8568 21.2521 13.4177C21.8984 14.4739 21.8675 15.759 21.4573 16.838C21.0461 17.9197 20.2127 18.9107 19.0815 19.378L19.0786 19.3792C18.0333 19.8058 16.8745 19.8662 15.7905 19.5506C14.7065 19.2351 13.7612 18.5621 13.1082 17.6411C12.8686 17.3032 12.9483 16.8351 13.2862 16.5955C13.6241 16.3559 14.0923 16.4356 14.3318 16.7735C14.789 17.4183 15.4508 17.8895 16.2098 18.1104C16.9681 18.3312 17.7789 18.2891 18.5103 17.991C19.1943 17.7079 19.7645 17.0696 20.0552 16.305C20.3467 15.5381 20.3161 14.7606 19.9717 14.199L19.9682 14.1933C19.5426 13.4852 18.7016 13.1471 17.2275 13.1471C17.2201 13.1471 17.2121 13.1471 17.2038 13.1471C17.1523 13.1472 17.0876 13.1473 17.0508 13.1451C17.0439 13.1447 17.0076 13.1426 16.9647 13.1352L16.9637 13.135C16.9524 13.1332 16.865 13.1191 16.7673 13.0722L16.7655 13.0714C16.7295 13.0542 16.547 12.967 16.4309 12.7512C16.3831 12.6425 16.3413 12.3989 16.3519 12.2701C16.3793 12.1601 16.4656 11.9821 16.5164 11.914C16.6196 11.7908 16.7354 11.7347 16.7637 11.721C16.8085 11.6993 16.8465 11.6864 16.8651 11.6805C16.9035 11.6683 16.9346 11.662 16.9457 11.6597C16.9718 11.6545 16.993 11.6517 16.9996 11.6509C17.024 11.6477 17.0535 11.645 17.0677 11.6438L17.0706 11.6435C17.0761 11.643 17.082 11.6425 17.0882 11.6419C17.1709 11.6346 17.3161 11.6217 17.4965 11.597C17.9218 11.5387 18.3862 11.4336 18.6392 11.2811L18.6415 11.2798C19.0547 11.0326 19.3923 10.6769 19.6175 10.2513C19.8377 9.83509 19.9422 9.36767 19.9204 8.89772C19.8245 8.28862 19.5105 7.73468 19.0362 7.33947C18.5557 6.93905 17.9446 6.7298 17.3196 6.75154Z"
  />
</svg>`,u=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M18.1928 5.85878C18.6593 5.15904 19.75 5.48927 19.75 6.33028V14.25H21C21.4142 14.25 21.75 14.5858 21.75 15C21.75 15.4142 21.4142 15.75 21 15.75H19.75V19C19.75 19.4142 19.4142 19.75 19 19.75C18.5858 19.75 18.25 19.4142 18.25 19V15.75H13.1869C12.508 15.75 12.103 14.9934 12.4796 14.4285L18.1928 5.85878ZM18.25 14.25V8.47708L14.4014 14.25H18.25Z"
  />
</svg>`,f=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.9558 5.94948C14.0287 5.5446 14.381 5.25 14.7924 5.25H20.892C21.3062 5.25 21.642 5.58579 21.642 6C21.642 6.41421 21.3062 6.75 20.892 6.75H15.3359L14.677 10.4122C14.7083 10.3958 14.7397 10.3796 14.7713 10.3638C15.4506 10.0234 16.193 9.8296 16.9512 9.79502L16.9745 9.79396L16.9978 9.79435C18.0629 9.81203 19.0907 10.1881 19.9189 10.8615C20.743 11.5316 21.3224 12.4578 21.5681 13.4941C21.8521 14.5302 21.8025 15.6309 21.4262 16.6371C21.048 17.6482 20.3593 18.512 19.4591 19.1014L19.4463 19.1098L19.4332 19.1176C17.1285 20.4957 13.8824 19.5672 12.3514 16.9306C12.1434 16.5724 12.2652 16.1134 12.6234 15.9054C12.9816 15.6974 13.4406 15.8192 13.6486 16.1774C14.8123 18.1815 17.1546 18.7212 18.6504 17.838C19.2754 17.4248 19.756 16.8207 20.0213 16.1116C20.2883 15.3975 20.3225 14.6155 20.1186 13.8802L20.1145 13.8654L20.1111 13.8506C19.9425 13.1297 19.5413 12.4877 18.9726 12.0253C18.41 11.5679 17.7152 11.3117 16.996 11.2946C16.4565 11.3225 15.928 11.462 15.4433 11.7049C15.047 11.9035 14.6868 12.1677 14.3774 12.4863C14.075 12.7978 13.6591 12.7916 13.385 12.6587C13.1072 12.524 12.8336 12.1871 12.9141 11.7396L13.9558 5.94948Z"
  />
</svg>`,p=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3 4.25C3.41421 4.25 3.75 4.58579 3.75 5V11.25H10.25V5C10.25 4.58579 10.5858 4.25 11 4.25C11.4142 4.25 11.75 4.58579 11.75 5V19C11.75 19.4142 11.4142 19.75 11 19.75C10.5858 19.75 10.25 19.4142 10.25 19V12.75H3.75V19C3.75 19.4142 3.41421 19.75 3 19.75C2.58579 19.75 2.25 19.4142 2.25 19V5C2.25 4.58579 2.58579 4.25 3 4.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M15.8428 6.08001C16.5038 5.78482 17.221 5.63827 17.9443 5.65076L17.9528 5.65091L17.9612 5.65124C18.6652 5.67922 19.3558 5.85344 19.9894 6.16278C20.6596 6.48991 21.0427 6.86843 21.4674 7.36832C21.7355 7.68402 21.697 8.15733 21.3813 8.42549C21.0656 8.69365 20.5923 8.65511 20.3241 8.33942C19.9679 7.92001 19.7421 7.71121 19.3314 7.51075C18.8869 7.29373 18.4031 7.17116 17.91 7.1504C17.4093 7.14298 16.9127 7.245 16.4544 7.44965C15.9982 7.65337 15.5906 7.95407 15.2596 8.3315C14.8157 8.89075 14.4914 9.53705 14.3076 10.2297C14.1125 10.9831 13.997 11.753 13.9617 12.5269C14.7663 11.5406 15.9873 10.9103 17.3576 10.9103C19.7888 10.9103 21.75 12.8945 21.75 15.3302C21.75 17.7659 19.7888 19.75 17.3576 19.75C15.6443 19.75 14.1643 18.7645 13.4398 17.3301C13.0351 16.5834 12.7496 15.7772 12.5937 14.9411L12.5912 14.9278L12.5892 14.9144C12.3372 13.226 12.428 11.5036 12.856 9.85144L12.8571 9.84743C13.0954 8.94816 13.5178 8.10867 14.0975 7.38296L14.1072 7.37079L14.1174 7.35903C14.5931 6.81178 15.1818 6.37518 15.8428 6.08001ZM14.821 16.7346C15.3136 17.6393 16.2672 18.25 17.3576 18.25C18.9497 18.25 20.25 16.9481 20.25 15.3302C20.25 13.7122 18.9497 12.4103 17.3576 12.4103C15.7655 12.4103 14.4652 13.7122 14.4652 15.3302C14.4652 15.7995 14.5747 16.2423 14.7689 16.6344C14.7763 16.6478 14.7836 16.6612 14.791 16.6746C14.802 16.6943 14.812 16.7143 14.821 16.7346Z"
  />
</svg>`,g=n.YP`<path
  fill-rule="evenodd"
  clip-rule="evenodd"
  d="M3 6.5C3 5.83266 3.54099 5.29167 4.20833 5.29167C4.87568 5.29167 5.41667 5.83265 5.41667 6.5C5.41667 7.16734 4.87568 7.70833 4.20833 7.70833C3.54099 7.70833 3 7.16734 3 6.5ZM7.58333 6.50057C7.58336 6.08636 7.91916 5.75059 8.33337 5.75061L20.25 5.75127C20.6642 5.7513 21 6.0871 21 6.50131C21 6.91553 20.6641 7.2513 20.2499 7.25127L8.33329 7.25061C7.91908 7.25059 7.58331 6.91478 7.58333 6.50057ZM3 12C3 11.3327 3.54099 10.7917 4.20833 10.7917C4.87568 10.7917 5.41667 11.3327 5.41667 12C5.41667 12.6673 4.87568 13.2083 4.20833 13.2083C3.54099 13.2083 3 12.6673 3 12ZM7.58333 12.0006C7.58336 11.5864 7.91916 11.2506 8.33338 11.2507L20.2501 11.2514C20.6643 11.2514 21.0001 11.5872 21 12.0014C21 12.4156 20.6642 12.7514 20.25 12.7514L8.33329 12.7507C7.91907 12.7506 7.58331 12.4148 7.58333 12.0006ZM3 17.5C3 16.8327 3.54099 16.2917 4.20833 16.2917C4.87568 16.2917 5.41667 16.8327 5.41667 17.5C5.41667 18.1673 4.87568 18.7083 4.20833 18.7083C3.54099 18.7083 3 18.1673 3 17.5ZM7.58333 17.5006C7.58336 17.0864 7.91916 16.7506 8.33338 16.7507L20.2501 16.7514C20.6643 16.7514 21 17.0872 21 17.5014C21 17.9156 20.6642 18.2514 20.25 18.2514L8.33329 18.2507C7.91907 18.2506 7.58331 17.9148 7.58333 17.5006Z"
/>`,m=r(g,20);r(g,24);let v=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.97755 4.02864C6.19866 4.16529 6.33325 4.40669 6.33325 4.66663V9.41663H7.41659C7.8308 9.41663 8.16659 9.75241 8.16659 10.1666C8.16659 10.5808 7.8308 10.9166 7.41659 10.9166H3.74992C3.33571 10.9166 2.99992 10.5808 2.99992 10.1666C2.99992 9.75241 3.33571 9.41663 3.74992 9.41663H4.83325V5.88015L4.08533 6.25411C3.71485 6.43936 3.26434 6.28919 3.0791 5.9187C2.89386 5.54822 3.04403 5.09772 3.41451 4.91247L5.24784 3.99581C5.48033 3.87956 5.75644 3.89198 5.97755 4.02864ZM9.41659 6.49991C9.41661 6.0857 9.75242 5.74994 10.1666 5.74996L20.25 5.75057C20.6642 5.75059 20.9999 6.0864 20.9999 6.50061C20.9999 6.91483 20.6641 7.25059 20.2499 7.25057L10.1665 7.24996C9.75233 7.24994 9.41656 6.91413 9.41659 6.49991ZM9.41659 11.9999C9.41661 11.5857 9.75242 11.2499 10.1666 11.25L20.25 11.2506C20.6642 11.2506 20.9999 11.5864 20.9999 12.0006C20.9999 12.4148 20.6641 12.7506 20.2499 12.7506L10.1665 12.75C9.75233 12.7499 9.41656 12.4141 9.41659 11.9999ZM5.58325 14.5833C5.07949 14.5833 4.65431 14.9278 4.53401 15.3952C4.43076 15.7964 4.02187 16.0379 3.62073 15.9346C3.21959 15.8314 2.9781 15.4225 3.08135 15.0213C3.36809 13.9073 4.3785 13.0833 5.58325 13.0833H5.84022C7.12504 13.0833 8.16659 14.1248 8.16659 15.4097C8.16659 16.0805 7.877 16.7187 7.37215 17.1604L5.74601 18.5833H7.41659C7.8308 18.5833 8.16659 18.9191 8.16659 19.3333C8.16659 19.7475 7.8308 20.0833 7.41659 20.0833H3.74992C3.43746 20.0833 3.15774 19.8896 3.04784 19.5971C2.93794 19.3046 3.02089 18.9746 3.25604 18.7689L6.38439 16.0316C6.56372 15.8746 6.66659 15.6479 6.66659 15.4097C6.66659 14.9533 6.29661 14.5833 5.84022 14.5833H5.58325ZM9.41659 17.4999C9.41661 17.0857 9.75242 16.7499 10.1666 16.75L20.25 16.7506C20.6642 16.7506 20.9999 17.0864 20.9999 17.5006C20.9999 17.9148 20.6641 18.2506 20.2499 18.2506L10.1665 18.25C9.75233 18.2499 9.41656 17.9141 9.41659 17.4999Z"
  />
</svg>`,b=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.97763 4.02868C6.19874 4.16533 6.33333 4.40673 6.33333 4.66667V9.41667H7.41666C7.83088 9.41667 8.16666 9.75245 8.16666 10.1667C8.16666 10.5809 7.83088 10.9167 7.41666 10.9167H3.75C3.33578 10.9167 3 10.5809 3 10.1667C3 9.75245 3.33578 9.41667 3.75 9.41667H4.83333V5.88019L4.08541 6.25415C3.71492 6.4394 3.26442 6.28923 3.07918 5.91874C2.89393 5.54826 3.0441 5.09776 3.41459 4.91251L5.24792 3.99585C5.48041 3.8796 5.75652 3.89202 5.97763 4.02868ZM9.41666 6.49995C9.41669 6.08574 9.7525 5.74998 10.1667 5.75L20.25 5.75061C20.6643 5.75063 21 6.08644 21 6.50065C21 6.91487 20.6642 7.25063 20.25 7.25061L10.1666 7.25C9.75241 7.24998 9.41664 6.91417 9.41666 6.49995ZM9.41666 12C9.41669 11.5857 9.7525 11.25 10.1667 11.25L20.25 11.2506C20.6643 11.2506 21 11.5864 21 12.0007C21 12.4149 20.6642 12.7506 20.25 12.7506L10.1666 12.75C9.75241 12.75 9.41664 12.4142 9.41666 12ZM5.58333 14.5833C5.07957 14.5833 4.65439 14.9279 4.53408 15.3953C4.43084 15.7964 4.02195 16.0379 3.62081 15.9347C3.21967 15.8314 2.97818 15.4225 3.08143 15.0214C3.36816 13.9073 4.37857 13.0833 5.58333 13.0833H5.8403C7.12512 13.0833 8.16666 14.1249 8.16666 15.4097C8.16666 16.0805 7.87708 16.7187 7.37222 17.1605L5.74608 18.5833H7.41666C7.83088 18.5833 8.16666 18.9191 8.16666 19.3333C8.16666 19.7475 7.83088 20.0833 7.41666 20.0833H3.75C3.43754 20.0833 3.15782 19.8896 3.04792 19.5971C2.93802 19.3046 3.02097 18.9747 3.25612 18.7689L6.38446 16.0316C6.5638 15.8747 6.66666 15.648 6.66666 15.4097C6.66666 14.9533 6.29669 14.5833 5.8403 14.5833H5.58333ZM9.41666 17.5C9.41669 17.0857 9.7525 16.75 10.1667 16.75L20.25 16.7506C20.6643 16.7506 21 17.0864 21 17.5007C21 17.9149 20.6642 18.2506 20.25 18.2506L10.1666 18.25C9.75241 18.25 9.41664 17.9142 9.41666 17.5Z"
  />
</svg>`,C=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.1728 4.25H17.8272C18.3641 4.24999 18.8067 4.24999 19.1671 4.27575C19.5398 4.3024 19.8854 4.35951 20.2134 4.50573C20.721 4.73207 21.1527 5.10167 21.4301 5.57811C21.6157 5.89681 21.6871 6.23393 21.7195 6.58088C21.75 6.90782 21.75 7.30509 21.75 7.76685V16.2331C21.75 16.6949 21.75 17.0922 21.7195 17.4191C21.6871 17.7661 21.6157 18.1032 21.4301 18.4219C21.1527 18.8983 20.721 19.2679 20.2134 19.4943C19.8854 19.6405 19.5398 19.6976 19.1671 19.7242C18.8067 19.75 18.3641 19.75 17.8272 19.75H6.1728C5.63587 19.75 5.19332 19.75 4.83292 19.7242C4.46022 19.6976 4.1146 19.6405 3.78662 19.4943C3.27896 19.2679 2.8473 18.8983 2.56987 18.4219C2.38428 18.1032 2.31289 17.7661 2.2805 17.4191C2.24997 17.0922 2.24998 16.6949 2.25 16.2331V7.76689C2.24998 7.30511 2.24997 6.90783 2.2805 6.58088C2.31289 6.23393 2.38428 5.89681 2.56987 5.57811C2.8473 5.10167 3.27896 4.73207 3.78662 4.50573C4.1146 4.35951 4.46022 4.3024 4.83292 4.27575C5.19332 4.24999 5.63586 4.24999 6.1728 4.25ZM3.75 10.125V16.2C3.75 16.7042 3.75076 17.0308 3.774 17.2797C3.7961 17.5164 3.83371 17.6114 3.86611 17.6671C3.97217 17.8492 4.15244 18.015 4.39742 18.1243C4.49727 18.1688 4.64558 18.207 4.93989 18.2281C5.24043 18.2496 5.62911 18.25 6.2 18.25H7.25V10.125H3.75ZM3.75 8.625V7.8C3.75 7.29583 3.75076 6.96922 3.774 6.72033C3.7961 6.48364 3.83371 6.38857 3.86611 6.33293C3.97217 6.1508 4.15243 5.98497 4.39742 5.87574C4.49727 5.83123 4.64558 5.79297 4.93989 5.77193C5.24043 5.75045 5.62911 5.75 6.2 5.75H17.8C18.3709 5.75 18.7596 5.75045 19.0601 5.77193C19.3544 5.79297 19.5027 5.83123 19.6026 5.87574C19.8476 5.98497 20.0278 6.1508 20.1339 6.33293C20.1663 6.38857 20.2039 6.48364 20.226 6.72033C20.2492 6.96922 20.25 7.29583 20.25 7.8V8.625H3.75ZM8.75 10.125V18.25H17.8C18.3709 18.25 18.7596 18.2496 19.0601 18.2281C19.3544 18.207 19.5027 18.1688 19.6026 18.1243C19.8476 18.015 20.0278 17.8492 20.1339 17.6671C20.1663 17.6114 20.2039 17.5164 20.226 17.2797C20.2492 17.0308 20.25 16.7042 20.25 16.2V10.125H8.75Z"
  />
</svg>`,y=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.25 8.4C5.25 7.76487 5.76487 7.25 6.4 7.25H10.1C10.7351 7.25 11.25 7.76487 11.25 8.4V15.6C11.25 16.2351 10.7351 16.75 10.1 16.75H6.4C5.76487 16.75 5.25 16.2351 5.25 15.6V8.4ZM6.75 8.75V15.25H9.75V8.75H6.75Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12.75 8.4C12.75 7.76487 13.2649 7.25 13.9 7.25H17.6C18.2351 7.25 18.75 7.76487 18.75 8.4V13.6C18.75 14.2351 18.2351 14.75 17.6 14.75H13.9C13.2649 14.75 12.75 14.2351 12.75 13.6V8.4ZM14.25 8.75V13.25H17.25V8.75H14.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.25 7C2.25 5.48122 3.48122 4.25 5 4.25H19C20.5188 4.25 21.75 5.48122 21.75 7V17C21.75 18.5188 20.5188 19.75 19 19.75H5C3.48122 19.75 2.25 18.5188 2.25 17V7ZM5 5.75C4.30964 5.75 3.75 6.30964 3.75 7V17C3.75 17.6904 4.30964 18.25 5 18.25H19C19.6904 18.25 20.25 17.6904 20.25 17V7C20.25 6.30964 19.6904 5.75 19 5.75H5Z"
  />
</svg>`,x=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 6.28571C3.25 4.60914 4.60914 3.25 6.28571 3.25H17.7143C19.3909 3.25 20.75 4.60914 20.75 6.28571V17.7143C20.75 19.3909 19.3909 20.75 17.7143 20.75H6.28571C4.60914 20.75 3.25 19.3909 3.25 17.7143V6.28571ZM6.28571 4.75C5.43756 4.75 4.75 5.43756 4.75 6.28571V17.7143C4.75 18.5624 5.43756 19.25 6.28571 19.25H17.7143C18.5624 19.25 19.25 18.5624 19.25 17.7143V6.28571C19.25 5.43756 18.5624 4.75 17.7143 4.75H6.28571Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.5068 8.44713C16.8121 8.72703 16.8328 9.20145 16.5529 9.50679L11.0529 15.5068C10.9146 15.6576 10.7208 15.7454 10.5163 15.7498C10.3118 15.7543 10.1143 15.675 9.96967 15.5303L7.46967 13.0303C7.17678 12.7374 7.17678 12.2626 7.46967 11.9697C7.76256 11.6768 8.23744 11.6768 8.53033 11.9697L10.4764 13.9158L15.4471 8.49321C15.727 8.18787 16.2015 8.16724 16.5068 8.44713Z"
  />
</svg>`,w=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.16957 4.25H17.8304C18.3646 4.24999 18.8104 4.24998 19.1747 4.27974C19.5546 4.31078 19.9112 4.37789 20.2485 4.54973C20.7659 4.81339 21.1866 5.23408 21.4503 5.75153C21.6221 6.08879 21.6892 6.44545 21.7203 6.82533C21.75 7.18956 21.75 7.6354 21.75 8.16955V15.8305C21.75 16.3646 21.75 16.8104 21.7203 17.1747C21.6892 17.5546 21.6221 17.9112 21.4503 18.2485C21.1866 18.7659 20.7659 19.1866 20.2485 19.4503C19.9112 19.6221 19.5546 19.6892 19.1747 19.7203C18.8104 19.75 18.3646 19.75 17.8305 19.75H6.16955C5.6354 19.75 5.18956 19.75 4.82533 19.7203C4.44545 19.6892 4.08879 19.6221 3.75153 19.4503C3.23408 19.1866 2.81338 18.7659 2.54973 18.2485C2.37789 17.9112 2.31078 17.5546 2.27974 17.1747C2.24998 16.8104 2.24999 16.3646 2.25 15.8304V8.16957C2.24999 7.63541 2.24998 7.18956 2.27974 6.82533C2.31078 6.44545 2.37789 6.08879 2.54973 5.75153C2.81338 5.23408 3.23408 4.81338 3.75153 4.54973C4.08879 4.37789 4.44545 4.31078 4.82533 4.27974C5.18956 4.24998 5.63541 4.24999 6.16957 4.25ZM4.94748 5.77476C4.66036 5.79822 4.52307 5.8401 4.43251 5.88624C4.19731 6.00608 4.00608 6.19731 3.88624 6.43251C3.8401 6.52307 3.79822 6.66036 3.77476 6.94748C3.75058 7.24336 3.75 7.62757 3.75 8.2V15.8C3.75 16.3724 3.75058 16.7566 3.77476 17.0525C3.79822 17.3396 3.8401 17.4769 3.88624 17.5675C4.00608 17.8027 4.19731 17.9939 4.43251 18.1138C4.52307 18.1599 4.66036 18.2018 4.94748 18.2252C5.24336 18.2494 5.62757 18.25 6.2 18.25H17.8C18.3724 18.25 18.7566 18.2494 19.0525 18.2252C19.3396 18.2018 19.4769 18.1599 19.5675 18.1138C19.8027 17.9939 19.9939 17.8027 20.1138 17.5675C20.1599 17.4769 20.2018 17.3396 20.2252 17.0525C20.2494 16.7566 20.25 16.3724 20.25 15.8V8.2C20.25 7.62757 20.2494 7.24336 20.2252 6.94748C20.2018 6.66036 20.1599 6.52307 20.1138 6.43251C19.9939 6.19731 19.8027 6.00608 19.5675 5.88624C19.4769 5.8401 19.3396 5.79822 19.0525 5.77476C18.7566 5.75058 18.3724 5.75 17.8 5.75H6.2C5.62757 5.75 5.24336 5.75058 4.94748 5.77476Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M10.5303 8.46967C10.8232 8.76256 10.8232 9.23744 10.5303 9.53033L8.06066 12L10.5303 14.4697C10.8232 14.7626 10.8232 15.2374 10.5303 15.5303C10.2374 15.8232 9.76256 15.8232 9.46967 15.5303L6.46967 12.5303C6.17678 12.2374 6.17678 11.7626 6.46967 11.4697L9.46967 8.46967C9.76256 8.17678 10.2374 8.17678 10.5303 8.46967ZM13.4697 8.46967C13.7626 8.17678 14.2374 8.17678 14.5303 8.46967L17.5303 11.4697C17.8232 11.7626 17.8232 12.2374 17.5303 12.5303L14.5303 15.5303C14.2374 15.8232 13.7626 15.8232 13.4697 15.5303C13.1768 15.2374 13.1768 14.7626 13.4697 14.4697L15.9393 12L13.4697 9.53033C13.1768 9.23744 13.1768 8.76256 13.4697 8.46967Z"
  />
</svg>`,_=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.75 4C4.16421 4 4.5 4.33579 4.5 4.75L4.5 19.25C4.5 19.6642 4.16421 20 3.75 20C3.33579 20 3 19.6642 3 19.25L3 4.75C3 4.33579 3.33579 4 3.75 4Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M19 6.75C19 7.16421 18.6642 7.5 18.25 7.5H7.75C7.33579 7.5 7 7.16421 7 6.75C7 6.33579 7.33579 6 7.75 6H18.25C18.6642 6 19 6.33579 19 6.75Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M17 11.75C17 12.1642 16.6642 12.5 16.25 12.5H7.75C7.33579 12.5 7 12.1642 7 11.75C7 11.3358 7.33579 11 7.75 11H16.25C16.6642 11 17 11.3358 17 11.75Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M21 16.75C21 17.1642 20.6642 17.5 20.25 17.5H7.75C7.33579 17.5 7 17.1642 7 16.75C7 16.3358 7.33579 16 7.75 16H20.25C20.6642 16 21 16.3358 21 16.75Z"
  />
</svg>`,k=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 12C3.25 11.5858 3.58579 11.25 4 11.25H4.94118C5.35539 11.25 5.69118 11.5858 5.69118 12C5.69118 12.4142 5.35539 12.75 4.94118 12.75H4C3.58579 12.75 3.25 12.4142 3.25 12ZM7.01471 12C7.01471 11.5858 7.35049 11.25 7.76471 11.25H8.70588C9.1201 11.25 9.45588 11.5858 9.45588 12C9.45588 12.4142 9.1201 12.75 8.70588 12.75H7.76471C7.35049 12.75 7.01471 12.4142 7.01471 12ZM10.7794 12C10.7794 11.5858 11.1152 11.25 11.5294 11.25H12.4706C12.8848 11.25 13.2206 11.5858 13.2206 12C13.2206 12.4142 12.8848 12.75 12.4706 12.75H11.5294C11.1152 12.75 10.7794 12.4142 10.7794 12ZM14.5441 12C14.5441 11.5858 14.8799 11.25 15.2941 11.25H16.2353C16.6495 11.25 16.9853 11.5858 16.9853 12C16.9853 12.4142 16.6495 12.75 16.2353 12.75H15.2941C14.8799 12.75 14.5441 12.4142 14.5441 12ZM18.3088 12C18.3088 11.5858 18.6446 11.25 19.0588 11.25H20C20.4142 11.25 20.75 11.5858 20.75 12C20.75 12.4142 20.4142 12.75 20 12.75H19.0588C18.6446 12.75 18.3088 12.4142 18.3088 12Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4 4.25C4.41421 4.25 4.75 4.58579 4.75 5V6.59459C4.75 7.1261 5.1896 7.57432 5.75343 7.57432H18.2466C18.8104 7.57432 19.25 7.1261 19.25 6.59459V5C19.25 4.58579 19.5858 4.25 20 4.25C20.4142 4.25 20.75 4.58579 20.75 5V6.59459C20.75 7.9737 19.6195 9.07432 18.2466 9.07432H5.75343C4.38048 9.07432 3.25 7.9737 3.25 6.59459V5C3.25 4.58579 3.58579 4.25 4 4.25ZM5.75342 16.4257C5.1896 16.4257 4.75 16.8739 4.75 17.4054V19C4.75 19.4142 4.41421 19.75 4 19.75C3.58579 19.75 3.25 19.4142 3.25 19V17.4054C3.25 16.0263 4.38047 14.9257 5.75342 14.9257L18.2466 14.9257C19.6195 14.9257 20.75 16.0263 20.75 17.4054V19C20.75 19.4142 20.4142 19.75 20 19.75C19.5858 19.75 19.25 19.4142 19.25 19V17.4054C19.25 16.8739 18.8104 16.4257 18.2466 16.4257L5.75342 16.4257Z"
  />
</svg>`,M=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.25 4C6.25 3.58579 6.58579 3.25 7 3.25H12.9583C15.6288 3.25 17.8333 5.35506 17.8333 8C17.8333 9.51519 17.1099 10.8532 15.9898 11.7198C17.6162 12.484 18.75 14.1032 18.75 16C18.75 18.6449 16.5455 20.75 13.875 20.75H7C6.58579 20.75 6.25 20.4142 6.25 20V4ZM7.75 12.75V19.25H13.875C15.7609 19.25 17.25 17.7733 17.25 16C17.25 14.2267 15.7609 12.75 13.875 12.75H7.75ZM7.75 11.25H12.9583C14.8442 11.25 16.3333 9.77334 16.3333 8C16.3333 6.22666 14.8442 4.75 12.9583 4.75H7.75V11.25Z"
  />
</svg>`,S=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M14.6075 3.25H10.25C9.83579 3.25 9.5 3.58579 9.5 4C9.5 4.41421 9.83579 4.75 10.25 4.75H13.5896L8.83175 19.25H5C4.58579 19.25 4.25 19.5858 4.25 20C4.25 20.4142 4.58579 20.75 5 20.75H9.35778C9.36938 20.7503 9.38095 20.7503 9.39249 20.75H13.75C14.1642 20.75 14.5 20.4142 14.5 20C14.5 19.5858 14.1642 19.25 13.75 19.25H10.4104L15.1682 4.75H19C19.4142 4.75 19.75 4.41421 19.75 4C19.75 3.58579 19.4142 3.25 19 3.25H14.6422C14.6306 3.24973 14.619 3.24973 14.6075 3.25Z"
  />
</svg>`,E=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4.25 4C4.25 3.58579 4.58579 3.25 5 3.25H8.5C8.91421 3.25 9.25 3.58579 9.25 4C9.25 4.41421 8.91421 4.75 8.5 4.75H7.48717C7.49559 4.79501 7.5 4.84143 7.5 4.88889V11.1111C7.5 13.6536 9.52581 15.6944 12 15.6944C14.4742 15.6944 16.5 13.6536 16.5 11.1111V4.88889C16.5 4.84143 16.5044 4.79501 16.5128 4.75H15.5C15.0858 4.75 14.75 4.41421 14.75 4C14.75 3.58579 15.0858 3.25 15.5 3.25H19C19.4142 3.25 19.75 3.58579 19.75 4C19.75 4.41421 19.4142 4.75 19 4.75H17.9872C17.9956 4.79501 18 4.84143 18 4.88889V11.1111C18 14.4597 15.3248 17.1944 12 17.1944C8.6752 17.1944 6 14.4597 6 11.1111V4.88889C6 4.84143 6.00441 4.79501 6.01283 4.75H5C4.58579 4.75 4.25 4.41421 4.25 4ZM4.25 20C4.25 19.5858 4.58579 19.25 5 19.25H19C19.4142 19.25 19.75 19.5858 19.75 20C19.75 20.4142 19.4142 20.75 19 20.75H5C4.58579 20.75 4.25 20.4142 4.25 20Z"
  />
</svg>`,L=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.02778 8C5.02778 5.37665 7.15442 3.25 9.77778 3.25H14.3889C16.9202 3.25 18.9722 5.30203 18.9722 7.83333V8C18.9722 8.41421 18.6364 8.75 18.2222 8.75C17.808 8.75 17.4722 8.41421 17.4722 8V7.83333C17.4722 6.13046 16.0918 4.75 14.3889 4.75H9.77778C7.98285 4.75 6.52778 6.20507 6.52778 8C6.52778 9.79493 7.98285 11.25 9.77778 11.25H20C20.4142 11.25 20.75 11.5858 20.75 12C20.75 12.4142 20.4142 12.75 20 12.75H17.6863C18.4838 13.5997 18.9722 14.7428 18.9722 16C18.9722 18.6234 16.8456 20.75 14.2222 20.75H9.69444C7.11712 20.75 5.02778 18.6607 5.02778 16.0833V16C5.02778 15.5858 5.36356 15.25 5.77778 15.25C6.19199 15.25 6.52778 15.5858 6.52778 16V16.0833C6.52778 17.8322 7.94554 19.25 9.69444 19.25H14.2222C16.0171 19.25 17.4722 17.7949 17.4722 16C17.4722 14.2051 16.0171 12.75 14.2222 12.75H4C3.58579 12.75 3.25 12.4142 3.25 12C3.25 11.5858 3.58579 11.25 4 11.25H6.31366C5.5162 10.4003 5.02778 9.25721 5.02778 8Z"
  />
</svg>`,$=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M14.1819 3.27239C14.5837 3.37285 14.8281 3.78006 14.7276 4.1819L10.7276 20.1819C10.6271 20.5837 10.2199 20.8281 9.8181 20.7276C9.41625 20.6271 9.17193 20.2199 9.27239 19.8181L13.2724 3.8181C13.3729 3.41625 13.7801 3.17193 14.1819 3.27239ZM7.5511 7.49129C7.83206 7.79566 7.81308 8.27015 7.50871 8.5511L4.06145 11.7332L7.5496 15.4897C7.83145 15.7932 7.81387 16.2677 7.51034 16.5496C7.20681 16.8314 6.73226 16.8139 6.45041 16.5103L2.45041 12.2026C2.31479 12.0566 2.24289 11.8626 2.25056 11.6634C2.25823 11.4643 2.34485 11.2764 2.49129 11.1412L6.49129 7.4489C6.79566 7.16794 7.27015 7.18692 7.5511 7.49129ZM16.4489 7.49129C16.7299 7.18692 17.2043 7.16794 17.5087 7.4489L21.5087 11.1412C21.6552 11.2764 21.7418 11.4643 21.7494 11.6634C21.7571 11.8626 21.6852 12.0566 21.5496 12.2026L17.5496 16.5103C17.2677 16.8139 16.7932 16.8314 16.4897 16.5496C16.1861 16.2677 16.1686 15.7932 16.4504 15.4897L19.9386 11.7332L16.4913 8.5511C16.1869 8.27015 16.1679 7.79566 16.4489 7.49129Z"
  />
</svg>`,P=n.YP`<path
  fill-rule="evenodd"
  clip-rule="evenodd"
  d="M12.8423 4.60675C14.6513 2.79775 17.5842 2.79775 19.3932 4.60676C21.2023 6.41576 21.2023 9.34874 19.3932 11.1577L17.3344 13.2166C17.0415 13.5095 16.5666 13.5095 16.2737 13.2166C15.9808 12.9237 15.9808 12.4489 16.2737 12.156L18.3326 10.0971C19.5558 8.87387 19.5558 6.89064 18.3326 5.66742C17.1094 4.4442 15.1261 4.44419 13.9029 5.66741L11.1577 8.41258C9.93453 9.6358 9.93453 11.619 11.1577 12.8423C11.3498 13.0343 11.5596 13.1955 11.7816 13.3266C12.1382 13.5373 12.2566 13.9971 12.046 14.3538C11.8353 14.7104 11.3754 14.8288 11.0188 14.6182C10.6891 14.4235 10.379 14.1849 10.0971 13.9029C8.28808 12.0939 8.28808 9.16093 10.0971 7.35192L12.8423 4.60675ZM11.954 9.64621C12.1647 9.28955 12.6246 9.17119 12.9812 9.38183C13.3109 9.57652 13.621 9.81515 13.9029 10.0971C15.7119 11.9061 15.7119 14.8391 13.9029 16.6481L11.1577 19.3932C9.34874 21.2023 6.41576 21.2023 4.60675 19.3932C2.79775 17.5842 2.79775 14.6513 4.60675 12.8423L6.66563 10.7834C6.95852 10.4905 7.4334 10.4905 7.72629 10.7834C8.01918 11.0763 8.01918 11.5511 7.72629 11.844L5.66741 13.9029C4.4442 15.1261 4.4442 17.1094 5.66742 18.3326C6.89064 19.5558 8.87387 19.5558 10.0971 18.3326L12.8423 15.5874C14.0655 14.3642 14.0655 12.381 12.8423 11.1577C12.6502 10.9657 12.4404 10.8045 12.2184 10.6734C11.8618 10.4627 11.7434 10.0029 11.954 9.64621Z"
/>`,B=r(P,20),R=o(P),T=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11.1696 3.25H16.8304C17.3646 3.24999 17.8104 3.24998 18.1747 3.27974C18.5546 3.31078 18.9112 3.37789 19.2485 3.54973C19.7659 3.81338 20.1866 4.23408 20.4503 4.75153C20.6221 5.08879 20.6892 5.44545 20.7203 5.82533C20.75 6.18956 20.75 6.6354 20.75 7.16955V12.8305C20.75 13.3646 20.75 13.8104 20.7203 14.1747C20.6892 14.5546 20.6221 14.9112 20.4503 15.2485C20.1866 15.7659 19.7659 16.1866 19.2485 16.4503C18.9112 16.6221 18.5546 16.6892 18.1747 16.7203C17.8104 16.75 17.3646 16.75 16.8305 16.75H16.75V16.8305C16.75 17.3646 16.75 17.8104 16.7203 18.1747C16.6892 18.5546 16.6221 18.9112 16.4503 19.2485C16.1866 19.7659 15.7659 20.1866 15.2485 20.4503C14.9112 20.6221 14.5546 20.6892 14.1747 20.7203C13.8104 20.75 13.3646 20.75 12.8305 20.75H7.16955C6.6354 20.75 6.18956 20.75 5.82533 20.7203C5.44545 20.6892 5.08879 20.6221 4.75153 20.4503C4.23408 20.1866 3.81338 19.7659 3.54973 19.2485C3.37789 18.9112 3.31078 18.5546 3.27974 18.1747C3.24998 17.8104 3.24999 17.3646 3.25 16.8304V11.1696C3.24999 10.6354 3.24998 10.1896 3.27974 9.82533C3.31078 9.44545 3.37789 9.08879 3.54973 8.75153C3.81338 8.23408 4.23408 7.81339 4.75153 7.54973C5.08879 7.37789 5.44545 7.31078 5.82533 7.27974C6.18957 7.24998 6.63542 7.24999 7.16957 7.25L7.25 7.25L7.25 7.16957C7.24999 6.63542 7.24998 6.18957 7.27974 5.82533C7.31078 5.44545 7.37789 5.08879 7.54973 4.75153C7.81339 4.23408 8.23408 3.81338 8.75153 3.54973C9.08879 3.37789 9.44545 3.31078 9.82533 3.27974C10.1896 3.24998 10.6354 3.24999 11.1696 3.25ZM7.25 8.75H7.2C6.62757 8.75 6.24336 8.75058 5.94748 8.77476C5.66036 8.79822 5.52307 8.8401 5.43251 8.88624C5.19731 9.00608 5.00608 9.19731 4.88624 9.43251C4.8401 9.52307 4.79822 9.66036 4.77476 9.94748C4.75058 10.2434 4.75 10.6276 4.75 11.2V16.8C4.75 17.3724 4.75058 17.7566 4.77476 18.0525C4.79822 18.3396 4.8401 18.4769 4.88624 18.5675C5.00608 18.8027 5.19731 18.9939 5.43251 19.1138C5.52307 19.1599 5.66036 19.2018 5.94748 19.2252C6.24336 19.2494 6.62757 19.25 7.2 19.25H12.8C13.3724 19.25 13.7566 19.2494 14.0525 19.2252C14.3396 19.2018 14.4769 19.1599 14.5675 19.1138C14.8027 18.9939 14.9939 18.8027 15.1138 18.5675C15.1599 18.4769 15.2018 18.3396 15.2252 18.0525C15.2494 17.7566 15.25 17.3724 15.25 16.8V16.75H11.1695C10.6354 16.75 10.1896 16.75 9.82533 16.7203C9.44545 16.6892 9.08879 16.6221 8.75153 16.4503C8.23408 16.1866 7.81339 15.7659 7.54973 15.2485C7.37789 14.9112 7.31078 14.5546 7.27974 14.1747C7.24998 13.8104 7.24999 13.3646 7.25 12.8304L7.25 8.75ZM11.2 15.25C10.6276 15.25 10.2434 15.2494 9.94748 15.2252C9.66036 15.2018 9.52307 15.1599 9.43251 15.1138C9.19731 14.9939 9.00608 14.8027 8.88624 14.5675C8.8401 14.4769 8.79822 14.3396 8.77476 14.0525C8.75058 13.7566 8.75 13.3724 8.75 12.8V7.2C8.75 6.62757 8.75058 6.24336 8.77476 5.94748C8.79822 5.66036 8.8401 5.52307 8.88624 5.43251C9.00608 5.19731 9.19731 5.00608 9.43251 4.88624C9.52307 4.8401 9.66036 4.79822 9.94748 4.77476C10.2434 4.75058 10.6276 4.75 11.2 4.75H16.8C17.3724 4.75 17.7566 4.75058 18.0525 4.77476C18.3396 4.79822 18.4769 4.8401 18.5675 4.88624C18.8027 5.00608 18.9939 5.19731 19.1138 5.43251C19.1599 5.52307 19.2018 5.66036 19.2252 5.94748C19.2494 6.24336 19.25 6.62757 19.25 7.2V12.8C19.25 13.3724 19.2494 13.7566 19.2252 14.0525C19.2018 14.3396 19.1599 14.4769 19.1138 14.5675C18.9939 14.8027 18.8027 14.9939 18.5675 15.1138C18.4769 15.1599 18.3396 15.2018 18.0525 15.2252C17.7566 15.2494 17.3724 15.25 16.8 15.25H11.2Z"
  />
</svg>`;n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.96967 2.96967C8.43047 2.50887 9.05544 2.25 9.70711 2.25H14.2929C14.9446 2.25 15.5695 2.50887 16.0303 2.96967C16.3835 3.32285 16.6181 3.77248 16.7084 4.25665C16.9029 4.26164 17.0816 4.27042 17.245 4.28594C17.5984 4.31952 17.9317 4.38831 18.2485 4.54973C18.7659 4.81338 19.1866 5.23408 19.4503 5.75153C19.6221 6.08879 19.6892 6.44545 19.7203 6.82533C19.75 7.18956 19.75 7.6354 19.75 8.16955V17.8305C19.75 18.3646 19.75 18.8104 19.7203 19.1747C19.6892 19.5546 19.6221 19.9112 19.4503 20.2485C19.1866 20.7659 18.7659 21.1866 18.2485 21.4503C17.9112 21.6221 17.5546 21.6892 17.1747 21.7203C16.8104 21.75 16.3646 21.75 15.8305 21.75H8.16955C7.6354 21.75 7.18956 21.75 6.82533 21.7203C6.44545 21.6892 6.08879 21.6221 5.75153 21.4503C5.23408 21.1866 4.81339 20.7659 4.54973 20.2485C4.37789 19.9112 4.31078 19.5546 4.27974 19.1747C4.24998 18.8104 4.24999 18.3646 4.25 17.8304V8.16957C4.24999 7.63541 4.24998 7.18956 4.27974 6.82533C4.31078 6.44545 4.37789 6.08879 4.54973 5.75153C4.81338 5.23408 5.23408 4.81338 5.75153 4.54973C6.06834 4.38831 6.40164 4.31952 6.75503 4.28594C6.91838 4.27042 7.09706 4.26164 7.29163 4.25665C7.38193 3.77248 7.61649 3.32285 7.96967 2.96967ZM7.25 5.75845C7.11656 5.76281 7.00058 5.76937 6.8969 5.77922C6.64378 5.80327 6.51726 5.84306 6.43251 5.88624C6.19731 6.00608 6.00608 6.19731 5.88624 6.43251C5.8401 6.52307 5.79822 6.66035 5.77476 6.94748C5.75058 7.24336 5.75 7.62757 5.75 8.2V17.8C5.75 18.3724 5.75058 18.7566 5.77476 19.0525C5.79822 19.3396 5.8401 19.4769 5.88624 19.5675C6.00608 19.8027 6.19731 19.9939 6.43251 20.1138C6.52307 20.1599 6.66036 20.2018 6.94748 20.2252C7.24336 20.2494 7.62757 20.25 8.2 20.25H15.8C16.3724 20.25 16.7566 20.2494 17.0525 20.2252C17.3396 20.2018 17.4769 20.1599 17.5675 20.1138C17.8027 19.9939 17.9939 19.8027 18.1138 19.5675C18.1599 19.4769 18.2018 19.3396 18.2252 19.0525C18.2494 18.7566 18.25 18.3724 18.25 17.8V8.2C18.25 7.62757 18.2494 7.24336 18.2252 6.94748C18.2018 6.66035 18.1599 6.52307 18.1138 6.43251C17.9939 6.19731 17.8027 6.00608 17.5675 5.88624C17.4827 5.84306 17.3562 5.80327 17.1031 5.77922C16.9994 5.76937 16.8834 5.76281 16.75 5.75845V7C16.75 7.41421 16.4142 7.75 16 7.75H8C7.58579 7.75 7.25 7.41421 7.25 7V5.75845ZM9.70711 3.75C9.45327 3.75 9.20982 3.85084 9.03033 4.03033C8.85084 4.20982 8.75 4.45327 8.75 4.70711V6.25H15.25V4.70711C15.25 4.45327 15.1492 4.20982 14.9697 4.03033C14.7902 3.85084 14.5467 3.75 14.2929 3.75H9.70711Z"
  />
</svg>`;let O=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M11.25 9C11.25 9.41421 11.5858 9.75 12 9.75H13.1893L7.46967 15.4697C7.17678 15.7626 7.17678 16.2374 7.46967 16.5303C7.76256 16.8232 8.23744 16.8232 8.53033 16.5303L14.25 10.8107V12C14.25 12.4142 14.5858 12.75 15 12.75C15.4142 12.75 15.75 12.4142 15.75 12V9.1C15.75 9.08264 15.7495 9.0654 15.7485 9.04829C15.7618 8.84059 15.6891 8.62841 15.5303 8.46967C15.3716 8.31093 15.1594 8.23823 14.9517 8.25155C14.9346 8.25052 14.9174 8.25 14.9 8.25H12C11.5858 8.25 11.25 8.58579 11.25 9Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.8304 3.25H11.1696C10.6354 3.24999 10.1896 3.24998 9.82533 3.27974C9.44545 3.31078 9.08879 3.37789 8.75153 3.54973C8.23408 3.81338 7.81339 4.23408 7.54973 4.75153C7.37789 5.08879 7.31078 5.44545 7.27974 5.82533C7.24998 6.18956 7.24999 6.63541 7.25 7.16956L7.25 7.25L7.16957 7.25C6.63542 7.24999 6.18956 7.24998 5.82533 7.27974C5.44545 7.31078 5.08879 7.37789 4.75153 7.54973C4.23408 7.81339 3.81338 8.23408 3.54973 8.75153C3.37789 9.08879 3.31078 9.44545 3.27974 9.82533C3.24998 10.1896 3.24999 10.6354 3.25 11.1696V16.8304C3.24999 17.3646 3.24998 17.8104 3.27974 18.1747C3.31078 18.5546 3.37789 18.9112 3.54973 19.2485C3.81338 19.7659 4.23408 20.1866 4.75153 20.4503C5.08879 20.6221 5.44545 20.6892 5.82533 20.7203C6.18956 20.75 6.6354 20.75 7.16955 20.75H12.8305C13.3646 20.75 13.8104 20.75 14.1747 20.7203C14.5546 20.6892 14.9112 20.6221 15.2485 20.4503C15.7659 20.1866 16.1866 19.7659 16.4503 19.2485C16.6221 18.9112 16.6892 18.5546 16.7203 18.1747C16.75 17.8105 16.75 17.3646 16.75 16.8305V16.75H16.8305C17.3646 16.75 17.8105 16.75 18.1747 16.7203C18.5546 16.6892 18.9112 16.6221 19.2485 16.4503C19.7659 16.1866 20.1866 15.7659 20.4503 15.2485C20.6221 14.9112 20.6892 14.5546 20.7203 14.1747C20.75 13.8104 20.75 13.3646 20.75 12.8305V7.16955C20.75 6.6354 20.75 6.18956 20.7203 5.82533C20.6892 5.44545 20.6221 5.08879 20.4503 4.75153C20.1866 4.23408 19.7659 3.81338 19.2485 3.54973C18.9112 3.37789 18.5546 3.31078 18.1747 3.27974C17.8104 3.24998 17.3646 3.24999 16.8304 3.25ZM7.25 11V8.75H7.2C6.62757 8.75 6.24336 8.75058 5.94748 8.77476C5.66036 8.79822 5.52307 8.8401 5.43251 8.88624C5.19731 9.00608 5.00608 9.19731 4.88624 9.43251C4.8401 9.52307 4.79822 9.66036 4.77476 9.94748C4.75058 10.2434 4.75 10.6276 4.75 11.2V16.8C4.75 17.3724 4.75058 17.7566 4.77476 18.0525C4.79822 18.3396 4.8401 18.4769 4.88624 18.5675C5.00608 18.8027 5.19731 18.9939 5.43251 19.1138C5.52307 19.1599 5.66036 19.2018 5.94748 19.2252C6.24336 19.2494 6.62757 19.25 7.2 19.25H12.8C13.3724 19.25 13.7566 19.2494 14.0525 19.2252C14.3396 19.2018 14.4769 19.1599 14.5675 19.1138C14.8027 18.9939 14.9939 18.8027 15.1138 18.5675C15.1599 18.4769 15.2018 18.3396 15.2252 18.0525C15.2494 17.7566 15.25 17.3724 15.25 16.8V16.75H13C12.5858 16.75 12.25 16.4142 12.25 16C12.25 15.5858 12.5858 15.25 13 15.25H16.8C17.3724 15.25 17.7566 15.2494 18.0525 15.2252C18.3396 15.2018 18.4769 15.1599 18.5675 15.1138C18.8027 14.9939 18.9939 14.8027 19.1138 14.5675C19.1599 14.4769 19.2018 14.3396 19.2252 14.0525C19.2494 13.7566 19.25 13.3724 19.25 12.8V7.2C19.25 6.62757 19.2494 6.24336 19.2252 5.94748C19.2018 5.66036 19.1599 5.52307 19.1138 5.43251C18.9939 5.19731 18.8027 5.00608 18.5675 4.88624C18.4769 4.8401 18.3396 4.79822 18.0525 4.77476C17.7566 4.75058 17.3724 4.75 16.8 4.75H11.2C10.6276 4.75 10.2434 4.75058 9.94748 4.77476C9.66036 4.79822 9.52307 4.8401 9.43251 4.88624C9.19731 5.00608 9.00608 5.19731 8.88624 5.43251C8.8401 5.52307 8.79822 5.66036 8.77476 5.94748C8.75058 6.24336 8.75 6.62757 8.75 7.2V11C8.75 11.4142 8.41422 11.75 8 11.75C7.58579 11.75 7.25 11.4142 7.25 11Z"
  />
</svg>`,I=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11.1799 2.24992C11.2215 2.24996 11.2637 2.25 11.3064 2.25H12.6936C12.7363 2.25 12.7785 2.24996 12.8201 2.24992C13.5245 2.24927 14.0767 2.24875 14.565 2.44082C14.9934 2.60932 15.3727 2.88268 15.668 3.23585C16.0047 3.6384 16.1788 4.1624 16.4009 4.83082C16.4141 4.87034 16.4274 4.91036 16.4409 4.9509L16.5406 5.25H20C20.4142 5.25 20.75 5.58579 20.75 6C20.75 6.41421 20.4142 6.75 20 6.75H18.75V16.2321C18.75 17.045 18.75 17.7006 18.7066 18.2315C18.662 18.7781 18.5676 19.2582 18.3413 19.7025C17.9817 20.4081 17.4081 20.9818 16.7025 21.3413C16.2582 21.5676 15.7781 21.662 15.2315 21.7066C14.7006 21.75 14.045 21.75 13.2321 21.75H10.7679C9.95505 21.75 9.29944 21.75 8.76853 21.7066C8.2219 21.662 7.74175 21.5676 7.29754 21.3413C6.59193 20.9818 6.01825 20.4081 5.65873 19.7025C5.43238 19.2582 5.33803 18.7781 5.29336 18.2315C5.24999 17.7006 5.24999 17.0449 5.25 16.2321L5.25 6.75H4C3.58579 6.75 3.25 6.41421 3.25 6C3.25 5.58579 3.58579 5.25 4 5.25H7.45943L7.55913 4.9509C7.57264 4.91036 7.58594 4.87034 7.59908 4.83081C7.82119 4.1624 7.99532 3.6384 8.33195 3.23585C8.62729 2.88269 9.00657 2.60932 9.435 2.44082C9.92335 2.24875 10.4755 2.24927 11.1799 2.24992ZM7.9827 6.75C7.99433 6.75027 8.00594 6.75027 8.01751 6.75H15.9825C15.9941 6.75027 16.0057 6.75027 16.0173 6.75H17.25V16.2C17.25 17.0525 17.2494 17.6467 17.2116 18.1093C17.1745 18.5632 17.1054 18.824 17.0048 19.0215C16.7891 19.4448 16.4448 19.789 16.0215 20.0048C15.824 20.1054 15.5632 20.1745 15.1093 20.2116C14.6467 20.2494 14.0525 20.25 13.2 20.25H10.8C9.94755 20.25 9.35331 20.2494 8.89068 20.2116C8.4368 20.1745 8.17604 20.1054 7.97852 20.0048C7.55516 19.789 7.21095 19.4448 6.99524 19.0215C6.8946 18.824 6.82546 18.5632 6.78838 18.1093C6.75058 17.6467 6.75 17.0525 6.75 16.2V6.75H7.9827ZM14.9592 5.25H9.0408C9.27769 4.54546 9.36214 4.34218 9.48262 4.19811C9.61687 4.03758 9.78927 3.91333 9.98401 3.83674C10.1725 3.76261 10.4131 3.75 11.3064 3.75H12.6936C13.5869 3.75 13.8275 3.76261 14.016 3.83674C14.2107 3.91333 14.3831 4.03759 14.5174 4.19811C14.6379 4.34218 14.7223 4.54546 14.9592 5.25ZM10 9.25C10.4142 9.25 10.75 9.58579 10.75 10V17C10.75 17.4142 10.4142 17.75 10 17.75C9.58579 17.75 9.25 17.4142 9.25 17V10C9.25 9.58579 9.58579 9.25 10 9.25ZM14 9.25C14.4142 9.25 14.75 9.58579 14.75 10V17C14.75 17.4142 14.4142 17.75 14 17.75C13.5858 17.75 13.25 17.4142 13.25 17V10C13.25 9.58579 13.5858 9.25 14 9.25Z"
  />
</svg>`,D=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M8.5 13.75C8.5 13.3358 8.16421 13 7.75 13C7.33579 13 7 13.3358 7 13.75L7 15.25C7 15.6642 7.33579 16 7.75 16C8.16421 16 8.5 15.6642 8.5 15.25V13.75Z"
  />
  <path
    d="M12 11C12.4142 11 12.75 11.3358 12.75 11.75V17.25C12.75 17.6642 12.4142 18 12 18C11.5858 18 11.25 17.6642 11.25 17.25V11.75C11.25 11.3358 11.5858 11 12 11Z"
  />
  <path
    d="M15.5 15.25C15.5 15.6642 15.8358 16 16.25 16C16.6642 16 17 15.6642 17 15.25V13.75C17 13.3358 16.6642 13 16.25 13C15.8358 13 15.5 13.3358 15.5 13.75V15.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.30556 4C8.30556 3.58579 7.96977 3.25 7.55556 3.25C7.14134 3.25 6.80556 3.58579 6.80556 4V5.02778C6.33711 5.02777 5.94085 5.02793 5.61573 5.05449C5.2729 5.0825 4.94369 5.14356 4.63019 5.30329C4.15456 5.54564 3.76786 5.93234 3.52551 6.40797C3.36578 6.72146 3.30472 7.05068 3.27671 7.39351C3.24998 7.72071 3.24999 8.11996 3.25 8.59235V17.1854C3.24999 17.6578 3.24998 18.0571 3.27671 18.3843C3.30472 18.7271 3.36578 19.0563 3.52551 19.3698C3.76786 19.8454 4.15456 20.2321 4.63019 20.4745C4.94369 20.6342 5.2729 20.6953 5.61573 20.7233C5.94291 20.75 6.34214 20.75 6.81449 20.75H17.1854C17.6578 20.75 18.0571 20.75 18.3843 20.7233C18.7271 20.6953 19.0563 20.6342 19.3698 20.4745C19.8454 20.2321 20.2321 19.8454 20.4745 19.3698C20.6342 19.0563 20.6953 18.7271 20.7233 18.3843C20.75 18.0571 20.75 17.6579 20.75 17.1855V8.59236C20.75 8.12001 20.75 7.72069 20.7233 7.39351C20.6953 7.05068 20.6342 6.72146 20.4745 6.40797C20.2321 5.93234 19.8454 5.54564 19.3698 5.30329C19.0563 5.14356 18.7271 5.0825 18.3843 5.05449C18.0592 5.02793 17.6629 5.02777 17.1944 5.02778V4C17.1944 3.58579 16.8587 3.25 16.4444 3.25C16.0302 3.25 15.6944 3.58579 15.6944 4V5.02778H8.30556V4ZM5.73788 6.54951C5.9967 6.52836 6.33425 6.52778 6.84445 6.52778H17.1556C17.6658 6.52778 18.0033 6.52836 18.2621 6.54951C18.5122 6.56994 18.622 6.60577 18.6888 6.6398C18.8822 6.73833 19.0394 6.89556 19.138 7.08895C19.172 7.15575 19.2078 7.26559 19.2283 7.51566C19.2489 7.76785 19.25 8.09477 19.25 8.58333H4.75C4.75004 8.09477 4.75113 7.76785 4.77173 7.51566C4.79216 7.26559 4.82799 7.15575 4.86202 7.08895C4.96056 6.89557 5.11779 6.73834 5.31118 6.6398C5.37797 6.60577 5.48781 6.56994 5.73788 6.54951ZM4.75 10.0833H19.25V17.1556C19.25 17.6658 19.2494 18.0033 19.2283 18.2621C19.2078 18.5122 19.172 18.622 19.138 18.6888C19.0394 18.8822 18.8822 19.0394 18.6888 19.138C18.622 19.172 18.5122 19.2078 18.2621 19.2283C18.0033 19.2494 17.6658 19.25 17.1556 19.25H6.84445C6.33425 19.25 5.9967 19.2494 5.73788 19.2283C5.48781 19.2078 5.37797 19.172 5.31118 19.138C5.11779 19.0394 4.96056 18.8822 4.86202 18.6888C4.82799 18.622 4.79216 18.5122 4.77173 18.2621C4.75058 18.0033 4.75 17.6658 4.75 17.1556V10.0833Z"
  />
</svg>`,z=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M8.5 13.75C8.5 13.3358 8.16421 13 7.75 13C7.33579 13 7 13.3358 7 13.75L7 15.25C7 15.6642 7.33579 16 7.75 16C8.16421 16 8.5 15.6642 8.5 15.25V13.75Z"
  />
  <path
    d="M12 13C12.4142 13 12.75 13.3358 12.75 13.75V15.25C12.75 15.6642 12.4142 16 12 16C11.5858 16 11.25 15.6642 11.25 15.25V13.75C11.25 13.3358 11.5858 13 12 13Z"
  />
  <path
    d="M15.5 17.25C15.5 17.6642 15.8358 18 16.25 18C16.6642 18 17 17.6642 17 17.25V11.75C17 11.3358 16.6642 11 16.25 11C15.8358 11 15.5 11.3358 15.5 11.75V17.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.30556 4C8.30556 3.58579 7.96977 3.25 7.55556 3.25C7.14134 3.25 6.80556 3.58579 6.80556 4V5.02778C6.33711 5.02777 5.94085 5.02793 5.61573 5.05449C5.2729 5.0825 4.94369 5.14356 4.63019 5.30329C4.15456 5.54564 3.76786 5.93234 3.52551 6.40797C3.36578 6.72146 3.30472 7.05068 3.27671 7.39351C3.24998 7.72071 3.24999 8.11996 3.25 8.59235V17.1854C3.24999 17.6578 3.24998 18.0571 3.27671 18.3843C3.30472 18.7271 3.36578 19.0563 3.52551 19.3698C3.76786 19.8454 4.15456 20.2321 4.63019 20.4745C4.94369 20.6342 5.2729 20.6953 5.61573 20.7233C5.94291 20.75 6.34214 20.75 6.81449 20.75H17.1854C17.6578 20.75 18.0571 20.75 18.3843 20.7233C18.7271 20.6953 19.0563 20.6342 19.3698 20.4745C19.8454 20.2321 20.2321 19.8454 20.4745 19.3698C20.6342 19.0563 20.6953 18.7271 20.7233 18.3843C20.75 18.0571 20.75 17.6579 20.75 17.1855V8.59236C20.75 8.12001 20.75 7.72069 20.7233 7.39351C20.6953 7.05068 20.6342 6.72146 20.4745 6.40797C20.2321 5.93234 19.8454 5.54564 19.3698 5.30329C19.0563 5.14356 18.7271 5.0825 18.3843 5.05449C18.0592 5.02793 17.6629 5.02777 17.1944 5.02778V4C17.1944 3.58579 16.8587 3.25 16.4444 3.25C16.0302 3.25 15.6944 3.58579 15.6944 4V5.02778H8.30556V4ZM5.73788 6.54951C5.9967 6.52836 6.33425 6.52778 6.84445 6.52778H17.1556C17.6658 6.52778 18.0033 6.52836 18.2621 6.54951C18.5122 6.56994 18.622 6.60577 18.6888 6.6398C18.8822 6.73833 19.0394 6.89556 19.138 7.08895C19.172 7.15575 19.2078 7.26559 19.2283 7.51566C19.2489 7.76785 19.25 8.09477 19.25 8.58333H4.75C4.75004 8.09477 4.75113 7.76785 4.77173 7.51566C4.79216 7.26559 4.82799 7.15575 4.86202 7.08895C4.96056 6.89557 5.11779 6.73834 5.31118 6.6398C5.37797 6.60577 5.48781 6.56994 5.73788 6.54951ZM4.75 10.0833H19.25V17.1556C19.25 17.6658 19.2494 18.0033 19.2283 18.2621C19.2078 18.5122 19.172 18.622 19.138 18.6888C19.0394 18.8822 18.8822 19.0394 18.6888 19.138C18.622 19.172 18.5122 19.2078 18.2621 19.2283C18.0033 19.2494 17.6658 19.25 17.1556 19.25H6.84445C6.33425 19.25 5.9967 19.2494 5.73788 19.2283C5.48781 19.2078 5.37797 19.172 5.31118 19.138C5.11779 19.0394 4.96056 18.8822 4.86202 18.6888C4.82799 18.622 4.79216 18.5122 4.77173 18.2621C4.75058 18.0033 4.75 17.6658 4.75 17.1556V10.0833Z"
  />
</svg>`,A=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.55556 3.25C7.96977 3.25 8.30556 3.58579 8.30556 4V5.02778H15.6944V4C15.6944 3.58579 16.0302 3.25 16.4444 3.25C16.8587 3.25 17.1944 3.58579 17.1944 4V5.02778C17.6629 5.02777 18.0592 5.02793 18.3843 5.05449C18.7271 5.0825 19.0563 5.14356 19.3698 5.30329C19.8454 5.54564 20.2321 5.93234 20.4745 6.40797C20.6342 6.72146 20.6953 7.05068 20.7233 7.39351C20.75 7.72071 20.75 8.11997 20.75 8.59236V17.1854C20.75 17.6578 20.75 18.0571 20.7233 18.3843C20.6953 18.7271 20.6342 19.0563 20.4745 19.3698C20.2321 19.8454 19.8454 20.2321 19.3698 20.4745C19.0563 20.6342 18.7271 20.6953 18.3843 20.7233C18.0571 20.75 17.6578 20.75 17.1854 20.75H6.81458C6.34219 20.75 5.94293 20.75 5.61573 20.7233C5.2729 20.6953 4.94369 20.6342 4.63019 20.4745C4.15456 20.2321 3.76786 19.8454 3.52551 19.3698C3.36578 19.0563 3.30472 18.7271 3.27671 18.3843C3.24998 18.0571 3.24999 17.6578 3.25 17.1854V8.59238C3.24999 8.11998 3.24998 7.72071 3.27671 7.39351C3.30472 7.05068 3.36578 6.72146 3.52551 6.40797C3.76786 5.93234 4.15456 5.54564 4.63019 5.30329C4.94369 5.14356 5.2729 5.0825 5.61573 5.05449C5.94085 5.02793 6.33711 5.02777 6.80556 5.02778V4C6.80556 3.58579 7.14134 3.25 7.55556 3.25ZM6.84445 6.52778C6.33425 6.52778 5.9967 6.52836 5.73788 6.54951C5.48781 6.56994 5.37797 6.60577 5.31118 6.6398C5.11779 6.73834 4.96056 6.89557 4.86202 7.08895C4.82799 7.15575 4.79216 7.26559 4.77173 7.51566C4.75113 7.76785 4.75004 8.09477 4.75 8.58333H19.25C19.25 8.09477 19.2489 7.76785 19.2283 7.51566C19.2078 7.26559 19.172 7.15575 19.138 7.08895C19.0394 6.89556 18.8822 6.73833 18.6888 6.6398C18.622 6.60577 18.5122 6.56994 18.2621 6.54951C18.0033 6.52836 17.6658 6.52778 17.1556 6.52778H6.84445ZM19.25 10.0833H4.75V17.1556C4.75 17.6658 4.75058 18.0033 4.77173 18.2621C4.79216 18.5122 4.82799 18.622 4.86202 18.6888C4.96056 18.8822 5.11779 19.0394 5.31118 19.138C5.37797 19.172 5.48781 19.2078 5.73788 19.2283C5.9967 19.2494 6.33425 19.25 6.84445 19.25H17.1556C17.6658 19.25 18.0033 19.2494 18.2621 19.2283C18.5122 19.2078 18.622 19.172 18.6888 19.138C18.8822 19.0394 19.0394 18.8822 19.138 18.6888C19.172 18.622 19.2078 18.5122 19.2283 18.2621C19.2494 18.0033 19.25 17.6658 19.25 17.1556V10.0833Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M16.25 13C15.8358 13 15.5 13.3358 15.5 13.75V15.25C15.5 15.6642 15.8358 16 16.25 16C16.6642 16 17 15.6642 17 15.25V13.75C17 13.3358 16.6642 13 16.25 13Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 13C11.5858 13 11.25 13.3358 11.25 13.75V15.25C11.25 15.6642 11.5858 16 12 16C12.4142 16 12.75 15.6642 12.75 15.25V13.75C12.75 13.3358 12.4142 13 12 13Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M7.75 18C8.16421 18 8.5 17.6642 8.5 17.25L8.5 11.75C8.5 11.3358 8.16421 11 7.75 11C7.33579 11 7 11.3358 7 11.75L7 17.25C7 17.6642 7.33579 18 7.75 18Z"
  />
</svg>`,H=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.11366 3.678C6.40656 3.9709 6.40656 4.44577 6.11366 4.73866L4.28033 6.572C3.98744 6.86489 3.51256 6.86489 3.21967 6.572C2.92678 6.2791 2.92678 5.80423 3.21967 5.51134L5.053 3.678C5.3459 3.38511 5.82077 3.38511 6.11366 3.678ZM17.8863 3.678C18.1792 3.38511 18.6541 3.38511 18.947 3.678L20.7803 5.51134C21.0732 5.80423 21.0732 6.2791 20.7803 6.572C20.4874 6.86489 20.0126 6.86489 19.7197 6.572L17.8863 4.73866C17.5934 4.44577 17.5934 3.9709 17.8863 3.678ZM12 5.875C8.36413 5.875 5.41667 8.82246 5.41667 12.4583C5.41667 16.0942 8.36413 19.0417 12 19.0417C15.6359 19.0417 18.5833 16.0942 18.5833 12.4583C18.5833 8.82246 15.6359 5.875 12 5.875ZM3.91667 12.4583C3.91667 7.99403 7.5357 4.375 12 4.375C16.4643 4.375 20.0833 7.99403 20.0833 12.4583C20.0833 16.9226 16.4643 20.5417 12 20.5417C7.5357 20.5417 3.91667 16.9226 3.91667 12.4583Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M15.197 10.3586C15.4899 10.6515 15.4899 11.1264 15.197 11.4192L11.6415 14.9748C11.3486 15.2677 10.8737 15.2677 10.5808 14.9748L8.80301 13.197C8.51012 12.9041 8.51012 12.4293 8.80301 12.1364C9.09591 11.8435 9.57078 11.8435 9.86367 12.1364L11.1111 13.3838L14.1363 10.3586C14.4292 10.0657 14.9041 10.0657 15.197 10.3586Z"
  />
</svg>`,V=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.34315 6.34314C6.63604 6.05025 7.11091 6.05025 7.40381 6.34314L12 10.9393L16.5962 6.34314C16.8891 6.05025 17.364 6.05025 17.6569 6.34314C17.9497 6.63604 17.9497 7.11091 17.6569 7.4038L13.0607 12L17.6569 16.5962C17.9497 16.8891 17.9497 17.364 17.6569 17.6569C17.364 17.9497 16.8891 17.9497 16.5962 17.6569L12 13.0607L7.40381 17.6569C7.11091 17.9497 6.63604 17.9497 6.34315 17.6569C6.05025 17.364 6.05025 16.8891 6.34315 16.5962L10.9393 12L6.34315 7.4038C6.05025 7.11091 6.05025 6.63604 6.34315 6.34314Z"
  />
</svg>`,Z=n.YP`<path
  fill-rule="evenodd"
  clip-rule="evenodd"
  d="M5.57378 3.25C5.5825 3.25 5.59124 3.25 5.6 3.25L8.42622 3.25C8.68371 3.24998 8.92019 3.24996 9.11787 3.26612C9.33101 3.28353 9.56418 3.32339 9.79449 3.44074C10.1238 3.60852 10.3915 3.87623 10.5593 4.20552C10.6766 4.43582 10.7165 4.669 10.7339 4.88213C10.75 5.07982 10.75 5.3163 10.75 5.57379V8.42621C10.75 8.6837 10.75 8.92019 10.7339 9.11787C10.7165 9.33101 10.6766 9.56418 10.5593 9.79448C10.3915 10.1238 10.1238 10.3915 9.79449 10.5593C9.56418 10.6766 9.33101 10.7165 9.11787 10.7339C8.92019 10.75 8.6837 10.75 8.42622 10.75H5.57379C5.3163 10.75 5.07982 10.75 4.88213 10.7339C4.669 10.7165 4.43583 10.6766 4.20552 10.5593C3.87624 10.3915 3.60852 10.1238 3.44074 9.79448C3.32339 9.56418 3.28353 9.33101 3.26612 9.11787C3.24997 8.92019 3.24998 8.6837 3.25 8.42622L3.25 5.6C3.25 5.59124 3.25 5.5825 3.25 5.57378C3.24998 5.3163 3.24997 5.07981 3.26612 4.88213C3.28353 4.669 3.32339 4.43582 3.44074 4.20552C3.60852 3.87623 3.87624 3.60852 4.20552 3.44074C4.43583 3.32339 4.669 3.28353 4.88213 3.26612C5.07982 3.24996 5.3163 3.24998 5.57378 3.25ZM4.88088 4.77973C4.88085 4.77972 4.88132 4.77952 4.88239 4.77917L4.88088 4.77973ZM4.88346 4.77882C4.89234 4.77607 4.92547 4.76757 5.00428 4.76113C5.13341 4.75058 5.3076 4.75 5.6 4.75H8.4C8.6924 4.75 8.8666 4.75058 8.99573 4.76113C9.07454 4.76757 9.10766 4.77607 9.11654 4.77882C9.16118 4.80234 9.19766 4.83882 9.22118 4.88346C9.22393 4.89234 9.23243 4.92547 9.23887 5.00428C9.24942 5.1334 9.25 5.3076 9.25 5.6V8.4C9.25 8.6924 9.24942 8.8666 9.23887 8.99572C9.23243 9.07453 9.22393 9.10766 9.22118 9.11654C9.19766 9.16118 9.16118 9.19766 9.11654 9.22118C9.10767 9.22393 9.07454 9.23243 8.99573 9.23887C8.8666 9.24942 8.6924 9.25 8.4 9.25H5.6C5.3076 9.25 5.13341 9.24942 5.00428 9.23887C4.92547 9.23243 4.89234 9.22393 4.88347 9.22118C4.83883 9.19766 4.80235 9.16118 4.77883 9.11654C4.77607 9.10766 4.76757 9.07453 4.76114 8.99572C4.75059 8.8666 4.75 8.6924 4.75 8.4V5.6C4.75 5.3076 4.75059 5.1334 4.76114 5.00428C4.76757 4.92547 4.77607 4.89234 4.77883 4.88346C4.80235 4.83882 4.83883 4.80234 4.88346 4.77882ZM4.77973 4.88088C4.77974 4.8809 4.77956 4.88144 4.77917 4.88239L4.77973 4.88088ZM4.77973 9.11913C4.77972 9.11915 4.77953 9.11869 4.77918 9.11764L4.77973 9.11913ZM4.88088 9.22027C4.88091 9.22026 4.88143 9.22044 4.88236 9.22082L4.88088 9.22027ZM9.11913 9.22027C9.11916 9.22028 9.11869 9.22048 9.11764 9.22082L9.11913 9.22027ZM9.22028 9.11913C9.22027 9.11909 9.22044 9.11856 9.22084 9.11761L9.22028 9.11913ZM9.22028 4.88088C9.22029 4.88085 9.22048 4.88132 9.22084 4.88239L9.22028 4.88088ZM9.11764 4.77918C9.11869 4.77952 9.11916 4.77972 9.11913 4.77973L9.11764 4.77918ZM15.5738 3.25H18.4262C18.6837 3.24998 18.9202 3.24996 19.1179 3.26612C19.331 3.28353 19.5642 3.32339 19.7945 3.44074C20.1238 3.60852 20.3915 3.87623 20.5593 4.20552C20.6766 4.43582 20.7165 4.669 20.7339 4.88213C20.75 5.07981 20.75 5.31629 20.75 5.57377V8.42623C20.75 8.68371 20.75 8.92019 20.7339 9.11787C20.7165 9.33101 20.6766 9.56418 20.5593 9.79448C20.3915 10.1238 20.1238 10.3915 19.7945 10.5593C19.5642 10.6766 19.331 10.7165 19.1179 10.7339C18.9202 10.75 18.6837 10.75 18.4262 10.75H15.5738C15.3163 10.75 15.0798 10.75 14.8821 10.7339C14.669 10.7165 14.4358 10.6766 14.2055 10.5593C13.8762 10.3915 13.6085 10.1238 13.4407 9.79448C13.3234 9.56418 13.2835 9.33101 13.2661 9.11787C13.25 8.92019 13.25 8.68371 13.25 8.42623V5.57377C13.25 5.31629 13.25 5.07981 13.2661 4.88213C13.2835 4.669 13.3234 4.43582 13.4407 4.20552C13.6085 3.87623 13.8762 3.60852 14.2055 3.44074C14.4358 3.32339 14.669 3.28353 14.8821 3.26612C15.0798 3.24996 15.3163 3.24998 15.5738 3.25ZM14.8809 4.77973C14.8808 4.77972 14.8813 4.77953 14.8824 4.77918L14.8809 4.77973ZM14.8835 4.77882C14.8923 4.77607 14.9255 4.76757 15.0043 4.76113C15.1334 4.75058 15.3076 4.75 15.6 4.75H18.4C18.6924 4.75 18.8666 4.75058 18.9957 4.76113C19.0745 4.76757 19.1077 4.77607 19.1165 4.77882C19.1612 4.80234 19.1977 4.83882 19.2212 4.88346C19.2239 4.89234 19.2324 4.92547 19.2389 5.00428C19.2494 5.1334 19.25 5.3076 19.25 5.6V8.4C19.25 8.6924 19.2494 8.8666 19.2389 8.99572C19.2324 9.07453 19.2239 9.10766 19.2212 9.11654C19.1977 9.16118 19.1612 9.19766 19.1165 9.22118C19.1077 9.22393 19.0745 9.23243 18.9957 9.23887C18.8666 9.24942 18.6924 9.25 18.4 9.25H15.6C15.3076 9.25 15.1334 9.24942 15.0043 9.23887C14.9255 9.23243 14.8923 9.22393 14.8835 9.22118C14.8388 9.19766 14.8023 9.16118 14.7788 9.11654C14.7761 9.10766 14.7676 9.07453 14.7611 8.99572C14.7506 8.8666 14.75 8.6924 14.75 8.4V5.6C14.75 5.3076 14.7506 5.1334 14.7611 5.00428C14.7676 4.92547 14.7761 4.89234 14.7788 4.88346C14.8023 4.83882 14.8388 4.80234 14.8835 4.77882ZM14.7797 4.88088C14.7797 4.8809 14.7796 4.88143 14.7792 4.88236L14.7797 4.88088ZM14.7797 9.11913C14.7797 9.11915 14.7795 9.11867 14.7792 9.11761L14.7797 9.11913ZM14.8809 9.22027C14.8809 9.22026 14.8814 9.22044 14.8824 9.22082L14.8809 9.22027ZM19.1191 9.22027C19.1192 9.22028 19.1187 9.22048 19.1176 9.22082L19.1191 9.22027ZM19.2203 9.11913C19.2203 9.11911 19.2204 9.11857 19.2208 9.11761L19.2203 9.11913ZM19.2203 4.88088C19.2203 4.88085 19.2205 4.88131 19.2208 4.88236L19.2203 4.88088ZM19.1176 4.77917C19.1187 4.77952 19.1192 4.77972 19.1191 4.77973L19.1176 4.77917ZM5.57377 13.25H8.42623C8.68372 13.25 8.92019 13.25 9.11787 13.2661C9.33101 13.2835 9.56418 13.3234 9.79449 13.4407C10.1238 13.6085 10.3915 13.8762 10.5593 14.2055C10.6766 14.4358 10.7165 14.669 10.7339 14.8821C10.75 15.0798 10.75 15.3163 10.75 15.5738V18.4262C10.75 18.6837 10.75 18.9202 10.7339 19.1179C10.7165 19.331 10.6766 19.5642 10.5593 19.7945C10.3915 20.1238 10.1238 20.3915 9.79449 20.5593C9.56418 20.6766 9.33101 20.7165 9.11787 20.7339C8.92019 20.75 8.68372 20.75 8.42623 20.75H5.57377C5.31629 20.75 5.07981 20.75 4.88213 20.7339C4.669 20.7165 4.43583 20.6766 4.20552 20.5593C3.87624 20.3915 3.60852 20.1238 3.44074 19.7945C3.32339 19.5642 3.28353 19.331 3.26612 19.1179C3.24997 18.9202 3.24998 18.6837 3.25 18.4262V15.5738C3.24998 15.3163 3.24997 15.0798 3.26612 14.8821C3.28353 14.669 3.32339 14.4358 3.44074 14.2055C3.60852 13.8762 3.87624 13.6085 4.20552 13.4407C4.43583 13.3234 4.669 13.2835 4.88213 13.2661C5.07981 13.25 5.31629 13.25 5.57377 13.25ZM4.88088 14.7797C4.88085 14.7797 4.88131 14.7795 4.88237 14.7792L4.88088 14.7797ZM4.88346 14.7788C4.89234 14.7761 4.92546 14.7676 5.00428 14.7611C5.13341 14.7506 5.3076 14.75 5.6 14.75H8.4C8.6924 14.75 8.8666 14.7506 8.99573 14.7611C9.07453 14.7676 9.10766 14.7761 9.11654 14.7788C9.16118 14.8023 9.19766 14.8388 9.22118 14.8835C9.22393 14.8923 9.23243 14.9255 9.23887 15.0043C9.24942 15.1334 9.25 15.3076 9.25 15.6V18.4C9.25 18.6924 9.24942 18.8666 9.23887 18.9957C9.23243 19.0745 9.22393 19.1077 9.22118 19.1165C9.19766 19.1612 9.16118 19.1977 9.11654 19.2212C9.10767 19.2239 9.07454 19.2324 8.99573 19.2389C8.8666 19.2494 8.6924 19.25 8.4 19.25H5.6C5.3076 19.25 5.13341 19.2494 5.00428 19.2389C4.92547 19.2324 4.89235 19.2239 4.88347 19.2212C4.83883 19.1977 4.80235 19.1612 4.77883 19.1165C4.77607 19.1077 4.76757 19.0745 4.76114 18.9957C4.75059 18.8666 4.75 18.6924 4.75 18.4V15.6C4.75 15.3076 4.75059 15.1334 4.76114 15.0043C4.76757 14.9255 4.77607 14.8923 4.77883 14.8835C4.80234 14.8388 4.83882 14.8023 4.88346 14.7788ZM4.77973 14.8809C4.77974 14.8809 4.77956 14.8814 4.77918 14.8824L4.77973 14.8809ZM4.77973 19.1191C4.77972 19.1192 4.77953 19.1187 4.77918 19.1176L4.77973 19.1191ZM4.88088 19.2203C4.8809 19.2203 4.88143 19.2204 4.88236 19.2208L4.88088 19.2203ZM9.11913 19.2203C9.11917 19.2203 9.1187 19.2205 9.11762 19.2208L9.11913 19.2203ZM9.22028 19.1191C9.22026 19.1191 9.22044 19.1185 9.22087 19.1175L9.22028 19.1191ZM9.22027 14.8809C9.22028 14.8808 9.22048 14.8813 9.22084 14.8824L9.22027 14.8809ZM9.11761 14.7792C9.11868 14.7795 9.11915 14.7797 9.11913 14.7797L9.11761 14.7792ZM17 13.25C17.4142 13.25 17.75 13.5858 17.75 14V16.25H20C20.4142 16.25 20.75 16.5858 20.75 17C20.75 17.4142 20.4142 17.75 20 17.75H17.75V20C17.75 20.4142 17.4142 20.75 17 20.75C16.5858 20.75 16.25 20.4142 16.25 20V17.75H14C13.5858 17.75 13.25 17.4142 13.25 17C13.25 16.5858 13.5858 16.25 14 16.25H16.25V14C16.25 13.5858 16.5858 13.25 17 13.25Z"
/>`,F=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  ${Z}
</svg>`,U=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M5.57378 3.25C5.5825 3.25 5.59124 3.25 5.6 3.25L8.42622 3.25C8.68371 3.24998 8.92019 3.24996 9.11787 3.26612C9.33101 3.28353 9.56418 3.32339 9.79449 3.44074C10.1238 3.60852 10.3915 3.87623 10.5593 4.20552C10.6766 4.43582 10.7165 4.669 10.7339 4.88213C10.75 5.07982 10.75 5.3163 10.75 5.57379V8.42621C10.75 8.6837 10.75 8.92019 10.7339 9.11787C10.7165 9.33101 10.6766 9.56418 10.5593 9.79448C10.3915 10.1238 10.1238 10.3915 9.79449 10.5593C9.56418 10.6766 9.33101 10.7165 9.11787 10.7339C8.92019 10.75 8.6837 10.75 8.42622 10.75H5.57379C5.3163 10.75 5.07982 10.75 4.88213 10.7339C4.669 10.7165 4.43583 10.6766 4.20552 10.5593C3.87624 10.3915 3.60852 10.1238 3.44074 9.79448C3.32339 9.56418 3.28353 9.33101 3.26612 9.11787C3.24997 8.92019 3.24998 8.6837 3.25 8.42622L3.25 5.6C3.25 5.59124 3.25 5.5825 3.25 5.57378C3.24998 5.3163 3.24997 5.07981 3.26612 4.88213C3.28353 4.669 3.32339 4.43582 3.44074 4.20552C3.60852 3.87623 3.87624 3.60852 4.20552 3.44074C4.43583 3.32339 4.669 3.28353 4.88213 3.26612C5.07982 3.24996 5.3163 3.24998 5.57378 3.25ZM4.88088 4.77973C4.88085 4.77972 4.88132 4.77952 4.88239 4.77917L4.88088 4.77973ZM4.88346 4.77882C4.89234 4.77607 4.92547 4.76757 5.00428 4.76113C5.13341 4.75058 5.3076 4.75 5.6 4.75H8.4C8.6924 4.75 8.8666 4.75058 8.99573 4.76113C9.07454 4.76757 9.10766 4.77607 9.11654 4.77882C9.16118 4.80234 9.19766 4.83882 9.22118 4.88346C9.22393 4.89234 9.23243 4.92547 9.23887 5.00428C9.24942 5.1334 9.25 5.3076 9.25 5.6V8.4C9.25 8.6924 9.24942 8.8666 9.23887 8.99572C9.23243 9.07453 9.22393 9.10766 9.22118 9.11654C9.19766 9.16118 9.16118 9.19766 9.11654 9.22118C9.10767 9.22393 9.07454 9.23243 8.99573 9.23887C8.8666 9.24942 8.6924 9.25 8.4 9.25H5.6C5.3076 9.25 5.13341 9.24942 5.00428 9.23887C4.92547 9.23243 4.89234 9.22393 4.88347 9.22118C4.83883 9.19766 4.80235 9.16118 4.77883 9.11654C4.77607 9.10766 4.76757 9.07453 4.76114 8.99572C4.75059 8.8666 4.75 8.6924 4.75 8.4V5.6C4.75 5.3076 4.75059 5.1334 4.76114 5.00428C4.76757 4.92547 4.77607 4.89234 4.77883 4.88346C4.80235 4.83882 4.83883 4.80234 4.88346 4.77882ZM4.77973 4.88088C4.77974 4.8809 4.77956 4.88144 4.77917 4.88239L4.77973 4.88088ZM4.77973 9.11913C4.77972 9.11915 4.77953 9.11869 4.77918 9.11764L4.77973 9.11913ZM4.88088 9.22027C4.88091 9.22026 4.88143 9.22044 4.88236 9.22082L4.88088 9.22027ZM9.11913 9.22027C9.11916 9.22028 9.11869 9.22048 9.11764 9.22082L9.11913 9.22027ZM9.22028 9.11913C9.22027 9.11909 9.22044 9.11856 9.22084 9.11761L9.22028 9.11913ZM9.22028 4.88088C9.22029 4.88085 9.22048 4.88132 9.22084 4.88239L9.22028 4.88088ZM9.11764 4.77918C9.11869 4.77952 9.11916 4.77972 9.11913 4.77973L9.11764 4.77918ZM15.5738 3.25H18.4262C18.6837 3.24998 18.9202 3.24996 19.1179 3.26612C19.331 3.28353 19.5642 3.32339 19.7945 3.44074C20.1238 3.60852 20.3915 3.87623 20.5593 4.20552C20.6766 4.43582 20.7165 4.669 20.7339 4.88213C20.75 5.07981 20.75 5.31629 20.75 5.57377V8.42623C20.75 8.68371 20.75 8.92019 20.7339 9.11787C20.7165 9.33101 20.6766 9.56418 20.5593 9.79448C20.3915 10.1238 20.1238 10.3915 19.7945 10.5593C19.5642 10.6766 19.331 10.7165 19.1179 10.7339C18.9202 10.75 18.6837 10.75 18.4262 10.75H15.5738C15.3163 10.75 15.0798 10.75 14.8821 10.7339C14.669 10.7165 14.4358 10.6766 14.2055 10.5593C13.8762 10.3915 13.6085 10.1238 13.4407 9.79448C13.3234 9.56418 13.2835 9.33101 13.2661 9.11787C13.25 8.92019 13.25 8.68371 13.25 8.42623V5.57377C13.25 5.31629 13.25 5.07981 13.2661 4.88213C13.2835 4.669 13.3234 4.43582 13.4407 4.20552C13.6085 3.87623 13.8762 3.60852 14.2055 3.44074C14.4358 3.32339 14.669 3.28353 14.8821 3.26612C15.0798 3.24996 15.3163 3.24998 15.5738 3.25ZM14.8809 4.77973C14.8808 4.77972 14.8813 4.77953 14.8824 4.77918L14.8809 4.77973ZM14.8835 4.77882C14.8923 4.77607 14.9255 4.76757 15.0043 4.76113C15.1334 4.75058 15.3076 4.75 15.6 4.75H18.4C18.6924 4.75 18.8666 4.75058 18.9957 4.76113C19.0745 4.76757 19.1077 4.77607 19.1165 4.77882C19.1612 4.80234 19.1977 4.83882 19.2212 4.88346C19.2239 4.89234 19.2324 4.92547 19.2389 5.00428C19.2494 5.1334 19.25 5.3076 19.25 5.6V8.4C19.25 8.6924 19.2494 8.8666 19.2389 8.99572C19.2324 9.07453 19.2239 9.10766 19.2212 9.11654C19.1977 9.16118 19.1612 9.19766 19.1165 9.22118C19.1077 9.22393 19.0745 9.23243 18.9957 9.23887C18.8666 9.24942 18.6924 9.25 18.4 9.25H15.6C15.3076 9.25 15.1334 9.24942 15.0043 9.23887C14.9255 9.23243 14.8923 9.22393 14.8835 9.22118C14.8388 9.19766 14.8023 9.16118 14.7788 9.11654C14.7761 9.10766 14.7676 9.07453 14.7611 8.99572C14.7506 8.8666 14.75 8.6924 14.75 8.4V5.6C14.75 5.3076 14.7506 5.1334 14.7611 5.00428C14.7676 4.92547 14.7761 4.89234 14.7788 4.88346C14.8023 4.83882 14.8388 4.80234 14.8835 4.77882ZM14.7797 4.88088C14.7797 4.8809 14.7796 4.88143 14.7792 4.88236L14.7797 4.88088ZM14.7797 9.11913C14.7797 9.11915 14.7795 9.11867 14.7792 9.11761L14.7797 9.11913ZM14.8809 9.22027C14.8809 9.22026 14.8814 9.22044 14.8824 9.22082L14.8809 9.22027ZM19.1191 9.22027C19.1192 9.22028 19.1187 9.22048 19.1176 9.22082L19.1191 9.22027ZM19.2203 9.11913C19.2203 9.11911 19.2204 9.11857 19.2208 9.11761L19.2203 9.11913ZM19.2203 4.88088C19.2203 4.88085 19.2205 4.88131 19.2208 4.88236L19.2203 4.88088ZM19.1176 4.77917C19.1187 4.77952 19.1192 4.77972 19.1191 4.77973L19.1176 4.77917ZM5.57377 13.25H8.42623C8.68372 13.25 8.92019 13.25 9.11787 13.2661C9.33101 13.2835 9.56418 13.3234 9.79449 13.4407C10.1238 13.6085 10.3915 13.8762 10.5593 14.2055C10.6766 14.4358 10.7165 14.669 10.7339 14.8821C10.75 15.0798 10.75 15.3163 10.75 15.5738V18.4262C10.75 18.6837 10.75 18.9202 10.7339 19.1179C10.7165 19.331 10.6766 19.5642 10.5593 19.7945C10.3915 20.1238 10.1238 20.3915 9.79449 20.5593C9.56418 20.6766 9.33101 20.7165 9.11787 20.7339C8.92019 20.75 8.68372 20.75 8.42623 20.75H5.57377C5.31629 20.75 5.07981 20.75 4.88213 20.7339C4.669 20.7165 4.43583 20.6766 4.20552 20.5593C3.87624 20.3915 3.60852 20.1238 3.44074 19.7945C3.32339 19.5642 3.28353 19.331 3.26612 19.1179C3.24997 18.9202 3.24998 18.6837 3.25 18.4262V15.5738C3.24998 15.3163 3.24997 15.0798 3.26612 14.8821C3.28353 14.669 3.32339 14.4358 3.44074 14.2055C3.60852 13.8762 3.87624 13.6085 4.20552 13.4407C4.43583 13.3234 4.669 13.2835 4.88213 13.2661C5.07981 13.25 5.31629 13.25 5.57377 13.25ZM4.88088 14.7797C4.88085 14.7797 4.88131 14.7795 4.88237 14.7792L4.88088 14.7797ZM4.88346 14.7788C4.89234 14.7761 4.92546 14.7676 5.00428 14.7611C5.13341 14.7506 5.3076 14.75 5.6 14.75H8.4C8.6924 14.75 8.8666 14.7506 8.99573 14.7611C9.07453 14.7676 9.10766 14.7761 9.11654 14.7788C9.16118 14.8023 9.19766 14.8388 9.22118 14.8835C9.22393 14.8923 9.23243 14.9255 9.23887 15.0043C9.24942 15.1334 9.25 15.3076 9.25 15.6V18.4C9.25 18.6924 9.24942 18.8666 9.23887 18.9957C9.23243 19.0745 9.22393 19.1077 9.22118 19.1165C9.19766 19.1612 9.16118 19.1977 9.11654 19.2212C9.10767 19.2239 9.07454 19.2324 8.99573 19.2389C8.8666 19.2494 8.6924 19.25 8.4 19.25H5.6C5.3076 19.25 5.13341 19.2494 5.00428 19.2389C4.92547 19.2324 4.89235 19.2239 4.88347 19.2212C4.83883 19.1977 4.80235 19.1612 4.77883 19.1165C4.77607 19.1077 4.76757 19.0745 4.76114 18.9957C4.75059 18.8666 4.75 18.6924 4.75 18.4V15.6C4.75 15.3076 4.75059 15.1334 4.76114 15.0043C4.76757 14.9255 4.77607 14.8923 4.77883 14.8835C4.80234 14.8388 4.83882 14.8023 4.88346 14.7788ZM4.77973 14.8809C4.77974 14.8809 4.77956 14.8814 4.77918 14.8824L4.77973 14.8809ZM4.77973 19.1191C4.77972 19.1192 4.77953 19.1187 4.77918 19.1176L4.77973 19.1191ZM4.88088 19.2203C4.8809 19.2203 4.88143 19.2204 4.88236 19.2208L4.88088 19.2203ZM9.11913 19.2203C9.11917 19.2203 9.1187 19.2205 9.11762 19.2208L9.11913 19.2203ZM9.22028 19.1191C9.22026 19.1191 9.22044 19.1185 9.22087 19.1175L9.22028 19.1191ZM9.22027 14.8809C9.22028 14.8808 9.22048 14.8813 9.22084 14.8824L9.22027 14.8809ZM9.11761 14.7792C9.11868 14.7795 9.11915 14.7797 9.11913 14.7797L9.11761 14.7792ZM17 13.25C17.4142 13.25 17.75 13.5858 17.75 14V16.25H20C20.4142 16.25 20.75 16.5858 20.75 17C20.75 17.4142 20.4142 17.75 20 17.75H17.75V20C17.75 20.4142 17.4142 20.75 17 20.75C16.5858 20.75 16.25 20.4142 16.25 20V17.75H14C13.5858 17.75 13.25 17.4142 13.25 17C13.25 16.5858 13.5858 16.25 14 16.25H16.25V14C16.25 13.5858 16.5858 13.25 17 13.25Z"
  />
</svg>`,j=n.dy`<svg
  width="24"
  height="24"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.25 7C2.25 5.48122 3.48122 4.25 5 4.25H19C20.5188 4.25 21.75 5.48122 21.75 7V17C21.75 18.5188 20.5188 19.75 19 19.75H5C3.48122 19.75 2.25 18.5188 2.25 17V7ZM5 5.75C4.30964 5.75 3.75 6.30964 3.75 7V17C3.75 17.6904 4.30964 18.25 5 18.25H19C19.6904 18.25 20.25 17.6904 20.25 17V7C20.25 6.30964 19.6904 5.75 19 5.75H5Z"
  />
</svg>`,N=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M11 3.75C6.99594 3.75 3.75 6.99594 3.75 11C3.75 15.0041 6.99594 18.25 11 18.25C13.0026 18.25 14.8156 17.4381 16.1276 16.1254C16.128 16.1251 16.1284 16.1247 16.1287 16.1243C16.1288 16.1243 16.1289 16.1242 16.1289 16.1241C17.4395 14.8123 18.25 13.0008 18.25 11C18.25 6.99594 15.0041 3.75 11 3.75ZM17.6965 16.6324C18.9779 15.1104 19.75 13.1453 19.75 11C19.75 6.16751 15.8325 2.25 11 2.25C6.16751 2.25 2.25 6.16751 2.25 11C2.25 15.8325 6.16751 19.75 11 19.75C13.1471 19.75 15.1136 18.9767 16.6361 17.6933L20.4694 21.5301C20.7622 21.8231 21.2371 21.8233 21.5301 21.5306C21.8231 21.2378 21.8233 20.7629 21.5306 20.4699L17.6965 16.6324ZM10.25 6C10.25 5.58579 10.5858 5.25 11 5.25C14.1756 5.25 16.75 7.82436 16.75 11C16.75 11.4142 16.4142 11.75 16 11.75C15.5858 11.75 15.25 11.4142 15.25 11C15.25 8.65279 13.3472 6.75 11 6.75C10.5858 6.75 10.25 6.41421 10.25 6Z"
  />
</svg>`,W=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M17.6726 6.0059L7.49998 16.1785L2.32739 11.0059L3.5059 9.82739L7.49998 13.8215L16.4941 4.82739L17.6726 6.0059Z"
  />
</svg>`,q=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.245 4.43531L12.543 5.16181L14.8382 7.45701L15.5647 6.75504C16.2018 6.11419 16.2006 5.07822 15.5612 4.4388C14.9218 3.7994 13.8859 3.79823 13.245 4.43531ZM13.9392 8.32572L11.6743 6.06086L5.13833 12.8251L4.2655 15.7345L7.17493 14.8617L13.9392 8.32572ZM12.3576 3.55492C13.4863 2.42619 15.3164 2.42619 16.4451 3.55492C17.5738 4.68365 17.5738 6.51369 16.4451 7.64242L16.4375 7.65L7.93429 15.8662C7.86252 15.9355 7.77518 15.9867 7.67959 16.0153L3.51292 17.2654C3.29269 17.3314 3.05397 17.2712 2.89139 17.1087C2.7288 16.9461 2.66862 16.7073 2.73469 16.4871L3.98469 12.3204C4.01337 12.2249 4.06452 12.1375 4.13387 12.0657L12.3576 3.55492Z"
  />
</svg>`,Y=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12.8423 4.60675C14.6513 2.79775 17.5843 2.79775 19.3933 4.60675C21.2023 6.41576 21.2023 9.34874 19.3933 11.1577L17.3344 13.2166C17.0415 13.5095 16.5666 13.5095 16.2737 13.2166C15.9808 12.9237 15.9808 12.4489 16.2737 12.156L18.3326 10.0971C19.5558 8.87386 19.5558 6.89063 18.3326 5.66741C17.1094 4.44419 15.1261 4.44419 13.9029 5.66741L11.1578 8.41258C9.93454 9.6358 9.93454 11.619 11.1578 12.8423C11.3498 13.0343 11.5596 13.1955 11.7816 13.3266C12.1383 13.5372 12.2566 13.9971 12.046 14.3538C11.8353 14.7104 11.3755 14.8288 11.0188 14.6182C10.6892 14.4235 10.379 14.1849 10.0971 13.9029C8.28809 12.0939 8.28809 9.16093 10.0971 7.35192L12.8423 4.60675ZM11.954 9.64621C12.1647 9.28955 12.6246 9.17119 12.9812 9.38183C13.3109 9.57652 13.621 9.81514 13.9029 10.0971C15.7119 11.9061 15.7119 14.8391 13.9029 16.6481L11.1578 19.3932C9.34875 21.2023 6.41577 21.2023 4.60677 19.3932C2.79776 17.5842 2.79776 14.6513 4.60677 12.8423L6.66564 10.7834C6.95854 10.4905 7.43341 10.4905 7.7263 10.7834C8.0192 11.0763 8.0192 11.5511 7.7263 11.844L5.66743 13.9029C4.44421 15.1261 4.44421 17.1094 5.66743 18.3326C6.89065 19.5558 8.87388 19.5558 10.0971 18.3326L12.8423 15.5874C14.0655 14.3642 14.0655 12.381 12.8423 11.1577C12.6503 10.9657 12.4404 10.8045 12.2184 10.6734C11.8618 10.4627 11.7434 10.0029 11.954 9.64621Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.19501 3.26921C8.59861 3.17607 9.0013 3.42775 9.09444 3.83135L9.53081 5.72226C9.62395 6.12587 9.37227 6.52856 8.96866 6.6217C8.56505 6.71484 8.16236 6.46316 8.06922 6.05955L7.63286 4.16864C7.53972 3.76504 7.7914 3.36234 8.19501 3.26921ZM3.26922 8.19499C3.36236 7.79138 3.76505 7.5397 4.16866 7.63284L6.05957 8.06921C6.46317 8.16235 6.71486 8.56504 6.62172 8.96864C6.52858 9.37225 6.12588 9.62393 5.72228 9.53079L3.83137 9.09443C3.42776 9.00129 3.17608 8.5986 3.26922 8.19499ZM17.3783 15.0314C17.4715 14.6277 17.8741 14.3761 18.2777 14.4692L20.1687 14.9056C20.5723 14.9987 20.8239 15.4014 20.7308 15.805C20.6377 16.2086 20.235 16.4603 19.8314 16.3672L17.9405 15.9308C17.5369 15.8377 17.2852 15.435 17.3783 15.0314ZM15.0314 17.3783C15.435 17.2852 15.8377 17.5368 15.9308 17.9404L16.3672 19.8314C16.4603 20.235 16.2086 20.6377 15.805 20.7308C15.4014 20.8239 14.9987 20.5723 14.9056 20.1686L14.4692 18.2777C14.3761 17.8741 14.6278 17.4714 15.0314 17.3783Z"
  />
</svg>`,X=n.dy`
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g clip-path="url(#clip0_3409_77516)">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M6.16667 6.79166C5.59137 6.79166 5.125 7.25803 5.125 7.83333V16.1667C5.125 16.742 5.59137 17.2083 6.16667 17.2083H17.8333C18.4086 17.2083 18.875 16.742 18.875 16.1667V12C18.875 11.6548 19.1548 11.375 19.5 11.375C19.8452 11.375 20.125 11.6548 20.125 12V16.1667C20.125 17.4323 19.099 18.4583 17.8333 18.4583H6.16667C4.90101 18.4583 3.875 17.4323 3.875 16.1667V7.83333C3.875 6.56768 4.90101 5.54166 6.16667 5.54166H12C12.3452 5.54166 12.625 5.82148 12.625 6.16666C12.625 6.51184 12.3452 6.79166 12 6.79166H6.16667Z"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M15.6063 5.48362C16.64 4.4499 18.316 4.4499 19.3497 5.48362C20.3834 6.51734 20.3834 8.19333 19.3497 9.22705L18.2774 10.2994C18.0333 10.5435 17.6376 10.5435 17.3935 10.2994C17.3371 10.243 17.2937 10.1784 17.2634 10.1096C17.2915 10.8217 17.0338 11.5429 16.4902 12.0866L15.0604 13.5164C14.0267 14.5501 12.3507 14.5501 11.317 13.5164C10.2832 12.4827 10.2832 10.8067 11.317 9.77294L12.3893 8.70061C12.6334 8.45653 13.0291 8.45653 13.2732 8.70061C13.3296 8.75703 13.373 8.82155 13.4033 8.89042C13.3751 8.17833 13.6329 7.45704 14.1765 6.91339L15.6063 5.48362ZM13.4445 9.2633C13.4215 9.38098 13.3643 9.49332 13.2732 9.58449L12.2008 10.6568C11.6553 11.2024 11.6553 12.0869 12.2008 12.6325C12.7464 13.1781 13.6309 13.1781 14.1765 12.6325L15.6063 11.2027C16.1518 10.6571 16.1518 9.77261 15.6063 9.22705C15.5203 9.1411 15.4267 9.0692 15.3279 9.01086C15.0307 8.83532 14.932 8.45209 15.1076 8.15487C15.2831 7.85766 15.6664 7.75902 15.9636 7.93456C16.1521 8.0459 16.3293 8.18227 16.4902 8.34317C16.8849 8.73787 17.1289 9.22622 17.2221 9.73669C17.2452 9.619 17.3023 9.50667 17.3935 9.4155L18.4658 8.34317C19.0114 7.7976 19.0114 6.91307 18.4658 6.3675C17.9203 5.82194 17.0357 5.82194 16.4902 6.3675L15.0604 7.79728C14.5148 8.34284 14.5148 9.22738 15.0604 9.77294C15.1463 9.85889 15.24 9.93079 15.3388 9.98913C15.636 10.1647 15.7346 10.5479 15.5591 10.8451C15.3835 11.1423 15.0003 11.241 14.7031 11.0654C14.5146 10.9541 14.3374 10.8177 14.1765 10.6568C13.7818 10.2621 13.5378 9.77377 13.4445 9.2633Z"
      />
    </g>
    <defs>
      <clipPath id="clip0_3409_77516">
        <rect width="20" height="20" fill="white" transform="translate(2 2)" />
      </clipPath>
    </defs>
  </svg>
`,K=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.70831 4.16671C2.70831 3.36129 3.36123 2.70837 4.16665 2.70837H7.49998C8.30539 2.70837 8.95831 3.36129 8.95831 4.16671V7.50004C8.95831 8.30546 8.30539 8.95837 7.49998 8.95837H4.16665C3.36123 8.95837 2.70831 8.30546 2.70831 7.50004V4.16671ZM4.16665 3.95837C4.05159 3.95837 3.95831 4.05165 3.95831 4.16671V7.50004C3.95831 7.6151 4.05159 7.70837 4.16665 7.70837H7.49998C7.61504 7.70837 7.70831 7.6151 7.70831 7.50004V4.16671C7.70831 4.05165 7.61504 3.95837 7.49998 3.95837H4.16665Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.70831 16.6667C2.70831 16.3215 2.98814 16.0417 3.33331 16.0417L13.3333 16.0417C13.6785 16.0417 13.9583 16.3215 13.9583 16.6667C13.9583 17.0119 13.6785 17.2917 13.3333 17.2917L3.33331 17.2917C2.98813 17.2917 2.70831 17.0119 2.70831 16.6667Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M2.70831 12.5C2.70831 12.1549 2.98814 11.875 3.33331 11.875L16.6666 11.875C17.0118 11.875 17.2916 12.1549 17.2916 12.5C17.2916 12.8452 17.0118 13.125 16.6666 13.125L3.33331 13.125C2.98813 13.125 2.70831 12.8452 2.70831 12.5Z"
  />
</svg>`,G=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M9.99997 2.70837C10.3452 2.70837 10.625 2.9882 10.625 3.33337V10.7134L12.197 9.14138C12.4411 8.8973 12.8368 8.8973 13.0809 9.14138C13.3249 9.38546 13.3249 9.78119 13.0809 10.0253L10.4419 12.6642C10.1978 12.9083 9.80211 12.9083 9.55803 12.6642L6.91909 10.0253C6.67502 9.78119 6.67502 9.38546 6.91909 9.14138C7.16317 8.8973 7.5589 8.8973 7.80298 9.14138L9.37498 10.7134V3.33337C9.37498 2.9882 9.6548 2.70837 9.99997 2.70837ZM16.6666 11.212C17.0118 11.212 17.2916 11.4918 17.2916 11.837V14.9104C17.2916 15.5317 17.0577 16.1337 16.6318 16.5825C16.2049 17.0324 15.6186 17.2917 15 17.2917H4.99998C4.38132 17.2917 3.79506 17.0324 3.36812 16.5825C2.94223 16.1337 2.70831 15.5317 2.70831 14.9104L2.70831 11.837C2.70831 11.4918 2.98813 11.212 3.33331 11.212C3.67849 11.212 3.95831 11.4918 3.95831 11.837L3.95831 14.9104C3.95831 15.2207 4.07559 15.5121 4.27482 15.722C4.473 15.9309 4.73459 16.0417 4.99998 16.0417H15C15.2654 16.0417 15.527 15.9309 15.7251 15.722C15.9244 15.5121 16.0416 15.2207 16.0416 14.9104V11.837C16.0416 11.4918 16.3215 11.212 16.6666 11.212Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M13.0787 13.6458C13.0787 13.3007 13.3585 13.0208 13.7037 13.0208H13.7111C14.0563 13.0208 14.3361 13.3007 14.3361 13.6458C14.3361 13.991 14.0563 14.2708 13.7111 14.2708H13.7037C13.3585 14.2708 13.0787 13.991 13.0787 13.6458Z"
  />
</svg>`,Q=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 20 20"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.16665 2.5C3.53484 2.5 3.83331 2.79848 3.83331 3.16667L3.83331 16.8333C3.83331 17.2015 3.53484 17.5 3.16665 17.5C2.79846 17.5 2.49998 17.2015 2.49998 16.8333L2.49998 3.16667C2.49998 2.79848 2.79846 2.5 3.16665 2.5ZM9.31209 14.6598C9.58453 14.4121 9.60461 13.9905 9.35694 13.7181L8.85553 13.1665H11.8939C13.5757 13.1665 14.8333 11.6875 14.8333 9.99983C14.8333 8.31215 13.5757 6.83317 11.8939 6.83317H5.83334C5.46515 6.83317 5.16668 7.13164 5.16668 7.49983C5.16668 7.86802 5.46515 8.1665 5.83334 8.1665H11.8939C12.7226 8.1665 13.5 8.92609 13.5 9.99983C13.5 11.0736 12.7226 11.8332 11.8939 11.8332H8.85553L9.35694 11.2816C9.60461 11.0092 9.58453 10.5875 9.31209 10.3399C9.03966 10.0922 8.61802 10.1123 8.37035 10.3847L6.8552 12.0514C6.62404 12.3057 6.62404 12.694 6.8552 12.9483L8.37035 14.6149C8.61802 14.8874 9.03966 14.9075 9.31209 14.6598ZM16.1666 16.8333C16.1666 17.2015 16.4651 17.5 16.8333 17.5C17.2015 17.5 17.5 17.2015 17.5 16.8333L17.5 3.16667C17.5 2.79848 17.2015 2.5 16.8333 2.5C16.4651 2.5 16.1666 2.79848 16.1666 3.16667V16.8333Z"
  />
</svg>`,J=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M4 3.25C4.41421 3.25 4.75 3.58579 4.75 4L4.75 20C4.75 20.4142 4.41421 20.75 4 20.75C3.58579 20.75 3.25 20.4142 3.25 20L3.25 4C3.25 3.58579 3.58579 3.25 4 3.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20 3.25C20.4142 3.25 20.75 3.58579 20.75 4V20C20.75 20.4142 20.4142 20.75 20 20.75C19.5858 20.75 19.25 20.4142 19.25 20V4C19.25 3.58579 19.5858 3.25 20 3.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M10.6437 12.408C10.3168 12.7053 10.2927 13.2112 10.5899 13.5381L11.1916 14.2H7C6.55817 14.2 6.2 14.5582 6.2 15C6.2 15.4418 6.55817 15.8 7 15.8L11.1916 15.8L10.5899 16.4619C10.2927 16.7888 10.3168 17.2947 10.6437 17.592C10.9706 17.8892 11.4766 17.8651 11.7738 17.5381L13.592 15.5381C13.8693 15.233 13.8693 14.767 13.592 14.4619L11.7738 12.4619C11.4766 12.1349 10.9706 12.1108 10.6437 12.408Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M14.6437 6.40805C14.3168 6.70525 14.2927 7.21121 14.5899 7.53814L15.1916 8.2H7C6.55817 8.2 6.2 8.55817 6.2 9C6.2 9.44183 6.55817 9.8 7 9.8H15.1916L14.5899 10.4619C14.2927 10.7888 14.3168 11.2947 14.6437 11.592C14.9706 11.8892 15.4766 11.8651 15.7738 11.5381L17.592 9.53814C17.8693 9.233 17.8693 8.767 17.592 8.46186L15.7738 6.46186C15.4766 6.13494 14.9706 6.11084 14.6437 6.40805Z"
  />
</svg>`;n.dy`<svg
  width="36"
  height="36"
  viewBox="0 0 36 36"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 14C8.25 11.9289 9.92893 10.25 12 10.25H24C26.0711 10.25 27.75 11.9289 27.75 14V22C27.75 24.0711 26.0711 25.75 24 25.75H12C9.92893 25.75 8.25 24.0711 8.25 22V14ZM12 11.75C10.7574 11.75 9.75 12.7574 9.75 14V22C9.75 23.2426 10.7574 24.25 12 24.25H24C25.2426 24.25 26.25 23.2426 26.25 22V14C26.25 12.7574 25.2426 11.75 24 11.75H12Z"
  />
</svg>`;let ee=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M6.46967 9.46967C6.76256 9.17678 7.23744 9.17678 7.53033 9.46967L11.6464 13.5858C11.8417 13.781 12.1583 13.781 12.3536 13.5858L16.4697 9.46967C16.7626 9.17678 17.2374 9.17678 17.5303 9.46967C17.8232 9.76256 17.8232 10.2374 17.5303 10.5303L13.4142 14.6464C12.6332 15.4275 11.3668 15.4275 10.5858 14.6464L6.46967 10.5303C6.17678 10.2374 6.17678 9.76256 6.46967 9.46967Z"
  />
</svg>`,et=n.YP`
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 6C3.25 4.48122 4.48122 3.25 6 3.25H14C14.4142 3.25 14.75 3.58579 14.75 4C14.75 4.41421 14.4142 4.75 14 4.75H6C5.30964 4.75 4.75 5.30964 4.75 6V20C4.75 20.4142 4.41421 20.75 4 20.75C3.58579 20.75 3.25 20.4142 3.25 20V6Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20.75 18C20.75 19.5188 19.5188 20.75 18 20.75H10C9.58579 20.75 9.25 20.4142 9.25 20C9.25 19.5858 9.58579 19.25 10 19.25L18 19.25C18.6904 19.25 19.25 18.6904 19.25 18L19.25 4C19.25 3.58579 19.5858 3.25 20 3.25C20.4142 3.25 20.75 3.58579 20.75 4L20.75 18Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 9C8.25 8.0335 9.0335 7.25 10 7.25H14C14.9665 7.25 15.75 8.0335 15.75 9V11C15.75 11.9665 14.9665 12.75 14 12.75H10C9.0335 12.75 8.25 11.9665 8.25 11V9ZM10 8.75C9.86193 8.75 9.75 8.86193 9.75 9V11C9.75 11.1381 9.86193 11.25 10 11.25H14C14.1381 11.25 14.25 11.1381 14.25 11V9C14.25 8.86193 14.1381 8.75 14 8.75H10Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 16C8.25 15.5858 8.58579 15.25 9 15.25H15C15.4142 15.25 15.75 15.5858 15.75 16C15.75 16.4142 15.4142 16.75 15 16.75H9C8.58579 16.75 8.25 16.4142 8.25 16Z"
  />`,ei=n.YP`<path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 6C3.25 4.48122 4.48122 3.25 6 3.25H14C14.4142 3.25 14.75 3.58579 14.75 4C14.75 4.41421 14.4142 4.75 14 4.75H6C5.30964 4.75 4.75 5.30964 4.75 6V20C4.75 20.4142 4.41421 20.75 4 20.75C3.58579 20.75 3.25 20.4142 3.25 20V6Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M20 10.75C19.5858 10.75 19.25 10.4142 19.25 10V4C19.25 3.58579 19.5858 3.25 20 3.25C20.4142 3.25 20.75 3.58579 20.75 4V10C20.75 10.4142 20.4142 10.75 20 10.75Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 9C8.25 8.0335 9.0335 7.25 10 7.25H14C14.9665 7.25 15.75 8.0335 15.75 9V11C15.75 11.9665 14.9665 12.75 14 12.75H10C9.0335 12.75 8.25 11.9665 8.25 11V9ZM10 8.75C9.86193 8.75 9.75 8.86193 9.75 9V11C9.75 11.1381 9.86193 11.25 10 11.25H14C14.1381 11.25 14.25 11.1381 14.25 11V9C14.25 8.86193 14.1381 8.75 14 8.75H10Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M8.25 16C8.25 15.5858 8.58579 15.25 9 15.25H12C12.4142 15.25 12.75 15.5858 12.75 16C12.75 16.4142 12.4142 16.75 12 16.75H9C8.58579 16.75 8.25 16.4142 8.25 16Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M18 14.75C17.5858 14.75 17.25 14.4142 17.25 14C17.25 13.5858 17.5858 13.25 18 13.25H20.9C20.9174 13.25 20.9346 13.2505 20.9517 13.2515C21.1594 13.2382 21.3716 13.3109 21.5303 13.4697C21.6891 13.6284 21.7618 13.8406 21.7485 14.0483C21.7495 14.0654 21.75 14.0826 21.75 14.1V17C21.75 17.4142 21.4142 17.75 21 17.75C20.5858 17.75 20.25 17.4142 20.25 17V15.8107L14.5303 21.5303C14.2374 21.8232 13.7626 21.8232 13.4697 21.5303C13.1768 21.2374 13.1768 20.7626 13.4697 20.4697L19.1893 14.75H18Z"
  />`,en=o(et),eo=o(ei),er=r(et,20),ea=r(ei,20),es=n.dy`<svg
  width="20"
  height="20"
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M12 3.25C12.4142 3.25 12.75 3.58579 12.75 4V20C12.75 20.4142 12.4142 20.75 12 20.75C11.5858 20.75 11.25 20.4142 11.25 20V4C11.25 3.58579 11.5858 3.25 12 3.25Z"
  />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M3.25 12C3.25 11.5858 3.58579 11.25 4 11.25H20C20.4142 11.25 20.75 11.5858 20.75 12C20.75 12.4142 20.4142 12.75 20 12.75H4C3.58579 12.75 3.25 12.4142 3.25 12Z"
  />
</svg>`,el=n.YP`<path
  fill-rule="evenodd"
  clip-rule="evenodd"
  d="M11 4.75C10.5858 4.75 10.25 4.41421 10.25 4C10.25 3.58579 10.5858 3.25 11 3.25H19.9C19.9174 3.25 19.9346 3.25052 19.9517 3.25155C20.1594 3.23823 20.3716 3.31093 20.5303 3.46967C20.6891 3.62841 20.7618 3.84059 20.7485 4.04829C20.7495 4.0654 20.75 4.08264 20.75 4.1V13C20.75 13.4142 20.4142 13.75 20 13.75C19.5858 13.75 19.25 13.4142 19.25 13V5.81066L4.53033 20.5303C4.23744 20.8232 3.76256 20.8232 3.46967 20.5303C3.17678 20.2374 3.17678 19.7626 3.46967 19.4697L18.1893 4.75H11Z"
/>`,ed=r(el,20),ec=r(el,16)},50634:function(e,t,i){"use strict";i.d(t,{z3:function(){return d},zN:function(){return S},Zi:function(){return s},$T:function(){return r}});var n=i(32916),o=i(43312);function r(e){return class extends e{constructor(){super(...arguments),this._disposables=new o.S}connectedCallback(){super.connectedCallback(),this._disposables.disposed&&(this._disposables=new o.S)}disconnectedCallback(){super.disconnectedCallback(),this._disposables.dispose()}}}var a=i(15486);class s extends a.oi{static finalizeStyles(e){let t=super.finalizeStyles(e),i=document.head;return this.disableShadowRoot&&(t.forEach(e=>{if(e instanceof a.c3){let t=document.createElement("style");t.textContent=e.cssText,i.appendChild(t)}else console.error("unreachable")}),t=[]),t}createRenderRoot(){return this.constructor.disableShadowRoot?this:super.createRenderRoot()}}s.disableShadowRoot=!0;var l=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class d extends r(s){}l([(0,n.Cb)()],d.prototype,"root",void 0),l([(0,n.Cb)()],d.prototype,"model",void 0),l([(0,n.Cb)()],d.prototype,"content",void 0),l([(0,n.Cb)()],d.prototype,"page",void 0);var c=i(57891),h=i(68815),u=i(31054);class f{constructor(e){this.event=e,this.type="defaultState"}}class p{constructor(){this._map={},this.add=e=>{let t=e.type;this._map[t]&&console.warn("UIEventStateContext: state name duplicated",t),this._map[t]=e},this.has=e=>!!this._map[e],this.get=e=>{let t=this._map[e];return(0,u.kP)(t,`UIEventStateContext: state ${e} not found`),t}}static from(...e){let t=new p;return e.forEach(e=>{t.add(e)}),t}}class g extends f{get x(){return this.point.x}get y(){return this.point.y}constructor({event:e,rect:t,startX:i,startY:n,last:o}){super(e),this.type="pointerState";let r=e.clientX-t.left,a=e.clientY-t.top;this.raw=e,this.point={x:r,y:a},this.containerOffset={x:t.left,y:t.top},this.start={x:i,y:n},this.delta=o?{x:r-o.point.x,y:a-o.point.y}:{x:0,y:0},this.keys={shift:e.shiftKey,cmd:e.metaKey||e.ctrlKey,alt:e.altKey},this.button=o?.button||e.button,this.dragging=!!o}}class m extends f{constructor({event:e}){super(e),this.type="keyboardState",this.raw=e}}class v{constructor(e){this._dispatcher=e,this._down=e=>{let t=new m({event:e});this._dispatcher.run("keyDown",p.from(t))},this._up=e=>{let t=new m({event:e});this._dispatcher.run("keyUp",p.from(t))}}listen(){this._dispatcher.disposables.addFromEvent(document,"keydown",this._down),this._dispatcher.disposables.addFromEvent(document,"keyup",this._up)}}function b(e,t){let i=e.x-t.x,n=e.y-t.y;return Math.pow(i,2)+Math.pow(n,2)>4}let C=e=>e.toLowerCase();class y{constructor(e){this._dispatcher=e,this._lastPointerDownEvent=null,this._startDragState=null,this._lastDragState=null,this._pointerDownCount=0,this._dragging=!1,this._startX=-1/0,this._startY=-1/0,this._reset=()=>{this._startX=-1/0,this._startY=-1/0,this._lastDragState=null,this._dragging=!1},this._down=e=>{this._lastPointerDownEvent&&e.timeStamp-this._lastPointerDownEvent.timeStamp<500&&!b(e,this._lastPointerDownEvent)?this._pointerDownCount++:this._pointerDownCount=1;let t=new g({event:e,rect:this._rect,startX:this._startX,startY:this._startY,last:null});this._startX=t.point.x,this._startY=t.point.y,this._startDragState=t,this._lastDragState=t,this._lastPointerDownEvent=e,this._dispatcher.run("pointerDown",p.from(t)),this._dispatcher.disposables.addFromEvent(document,"pointermove",this._move),this._dispatcher.disposables.addFromEvent(document,"pointerup",this._up)},this._up=e=>{let t=new g({event:e,rect:this._rect,startX:this._startX,startY:this._startY,last:this._lastDragState}),i=p.from(t);(()=>{if(this._dragging){this._dispatcher.run("dragEnd",i);return}this._dispatcher.run("click",i),2===this._pointerDownCount&&this._dispatcher.run("doubleClick",i),3===this._pointerDownCount&&this._dispatcher.run("tripleClick",i)})(),this._dispatcher.run("pointerUp",i),this._reset(),document.removeEventListener("pointermove",this._move),document.removeEventListener("pointerup",this._up)},this._move=e=>{let t=this._lastDragState,i=new g({event:e,rect:this._rect,startX:this._startX,startY:this._startY,last:t});this._lastDragState=i,(0,u.kP)(this._startDragState),!this._dragging&&b(this._startDragState.raw,i.raw)&&(this._dragging=!0,this._dispatcher.run("dragStart",p.from(this._startDragState))),this._dragging&&this._dispatcher.run("dragMove",p.from(i))},this._moveOn=e=>{let t=new g({event:e,rect:this._rect,startX:this._startX,startY:this._startY,last:this._lastDragState});this._dispatcher.run("pointerMove",p.from(t))},this._out=e=>{let t=new g({event:e,rect:this._rect,startX:-1/0,startY:-1/0,last:null});this._dispatcher.run("pointerOut",p.from(t))}}listen(){this._dispatcher.disposables.addFromEvent(this._dispatcher.root,"pointerdown",this._down),this._dispatcher.disposables.addFromEvent(this._dispatcher.root,"pointermove",this._moveOn),this._dispatcher.disposables.addFromEvent(this._dispatcher.root,"pointerout",this._out)}get _rect(){return this._dispatcher.root.getBoundingClientRect()}}let x=["beforeInput","compositionStart","compositionUpdate","compositionEnd","paste","copy","blur","focus","drop","contextMenu","wheel"],w=["selectionChange","virgo-vrange-updated"],_=["click","doubleClick","tripleClick","pointerDown","pointerMove","pointerUp","pointerOut","dragStart","dragMove","dragEnd","keyDown","keyUp",...x,...w];class k{constructor(e){this.root=e,this.disposables=new o.S,this._handlersMap=Object.fromEntries(_.map(e=>[e,[]])),this._pointerControl=new y(this),this._keyboardControl=new v(this)}mount(){this.disposables.disposed&&(this.disposables=new o.S),this._bindEvents()}unmount(){this.disposables.dispose()}run(e,t){let i=this._handlersMap[e];if(i)for(let e of i){let i=e(t);if(i)return}}add(e,t){return this._handlersMap[e].unshift(t),()=>{this._handlersMap[e].includes(t)&&(this._handlersMap[e]=this._handlersMap[e].filter(e=>e!==t))}}_bindEvents(){x.forEach(e=>{this.disposables.addFromEvent(this.root,C(e),t=>{this.run(e,p.from(new f(t)))})}),w.forEach(e=>{this.disposables.addFromEvent(document,C(e),t=>{this.run(e,p.from(new f(t)))})}),this._pointerControl.listen(),this._keyboardControl.listen()}}var M=function(e,t,i,n){var o,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(r<3?o(a):r>3?o(t,i,a):o(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let S=class extends s{constructor(){super(...arguments),this.blockIdAttr="data-block-id",this.modelSubscribed=new Set,this.uiEventDispatcher=new k(this),this.renderModel=e=>{let{flavour:t,children:i}=e,n=this.page.schema.flavourSchemaMap.get(t);if(!n)return console.warn(`Cannot find schema for ${t}.`),h.dy`${a.Ld}`;let o=this.componentMap.get(n);return o?(this._onLoadModel(e),h.dy`<${o}
      ${(0,h.s2)(this.blockIdAttr)}=${e.id}
      .root=${this}
      .page=${this.page}
      .model=${e}
      .content=${h.dy`${(0,c.r)(i,e=>e.id,e=>this.renderModel(e))}`}
    ></${o}>`):(console.warn(`Cannot find tag for ${t}.`),h.dy`${a.Ld}`)},this._onLoadModel=e=>{let{id:t}=e;this.modelSubscribed.has(t)||(e.propsUpdated.on(()=>{this.requestUpdate()}),e.childrenUpdated.on(()=>{this.requestUpdate()}),this.modelSubscribed.add(t))}}connectedCallback(){super.connectedCallback(),this.uiEventDispatcher.mount()}disconnectedCallback(){super.disconnectedCallback(),this.uiEventDispatcher.unmount()}render(){let{root:e}=this.page;return e?this.renderModel(e):null}};M([(0,n.Cb)()],S.prototype,"componentMap",void 0),M([(0,n.Cb)()],S.prototype,"page",void 0),M([(0,n.Cb)()],S.prototype,"blockIdAttr",void 0),S=M([(0,n.Mo)("block-suite-root")],S)},45598:function(e,t,i){"use strict";i.d(t,{Mb:function(){return k},vy:function(){return O},oI:function(){return j},qb:function(){return U},Bo:function(){return te},Gy:function(){return ei},yF:function(){return n},tm:function(){return o},V4:function(){return r},qu:function(){return el},r3:function(){return S},CV:function(){return _},vk:function(){return e8},zJ:function(){return function e(t,i,n,o=e2){if(0===n)return[];if(1===n)return[e8(t,i,o)];if(null==i){let e=e8(t,i,o),r=[e];for(let t=0;t<n-1;t++)r.push(e=e8(e,i,o));return r}if(null==t){let e=e8(t,i,o),r=[e];for(let i=0;i<n-1;i++)r.push(e=e8(t,e,o));return r.reverse(),r}let r=Math.floor(n/2),a=e8(t,i,o);return[...e(t,a,r,o),a,...e(a,i,n-r-1,o)]}},ci:function(){return M},kK:function(){return B},Gn:function(){return P},rQ:function(){return e9},cJ:function(){return w}});let n=6,o=.1,r=.25;function a(e,t,i,n=e=>e){return e*n(.5-t*(.5-i))}function s(e,t){return[e[0]+t[0],e[1]+t[1]]}function l(e,t){return[e[0]-t[0],e[1]-t[1]]}function d(e,t){return[e[0]*t,e[1]*t]}function c(e){return[e[1],-e[0]]}function h(e,t){return e[0]*t[0]+e[1]*t[1]}function u(e,t){var i;return(i=l(e,t))[0]*i[0]+i[1]*i[1]}function f(e){var t;return t=Math.hypot(e[0],e[1]),[e[0]/t,e[1]/t]}function p(e,t,i){let n=Math.sin(i),o=Math.cos(i),r=e[0]-t[0],a=e[1]-t[1];return[r*o-a*n+t[0],r*n+a*o+t[1]]}function g(e,t,i){return s(e,d(l(t,e),i))}(A=U||(U={})).Solid="solid",A.Dashed="dash",A.None="none",(H=j||(j={}))[H.Straight=0]="Straight",H[H.Orthogonal=1]="Orthogonal";let{min:m,PI:v}=Math,b=v+1e-4;class C{static clamp(e,t,i){return Math.max(t,void 0!==i?Math.min(e,i):e)}static clampV(e,t,i){return e.map(e=>i?C.clamp(e,t,i):C.clamp(e,t))}static cross(e,t,i){return(t[0]-e[0])*(i[1]-e[1])-(i[0]-e[0])*(t[1]-e[1])}static snap(e,t=1){return[Math.round(e[0]/t)*t,Math.round(e[1]/t)*t]}}C.neg=e=>[-e[0],-e[1]],C.add=(e,t)=>[e[0]+t[0],e[1]+t[1]],C.addScalar=(e,t)=>[e[0]+t,e[1]+t],C.sub=(e,t)=>[e[0]-t[0],e[1]-t[1]],C.subScalar=(e,t)=>[e[0]-t,e[1]-t],C.vec=(e,t)=>[t[0]-e[0],t[1]-e[1]],C.mul=(e,t)=>[e[0]*t,e[1]*t],C.mulV=(e,t)=>[e[0]*t[0],e[1]*t[1]],C.div=(e,t)=>[e[0]/t,e[1]/t],C.divV=(e,t)=>[e[0]/t[0],e[1]/t[1]],C.per=e=>[e[1],-e[0]],C.dpr=(e,t)=>e[0]*t[0]+e[1]*t[1],C.cpr=(e,t)=>e[0]*t[1]-t[0]*e[1],C.len2=e=>e[0]*e[0]+e[1]*e[1],C.len=e=>Math.hypot(e[0],e[1]),C.pry=(e,t)=>C.dpr(e,t)/C.len(t),C.uni=e=>C.div(e,C.len(e)),C.normalize=e=>C.uni(e),C.tangent=(e,t)=>C.uni(C.sub(e,t)),C.dist2=(e,t)=>C.len2(C.sub(e,t)),C.dist=(e,t)=>Math.hypot(e[1]-t[1],e[0]-t[0]),C.fastDist=(e,t)=>{let i=[t[0]-e[0],t[1]-e[1]],n=[Math.abs(i[0]),Math.abs(i[1])],o=1/Math.max(n[0],n[1]);return[i[0]*(o*=1.29289-(n[0]+n[1])*o*.29289),i[1]*o]},C.ang=(e,t)=>Math.atan2(C.cpr(e,t),C.dpr(e,t)),C.angle=(e,t)=>Math.atan2(t[1]-e[1],t[0]-e[0]),C.med=(e,t)=>C.mul(C.add(e,t),.5),C.rot=(e,t=0)=>[e[0]*Math.cos(t)-e[1]*Math.sin(t),e[0]*Math.sin(t)+e[1]*Math.cos(t)],C.rotWith=(e,t,i=0)=>{if(0===i)return e;let n=Math.sin(i),o=Math.cos(i),r=e[0]-t[0],a=e[1]-t[1];return[r*o-a*n+t[0],r*n+a*o+t[1]]},C.isEqual=(e,t)=>e[0]===t[0]&&e[1]===t[1],C.lrp=(e,t,i)=>C.add(e,C.mul(C.sub(t,e),i)),C.int=(e,t,i,n,o=1)=>{let r=(C.clamp(i,n)-i)/(n-i);return C.add(C.mul(e,1-r),C.mul(t,o))},C.ang3=(e,t,i)=>{let n=C.vec(t,e),o=C.vec(t,i);return C.ang(n,o)},C.abs=e=>[Math.abs(e[0]),Math.abs(e[1])],C.rescale=(e,t)=>{let i=C.len(e);return[t*e[0]/i,t*e[1]/i]},C.isLeft=(e,t,i)=>(t[0]-e[0])*(i[1]-e[1])-(i[0]-e[0])*(t[1]-e[1]),C.clockwise=(e,t,i)=>C.isLeft(e,t,i)>0,C.toFixed=e=>e.map(e=>Math.round(100*e)/100),C.nearestPointOnLineThroughPoint=(e,t,i)=>C.add(e,C.mul(t,C.pry(C.sub(i,e),t))),C.distanceToLineThroughPoint=(e,t,i)=>C.dist(i,C.nearestPointOnLineThroughPoint(e,t,i)),C.nearestPointOnLineSegment=(e,t,i,n=!0)=>{let o=C.uni(C.sub(t,e)),r=C.add(e,C.mul(o,C.pry(C.sub(i,e),o)));if(n){if(r[0]<Math.min(e[0],t[0]))return e[0]<t[0]?e:t;if(r[0]>Math.max(e[0],t[0]))return e[0]>t[0]?e:t;if(r[1]<Math.min(e[1],t[1]))return e[1]<t[1]?e:t;if(r[1]>Math.max(e[1],t[1]))return e[1]>t[1]?e:t}return r},C.distanceToLineSegment=(e,t,i,n=!0)=>C.dist(i,C.nearestPointOnLineSegment(e,t,i,n)),C.nearestPointOnBounds=(e,t)=>[C.clamp(t[0],e.minX,e.maxX),C.clamp(t[1],e.minY,e.maxY)],C.distanceToBounds=(e,t)=>C.dist(t,C.nearestPointOnBounds(e,t)),C.nudge=(e,t,i)=>C.isEqual(e,t)?e:C.add(e,C.mul(C.uni(C.sub(t,e)),i)),C.nudgeAtAngle=(e,t,i)=>[Math.cos(t)*i+e[0],Math.sin(t)*i+e[1]],C.toPrecision=(e,t=4)=>[+e[0].toPrecision(t),+e[1].toPrecision(t)],C.pointsBetween=(e,t,i=6)=>Array.from(Array(i)).map((n,o)=>{let r=o/(i-1);return[...C.lrp(e,t,r),Math.min(1,.5+Math.abs(.5-r))]}),C.slope=(e,t)=>e[0]===t[0]?NaN:(e[1]-t[1])/(e[0]-t[0]),C.max=(...e)=>[Math.max(...e.map(e=>e[0])),Math.max(...e.map(e=>e[1]))],C.min=(...e)=>[Math.min(...e.map(e=>e[0])),Math.min(...e.map(e=>e[1]))];let y=2*Math.PI;(V=N||(N={})).Top="top_edge",V.Right="right_edge",V.Bottom="bottom_edge",V.Left="left_edge",(Z=W||(W={})).TopLeft="top_left_corner",Z.TopRight="top_right_corner",Z.BottomRight="bottom_right_corner",Z.BottomLeft="bottom_left_corner",(F=q||(q={})).minX="minX",F.midX="midX",F.maxX="maxX",F.minY="minY",F.midY="midY",F.maxY="maxY";class x{static lerp(e,t,i){return e*(1-(i=x.clamp(i,0,1)))+t*i}static lerpColor(e,t,i=.5){function n(e){let t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return[parseInt(t[1],16),parseInt(t[2],16),parseInt(t[3],16)]}let o=n(e)||[0,0,0],r=n(t)||[0,0,0],a=o.slice();for(let e=0;e<3;e++)a[e]=Math.round(a[e]+i*(r[e]-o[e]));return"#"+(16777216+(a[0]<<16)+(a[1]<<8)+a[2]).toString(16).slice(1)}static modulate(e,t,i,n=!1){let[o,r]=t,[a,s]=i,l=a+(e-o)/(r-o)*(s-a);return n?a<s?Math.max(Math.min(l,s),a):Math.max(Math.min(l,a),s):l}static clamp(e,t,i){return Math.max(t,void 0!==i?Math.min(e,i):e)}static deepClone(e){if(null===e)return e;if(Array.isArray(e))return[...e];if("object"==typeof e){let t={...e};return Object.keys(t).forEach(i=>t[i]="object"==typeof e[i]?x.deepClone(e[i]):e[i]),t}return e}static rng(e=""){let t=0,i=0,n=0,o=0;function r(){let e=t^t<<11;return t=i,i=n,n=o,(o^=(o>>>19^e^e>>>8)>>>0)/4294967296}for(let i=0;i<e.length+64;i++)t^=0|e.charCodeAt(i),r();return r}static pointsToLineSegments(e,t=!1){let i=[];for(let t=1;t<e.length;t++)i.push([e[t-1],e[t]]);return t&&i.push([e[e.length-1],e[0]]),i}static getRectangleSides(e,t,i=0){let n=[e[0]+t[0]/2,e[1]+t[1]/2],o=C.rotWith(e,n,i),r=C.rotWith(C.add(e,[t[0],0]),n,i),a=C.rotWith(C.add(e,t),n,i),s=C.rotWith(C.add(e,[0,t[1]]),n,i);return[["top",[o,r]],["right",[r,a]],["bottom",[a,s]],["left",[s,o]]]}static circleFromThreePoints(e,t,i){let[n,o]=e,[r,a]=t,[s,l]=i,d=n*(a-l)-o*(r-s)+r*l-s*a,c=-((n*n+o*o)*(l-a)+(r*r+a*a)*(o-l)+(s*s+l*l)*(a-o))/(2*d),h=-((n*n+o*o)*(r-s)+(r*r+a*a)*(s-n)+(s*s+l*l)*(n-r))/(2*d);return[c,h,Math.hypot(c-n,h-o)]}static perimeterOfEllipse(e,t){let i=Math.pow(e-t,2)/Math.pow(e+t,2);return Math.PI*(e+t)*(1+3*i/(10+Math.sqrt(4-3*i)))}static shortAngleDist(e,t){let i=2*Math.PI,n=(t-e)%i;return 2*n%i-n}static longAngleDist(e,t){return 2*Math.PI-x.shortAngleDist(e,t)}static lerpAngles(e,t,i){return e+x.shortAngleDist(e,t)*i}static angleDelta(e,t){return x.shortAngleDist(e,t)}static getSweep(e,t,i){return x.angleDelta(C.angle(e,t),C.angle(e,i))}static clampRadians(e){return(2*Math.PI+e)%(2*Math.PI)}static snapAngleToSegments(e,t){let i=2*Math.PI/t;return Math.floor((x.clampRadians(e)+i/2)/i)*i}static isAngleBetween(e,t,i){if(i===e||i===t)return!0;let n=(t-e+y)%y;return n<=Math.PI!=(i-e+y)%y>n}static degreesToRadians(e){return e*Math.PI/180}static radiansToDegrees(e){return 180*e/Math.PI}static getArcLength(e,t,i,n){let o=x.getSweep(e,i,n);return t*(2*Math.PI)*(o/(2*Math.PI))}static getSweepFlag(e,t,i){let n=C.angle(e,i),o=C.angle(e,t);return(o-n+3*Math.PI)%(2*Math.PI)-Math.PI>0?0:1}static getLargeArcFlag(e,t,i){let n=C.angle(i,e),o=C.angle(i,t);return Math.abs((o-n+3*Math.PI)%(2*Math.PI)-Math.PI)>Math.PI/2?0:1}static getArcDashOffset(e,t,i,n,o){let r=x.getSweepFlag(e,i,n),a=x.getArcLength(e,t,i,n),s=r<0?a:2*Math.PI*e[2]-a;return-s/2+o}static getEllipseDashOffset(e,t){let i=2*Math.PI*e[2];return-i/2+-t}static pointInCircle(e,t,i){return C.dist(e,t)<=i}static pointInEllipse(e,t,i,n,o=0){o=o||0;let r=Math.cos(o),a=Math.sin(o),s=C.sub(e,t),l=r*s[0]+a*s[1],d=a*s[0]-r*s[1];return l*l/(i*i)+d*d/(n*n)<=1}static pointInRect(e,t){return!(e[0]<t[0]||e[0]>e[0]+t[0]||e[1]<t[1]||e[1]>e[1]+t[1])}static pointInPolygon(e,t){let i=0;return t.forEach((n,o)=>{let r=t[(o+1)%t.length];n[1]<=e[1]?r[1]>e[1]&&C.cross(n,r,e)>0&&(i+=1):r[1]<=e[1]&&0>C.cross(n,r,e)&&(i-=1)}),0!==i}static pointInBounds(e,t){return!(e[0]<t.minX||e[0]>t.maxX||e[1]<t.minY||e[1]>t.maxY)}static pointInPolyline(e,t,i=3){for(let n=1;n<t.length;n++)if(C.distanceToLineSegment(t[n-1],t[n],e)<i)return!0;return!1}static getBoundsSides(e){return this.getRectangleSides([e.minX,e.minY],[e.width,e.height])}static expandBounds(e,t){return{minX:e.minX-t,minY:e.minY-t,maxX:e.maxX+t,maxY:e.maxY+t,width:e.width+2*t,height:e.height+2*t}}static boundsCollide(e,t){return!(e.maxX<t.minX||e.minX>t.maxX||e.maxY<t.minY||e.minY>t.maxY)}static boundsContain(e,t){return e.minX<t.minX&&e.minY<t.minY&&e.maxY>t.maxY&&e.maxX>t.maxX}static boundsContained(e,t){return x.boundsContain(t,e)}static boundsAreEqual(e,t){return!(t.maxX!==e.maxX||t.minX!==e.minX||t.maxY!==e.maxY||t.minY!==e.minY)}static getBoundsFromPoints(e,t=0){let i=1/0,n=1/0,o=-1/0,r=-1/0;if(e.length<2)i=0,n=0,o=1,r=1;else for(let[t,a]of e)i=Math.min(t,i),n=Math.min(a,n),o=Math.max(t,o),r=Math.max(a,r);return 0!==t?x.getBoundsFromPoints(e.map(e=>C.rotWith(e,[(i+o)/2,(n+r)/2],t))):{minX:i,minY:n,maxX:o,maxY:r,width:Math.max(1,o-i),height:Math.max(1,r-n)}}static centerBounds(e,t){let i=this.getBoundsCenter(e),n=t[0]-i[0],o=t[1]-i[1];return this.translateBounds(e,[n,o])}static snapBoundsToGrid(e,t){let i=Math.round(e.minX/t)*t,n=Math.round(e.minY/t)*t,o=Math.round(e.maxX/t)*t,r=Math.round(e.maxY/t)*t;return{minX:i,minY:n,maxX:o,maxY:r,width:Math.max(1,o-i),height:Math.max(1,r-n)}}static translateBounds(e,t){return{minX:e.minX+t[0],minY:e.minY+t[1],maxX:e.maxX+t[0],maxY:e.maxY+t[1],width:e.width,height:e.height}}static rotateBounds(e,t,i){let[n,o]=C.rotWith([e.minX,e.minY],t,i),[r,a]=C.rotWith([e.maxX,e.maxY],t,i);return{minX:n,minY:o,maxX:r,maxY:a,width:e.width,height:e.height}}static getRotatedEllipseBounds(e,t,i,n,o=0){let r=Math.cos(o),a=Math.sin(o),s=Math.hypot(i*r,n*a),l=Math.hypot(i*a,n*r);return{minX:e+i-s,minY:t+n-l,maxX:e+i+s,maxY:t+n+l,width:2*s,height:2*l}}static getExpandedBounds(e,t){let i=Math.min(e.minX,t.minX),n=Math.min(e.minY,t.minY),o=Math.max(e.maxX,t.maxX),r=Math.max(e.maxY,t.maxY);return{minX:i,minY:n,maxX:o,maxY:r,width:Math.abs(o-i),height:Math.abs(r-n)}}static getCommonBounds(e){if(e.length<2)return e[0];let t=e[0];for(let i=1;i<e.length;i++)t=x.getExpandedBounds(t,e[i]);return t}static getRotatedCorners(e,t=0){let i=[e.minX+e.width/2,e.minY+e.height/2];return[[e.minX,e.minY],[e.maxX,e.minY],[e.maxX,e.maxY],[e.minX,e.maxY]].map(e=>C.rotWith(e,i,t))}static getTransformedBoundingBox(e,t,i,n=0,o=!1){let[r,a]=[e.minX,e.minY],[s,l]=[e.maxX,e.maxY],[d,c]=[e.minX,e.minY],[h,u]=[e.maxX,e.maxY];if("center"===t)return{minX:d+i[0],minY:c+i[1],maxX:h+i[0],maxY:u+i[1],width:h-d,height:u-c,scaleX:1,scaleY:1};let[f,p]=C.rot(i,-n);switch(t){case N.Top:case W.TopLeft:case W.TopRight:c+=p;break;case N.Bottom:case W.BottomLeft:case W.BottomRight:u+=p}switch(t){case N.Left:case W.TopLeft:case W.BottomLeft:d+=f;break;case N.Right:case W.TopRight:case W.BottomRight:h+=f}let g=s-r,m=l-a,v=(h-d)/g,b=(u-c)/m,y=Math.abs(h-d),x=Math.abs(u-c);if(o){let e=g/m,i=e<y/x,n=y*(b<0?1:-1)*(1/e),o=x*(v<0?1:-1)*e;switch(t){case W.TopLeft:i?c=u+n:d=h+o;break;case W.TopRight:i?c=u+n:h=d-o;break;case W.BottomRight:i?u=c-n:h=d-o;break;case W.BottomLeft:i?u=c-n:d=h+o;break;case N.Bottom:case N.Top:{let t=(d+h)/2,i=x*e;d=t-i/2,h=t+i/2;break}case N.Left:case N.Right:{let t=(c+u)/2,i=y/e;c=t-i/2,u=t+i/2}}}if(n%(2*Math.PI)!=0){let e=[0,0],i=C.med([r,a],[s,l]),o=C.med([d,c],[h,u]);switch(t){case W.TopLeft:e=C.sub(C.rotWith([h,u],o,n),C.rotWith([s,l],i,n));break;case W.TopRight:e=C.sub(C.rotWith([d,u],o,n),C.rotWith([r,l],i,n));break;case W.BottomRight:e=C.sub(C.rotWith([d,c],o,n),C.rotWith([r,a],i,n));break;case W.BottomLeft:e=C.sub(C.rotWith([h,c],o,n),C.rotWith([s,a],i,n));break;case N.Top:e=C.sub(C.rotWith(C.med([d,u],[h,u]),o,n),C.rotWith(C.med([r,l],[s,l]),i,n));break;case N.Left:e=C.sub(C.rotWith(C.med([h,c],[h,u]),o,n),C.rotWith(C.med([s,a],[s,l]),i,n));break;case N.Bottom:e=C.sub(C.rotWith(C.med([d,c],[h,c]),o,n),C.rotWith(C.med([r,a],[s,a]),i,n));break;case N.Right:e=C.sub(C.rotWith(C.med([d,c],[d,u]),o,n),C.rotWith(C.med([r,a],[r,l]),i,n))}[d,c]=C.sub([d,c],e),[h,u]=C.sub([h,u],e)}return h<d&&([h,d]=[d,h]),u<c&&([u,c]=[c,u]),{minX:d,minY:c,maxX:h,maxY:u,width:h-d,height:u-c,scaleX:(h-d)/(s-r||1)*(v<0?-1:1),scaleY:(u-c)/(l-a||1)*(b<0?-1:1)}}static getTransformAnchor(e,t,i){let n=e;switch(e){case W.TopLeft:n=t&&i?W.BottomRight:t?W.TopRight:i?W.BottomLeft:W.BottomRight;break;case W.TopRight:n=t&&i?W.BottomLeft:t?W.TopLeft:i?W.BottomRight:W.BottomLeft;break;case W.BottomRight:n=t&&i?W.TopLeft:t?W.BottomLeft:i?W.TopRight:W.TopLeft;break;case W.BottomLeft:n=t&&i?W.TopRight:t?W.BottomRight:i?W.TopLeft:W.TopRight}return n}static getRelativeTransformedBoundingBox(e,t,i,n,o){let r=(n?t.maxX-i.maxX:i.minX-t.minX)/t.width,a=(o?t.maxY-i.maxY:i.minY-t.minY)/t.height,s=i.width/t.width,l=i.height/t.height,d=e.minX+e.width*r,c=e.minY+e.height*a,h=e.width*s,u=e.height*l;return{minX:d,minY:c,maxX:d+h,maxY:c+u,width:h,height:u}}static getRotatedSize(e,t){let i=C.div(e,2),n=[[0,0],[e[0],0],e,[0,e[1]]].map(e=>C.rotWith(e,i,t)),o=x.getBoundsFromPoints(n);return[o.width,o.height]}static getBoundsCenter(e){return[e.minX+e.width/2,e.minY+e.height/2]}static getBoundsWithCenter(e){let t=x.getBoundsCenter(e);return{...e,midX:t[0],midY:t[1]}}static getCommonTopLeft(e){let t=[1/0,1/0];return e.forEach(e=>{t[0]=Math.min(t[0],e[0]),t[1]=Math.min(t[1],e[1])}),t}static getFromCache(e,t,i){let n=e.get(t);if(void 0===n&&(e.set(t,i()),void 0===(n=e.get(t))))throw Error("Cache did not include item!");return n}static uniqueId(e=""){return e?((Number(e)^16*Math.random())>>Number(e)/4).toString(16):"10000000-1000-4000-8000-100000000000".replace(/[018]/g,x.uniqueId)}static rotateArray(e,t){return e.map((i,n)=>e[(n+t)%e.length])}static debounce(e,t=0){let i;return function(...n){clearTimeout(i),i=setTimeout(()=>e.apply(n),t)}}static getSvgPathFromStroke(e,t=!0){var i,n,o,r,a,s;let l=e.length;if(l<4)return"";let d=e[0],c=e[1],h=e[2],u=`M${d[0].toFixed(2)},${d[1].toFixed(2)} Q${c[0].toFixed(2)},${c[1].toFixed(2)} ${(((i=c[0])+(n=h[0]))/2).toFixed(2)},${(((o=c[1])+(r=h[1]))/2).toFixed(2)} T`;for(let t=2,i=l-1;t<i;t++)d=e[t],c=e[t+1],u+=`${((d[0]+(0,c[0]))/2).toFixed(2)},${((d[1]+(0,c[1]))/2).toFixed(2)} `;return t&&(u+="Z"),u}static getSvgPathFromStrokePoints(e,t=!1){var i,n,o,r,a,s;let l=e.length;if(l<4)return"";let d=e[0].point,c=e[1].point,h=e[2].point,u=`M${d[0].toFixed(2)},${d[1].toFixed(2)} Q${c[0].toFixed(2)},${c[1].toFixed(2)} ${(((i=c[0])+(n=h[0]))/2).toFixed(2)},${(((o=c[1])+(r=h[1]))/2).toFixed(2)} T`;for(let t=2,i=l-1;t<i;t++)d=e[t].point,c=e[t+1].point,u+=`${((d[0]+(0,c[0]))/2).toFixed(2)},${((d[1]+(0,c[1]))/2).toFixed(2)} `;return t&&(u+="Z"),u}static getPerfectDashProps(e,t,i,n=1,o=!0,r=2){let a,s,l;if("dashed"===i.toLowerCase())a=t*r,l=1,s=o?(a/2).toString():"0";else{if("dotted"!==i.toLowerCase())return{strokeDasharray:"none",strokeDashoffset:"none"};a=t/100,l=100,s="0"}let d=Math.floor(e/a/(2*l));d-=d%n,d=Math.max(d,4);let c=Math.max(a,(e-d*a)/(o?d:d-1));return{strokeDasharray:[a,c].join(" "),strokeDashoffset:s}}static isMobileSafari(){if("undefined"==typeof window)return!1;let e=window.navigator.userAgent,t=!!e.match(/iPad/i)||!!e.match(/iPhone/i),i=!!e.match(/WebKit/i);return t&&i&&!e.match(/CriOS/i)}static throttle(e,t){let i,n;return function(...o){return i||(i=!0,setTimeout(()=>i=!1,t),n=e(...o)),n}}static isDarwin(){return/Mac|iPod|iPhone|iPad/.test(window.navigator.platform)}static metaKey(e){return x.isDarwin()?e.metaKey:e.ctrlKey}static lns(e){let t=e.split("");return t.push(...t.splice(0,Math.round(t.length/5))),t.push(...t.splice(0,Math.round(t.length/4))),t.push(...t.splice(0,Math.round(t.length/3))),t.push(...t.splice(0,Math.round(t.length/2))),t.reverse().map(e=>+e?5>+e?5+ +e:+e>5?+e-5:e:e).join("")}}function w(e,t,i,n){return`[${e},${t},${i},${n}]`}function _(e){return JSON.parse(e)}x.getSnapPoints=(e,t,i)=>{let n={...e},o=[0,0],r=[],a={[q.minX]:{id:q.minX,isSnapped:!1},[q.midX]:{id:q.midX,isSnapped:!1},[q.maxX]:{id:q.maxX,isSnapped:!1},[q.minY]:{id:q.minY,isSnapped:!1},[q.midY]:{id:q.midY,isSnapped:!1},[q.maxY]:{id:q.maxY,isSnapped:!1}},s=[q.midX,q.minX,q.maxX],l=[q.midY,q.minY,q.maxY],d=t.map(e=>{let t=s.flatMap((t,i)=>s.map((o,r)=>{let a=n[t]-e[o];return{f:t,t:o,gap:a,distance:Math.abs(a),isCareful:0===i||i+r===3}})),i=l.flatMap((t,i)=>l.map((o,r)=>{let a=n[t]-e[o];return{f:t,t:o,gap:a,distance:Math.abs(a),isCareful:0===i||i+r===3}}));return[e,t,i]}),c=1/0,h=1/0,u=1/0,f=1/0;return d.forEach(([e,t,n])=>{t.forEach(e=>{e.distance<i&&e.distance<u&&(u=e.distance,c=e.gap)}),n.forEach(e=>{e.distance<i&&e.distance<f&&(f=e.distance,h=e.gap)})}),d.forEach(([e,t,i])=>{c!==1/0&&t.forEach(t=>{2>Math.abs(t.gap-c)&&(a[t.f]={...a[t.f],isSnapped:!0,to:e[t.t],B:e,distance:t.distance})}),h!==1/0&&i.forEach(t=>{2>Math.abs(t.gap-h)&&(a[t.f]={...a[t.f],isSnapped:!0,to:e[t.t],B:e,distance:t.distance})})}),o[0]=c===1/0?0:c,o[1]=h===1/0?0:h,n.minX-=o[0],n.midX-=o[0],n.maxX-=o[0],n.minY-=o[1],n.midY-=o[1],n.maxY-=o[1],s.forEach(e=>{let t=a[e];if(!t.isSnapped)return;let{id:i,B:o}=t,s=n[i];r.push(i===q.minX?[[s,n.midY],[s,o.minY],[s,o.maxY]]:[[s,n.minY],[s,n.maxY],[s,o.minY],[s,o.maxY]])}),l.forEach(e=>{let t=a[e];if(!t.isSnapped)return;let{id:i,B:o}=t,s=n[i];r.push(i===q.midY?[[n.midX,s],[o.minX,s],[o.maxX,s]]:[[n.minX,s],[n.maxX,s],[o.minX,s],[o.maxX,s]])}),{offset:o,snapLines:r}},x.deepMerge=(e,t)=>{let i={...e},n=Object.entries(t);for(let[e,t]of n)i[e]=t!==Object(t)||Array.isArray(t)?t:x.deepMerge(i[e],t);return i};class k{constructor(e,t,i,n){this.x=e,this.y=t,this.w=i,this.h=n}serialize(){return w(this.x,this.y,this.w,this.h)}static deserialize(e){let[t,i,n,o]=_(e);return new k(t,i,n,o)}}function M(e){if(!e.length)return null;if(1===e.length){let{x:t,y:i,w:n,h:o}=e[0];return new k(t,i,n,o)}let t=e[0];for(let i=1;i<e.length;i++)t=function(e,t){let i=Math.min(e.x,t.x),n=Math.min(e.y,t.y),o=Math.max(e.x+e.w,t.x+t.w),r=Math.max(e.y+e.h,t.y+t.h);return{x:i,y:n,w:Math.abs(o-i),h:Math.abs(r-n)}}(t,e[i]);return new k(t.x,t.y,t.w,t.h)}function S(e,t){return e.x<=t.x&&e.x+e.w>=t.x+t.w&&e.y<=t.y&&e.y+e.h>=t.y+t.h}function E(e){let{minX:t,minY:i,width:n,height:o}=x.getBoundsFromPoints(e);return new k(t,i,n,o)}function L(e,t){let i=t/2,n=new k(e.x-i,e.y-i,e.w+t,e.h+t);if(n.w<=0||n.h<=0)throw Error("Invalid delta range or bound size.");return n}function $(e,t,i,n,o){let r=2*i,a=2*o,s=Math.max(t.w-r,1),l=Math.max(t.h-r,1),d=Math.max(n.w-a,1),c=Math.max(n.h-a,1),h=e.map(e=>({...e,x:d*((e.x-i)/s)+o,y:c*((e.y-i)/l)+o}));return{points:h,bound:new k(n.x,n.y,d+a,c+a)}}function P(e,t,i){return e.x<=t&&t<=e.x+e.w&&e.y<=i&&i<=e.y+e.h}function B(e,t){return e.x<t.x+t.w&&e.x+e.w>t.x&&e.y<t.y+t.h&&e.y+e.h>t.y}class R{get display(){return this._display}setDisplay(e){this._display=e,this.renderer?.removeElement(this),this.renderer?.addElement(this)}constructor(e,t,i){if(this.renderer=null,this.surface=null,this.computedValue=e=>e,this._display=!0,this._onMap=()=>{this.renderer?.removeElement(this),this.renderer?.addElement(this)},!e.doc)throw Error("yMap must be bound to a Y.Doc");if(this.yMap=e,i)for(let e in i)this.yMap.set(e,i[e]);this.surface=t}get id(){let e=this.yMap.get("id");return e}get index(){let e=this.yMap.get("index");return e}get type(){let e=this.yMap.get("type");return e}get xywh(){let e=this.yMap.get("xywh");return e}get x(){let[e]=_(this.xywh);return e}get y(){let[,e]=_(this.xywh);return e}get w(){let[,,e]=_(this.xywh);return e}get h(){let[,,,e]=_(this.xywh);return e}get seed(){let e=this.yMap.get("seed");return e}get minWidth(){return this.w}get minHeight(){return this.h}applyUpdate(e){for(let t in e)this.yMap.set(t,e[t])}serialize(){return this.yMap.toJSON()}hitTest(e,t,i){return P(this,e,t)}mount(e){this.renderer=e,this.renderer.addElement(this),this.yMap.observeDeep(this._onMap)}unmount(){this.yMap.unobserveDeep(this._onMap),this.renderer?.removeElement(this),this.renderer=null}render(e,t){}}function T([e,t],[i,n],o=10){let r=Math.atan2(n-t,i-e);return{sides:[[i-o*Math.cos(r-Math.PI/10),n-o*Math.sin(r-Math.PI/10)],[i-o*Math.cos(r+Math.PI/10),n-o*Math.sin(r+Math.PI/10)]],start:[e,t],end:[i,n]}}class O extends R{get mode(){return this.yMap.get("mode")}get lineWidth(){return this.yMap.get("lineWidth")}get color(){return this.yMap.get("color")}get strokeStyle(){return this.yMap.get("strokeStyle")}get roughness(){return this.yMap.get("roughness")??2}get startElement(){return this.yMap.get("startElement")}get endElement(){return this.yMap.get("endElement")}get controllers(){return this.yMap.get("controllers")}render(e,t){let{seed:i,strokeStyle:n,color:o,roughness:r,lineWidth:a,controllers:s}=this,l=this.computedValue(o);this.mode===j.Orthogonal?t.linearPath(s.map(e=>[e.x,e.y]),{seed:i,roughness:r,strokeLineDash:n===U.Dashed?[12,12]:void 0,stroke:l,strokeWidth:a}):t.linearPath([[s[0].x,s[0].y],[s[s.length-1].x,s[s.length-1].y]],{seed:i,roughness:r,strokeLineDash:n===U.Dashed?[12,12]:void 0,stroke:l,strokeWidth:a});let d=this.controllers[this.controllers.length-1],c=this.controllers[this.controllers.length-2],{sides:h,end:u}=T([c.x,c.y],[d.x,d.y],35);t.linearPath([[h[0][0],h[0][1]],[u[0],u[1]],[h[1][0],h[1][1]]],{seed:i,roughness:r,strokeLineDash:n===U.Dashed?[12,12]:void 0,stroke:l,strokeWidth:a})}applyUpdate(e){let t={...e},{controllers:i,xywh:n}=e;if(i?.length){let n=e.lineWidth??this.lineWidth,o=function(e){let t=e[e.length-1],i=e[e.length-2],n=T([t.x,t.y],[i.x,i.y]),o=n.sides.concat(e.map(e=>[e.x,e.y]));return E(o)}(i),r=L(o,n),a=i.map(e=>({...e,x:e.x-r.x,y:e.y-r.y}));t.controllers=a,t.xywh=r.serialize()}if(n){let{lineWidth:e}=this,i=k.deserialize(n),o=$(this.controllers,this,e/2,i,e/2);t.controllers=o.points,t.xywh=o.bound.serialize()}if(e.lineWidth&&e.lineWidth!==this.lineWidth){let i=t.xywh?k.deserialize(t.xywh):this,n=t.controllers??this.controllers,o=$(n,i,this.lineWidth/2,L(i,e.lineWidth-this.lineWidth),e.lineWidth/2);t.controllers=o.points,t.xywh=o.bound.serialize()}for(let e in t)this.yMap.set(e,t[e])}}let I={type:"connector",xywh:"[0,0,0,0]",mode:j.Orthogonal,lineWidth:4,color:"#000000",strokeStyle:U.Solid,roughness:2,controllers:[]},D={type:"shape",xywh:"[0,0,0,0]",shapeType:"rect",radius:0,filled:!1,fillColor:"#ffffff",strokeWidth:4,strokeColor:"#000000",strokeStyle:U.Solid,roughness:2},z={rect:{render(e,t,i){let{w:n,h:o,seed:r,strokeWidth:a,filled:s,realFillColor:l,realStrokeColor:d,radius:c,strokeStyle:h,roughness:u}=i,f=Math.max(a,0)/2,p=n-2*f,g=o-2*f,m=Math.min(p*c,g*c);e.translate(f,f),t.path(`
      M${m} 0
      L${p-m} 0
      C ${p-.4477152502*m} 0 ${p} ${.4477152502*m} ${p} ${m}
      L${p} ${g-m}
      C ${p} ${g-.4477152502*m} ${p-.4477152502*m} ${g} ${p-m} ${g}
      L${m} ${g}
      C ${.4477152502*m} ${g} 0 ${g-.4477152502*m} 0 ${g-m}
      L0 ${m}
      C 0 ${.4477152502*m} ${.4477152502*m} 0 ${m} 0
      Z
      `,{seed:r,roughness:u,strokeLineDash:h===U.Dashed?[12,12]:void 0,stroke:d,strokeWidth:a,fill:s?l:void 0})},hitTest:(e,t,i,n)=>P(i,e,t)},triangle:{render(e,t,i){let{w:n,h:o,seed:r,strokeWidth:a,filled:s,realFillColor:l,realStrokeColor:d,strokeStyle:c,roughness:h}=i,u=Math.max(a,0)/2,f=n-2*u,p=o-2*u;e.translate(u,u),t.polygon([[f/2,0],[f,p],[0,p]],{seed:r,roughness:h,strokeLineDash:c===U.Dashed?[12,12]:void 0,stroke:d,strokeWidth:a,fill:s?l:void 0})},hitTest(e,t,i,n){let o=[[i.x+i.w/2,i.y+0],[i.x+i.w,i.y+i.h],[i.x+0,i.y+i.h]];return x.pointInPolygon([e,t],o)}},ellipse:{render(e,t,i){let{w:n,h:o,seed:r,strokeWidth:a,filled:s,realFillColor:l,realStrokeColor:d,strokeStyle:c,roughness:h}=i,u=Math.max(a,0)/2,f=Math.max(1,n-2*u),p=Math.max(1,o-2*u);e.translate(u,u),t.ellipse(f/2,p/2,f,p,{seed:r,roughness:h,strokeLineDash:c===U.Dashed?[12,12]:void 0,stroke:d,strokeWidth:a,fill:s?l:void 0})},hitTest:(e,t,i,n)=>x.pointInEllipse([e,t],[i.x+i.w/2,i.y+i.h/2],i.w/2,i.h/2)},diamond:{render(e,t,i){let{w:n,h:o,seed:r,strokeWidth:a,filled:s,realFillColor:l,realStrokeColor:d,strokeStyle:c,roughness:h}=i,u=Math.max(a,0)/2,f=n-2*u,p=o-2*u;e.translate(u,u),t.polygon([[f/2,0],[f,p/2],[f/2,p],[0,p/2]],{seed:r,roughness:h,strokeLineDash:c===U.Dashed?[12,12]:void 0,stroke:d,strokeWidth:a,fill:s?l:void 0})},hitTest(e,t,i,n){let o=[[i.x+i.w/2,i.y+0],[i.x+i.w,i.y+i.h/2],[i.x+i.w/2,i.y+i.h],[i.x+0,i.y+i.h/2]];return x.pointInPolygon([e,t],o)}}};var A,H,V,Z,F,U,j,N,W,q,Y=i(60803);let X={type:"text",xywh:"[0,0,0,0]",text:new Y.Text,color:"#000000",fontSize:16,fontFamily:"'Kalam', cursive",textAlign:"center"},K=RegExp(`^[^A-Za-z\xc0-\xd6\xd8-\xf6\xf8-ʸ̀-֐ࠀ-῿Ⰰ-﬜﷾-﹯﻽-￿]*[֑-߿יִ-﷽ﹰ-ﻼ]`),G=e=>K.test(e),Q=-1!==globalThis.navigator?.userAgent.indexOf("Chrome");Q||globalThis.navigator?.userAgent.indexOf("Safari");let J=({fontSize:e,fontFamily:t,lineHeight:i})=>`${e}px/${i} ${t}`,ee=e=>e.replace(/\t/g,"        ").replace(/\r?\n|\r/g,"\n").split("\n");function et(e){let t=[],i=e.insert;for(;i.length>0;){let n=i.indexOf("\n");if(-1===n){t.push({insert:i,attributes:e.attributes});break}i.slice(0,n).length>0&&t.push({insert:i.slice(0,n),attributes:e.attributes}),t.push("\n"),i=i.slice(n+1)}return t}class ei extends R{constructor(){super(...arguments),this._maxTextWidth=0,this._maxTextHeight=0,this._lineHeight=0,this._lines=[]}get text(){return this.yMap.get("text")}get color(){return this.yMap.get("color")}get fontSize(){return this.yMap.get("fontSize")}get fontFamily(){return this.yMap.get("fontFamily")}get textAlign(){return this.yMap.get("textAlign")}get minWidth(){return this._maxTextWidth}get minHeight(){return this._maxTextHeight}get lineHeight(){return this._lineHeight}get lines(){return this._lines}render(e){let{w:t,text:i,color:n,fontSize:o,fontFamily:r,textAlign:a}=this,s=i.toDelta(),l=function(e){if(0===e.length)return[[]];let t=e.flatMap(et);return[...function*(e){let t=0;for(let i=0;i<e.length;i++)if("\n"===e[i]){let n=e.slice(t,i);t=i+1,yield n}else i===e.length-1&&(yield e.slice(t));"\n"===e.at(-1)&&(yield[])}(t)]}(s);this._lines=l;let d=this.h/l.length,c=J({fontSize:o,lineHeight:`${d}px`,fontFamily:r});this._lineHeight=d;let h="center"===a?t/2:"right"===a?t:0;for(let[t,i]of l.entries()){let o=0;for(let s of i){e.save();let i=s.insert,l=G(i),u=l&&!e.canvas.isConnected;u&&document.body.appendChild(e.canvas),e.canvas.setAttribute("dir",l?"rtl":"ltr"),e.font=c,e.fillStyle=this.computedValue(n),e.textAlign=a,e.textBaseline="ideographic",e.fillText(i,h+o,(t+1)*d),o+=function(e,t){let i=ee(e),n=0;return i.forEach(e=>{n=Math.max(n,function(e,t){let i=document.createElement("canvas"),n=i.getContext("2d");n.font=t;let o=n.measureText(e).width;return o}(e,t))}),n}(i,r),u&&e.canvas.remove(),e.restore()}o>this._maxTextWidth&&(this._maxTextWidth=o)}this._maxTextHeight<l.length*d&&(this._maxTextHeight=l.length*d)}}let en={debug:class extends R{get color(){let e=this.yMap.get("color");return e}render(e){e.fillStyle=this.color,e.fillRect(0,0,this.w,this.h)}},brush:class extends R{get points(){let e=this.yMap.get("points");return e}get color(){let e=this.yMap.get("color");return e}get lineWidth(){let e=this.yMap.get("lineWidth");return e}render(e){let t=function(e,t={}){return function(e,t={}){var i,n;let o;let{size:r=16,smoothing:v=.5,thinning:C=.5,simulatePressure:y=!0,easing:x=e=>e,start:w={},end:_={},last:k=!1}=t,{cap:M=!0,easing:S=e=>e*(2-e)}=w,{cap:E=!0,easing:L=e=>--e*e*e+1}=_;if(0===e.length||r<=0)return[];let $=e[e.length-1].runningLength,P=!1===w.taper?0:!0===w.taper?Math.max(r,$):w.taper,B=!1===_.taper?0:!0===_.taper?Math.max(r,$):_.taper,R=Math.pow(r*v,2),T=[],O=[],I=e.slice(0,10).reduce((e,t)=>{let i=t.pressure;if(y){let n=m(1,t.distance/r),o=m(1,1-n);i=m(1,e+(o-e)*(.275*n))}return(e+i)/2},e[0].pressure),D=a(r,C,e[e.length-1].pressure,x),z=e[0].vector,A=e[0].point,H=A,V=A,Z=H,F=!1;for(let t=0;t<e.length;t++){let{pressure:i}=e[t],{point:n,vector:f,distance:v,runningLength:w}=e[t];if(t<e.length-1&&$-w<3)continue;if(C){if(y){let e=m(1,v/r),t=m(1,1-e);i=m(1,I+(t-I)*(.275*e))}D=a(r,C,i,x)}else D=r/2;void 0===o&&(o=D);let _=w<P?S(w/P):1,k=$-w<B?L(($-w)/B):1;D=Math.max(.01,D*Math.min(_,k));let M=(t<e.length-1?e[t+1]:e[t]).vector,E=t<e.length-1?h(f,M):1,U=h(f,z),j=U<0&&!F,N=null!==E&&E<0;if(j||N){let e=d(c(z),D);for(let t=1/13,i=0;i<=1;i+=t)V=p(l(n,e),n,b*i),T.push(V),Z=p(s(n,e),n,-(b*i)),O.push(Z);A=V,H=Z,N&&(F=!0);continue}if(F=!1,t===e.length-1){let e=d(c(f),D);T.push(l(n,e)),O.push(s(n,e));continue}let W=d(c(g(M,f,E)),D);V=l(n,W),(t<=1||u(A,V)>R)&&(T.push(V),A=V),Z=s(n,W),(t<=1||u(H,Z)>R)&&(O.push(Z),H=Z),I=i,z=f}let U=e[0].point.slice(0,2),j=e.length>1?e[e.length-1].point.slice(0,2):s(e[0].point,[1,1]),N=[],W=[];if(1===e.length){if(!(P||B)||k){let e=(i=f(c(l(U,j))),s(U,d(i,-(o||D)))),t=[];for(let i=1/13,n=i;n<=1;n+=i)t.push(p(e,U,2*b*n));return t}}else{if(P||B&&1===e.length);else if(M)for(let e=1/13,t=e;t<=1;t+=e){let e=p(O[0],U,b*t);N.push(e)}else{let e=l(T[0],O[0]),t=d(e,.5),i=d(e,.51);N.push(l(U,t),l(U,i),s(U,i),s(U,t))}let t=c([-(n=e[e.length-1].vector)[0],-n[1]]);if(B||P&&1===e.length)W.push(j);else if(E){let e=s(j,d(t,D));for(let t=1/29,i=t;i<1;i+=t)W.push(p(e,j,3*b*i))}else W.push(s(j,d(t,D)),s(j,d(t,.99*D)),l(j,d(t,.99*D)),l(j,d(t,D)))}return T.concat(W,O.reverse(),N)}(function(e,t={}){let{streamline:i=.5,size:n=16,last:o=!1}=t;if(0===e.length)return[];let r=.15+(1-i)*.85,a=Array.isArray(e[0])?e:e.map(({x:e,y:t,pressure:i=.5})=>[e,t,i]);if(2===a.length){let e=a[1];a=a.slice(0,-1);for(let t=1;t<5;t++)a.push(g(a[0],e,t/4))}1===a.length&&(a=[...a,[...s(a[0],[1,1]),...a[0].slice(2)]]);let d=[{point:[a[0][0],a[0][1]],pressure:a[0][2]>=0?a[0][2]:.25,vector:[1,1],distance:0,runningLength:0}],c=!1,h=0,u=d[0],p=a.length-1;for(let e=1;e<a.length;e++){var m,v;let t=o&&e===p?a[e].slice(0,2):g(u.point,a[e],r);if((m=u.point)[0]===t[0]&&m[1]===t[1])continue;let i=(v=u.point,Math.hypot(t[1]-v[1],t[0]-v[0]));if(h+=i,e<p&&!c){if(h<n)continue;c=!0}u={point:t,pressure:a[e][2]>=0?a[e][2]:.5,vector:f(l(u.point,t)),distance:i,runningLength:h},d.push(u)}return d[0].vector=d[1]?.vector||[0,0],d}(e,t),t)}(this.points,{size:this.lineWidth,thinning:.6,streamline:.5,smoothing:.5,easing:e=>Math.sin(e*Math.PI/2),simulatePressure:!0}),i=x.getSvgPathFromStroke(t),n=new Path2D(i);e.fillStyle=this.computedValue(this.color),e.fill(n)}applyUpdate(e){let t={...e},{points:i,xywh:n}=e;if(i?.length){let e=this.lineWidth,n=E(i),o=L(n,e),r=i.map(([e,t])=>[e-o.x,t-o.y]);t.points=r,t.xywh=o.serialize()}if(n){let e=k.deserialize(n),{lineWidth:i}=this,o=$(this.points.map(([e,t])=>({x:e,y:t})),this,i/2,e,i/2);t.points=o.points.map(e=>[e.x,e.y]),t.xywh=o.bound.serialize()}if(e.lineWidth&&e.lineWidth!==this.lineWidth){let i=t.xywh?k.deserialize(t.xywh):this,n=t.points??this.points,o=$(n.map(([e,t])=>({x:e,y:t})),i,this.lineWidth/2,L(i,e.lineWidth-this.lineWidth),e.lineWidth/2);t.points=o.points.map(e=>[e.x,e.y]),t.xywh=o.bound.serialize()}for(let e in t)this.yMap.set(e,t[e])}},shape:class extends R{get shapeType(){let e=this.yMap.get("shapeType");return e}get radius(){let e=this.yMap.get("radius");return e}get filled(){let e=this.yMap.get("filled");return e}get fillColor(){let e=this.yMap.get("fillColor");return e}get strokeWidth(){let e=this.yMap.get("strokeWidth");return e}get strokeColor(){let e=this.yMap.get("strokeColor");return e}get strokeStyle(){let e=this.yMap.get("strokeStyle");return e}get roughness(){let e=this.yMap.get("roughness")??2;return e}get realStrokeColor(){return this.computedValue(this.strokeColor)}get realFillColor(){return this.computedValue(this.fillColor)}hitTest(e,t,i){let{hitTest:n}=z[this.shapeType];return n(e,t,this,i)}render(e,t){let{render:i}=z[this.shapeType];i(e,t,this)}},connector:O,text:ei},eo={debug:{type:"debug",xywh:"[0,0,0,0]",color:"#000000"},brush:{type:"brush",xywh:"[0,0,0,0]",points:[],color:"#000000",lineWidth:4},shape:D,connector:I,text:X};var er=i(13246);function ea(e){return Math.ceil(e/3e3)-1}function es(e){let t=ea(e.x),i=ea(e.x+e.w),n=ea(e.y),o=ea(e.y+e.h);return[t,i,n,o]}function el(e,t){return e.index<t.index?-1:e.index>t.index?1:0}class ed{constructor(){this._grids=new Map,this._elementToGrids=new Map}_createGrid(e,t){let i=new Set;return this._grids.set(e+"|"+t,i),i}_getGrid(e,t){return this._grids.get(e+"|"+t)}get isEmpty(){return 0===this._grids.size}add(e){let[t,i,n,o]=es(e),r=new Set;this._elementToGrids.set(e,r);for(let a=t;a<=i;a++)for(let t=n;t<=o;t++){let i=this._getGrid(a,t);i||(i=this._createGrid(a,t)),i.add(e),r.add(i)}}remove(e){let t=this._elementToGrids.get(e);for(let i of((0,er.kP)(t),t))i.delete(e)}boundHasChanged(e,t){let[i,n,o,r]=es(e),[a,s,l,d]=es(t);return i!==a||n!==s||o!==l||r!==d}search(e){let[t,i,n,o]=es(e),r=new Set;for(let a=t;a<=i;a++)for(let t=n;t<=o;t++){let i=this._getGrid(a,t);if(i)for(let t of i)B(t,e)&&r.add(t)}let a=Array.from(r).sort(el);return a}pick(e,t){let i=ea(e),n=ea(t),o=this._getGrid(i,n);if(!o)return[];let r=[];for(let i of o)P(i,e,t)&&r.push(i);return r}}var ec=i(29045),eh=i(31054);function eu(e,t,i){if(e&&e.length){let[n,o]=t,r=Math.PI/180*i,a=Math.cos(r),s=Math.sin(r);e.forEach(e=>{let[t,i]=e;e[0]=(t-n)*a-(i-o)*s+n,e[1]=(t-n)*s+(i-o)*a+o})}}function ef(e){let t=e[0],i=e[1];return Math.sqrt(Math.pow(t[0]-i[0],2)+Math.pow(t[1]-i[1],2))}function ep(e,t){let i=t.hachureAngle+90,n=t.hachureGap;n<0&&(n=4*t.strokeWidth),n=Math.max(n,.1);let o=[0,0];if(i)for(let t of e)eu(t,o,i);let r=function(e,t){let i=[];for(let t of e){let e=[...t];e[0].join(",")!==e[e.length-1].join(",")&&e.push([e[0][0],e[0][1]]),e.length>2&&i.push(e)}let n=[];t=Math.max(t,.1);let o=[];for(let e of i)for(let t=0;t<e.length-1;t++){let i=e[t],n=e[t+1];if(i[1]!==n[1]){let e=Math.min(i[1],n[1]);o.push({ymin:e,ymax:Math.max(i[1],n[1]),x:e===i[1]?i[0]:n[0],islope:(n[0]-i[0])/(n[1]-i[1])})}}if(o.sort((e,t)=>e.ymin<t.ymin?-1:e.ymin>t.ymin?1:e.x<t.x?-1:e.x>t.x?1:e.ymax===t.ymax?0:(e.ymax-t.ymax)/Math.abs(e.ymax-t.ymax)),!o.length)return n;let r=[],a=o[0].ymin;for(;r.length||o.length;){if(o.length){let e=-1;for(let t=0;t<o.length&&!(o[t].ymin>a);t++)e=t;let t=o.splice(0,e+1);t.forEach(e=>{r.push({s:a,edge:e})})}if((r=r.filter(e=>!(e.edge.ymax<=a))).sort((e,t)=>e.edge.x===t.edge.x?0:(e.edge.x-t.edge.x)/Math.abs(e.edge.x-t.edge.x)),r.length>1)for(let e=0;e<r.length;e+=2){let t=e+1;if(t>=r.length)break;let i=r[e].edge,o=r[t].edge;n.push([[Math.round(i.x),a],[Math.round(o.x),a]])}a+=t,r.forEach(e=>{e.edge.x=e.edge.x+t*e.edge.islope})}return n}(e,n);if(i){for(let t of e)eu(t,o,-i);!function(e,t,i){let n=[];e.forEach(e=>n.push(...e)),eu(n,t,i)}(r,o,-i)}return r}class eg{constructor(e){this.helper=e}fillPolygons(e,t){return this._fillPolygons(e,t)}_fillPolygons(e,t){let i=ep(e,t),n=this.renderLines(i,t);return{type:"fillSketch",ops:n}}renderLines(e,t){let i=[];for(let n of e)i.push(...this.helper.doubleLineOps(n[0][0],n[0][1],n[1][0],n[1][1],t));return i}}class em extends eg{fillPolygons(e,t){let i=t.hachureGap;i<0&&(i=4*t.strokeWidth),i=Math.max(i,.1);let n=Object.assign({},t,{hachureGap:i}),o=ep(e,n),r=Math.PI/180*t.hachureAngle,a=[],s=.5*i*Math.cos(r),l=.5*i*Math.sin(r);for(let[e,t]of o)ef([e,t])&&a.push([[e[0]-s,e[1]+l],[...t]],[[e[0]+s,e[1]-l],[...t]]);let d=this.renderLines(a,t);return{type:"fillSketch",ops:d}}}class ev extends eg{fillPolygons(e,t){let i=this._fillPolygons(e,t),n=Object.assign({},t,{hachureAngle:t.hachureAngle+90}),o=this._fillPolygons(e,n);return i.ops=i.ops.concat(o.ops),i}}class eb{constructor(e){this.helper=e}fillPolygons(e,t){t=Object.assign({},t,{hachureAngle:0});let i=ep(e,t);return this.dotsOnLines(i,t)}dotsOnLines(e,t){let i=[],n=t.hachureGap;n<0&&(n=4*t.strokeWidth),n=Math.max(n,.1);let o=t.fillWeight;o<0&&(o=t.strokeWidth/2);let r=n/4;for(let a of e){let e=ef(a),s=e/n,l=Math.ceil(s)-1,d=e-l*n,c=(a[0][0]+a[1][0])/2-n/4,h=Math.min(a[0][1],a[1][1]);for(let e=0;e<l;e++){let a=h+d+e*n,s=c-r+2*Math.random()*r,l=a-r+2*Math.random()*r,u=this.helper.ellipse(s,l,o,o,t);i.push(...u.ops)}}return{type:"fillSketch",ops:i}}}class eC{constructor(e){this.helper=e}fillPolygons(e,t){let i=ep(e,t);return{type:"fillSketch",ops:this.dashedLine(i,t)}}dashedLine(e,t){let i=t.dashOffset<0?t.hachureGap<0?4*t.strokeWidth:t.hachureGap:t.dashOffset,n=t.dashGap<0?t.hachureGap<0?4*t.strokeWidth:t.hachureGap:t.dashGap,o=[];return e.forEach(e=>{let r=ef(e),a=Math.floor(r/(i+n)),s=(r+n-a*(i+n))/2,l=e[0],d=e[1];l[0]>d[0]&&(l=e[1],d=e[0]);let c=Math.atan((d[1]-l[1])/(d[0]-l[0]));for(let e=0;e<a;e++){let r=e*(i+n),a=r+i,d=[l[0]+r*Math.cos(c)+s*Math.cos(c),l[1]+r*Math.sin(c)+s*Math.sin(c)],h=[l[0]+a*Math.cos(c)+s*Math.cos(c),l[1]+a*Math.sin(c)+s*Math.sin(c)];o.push(...this.helper.doubleLineOps(d[0],d[1],h[0],h[1],t))}}),o}}class ey{constructor(e){this.helper=e}fillPolygons(e,t){let i=t.hachureGap<0?4*t.strokeWidth:t.hachureGap,n=t.zigzagOffset<0?i:t.zigzagOffset;t=Object.assign({},t,{hachureGap:i+n});let o=ep(e,t);return{type:"fillSketch",ops:this.zigzagLines(o,n,t)}}zigzagLines(e,t,i){let n=[];return e.forEach(e=>{let o=ef(e),r=Math.round(o/(2*t)),a=e[0],s=e[1];a[0]>s[0]&&(a=e[1],s=e[0]);let l=Math.atan((s[1]-a[1])/(s[0]-a[0]));for(let e=0;e<r;e++){let o=2*e*t,r=(e+1)*2*t,s=Math.sqrt(2*Math.pow(t,2)),d=[a[0]+o*Math.cos(l),a[1]+o*Math.sin(l)],c=[a[0]+r*Math.cos(l),a[1]+r*Math.sin(l)],h=[d[0]+s*Math.cos(l+Math.PI/4),d[1]+s*Math.sin(l+Math.PI/4)];n.push(...this.helper.doubleLineOps(d[0],d[1],h[0],h[1],i),...this.helper.doubleLineOps(h[0],h[1],c[0],c[1],i))}}),n}}let ex={};function ew(){return Math.floor(2147483648*Math.random())}class e_{constructor(e){this.seed=e}next(){return this.seed?(2147483648-1&(this.seed=Math.imul(48271,this.seed)))/2147483648:Math.random()}}let ek={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function eM(e){let t=[],i=function(e){let t=[];for(;""!==e;)if(e.match(/^([ \t\r\n,]+)/))e=e.substr(RegExp.$1.length);else if(e.match(/^([aAcChHlLmMqQsStTvVzZ])/))t[t.length]={type:0,text:RegExp.$1},e=e.substr(RegExp.$1.length);else{if(!e.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];t[t.length]={type:1,text:`${parseFloat(RegExp.$1)}`},e=e.substr(RegExp.$1.length)}return t[t.length]={type:2,text:""},t}(e),n="BOD",o=0,r=i[0];for(;2!==r.type;){let a=0,s=[];if("BOD"===n){if("M"!==r.text&&"m"!==r.text)return eM("M0,0"+e);o++,a=ek[r.text],n=r.text}else 1===r.type?a=ek[n]:(o++,a=ek[r.text],n=r.text);if(o+a<i.length){for(let e=o;e<o+a;e++){let t=i[e];if(1===t.type)s[s.length]=+t.text;else throw Error("Param not a number: "+n+","+t.text)}if("number"==typeof ek[n]){let e={key:n,data:s};t.push(e),o+=a,r=i[o],"M"===n&&(n="L"),"m"===n&&(n="l")}else throw Error("Bad segment: "+n)}else throw Error("Path data ended short")}return t}function eS(e){let t=0,i=0,n=0,o=0,r=[];for(let{key:a,data:s}of e)switch(a){case"M":r.push({key:"M",data:[...s]}),[t,i]=s,[n,o]=s;break;case"m":t+=s[0],i+=s[1],r.push({key:"M",data:[t,i]}),n=t,o=i;break;case"L":r.push({key:"L",data:[...s]}),[t,i]=s;break;case"l":t+=s[0],i+=s[1],r.push({key:"L",data:[t,i]});break;case"C":r.push({key:"C",data:[...s]}),t=s[4],i=s[5];break;case"c":{let e=s.map((e,n)=>n%2?e+i:e+t);r.push({key:"C",data:e}),t=e[4],i=e[5];break}case"Q":r.push({key:"Q",data:[...s]}),t=s[2],i=s[3];break;case"q":{let e=s.map((e,n)=>n%2?e+i:e+t);r.push({key:"Q",data:e}),t=e[2],i=e[3];break}case"A":r.push({key:"A",data:[...s]}),t=s[5],i=s[6];break;case"a":t+=s[5],i+=s[6],r.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],t,i]});break;case"H":r.push({key:"H",data:[...s]}),t=s[0];break;case"h":t+=s[0],r.push({key:"H",data:[t]});break;case"V":r.push({key:"V",data:[...s]}),i=s[0];break;case"v":i+=s[0],r.push({key:"V",data:[i]});break;case"S":r.push({key:"S",data:[...s]}),t=s[2],i=s[3];break;case"s":{let e=s.map((e,n)=>n%2?e+i:e+t);r.push({key:"S",data:e}),t=e[2],i=e[3];break}case"T":r.push({key:"T",data:[...s]}),t=s[0],i=s[1];break;case"t":t+=s[0],i+=s[1],r.push({key:"T",data:[t,i]});break;case"Z":case"z":r.push({key:"Z",data:[]}),t=n,i=o}return r}function eE(e){let t=[],i="",n=0,o=0,r=0,a=0,s=0,l=0;for(let{key:d,data:c}of e){switch(d){case"M":t.push({key:"M",data:[...c]}),[n,o]=c,[r,a]=c;break;case"C":t.push({key:"C",data:[...c]}),n=c[4],o=c[5],s=c[2],l=c[3];break;case"L":t.push({key:"L",data:[...c]}),[n,o]=c;break;case"H":n=c[0],t.push({key:"L",data:[n,o]});break;case"V":o=c[0],t.push({key:"L",data:[n,o]});break;case"S":{let e=0,r=0;"C"===i||"S"===i?(e=n+(n-s),r=o+(o-l)):(e=n,r=o),t.push({key:"C",data:[e,r,...c]}),s=c[0],l=c[1],n=c[2],o=c[3];break}case"T":{let[e,r]=c,a=0,d=0;"Q"===i||"T"===i?(a=n+(n-s),d=o+(o-l)):(a=n,d=o);let h=n+2*(a-n)/3,u=o+2*(d-o)/3,f=e+2*(a-e)/3,p=r+2*(d-r)/3;t.push({key:"C",data:[h,u,f,p,e,r]}),s=a,l=d,n=e,o=r;break}case"Q":{let[e,i,r,a]=c,d=n+2*(e-n)/3,h=o+2*(i-o)/3,u=r+2*(e-r)/3,f=a+2*(i-a)/3;t.push({key:"C",data:[d,h,u,f,r,a]}),s=e,l=i,n=r,o=a;break}case"A":{let e=Math.abs(c[0]),i=Math.abs(c[1]),r=c[2],a=c[3],s=c[4],l=c[5],d=c[6];if(0===e||0===i)t.push({key:"C",data:[n,o,l,d,l,d]}),n=l,o=d;else if(n!==l||o!==d){let c=function e(t,i,n,o,r,a,s,l,d,c){let h=Math.PI*s/180,u=[],f=0,p=0,g=0,m=0;if(c)[f,p,g,m]=c;else{[t,i]=eL(t,i,-h),[n,o]=eL(n,o,-h);let e=(t-n)/2,s=(i-o)/2,c=e*e/(r*r)+s*s/(a*a);c>1&&(r*=c=Math.sqrt(c),a*=c);let u=r*r,v=a*a,b=(l===d?-1:1)*Math.sqrt(Math.abs((u*v-u*s*s-v*e*e)/(u*s*s+v*e*e)));g=b*r*s/a+(t+n)/2,m=-(b*a)*e/r+(i+o)/2,f=Math.asin(parseFloat(((i-m)/a).toFixed(9))),p=Math.asin(parseFloat(((o-m)/a).toFixed(9))),t<g&&(f=Math.PI-f),n<g&&(p=Math.PI-p),f<0&&(f=2*Math.PI+f),p<0&&(p=2*Math.PI+p),d&&f>p&&(f-=2*Math.PI),!d&&p>f&&(p-=2*Math.PI)}let v=p-f;if(Math.abs(v)>120*Math.PI/180){let t=p,i=n,l=o;u=e(n=g+r*Math.cos(p=d&&p>f?f+120*Math.PI/180*1:f+-(120*Math.PI/180*1)),o=m+a*Math.sin(p),i,l,r,a,s,0,d,[p,t,g,m])}v=p-f;let b=Math.cos(f),C=Math.sin(f),y=Math.cos(p),x=Math.sin(p),w=Math.tan(v/4),_=4/3*r*w,k=4/3*a*w,M=[t,i],S=[t+_*C,i-k*b],E=[n+_*x,o-k*y],L=[n,o];if(S[0]=2*M[0]-S[0],S[1]=2*M[1]-S[1],c)return[S,E,L].concat(u);{u=[S,E,L].concat(u);let e=[];for(let t=0;t<u.length;t+=3){let i=eL(u[t][0],u[t][1],h),n=eL(u[t+1][0],u[t+1][1],h),o=eL(u[t+2][0],u[t+2][1],h);e.push([i[0],i[1],n[0],n[1],o[0],o[1]])}return e}}(n,o,l,d,e,i,r,a,s);c.forEach(function(e){t.push({key:"C",data:e})}),n=l,o=d}break}case"Z":t.push({key:"Z",data:[]}),n=r,o=a}i=d}return t}function eL(e,t,i){return[e*Math.cos(i)-t*Math.sin(i),e*Math.sin(i)+t*Math.cos(i)]}let e$={randOffset:function(e,t){return eH(e,t)},randOffsetWithRange:function(e,t,i){return eA(e,t,i)},ellipse:function(e,t,i,n,o){let r=eR(i,n,o);return eT(e,t,o,r).opset},doubleLineOps:function(e,t,i,n,o){return eV(e,t,i,n,o,!0)}};function eP(e,t,i,n,o){return{type:"path",ops:eV(e,t,i,n,o)}}function eB(e,t,i){let n=(e||[]).length;if(n>2){let o=[];for(let t=0;t<n-1;t++)o.push(...eV(e[t][0],e[t][1],e[t+1][0],e[t+1][1],i));return t&&o.push(...eV(e[n-1][0],e[n-1][1],e[0][0],e[0][1],i)),{type:"path",ops:o}}return 2===n?eP(e[0][0],e[0][1],e[1][0],e[1][1],i):{type:"path",ops:[]}}function eR(e,t,i){let n=Math.ceil(Math.max(i.curveStepCount,i.curveStepCount/Math.sqrt(200)*Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(e/2,2)+Math.pow(t/2,2))/2)))),o=Math.abs(e/2),r=Math.abs(t/2),a=1-i.curveFitting;return o+=eH(o*a,i),r+=eH(r*a,i),{increment:2*Math.PI/n,rx:o,ry:r}}function eT(e,t,i,n){let[o,r]=ej(n.increment,e,t,n.rx,n.ry,1,n.increment*eA(.1,eA(.4,1,i),i),i),a=eU(o,null,i);if(!i.disableMultiStroke&&0!==i.roughness){let[o]=ej(n.increment,e,t,n.rx,n.ry,1.5,0,i),r=eU(o,null,i);a=a.concat(r)}return{estimatedPoints:r,opset:{type:"path",ops:a}}}function eO(e,t,i,n,o,r,a,s,l){let d=Math.abs(i/2),c=Math.abs(n/2);d+=eH(.01*d,l),c+=eH(.01*c,l);let h=o,u=r;for(;h<0;)h+=2*Math.PI,u+=2*Math.PI;u-h>2*Math.PI&&(h=0,u=2*Math.PI);let f=2*Math.PI/l.curveStepCount,p=Math.min(f/2,(u-h)/2),g=eN(p,e,t,d,c,h,u,1,l);if(!l.disableMultiStroke){let i=eN(p,e,t,d,c,h,u,1.5,l);g.push(...i)}return a&&(s?g.push(...eV(e,t,e+d*Math.cos(h),t+c*Math.sin(h),l),...eV(e,t,e+d*Math.cos(u),t+c*Math.sin(u),l)):g.push({op:"lineTo",data:[e,t]},{op:"lineTo",data:[e+d*Math.cos(h),t+c*Math.sin(h)]})),{type:"path",ops:g}}function eI(e,t){let i=[];for(let n of e)if(n.length){let e=t.maxRandomnessOffset||0,o=n.length;if(o>2){i.push({op:"move",data:[n[0][0]+eH(e,t),n[0][1]+eH(e,t)]});for(let r=1;r<o;r++)i.push({op:"lineTo",data:[n[r][0]+eH(e,t),n[r][1]+eH(e,t)]})}}return{type:"fillPath",ops:i}}function eD(e,t){return(function(e,t){let i=e.fillStyle||"hachure";if(!ex[i])switch(i){case"zigzag":ex[i]||(ex[i]=new em(t));break;case"cross-hatch":ex[i]||(ex[i]=new ev(t));break;case"dots":ex[i]||(ex[i]=new eb(t));break;case"dashed":ex[i]||(ex[i]=new eC(t));break;case"zigzag-line":ex[i]||(ex[i]=new ey(t));break;default:ex[i="hachure"]||(ex[i]=new eg(t))}return ex[i]})(t,e$).fillPolygons(e,t)}function ez(e){return e.randomizer||(e.randomizer=new e_(e.seed||0)),e.randomizer.next()}function eA(e,t,i,n=1){return i.roughness*n*(ez(i)*(t-e)+e)}function eH(e,t,i=1){return eA(-e,e,t,i)}function eV(e,t,i,n,o,r=!1){let a=r?o.disableMultiStrokeFill:o.disableMultiStroke,s=eZ(e,t,i,n,o,!0,!1);if(a)return s;let l=eZ(e,t,i,n,o,!0,!0);return s.concat(l)}function eZ(e,t,i,n,o,r,a){let s=Math.pow(e-i,2)+Math.pow(t-n,2),l=Math.sqrt(s),d=1;d=l<200?1:l>500?.4:-.0016668*l+1.233334;let c=o.maxRandomnessOffset||0;c*c*100>s&&(c=l/10);let h=c/2,u=.2+.2*ez(o),f=o.bowing*o.maxRandomnessOffset*(n-t)/200,p=o.bowing*o.maxRandomnessOffset*(e-i)/200;f=eH(f,o,d),p=eH(p,o,d);let g=[],m=()=>eH(h,o,d),v=()=>eH(c,o,d),b=o.preserveVertices;return r&&(a?g.push({op:"move",data:[e+(b?0:m()),t+(b?0:m())]}):g.push({op:"move",data:[e+(b?0:eH(c,o,d)),t+(b?0:eH(c,o,d))]})),a?g.push({op:"bcurveTo",data:[f+e+(i-e)*u+m(),p+t+(n-t)*u+m(),f+e+2*(i-e)*u+m(),p+t+2*(n-t)*u+m(),i+(b?0:m()),n+(b?0:m())]}):g.push({op:"bcurveTo",data:[f+e+(i-e)*u+v(),p+t+(n-t)*u+v(),f+e+2*(i-e)*u+v(),p+t+2*(n-t)*u+v(),i+(b?0:v()),n+(b?0:v())]}),g}function eF(e,t,i){let n=[];n.push([e[0][0]+eH(t,i),e[0][1]+eH(t,i)]),n.push([e[0][0]+eH(t,i),e[0][1]+eH(t,i)]);for(let o=1;o<e.length;o++)n.push([e[o][0]+eH(t,i),e[o][1]+eH(t,i)]),o===e.length-1&&n.push([e[o][0]+eH(t,i),e[o][1]+eH(t,i)]);return eU(n,null,i)}function eU(e,t,i){let n=e.length,o=[];if(n>3){let r=[],a=1-i.curveTightness;o.push({op:"move",data:[e[1][0],e[1][1]]});for(let t=1;t+2<n;t++){let i=e[t];r[0]=[i[0],i[1]],r[1]=[i[0]+(a*e[t+1][0]-a*e[t-1][0])/6,i[1]+(a*e[t+1][1]-a*e[t-1][1])/6],r[2]=[e[t+1][0]+(a*e[t][0]-a*e[t+2][0])/6,e[t+1][1]+(a*e[t][1]-a*e[t+2][1])/6],r[3]=[e[t+1][0],e[t+1][1]],o.push({op:"bcurveTo",data:[r[1][0],r[1][1],r[2][0],r[2][1],r[3][0],r[3][1]]})}if(t&&2===t.length){let e=i.maxRandomnessOffset;o.push({op:"lineTo",data:[t[0]+eH(e,i),t[1]+eH(e,i)]})}}else 3===n?(o.push({op:"move",data:[e[1][0],e[1][1]]}),o.push({op:"bcurveTo",data:[e[1][0],e[1][1],e[2][0],e[2][1],e[2][0],e[2][1]]})):2===n&&o.push(...eV(e[0][0],e[0][1],e[1][0],e[1][1],i));return o}function ej(e,t,i,n,o,r,a,s){let l=0===s.roughness,d=[],c=[];if(l){e/=4,c.push([t+n*Math.cos(-e),i+o*Math.sin(-e)]);for(let r=0;r<=2*Math.PI;r+=e){let e=[t+n*Math.cos(r),i+o*Math.sin(r)];d.push(e),c.push(e)}c.push([t+1*n,i+0*o]),c.push([t+n*Math.cos(e),i+o*Math.sin(e)])}else{let l=eH(.5,s)-Math.PI/2;c.push([eH(r,s)+t+.9*n*Math.cos(l-e),eH(r,s)+i+.9*o*Math.sin(l-e)]);let h=2*Math.PI+l-.01;for(let a=l;a<h;a+=e){let e=[eH(r,s)+t+n*Math.cos(a),eH(r,s)+i+o*Math.sin(a)];d.push(e),c.push(e)}c.push([eH(r,s)+t+n*Math.cos(l+2*Math.PI+.5*a),eH(r,s)+i+o*Math.sin(l+2*Math.PI+.5*a)]),c.push([eH(r,s)+t+.98*n*Math.cos(l+a),eH(r,s)+i+.98*o*Math.sin(l+a)]),c.push([eH(r,s)+t+.9*n*Math.cos(l+.5*a),eH(r,s)+i+.9*o*Math.sin(l+.5*a)])}return[c,d]}function eN(e,t,i,n,o,r,a,s,l){let d=r+eH(.1,l),c=[];c.push([eH(s,l)+t+.9*n*Math.cos(d-e),eH(s,l)+i+.9*o*Math.sin(d-e)]);for(let r=d;r<=a;r+=e)c.push([eH(s,l)+t+n*Math.cos(r),eH(s,l)+i+o*Math.sin(r)]);return c.push([t+n*Math.cos(a),i+o*Math.sin(a)]),c.push([t+n*Math.cos(a),i+o*Math.sin(a)]),eU(c,null,l)}function eW(e,t){return Math.pow(e[0]-t[0],2)+Math.pow(e[1]-t[1],2)}function eq(e,t,i){return[e[0]+(t[0]-e[0])*i,e[1]+(t[1]-e[1])*i]}function eY(e,t,i,n,o){let r=o||[],a=e[t],s=e[i-1],l=0,d=1;for(let n=t+1;n<i-1;++n){let t=function(e,t,i){let n=eW(t,i);if(0===n)return eW(e,t);let o=((e[0]-t[0])*(i[0]-t[0])+(e[1]-t[1])*(i[1]-t[1]))/n;return eW(e,eq(t,i,o=Math.max(0,Math.min(1,o))))}(e[n],a,s);t>l&&(l=t,d=n)}return Math.sqrt(l)>n?(eY(e,t,d+1,n,r),eY(e,d,i,n,r)):(r.length||r.push(a),r.push(s)),r}function eX(e,t=.15,i){let n=[],o=(e.length-1)/3;for(let i=0;i<o;i++){let o=3*i;!function e(t,i,n,o){let r=o||[];if(function(e,t){let i=e[t+0],n=e[t+1],o=e[t+2],r=e[t+3],a=3*n[0]-2*i[0]-r[0];a*=a;let s=3*n[1]-2*i[1]-r[1];s*=s;let l=3*o[0]-2*r[0]-i[0];l*=l;let d=3*o[1]-2*r[1]-i[1];return d*=d,a<l&&(a=l),s<d&&(s=d),a+s}(t,i)<n){let e=t[i+0];if(r.length){let t=Math.sqrt(eW(r[r.length-1],e));t>1&&r.push(e)}else r.push(e);r.push(t[i+3])}else{let o=t[i+0],a=t[i+1],s=t[i+2],l=t[i+3],d=eq(o,a,.5),c=eq(a,s,.5),h=eq(s,l,.5),u=eq(d,c,.5),f=eq(c,h,.5),p=eq(u,f,.5);e([o,d,u,p],0,n,r),e([p,f,h,l],0,n,r)}return r}(e,o,t,n)}return i&&i>0?eY(n,0,n.length,i):n}let eK="none";class eG{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return ew()}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,t,i){return{shape:e,sets:t||[],options:i||this.defaultOptions}}line(e,t,i,n,o){let r=this._o(o);return this._d("line",[eP(e,t,i,n,r)],r)}rectangle(e,t,i,n,o){let r=this._o(o),a=[],s=eB([[e,t],[e+i,t],[e+i,t+n],[e,t+n]],!0,r);if(r.fill){let o=[[e,t],[e+i,t],[e+i,t+n],[e,t+n]];"solid"===r.fillStyle?a.push(eI([o],r)):a.push(eD([o],r))}return r.stroke!==eK&&a.push(s),this._d("rectangle",a,r)}ellipse(e,t,i,n,o){let r=this._o(o),a=[],s=eR(i,n,r),l=eT(e,t,r,s);if(r.fill){if("solid"===r.fillStyle){let i=eT(e,t,r,s).opset;i.type="fillPath",a.push(i)}else a.push(eD([l.estimatedPoints],r))}return r.stroke!==eK&&a.push(l.opset),this._d("ellipse",a,r)}circle(e,t,i,n){let o=this.ellipse(e,t,i,i,n);return o.shape="circle",o}linearPath(e,t){let i=this._o(t);return this._d("linearPath",[eB(e,!1,i)],i)}arc(e,t,i,n,o,r,a=!1,s){let l=this._o(s),d=[],c=eO(e,t,i,n,o,r,a,!0,l);if(a&&l.fill){if("solid"===l.fillStyle){let a=Object.assign({},l);a.disableMultiStroke=!0;let s=eO(e,t,i,n,o,r,!0,!1,a);s.type="fillPath",d.push(s)}else d.push(function(e,t,i,n,o,r,a){let s=Math.abs(i/2),l=Math.abs(n/2);s+=eH(.01*s,a),l+=eH(.01*l,a);let d=o,c=r;for(;d<0;)d+=2*Math.PI,c+=2*Math.PI;c-d>2*Math.PI&&(d=0,c=2*Math.PI);let h=(c-d)/a.curveStepCount,u=[];for(let i=d;i<=c;i+=h)u.push([e+s*Math.cos(i),t+l*Math.sin(i)]);return u.push([e+s*Math.cos(c),t+l*Math.sin(c)]),u.push([e,t]),eD([u],a)}(e,t,i,n,o,r,l))}return l.stroke!==eK&&d.push(c),this._d("arc",d,l)}curve(e,t){let i=this._o(t),n=[],o=function(e,t){let i=eF(e,1*(1+.2*t.roughness),t);if(!t.disableMultiStroke){let n=eF(e,1.5*(1+.22*t.roughness),function(e){let t=Object.assign({},e);return t.randomizer=void 0,e.seed&&(t.seed=e.seed+1),t}(t));i=i.concat(n)}return{type:"path",ops:i}}(e,i);if(i.fill&&i.fill!==eK&&e.length>=3){let t=function(e,t=0){let i=e.length;if(i<3)throw Error("A curve must have at least three points.");let n=[];if(3===i)n.push([...e[0]],[...e[1]],[...e[2]],[...e[2]]);else{let i=[];i.push(e[0],e[0]);for(let t=1;t<e.length;t++)i.push(e[t]),t===e.length-1&&i.push(e[t]);let o=[],r=1-t;n.push([...i[0]]);for(let e=1;e+2<i.length;e++){let t=i[e];o[0]=[t[0],t[1]],o[1]=[t[0]+(r*i[e+1][0]-r*i[e-1][0])/6,t[1]+(r*i[e+1][1]-r*i[e-1][1])/6],o[2]=[i[e+1][0]+(r*i[e][0]-r*i[e+2][0])/6,i[e+1][1]+(r*i[e][1]-r*i[e+2][1])/6],o[3]=[i[e+1][0],i[e+1][1]],n.push(o[1],o[2],o[3])}}return n}(e),o=eX(t,10,(1+i.roughness)/2);"solid"===i.fillStyle?n.push(eI([o],i)):n.push(eD([o],i))}return i.stroke!==eK&&n.push(o),this._d("curve",n,i)}polygon(e,t){let i=this._o(t),n=[],o=eB(e,!0,i);return i.fill&&("solid"===i.fillStyle?n.push(eI([e],i)):n.push(eD([e],i))),i.stroke!==eK&&n.push(o),this._d("polygon",n,i)}path(e,t){let i=this._o(t),n=[];if(!e)return this._d("path",n,i);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");let o=i.fill&&"transparent"!==i.fill&&i.fill!==eK,r=i.stroke!==eK,a=!!(i.simplification&&i.simplification<1),s=a?4-4*i.simplification:(1+i.roughness)/2,l=function(e,t,i){let n=eM(e),o=eE(eS(n)),r=[],a=[],s=[0,0],l=[],d=()=>{l.length>=4&&a.push(...eX(l,1)),l=[]},c=()=>{d(),a.length&&(r.push(a),a=[])};for(let{key:e,data:t}of o)switch(e){case"M":c(),s=[t[0],t[1]],a.push(s);break;case"L":d(),a.push([t[0],t[1]]);break;case"C":if(!l.length){let e=a.length?a[a.length-1]:s;l.push([e[0],e[1]])}l.push([t[0],t[1]]),l.push([t[2],t[3]]),l.push([t[4],t[5]]);break;case"Z":d(),a.push([s[0],s[1]])}if(c(),!i)return r;let h=[];for(let e of r){var u;let t=eY(u=e,0,u.length,i);t.length&&h.push(t)}return h}(e,0,s);return o&&("solid"===i.fillStyle?n.push(eI(l,i)):n.push(eD(l,i))),r&&(a?l.forEach(e=>{n.push(eB(e,!1,i))}):n.push(function(e,t){let i=eE(eS(eM(e))),n=[],o=[0,0],r=[0,0];for(let{key:e,data:a}of i)switch(e){case"M":{let e=1*(t.maxRandomnessOffset||0),i=t.preserveVertices;n.push({op:"move",data:a.map(n=>n+(i?0:eH(e,t)))}),r=[a[0],a[1]],o=[a[0],a[1]];break}case"L":n.push(...eV(r[0],r[1],a[0],a[1],t)),r=[a[0],a[1]];break;case"C":{let[e,i,o,s,l,d]=a;n.push(...function(e,t,i,n,o,r,a,s){let l=[],d=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3],c=[0,0],h=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let f=0;f<h;f++)0===f?l.push({op:"move",data:[a[0],a[1]]}):l.push({op:"move",data:[a[0]+(u?0:eH(d[0],s)),a[1]+(u?0:eH(d[0],s))]}),c=u?[o,r]:[o+eH(d[f],s),r+eH(d[f],s)],l.push({op:"bcurveTo",data:[e+eH(d[f],s),t+eH(d[f],s),i+eH(d[f],s),n+eH(d[f],s),c[0],c[1]]});return l}(e,i,o,s,l,d,r,t)),r=[l,d];break}case"Z":n.push(...eV(r[0],r[1],o[0],o[1],t)),r=[o[0],o[1]]}return{type:"path",ops:n}}(e,i))),this._d("path",n,i)}opsToPath(e,t){let i="";for(let n of e.ops){let e="number"==typeof t&&t>=0?n.data.map(e=>+e.toFixed(t)):n.data;switch(n.op){case"move":i+=`M${e[0]} ${e[1]} `;break;case"bcurveTo":i+=`C${e[0]} ${e[1]}, ${e[2]} ${e[3]}, ${e[4]} ${e[5]} `;break;case"lineTo":i+=`L${e[0]} ${e[1]} `}}return i.trim()}toPaths(e){let t=e.sets||[],i=e.options||this.defaultOptions,n=[];for(let e of t){let t=null;switch(e.type){case"path":t={d:this.opsToPath(e),stroke:i.stroke,strokeWidth:i.strokeWidth,fill:eK};break;case"fillPath":t={d:this.opsToPath(e),stroke:eK,strokeWidth:0,fill:i.fill||eK};break;case"fillSketch":t=this.fillSketch(e,i)}t&&n.push(t)}return n}fillSketch(e,t){let i=t.fillWeight;return i<0&&(i=t.strokeWidth/2),{d:this.opsToPath(e),stroke:t.fill||eK,strokeWidth:i,fill:eK}}}class eQ{constructor(e,t){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new eG(t)}draw(e){let t=e.sets||[],i=e.options||this.getDefaultOptions(),n=this.ctx,o=e.options.fixedDecimalPlaceDigits;for(let r of t)switch(r.type){case"path":n.save(),n.strokeStyle="none"===i.stroke?"transparent":i.stroke,n.lineWidth=i.strokeWidth,i.strokeLineDash&&n.setLineDash(i.strokeLineDash),i.strokeLineDashOffset&&(n.lineDashOffset=i.strokeLineDashOffset),this._drawToContext(n,r,o),n.restore();break;case"fillPath":{n.save(),n.fillStyle=i.fill||"";let t="curve"===e.shape||"polygon"===e.shape||"path"===e.shape?"evenodd":"nonzero";this._drawToContext(n,r,o,t),n.restore();break}case"fillSketch":this.fillSketch(n,r,i)}}fillSketch(e,t,i){let n=i.fillWeight;n<0&&(n=i.strokeWidth/2),e.save(),i.fillLineDash&&e.setLineDash(i.fillLineDash),i.fillLineDashOffset&&(e.lineDashOffset=i.fillLineDashOffset),e.strokeStyle=i.fill||"",e.lineWidth=n,this._drawToContext(e,t,i.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,t,i,n="nonzero"){for(let n of(e.beginPath(),t.ops)){let t="number"==typeof i&&i>=0?n.data.map(e=>+e.toFixed(i)):n.data;switch(n.op){case"move":e.moveTo(t[0],t[1]);break;case"bcurveTo":e.bezierCurveTo(t[0],t[1],t[2],t[3],t[4],t[5]);break;case"lineTo":e.lineTo(t[0],t[1])}}"fillPath"===t.type?e.fill(n):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,t,i,n,o){let r=this.gen.line(e,t,i,n,o);return this.draw(r),r}rectangle(e,t,i,n,o){let r=this.gen.rectangle(e,t,i,n,o);return this.draw(r),r}ellipse(e,t,i,n,o){let r=this.gen.ellipse(e,t,i,n,o);return this.draw(r),r}circle(e,t,i,n){let o=this.gen.circle(e,t,i,n);return this.draw(o),o}linearPath(e,t){let i=this.gen.linearPath(e,t);return this.draw(i),i}polygon(e,t){let i=this.gen.polygon(e,t);return this.draw(i),i}arc(e,t,i,n,o,r,a=!1,s){let l=this.gen.arc(e,t,i,n,o,r,a,s);return this.draw(l),l}curve(e,t){let i=this.gen.curve(e,t);return this.draw(i),i}path(e,t){let i=this.gen.path(e,t);return this.draw(i),i}}class eJ{constructor(){this.gridManager=new ed,this._left=0,this._top=0,this._width=0,this._height=0,this._zoom=1,this._center=new ec.E9,this._shouldUpdate=!1,this.applyDeltaCenter=(e,t)=>{this.setCenter(this.centerX+e,this.centerY+t)};let e=document.createElement("canvas");this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.rc=new eQ(e)}get left(){return this._left}get top(){return this._top}get width(){return this._width}get height(){return this._height}get zoom(){return this._zoom}get centerX(){return this._center.x}get centerY(){return this._center.y}get center(){return this._center}get viewportX(){let{centerX:e,width:t,zoom:i}=this;return e-t/2/i}get viewportY(){let{centerY:e,height:t,zoom:i}=this;return e-t/2/i}get viewportMinXY(){let{centerX:e,centerY:t,width:i,height:n,zoom:o}=this;return{x:e-i/2/o,y:t-n/2/o}}get viewportMaxXY(){let{centerX:e,centerY:t,width:i,height:n,zoom:o}=this;return{x:e+i/2/o,y:t+n/2/o}}get viewportBounds(){let{viewportMinXY:e,viewportMaxXY:t}=this;return{...e,w:t.x-e.x,h:t.y-e.y}}toModelCoord(e,t){let{viewportX:i,viewportY:n,zoom:o}=this;return[i+e/o,n+t/o]}toViewCoord(e,t){let{viewportX:i,viewportY:n,zoom:o}=this;return[(e-i)*o,(t-n)*o]}setCenter(e,t){this._center.set(e,t),this._shouldUpdate=!0}setZoom(e,t){let i=this.zoom;t=t??this._center,this._zoom=(0,ec.uZ)(e,o,n);let r=this.zoom,a=this.center.subtract(t),s=t.add(a.scale(i/r));this.setCenter(s.x,s.y),this._shouldUpdate=!0}addElement(e){this.gridManager.add(e),this._shouldUpdate=!0}removeElement(e){this.gridManager.remove(e),this._shouldUpdate=!0}load(e){for(let t=0;t<e.length;t++)this.gridManager.add(e[t]);this._shouldUpdate=!0}refresh(){this._shouldUpdate=!0}attach(e){(0,eh.Np)(this._container,"Phasor surface is attached multiple times"),this._container=e,e.appendChild(this.canvas),this._resetSize(),this._loop()}onResize(){let e=this.width,t=this.height;this._resetSize(),this.setCenter(this.centerX-(e-this.width)/2,this.centerY-(t-this.height)/2),this._render(),this._shouldUpdate=!1}_resetSize(){let{canvas:e}=this,t=window.devicePixelRatio;e.style.width="100%",e.style.height="100%";let i=e.getBoundingClientRect();e.width=Math.ceil(i.width*t),e.height=Math.ceil(i.height*t),this._left=i.left,this._top=i.top,this._width=i.width,this._height=i.height,this._shouldUpdate=!0}_loop(){requestAnimationFrame(()=>{this._shouldUpdate&&this._render(),this._shouldUpdate=!1,this._loop()})}_render(){let{ctx:e,gridManager:t,viewportBounds:i,width:n,height:o,rc:r,zoom:a}=this,s=window.devicePixelRatio;e.clearRect(0,0,n*s,o*s),e.save(),e.setTransform(a*s,0,0,a*s,0,0);let l=t.search(i);for(let t of l){let n=t.x-i.x,o=t.y-i.y;e.save(),e.translate(n,o),B(t,i)&&t.display&&t.render(e,r),e.restore()}e.restore()}}var e1=i(37164);let e2="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";function e0(e,t,i){let n=i[0];if(null!=t&&e>=t)throw Error(e+" >= "+t);if(e.slice(-1)===n||t&&t.slice(-1)===n)throw Error("trailing zero");if(t){let o=0;for(;(e[o]||n)===t[o];)o++;if(o>0)return t.slice(0,o)+e0(e.slice(o),t.slice(o),i)}let o=e?i.indexOf(e[0]):0,r=null!=t?i.indexOf(t[0]):i.length;return r-o>1?i[Math.round(.5*(o+r))]:t&&t.length>1?t.slice(0,1):i[o]+e0(e.slice(1),null,i)}function e5(e){if(e.length!==e3(e[0]))throw Error("invalid integer part of order key: "+e)}function e3(e){if(e>="a"&&e<="z")return e.charCodeAt(0)-97+2;if(e>="A"&&e<="Z")return 90-e.charCodeAt(0)+2;throw Error("invalid order key head: "+e)}function e7(e){let t=e3(e[0]);if(t>e.length)throw Error("invalid order key: "+e);return e.slice(0,t)}function e4(e,t){if(e==="A"+t[0].repeat(26))throw Error("invalid order key: "+e);let i=e7(e),n=e.slice(i.length);if(n.slice(-1)===t[0])throw Error("invalid order key: "+e)}function e6(e,t){e5(e);let[i,...n]=e.split(""),o=!0;for(let e=n.length-1;o&&e>=0;e--){let i=t.indexOf(n[e])+1;i===t.length?n[e]=t[0]:(n[e]=t[i],o=!1)}if(!o)return i+n.join("");{if("Z"===i)return"a"+t[0];if("z"===i)return null;let e=String.fromCharCode(i.charCodeAt(0)+1);return e>"a"?n.push(t[0]):n.pop(),e+n.join("")}}function e8(e,t,i=e2){if(null!=e&&e4(e,i),null!=t&&e4(t,i),null!=e&&null!=t&&e>=t)throw Error(e+" >= "+t);if(null==e){if(null==t)return"a"+i[0];let e=e7(t),n=t.slice(e.length);if(e==="A"+i[0].repeat(26))return e+e0("",n,i);if(e<t)return e;let o=function(e,t){e5(e);let[i,...n]=e.split(""),o=!0;for(let e=n.length-1;o&&e>=0;e--){let i=t.indexOf(n[e])-1;-1===i?n[e]=t.slice(-1):(n[e]=t[i],o=!1)}if(!o)return i+n.join("");{if("a"===i)return"Z"+t.slice(-1);if("A"===i)return null;let e=String.fromCharCode(i.charCodeAt(0)-1);return e<"Z"?n.push(t.slice(-1)):n.pop(),e+n.join("")}}(e,i);if(null==o)throw Error("cannot decrement any more");return o}if(null==t){let t=e7(e),n=e.slice(t.length),o=e6(t,i);return null==o?t+e0(n,null,i):o}let n=e7(e),o=e.slice(n.length),r=e7(t),a=t.slice(r.length);if(n===r)return n+e0(o,a,i);let s=e6(n,i);if(null==s)throw Error("cannot increment any more");return s<t?s:n+e0(o,null,i)}function e9(e,t=1){let i=Math.sign(e),n=Math.abs(e),o=100*r;return n>o&&(e=o*i),t-e/100+-(Math.log10(Math.max(1,t))*i)*Math.min(1,n/20)}class te{constructor(e,t=e=>e){this._elements=new Map,this._bindings=new Map,this.indexes={min:"a0",max:"a0"},this._onYContainer=e=>{0!==e.changes.keys.size&&e.keysChanged.forEach(t=>{let i=e.changes.keys.get(t);if(!i){console.error("invalid event",e);return}if("add"===i.action){let e=this._yContainer.get(t),i=e.get("type"),n=en[i];(0,eh.kP)(n);let o=new n(e,this);o.computedValue=this._computedValue,o.mount(this._renderer),this._elements.set(o.id,o),o.index>this.indexes.max&&(this.indexes.max=o.index),this._updateBindings(o)}else if("update"===i.action)console.error("update event on yElements is not supported",e);else if("delete"===i.action){let e=this._elements.get(t);(0,eh.kP)(e),e.unmount(),this._elements.delete(t),e.index===this.indexes.min&&(this.indexes.min=e8(e.index,null))}})},this._renderer=new eJ,this._yContainer=e,this._computedValue=t,this._syncFromExistingContainer(),this._yContainer.observe(this._onYContainer)}get viewport(){return this._renderer}_addBinding(e,t){this._bindings.has(e)||this._bindings.set(e,new Set),this._bindings.get(e)?.add(t)}_updateBindings(e){e instanceof O&&(e.startElement&&(this._addBinding(e.startElement.id,e.id),this._addBinding(e.id,e.startElement.id)),e.endElement&&(this._addBinding(e.endElement.id,e.id),this._addBinding(e.id,e.endElement.id)))}_syncFromExistingContainer(){this._transact(()=>{this._yContainer.forEach(e=>{let t=e.get("type"),i=en[t];(0,eh.kP)(i);let n=new i(e,this);n.computedValue=this._computedValue,n.mount(this._renderer),this._elements.set(n.id,n),n.index>this.indexes.max?this.indexes.max=n.index:n.index<this.indexes.min&&(this.indexes.min=n.index),this._updateBindings(n)})})}_transact(e){let t=this._yContainer.doc;t.transact(e,t.clientID)}refresh(){this._renderer.refresh()}updateIndexes(e,t,i){this._transact(()=>{let n;let o=0,r=t.length;for(;o<r;o++){n=e[o];let i=this._yContainer.get(t[o].id),r=i.get("index");r!==n&&i.set("index",n)}i(e)})}attach(e){this._renderer.attach(e)}onResize(){this._renderer.onResize()}getElementsBound(){return M([...this._elements.values()])}addElement(e,t){let i=(0,e1.x0)(10),n=new Y.Map,o=eo[e],r={...o,...t,id:i,index:e8(this.indexes.max,null),seed:ew()};return this._transact(()=>{for(let[e,t]of Object.entries(r))"text"!==e||t instanceof Y.Text?n.set(e,t):n.set(e,new Y.Text(t));this._yContainer.set(i,n)}),i}updateElement(e,t){this._transact(()=>{let i=this._elements.get(e);(0,eh.kP)(i),i.applyUpdate(t)})}setElementBound(e,t){this.updateElement(e,{xywh:w(t.x,t.y,t.w,t.h)})}removeElement(e){this._transact(()=>{this._yContainer.delete(e)})}hasElement(e){return this._yContainer.has(e)}toModelCoord(e,t){return this._renderer.toModelCoord(e,t)}toViewCoord(e,t){return this._renderer.toViewCoord(e,t)}pickById(e){return this._elements.get(e)}pickByPoint(e,t,i){let n=this._renderer.gridManager.search({x:e-1,y:t-1,w:2,h:2}),o=n.filter(n=>n.hitTest(e,t,i));return o}pickTop(e,t){let i=this.pickByPoint(e,t);return i[i.length-1]??null}pickByBound(e){let t=this._renderer.gridManager.search(e),i=t.filter(t=>S(e,t)||B(e,t));return i}getSortedElementsWithViewportBounds(){return this.pickByBound(this.viewport.viewportBounds).sort(el)}getBindingElements(e){let t=this._bindings.get(e);return t?.size?[...t.values()].map(e=>this.pickById(e)).filter(e=>!!e):[]}dispose(){this._yContainer.unobserve(this._onYContainer)}initDefaultGestureHandler(){let{_renderer:e}=this;e.canvas.addEventListener("wheel",t=>{if(t.preventDefault(),t.ctrlKey){let i=e9(t.deltaY);e.setZoom(i)}else{let i=t.deltaX/e.zoom,n=t.deltaY/e.zoom;e.setCenter(e.centerX+i,e.centerY+n)}})}getElements(){return[...this._elements.values()]}}},16025:function(e,t,i){"use strict";i.d(t,{$:function(){return r}});var n=i(93311),o=i(47514);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let r=(0,o.XM)(class extends o.Xe{constructor(e){var t;if(super(e),e.type!==o.pX.ATTRIBUTE||"class"!==e.name||(null===(t=e.strings)||void 0===t?void 0:t.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(e){return" "+Object.keys(e).filter(t=>e[t]).join(" ")+" "}update(e,[t]){var i,o;if(void 0===this.it){for(let n in this.it=new Set,void 0!==e.strings&&(this.nt=new Set(e.strings.join(" ").split(/\s/).filter(e=>""!==e))),t)!t[n]||(null===(i=this.nt)||void 0===i?void 0:i.has(n))||this.it.add(n);return this.render(t)}let r=e.element.classList;for(let e in this.it.forEach(e=>{e in t||(r.remove(e),this.it.delete(e))}),t){let i=!!t[e];i===this.it.has(e)||(null===(o=this.nt)||void 0===o?void 0:o.has(e))||(i?(r.add(e),this.it.add(e)):(r.remove(e),this.it.delete(e)))}return n.Jb}})}}]);
//# sourceMappingURL=280.003a722816badffe.js.map